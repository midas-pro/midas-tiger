
/*
Project : Cryptotrades
FileName :  viewModel.js
Author : Indiefire
File Created : 21/07/2021
CopyRights : Indiefire
Purpose : This is the file which used to define view schema that will store and reterive item view information.
*/

var mongoose = require('mongoose');
var mongoosePaginate = require('mongoose-paginate-v2');
var uniqueValidator = require('mongoose-unique-validator');
var config = require('./../../../helper/config')
const Schema = mongoose.Schema;

var playlistViewSchema = mongoose.Schema({
    playlist_id: { type: Schema.Types.ObjectId, ref: 'playlists' },
    user_id: { type: Schema.Types.ObjectId, ref: 'users' },
    created_date: {
        type: Date,
        default: Date.now
    },
});

playlistViewSchema.plugin(uniqueValidator);
playlistViewSchema.plugin(mongoosePaginate);

module.exports = mongoose.model('playlist_views', playlistViewSchema,config.db.prefix+'playlist_views');