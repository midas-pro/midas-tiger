/*
Project : Cryptotrades
FileName : playlistModel.js
Author : Indiefire
File Created : 21/07/2021
CopyRights : Indiefire
Purpose : This is the file which used to define playlist schema that will communicate and process playlist information with mongodb through mongoose ODM.
*/

var mongoose = require('mongoose');
var mongoosePaginate = require('mongoose-paginate-v2');
var uniqueValidator = require('mongoose-unique-validator');
var config = require('../../../helper/config')
const Schema = mongoose.Schema;
// Setup schema
var playItemSchema = new Schema({
    item_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'items'
    },
    edition: {
        type: String,
    },
    user_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'users'
    }
})

var manageUserSchema = new Schema({
    user_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "users"
    },
    active: {
        type: Boolean,
        default: false
    }
})

var playlistSchema = mongoose.Schema({
    name: {
        type: String,
        // minlength: [3, 'Name must be 3 characters or more'],
        // maxlength: [255, "Name can't exceed 255 characters"],
        // unique: [ true , 'Name already exists. Please try a different name'],
        // required: [ true , 'Name is required'], 
    },   
    description: {
        type: String,
        maxlength: [1000, "Description can't exceed 1000 characters"]
    },
    image: String,
    item_count:{
        type: Number,
        default:0
    },
    view: {
        type: String,
        default: 'everyone'
    },
    selected_users: [
        {
            type: mongoose.Schema.Types.ObjectId,
            ref: 'users'
        }
    ],
    is_private: {
        type: Boolean,
        default: false
    },
    items: [
        playItemSchema
    ],
    
    daily_play: [
        {
            date: {
                type: String,
            },
            count: {
                type: Number,
            }
        }
    ],
    manage_users: [
        manageUserSchema
    ],
    author_id: { type: Schema.Types.ObjectId, ref: 'users' },
    create_date: {
        type: Date,
        default: Date.now
    },
    category_id : String,
});

playlistSchema.plugin(uniqueValidator);
playlistSchema.plugin(mongoosePaginate);

module.exports = mongoose.model('playlist', playlistSchema,config.db.prefix+'playlist');