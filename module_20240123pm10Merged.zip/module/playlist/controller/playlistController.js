/*
Project : Cryptotrades
FileName : playlistController.js
Author : Indiefire
File Created : 21/07/2021
CopyRights : Indiefire
Purpose : This is the file which used to define all playlist related api function.
*/

var playlists = require("../model/playlistModel");
var playerModel = require("../../player/model/playerModel");
var followers = require("../../user/model/followerModel");
var blockModel = require("../../user/model/blockModel");
var muteModel = require("../../user/model/muteModel");
var items = require("../../item/model/itemModel");
const followerModel = require("../../user/model/followerModel");
const itemloveModel = require("../../item/model/itemloveModel");

var userController = require("../../user/controller/userController");
var validator = require("validator");
const { validationResult } = require("express-validator");
var cp = require("child_process");
var Web3 = require("web3");
const config = require("../../../helper/config");
var fs = require("fs");

const {
  NOTIFICATION_TYPES,
  NOTIFICATION_FILTERS,
} = require("../../helper/notification_config");
const notificationModel = require("../../notification/model/notificationModel");
const userModel = require("../../user/model/userModel");
const { getDateStr } = require("../../helper/helpers");
const { getErrLine } = require("../../helper/helpers");
const playlistViewModel = require("../model/playlistViewModel");
/*
 * This is the function which used to add playlist in database
 */
exports.add = async function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded.user_id;
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    res.json({
      status: false,
      message: "Request failed",
      errors: errors.array(),
    });
    return;
  }

  try {
    var symbol = req.body.name.replace(" ", "_");
    var playlist = new playlists(req.body);
    playlist.author_id = user_id;

    if(req.body.manage_users && req.body.manage_users.length > 0) {
      playlist.manage_users = req.body.manage_users.map(d => ({
        user_id: d
      }))
    }

    await playlist.save();
    // create notification

    let notif_users = [];

    var manage_users = req.body.manage_users;
    if (manage_users && manage_users.length > 0) {
      await Promise.all(
        manage_users.map(async (d) => {
          let new_notification = new notificationModel({
            type: NOTIFICATION_TYPES.PLAYLIST_JOIN,
            filter: NOTIFICATION_FILTERS.NEW_PLAYLIST,
            message: "Wants to add you to their playlist",
            from_id: user_id,
            to_id: d.user_id,
            item_id: playlist._id,
          });
          await new_notification.save();
          notif_users.push(d.user_id?._id || d.user_id);
        })
      );
      res.json({
        status: true,
        message: "Created successfully",
        result: {
          notif_users
        }
      });
    } else {
      res.json({
        status: true,
        message: "Created successfully",
      });
    }
  } catch (error) {
    console.log(error);
    res.json({
      status: false,
      message: "Something went wrong",
    });
  }
};

/*
 * This is the function which used to update playlist in database
 */
exports.update = async function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded.user_id;
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    res.json({
      status: false,
      message: "Request failed",
      errors: errors.array(),
    });
    return;
  }
  try {
    let playlist = await playlists.findById(req.body._id);
    if (playlist) {
      let new_added_manage_users = [];
      if (req.body.manage_users && req.body.manage_users.length > 0) {
        req.body.manage_users.map((d) => {
          if (!playlist.manage_users.some((p) => p.user_id == d || p.user_id == d._id)) {
            new_added_manage_users.push(d);
          }
        });
        playlist.manage_users = req.body.manage_users.map(d => (
          { user_id: d }
        ))
      }

      let notify_users = [];

      

      await playlists.findByIdAndUpdate(req.body._id, req.body);
      // create notification
      if (new_added_manage_users.length > 0) {
        notify_users = [...notify_users, ...new_added_manage_users.map(d => d._id)];
        await Promise.all(
          new_added_manage_users.map(async (d) => {
            let new_notification = new notificationModel({
              type: NOTIFICATION_TYPES.PLAYLIST_JOIN,
              filter: NOTIFICATION_FILTERS.NEW_PLAYLIST,
              message: "Wants to add you to their playlist",
              from_id: user_id,
              to_id: d,
              item_id: playlist._id,
            });
            await new_notification.save();
          })
        );
      }

      // NAME CHANGE NOTIFICATION
      if (playlist.name != req.body.name) {
        // FIND USERS WHO FOLLOWS ME AND HAS THE SETTING ENABLED NOTIFICATION SETTING
        let _followers = (await followers.find({ star_id: user_id })).map(
          (d) => d.user_id
        );
        let _users = (
          await userModel.find({
            _id: { $in: _followers },
            "notif_playlists.is_changes": true,
          })
        ).map((d) => d._id);
        if (_users && _users.length > 0) {
          notify_users = [...notify_users, ..._users];
          console.log(150);
          console.log("users", _users);
          await Promise.all(
            _users.map(async (d) => {
              let new_notification = new notificationModel({
                type: NOTIFICATION_TYPES.PLAYLIST_CHANGE,
                filter: NOTIFICATION_FILTERS.NEW_PLAYLIST,
                message: `Changed their playlist name <br/> Playlist name to ${req.body.name}`,
                from_id: user_id,
                to_id: d,
                item_id: playlist._id,
              });
              await new_notification.save();
              console.log(d);
            })
          );
        }
      }

      res.json({
        status: true,
        message: "Updated successfully",
        result: {
          notify_users,
        },
      });
    } else {
      res.json({
        status: false,
        message: "Not found playlist",
      });
    }
  } catch (error) {
    console.log(error);
    res.json({
      status: false,
      message: "Something went wrong",
    });
  }
};

/*
 * This is the function which used to delete playlist in database
 */
exports.delete = function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded.user_id;
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    res.json({
      status: false,
      message: "Request failed",
      errors: errors.array(),
    });
    return;
  }
  playlists.findOne(
    { _id: req.body.playlist_id },
    async function (err, playlist) {
      if (err || !playlist) {
        res.json({
          status: false,
          message: "Playlist not found",
          errors: err,
        });
        return;
      }

      if (
        playlist.manage_users?.some((d) => d.user_id == user_id) ||
        playlist.author_id == user_id
      ) {
        if (playlist.items.length > 0) {
          res.json({
            status: false,
            message: "Playlist contains the items ",
          });
        } else {
          await playlists.findByIdAndDelete(req.body.playlist_id);
          res.json({
            status: true,
            message: "Delete successfully",
          });
        }
      } else {
        res.json({
          status: false,
          message: "You can't delete this playlist",
        });
      }
    }
  );
};

/**
 *  This is the function which used to view playlist
 */
exports.view = function (req, res) {
  console.log(getErrLine().str, "apistart");
  playlists
    .findOne({ _id: req.query.playlist_id })
    .exec(function (err, playlist) {
      if (err) {
        res.json({
          status: false,
          message: "Request failed",
          errors: "Playlist not found",
        });
        return;
      }
      if (!playlist) {
        res.json({
          status: false,
          message: "Request failed",
          errors: "Playlist not found",
        });
        return;
      }
      res.json({
        status: true,
        message: "Playlist info retrieved successfully",
        result: playlist,
      });
    });
};

/**
 * This is the function which used to list playlist with filters
 */
exports.list = function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded?.user_id;
  var keyword = req.query.keyword ? req.query.keyword : "";
  keyword = keyword.replace("+", " ").trim();
  var page = req.query.page ? req.query.page : "1";
  var limit = req.query.limit ? req.query.limit : "10";
  var show = req.query.show || "all";
  var type = req.query.type || "all";
  var sortby = req.query.sortby || "new";

  var query = playlists.find();
  var offset = page == "1" ? 0 : parseInt(page - 1) * limit;
  console.log(keyword);
  if (keyword != "") {
    console.log(keyword);
    let search = {
      $or: [
        { name: { $regex: new RegExp(keyword, "ig") } },
        { description: { $regex: new RegExp(keyword, "ig") } },
      ],
    };
    query = query.find(search);
  }

  query = query.find({
    $or: [
      { selected_users: { $elemMatch: { $eq: user_id } } },
      { "manage_users.user_id": user_id },
      { "manage_users.active": true },
      { author_id: user_id },
    ],
  });

  switch (show) {
    case "all":
      break;
    case "my":
      query = query.find({ author_id: user_id });
      break;
    case "other":
      query = query.find({ author_id: { $ne: user_id } });
      break;
    default:
      break;
  }

  switch (type) {
    case "all":
      break;
    case "public":
      query = query.find({ view: "everyone" });
      break;
    case "private":
      query = query.find({ view: "me" });
      break;
    case "shared":
      query = query.find({ view: "shared" });
      break;
    default:
      break;
  }
  switch (sortby) {
    case "new":
      query = query.sort({ create_date: -1 });
      break;
    case "old":
      query = query.sort({ create_date: 1 });
      break;
    case "me":
      // work later
      break;
    case "az":
      query = query.sort({ name: -1 });
      break;
    case "za":
      query = query.sort({ name: 1 });
    default:
      query = query.sort({ create_date: -1 });
      break;
  }

  query = query.populate({
    path: "items.item_id",
    model: items,
    populate: [
      {
        path: "category_id",
        model: "category",
      },
      {
        path: "author_id",
        model: "users",
        select:
          "username email first_name last_name profile_image profile_cover metamask_info password status is_idverified create_date",
      },
    ],
  });

  query = query.populate({
    path: "author_id",
    model: "users",
    select:
      "_id username first_name last_name profile_image metamask_info is_idverified",
  });
  query = query.populate({
    path: "selected_users",
    model: "users",
    select:
      "_id username first_name last_name profile_image metamask_info is_idverified",
  });
  query = query.populate({
    path: "manage_users.user_id",
    model: "users",
    select:
      "_id username first_name last_name profile_image metamask_info is_idverified",
  });

  var options = {
    page: page,
    offset: offset,
    limit: limit,
  };
  playlists.paginate(query, options).then(async function (result) {
    const updatedDocs = await Promise.all(
      result.docs.map(async (d) => {
        // console.log(playLists.some(pl => pl.item_id == d._doc._id && pl.user_id == user_id))
        // check whether this is exited in up to next
        const up_to_next = await playerModel.findOne({
          playlist_id: d._doc._id,
          user_id,
        });

        // check is follower, mute, block
        var _db_follower = await followers.findOne({
          star_id: d._doc?.author_id?._id,
          user_id: user_id,
        });
        var _db_block = await blockModel.findOne({
          block_user_id: d._doc?.author_id?._id,
          user_id: user_id,
        });
        var _db_mute = await muteModel.findOne({
          mute_user_id: d._doc?.author_id?._id,
          user_id: user_id,
        });

        return {
          ...d._doc, // copy all the existing fields
          isUptoNext: up_to_next ? true : false,
          isFollow: _db_follower ? true : false,
          isBlock: _db_block ? true : false,
          isMute: _db_mute ? true : false,
        };
      })
    );

    const updatedResult = { ...result, docs: updatedDocs };

    res.json({
      status: true,
      message: "Playlist retrieved successfully",
      data: updatedResult,
    });
  });
};

/**
 * This is the function which used to list all items for admin
 */
exports.getAdminList = function (req, res) {
  console.log(getErrLine().str, "apistart");
  var keyword = req.query.keyword ? req.query.keyword : "";
  keyword = keyword.replace("+", " ");
  var page = req.query.page ? req.query.page : "1";
  var limit = req.query.limit ? req.query.limit : "10";
  var query = playlists.find();
  var offset = page == "1" ? 0 : parseInt(page - 1) * 10;
  if (keyword != "") {
    search = {
      $or: [
        {
          name: {
            $regex: new RegExp(keyword, "ig"),
          },
        },
        {
          description: {
            $regex: new RegExp(keyword, "ig"),
          },
        },
      ],
    };
    query = query.or(search);
  }
  query = query.sort("-create_date");
  var options = {
    select: "name description items is_private item_count author_id image",
    page: page,
    offset: offset,
    limit: limit,
  };
  playlists.paginate(query, options).then(function (result) {
    res.json({
      status: true,
      message: "Playlist retrieved successfully",
      data: result,
    });
  });
};

// add item to playlist

exports.add_item_to_playlist = async function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded.user_id;
  var item_id = req.body.item_id;
  var edition = req.body.edition;
  var playlist_id = req.body.playlist_id;
  try {
    let playlist = await playlists.findById(playlist_id);
    if (playlist) {
      if (
        playlist.manage_users?.some((d) => d.user_id == user_id) ||
        playlist.author_id == user_id
      ) {
        let lists = playlist.items;
        if (lists.find((d) => d.item_id == item_id && d.edition == edition)) {
          res.json({
            status: false,
            message: "Already added to this playlist",
          });
        } else {
          let original_item = await items.findById(item_id);
          if (original_item) {
            if (user_id == original_item.author_id) {
            } else {
              if (edition == "free") {
              } else {
                let query = {
                  original_id: item_id,
                  current_owner: user_id,
                };
                switch (edition) {
                  case "standard":
                    query.es_enabled = true;
                    break;
                  case "collective":
                    query.ec_enabled = true;
                    break;
                  case "limited":
                    query.el_enabled = true;
                    break;
                  default:
                    break;
                }
                let bought_item = await items.findOne(query);
                if (!bought_item) {
                  res.json({
                    status: false,
                    message: "You didn't purchase this item",
                  });
                  return;
                }
              }
            }
            var newList = {
              item_id,
              edition,
              user_id,
            };
            lists.push(newList);
            await playlist.save();

            // CREATE NOTIFICATION FOR UPDATE
            let notify_users = [];
            let _followers = (await followers.find({ star_id: user_id })).map(
              (d) => d.user_id
            );
            let _users = (
              await userModel.find({
                _id: { $in: _followers },
                "notif_playlists.is_updates": true,
              })
            ).map((d) => d._id);
            if (_users && _users.length > 0) {
              notify_users = [...notify_users, ..._users];
              await Promise.all(
                _users.map(async (d) => {
                  let new_notification = new notificationModel({
                    type: NOTIFICATION_TYPES.PLAYLIST_UPDATE,
                    filter: NOTIFICATION_FILTERS.NEW_PLAYLIST,
                    message: `Updated their playlist`,
                    from_id: user_id,
                    to_id: d,
                    item_id: playlist._id,
                  });
                  await new_notification.save();
                })
              );
            }

            res.json({
              status: true,
              message: "Saved successfully",
              result: {
                notify_users,
              },
            });
          } else {
            res.json({
              status: false,
              message: "No exists",
            });
          }
        }
      } else {
        res.json({
          status: false,
          message: "You can't add item to this playlist",
        });
      }
    } else {
      res.json({
        status: false,
        message: "No playlist",
      });
    }
  } catch (error) {
    console.log(error);
    res.json({
      status: false,
      message: "Something went wrong",
    });
  }
};

// add playlist to playlist
exports.add_playlist_to_playlist = async function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded.user_id;
  var playlist_id = req.body.playlist_id;
  var playlist_to_id = req.body.playlist_to_id;
  try {
    let playlist = await playlists.findById(playlist_id);
    let playlistTo = await playlists.findById(playlist_to_id);
    if (
      playlistTo.manage_users?.some((d) => d.user_id == user_id) ||
      playlistTo.author_id == user_id
    ) {
      if (playlist) {
        let _items = playlist.items;
        if (_items && _items.length > 0) {
          let _new_up_next_arr = [];
          await Promise.all(
            _items.map(async (d) => {
              let _item_id = d.item_id;
              let _edition = d.edition;
              let item = await items.findById(_item_id);
              if (item) {
                // check item is belongs to you or else
                if (item.author_id == user_id) {
                  // check up next already contains the item edition
                } else {
                  // check whether you purchased the item edition
                  if (_edition == "free") {
                  } else {
                    let query = {
                      original_id: item_id,
                      current_owner: user_id,
                    };
                    switch (_edition) {
                      case "standard":
                        query.es_enabled = true;
                        break;
                      case "collective":
                        query.ec_enabled = true;
                        break;
                      case "limited":
                        query.el_enabled = true;
                        break;
                      default:
                        break;
                    }
                    let bought_item = await items.findOne(query);
                    if (!bought_item) {
                      return;
                    }
                  }
                }
                // check item edition is already added or not
                if (
                  playlistTo.items.find(
                    (up) => up.item_id == _item_id && edition == _edition
                  )
                ) {
                  return;
                }
                let new_up_next = {
                  item_id: _item_id,
                  edition: _edition,
                  playlist_id,
                  user_id,
                };
                console.log("new_up_next");
                console.log(new_up_next);
                playlistTo.items.push(new_up_next);
              }
            })
          );
          await playlistTo.save();

          // CREATE NOTIFICATION FOR UPDATE
          let notify_users = [];
          let _followers = (await followers.find({ star_id: user_id })).map(
            (d) => d.user_id
          );
          let _users = (
            await userModel.find({
              _id: { $in: _followers },
              "notif_playlists.is_updates": true,
            })
          ).map((d) => d._id);
          if (_users && _users.length > 0) {
            notify_users = [...notify_users, ..._users];
            await Promise.all(
              _users.map(async (d) => {
                let new_notification = new notificationModel({
                  type: NOTIFICATION_TYPES.PLAYLIST_UPDATE,
                  filter: NOTIFICATION_FILTERS.NEW_PLAYLIST,
                  message: `Updated their playlist`,
                  from_id: user_id,
                  to_id: d,
                  item_id: playlist._id,
                });
                await new_notification.save();
              })
            );
          }

          res.json({
            status: true,
            message: "Added successfully",
            result: {
              notify_users,
            },
          });
        } else {
          res.json({
            status: false,
            message: "Playlist doesn't contain any item.",
          });
        }
      } else {
        res.json({
          status: false,
          message: "No playlist",
        });
      }
    } else {
      res.json({
        status: false,
        message: "You can't  do this",
      });
    }
  } catch (error) {
    console.log(error);
    res.json({
      status: false,
      message: "Something went wrong",
    });
  }
};

// get info for playlist
exports.get_info_for_playlist = async function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded.user_id;
  var playlist_id = req.query.playlist_id;

  try {
    var playlist = await playlists.findById(playlist_id);
    if (playlist) {
      var up_next = await playerModel.findOne({ playlist_id });

      var data = {
        isUptoNext: up_next ? true : false,
      };
      if (playlist.author_id != user_id) {
        var _follower = await followerModel.findOne({
          star_id: playlist.author_id,
          user_id,
        });
        var _block = await blockModel.findOne({
          block_user_id: playlist.author_id,
          user_id,
        });
        var _mute = await muteModel.findOne({
          mute_user_id: playlist.author_id,
          user_id,
        });
        (data.isFollow = _follower ? true : false),
          (data.isBlock = _block ? true : false);
        data.isMute = _mute ? true : false;
      }

      res.json({
        status: true,
        message: "Retrived successfully",
        result: data,
      });
    } else {
      res.json({
        status: false,
        message: "No list",
      });
    }
  } catch (error) {
    console.log(error);
    res.json({
      status: false,
      message: "Something went wrong",
    });
  }
};


// accept_join_playlist
exports.accept_join_playlist = async function(req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded.user_id;
  var _id = req.body._id;
  var status = req.body.status;
  try {
    var playlist = await playlists.findById(_id);
    if(playlist) {
      if(playlist.manage_users?.some(d => d.user_id == user_id)) {
        let index = playlist.manage_users?.findIndex(p => p.user_id == user_id);
        if(index < 0) {
          res.json({
            status: false,
            message: "You are not in manage user list"
          })
        } else {
          if(status) {
            playlist.manage_users[index].active = true
          } else {
            playlist.manage_users = playlist.manage_users.filter(p => p.user_id != user_id)
          }
          await playlist.save();
          res.json({
            status: true,
            message: "Saved successfully"
          });
        } 
      } else {
        res.json({
          status: false,
          message: "You are not in manage user list"
        })
      }
    } else {
      res.json({
        status: false,
        message: "Playlist does not exist"
      })
    }
  } catch (error) {
    console.log(error)
    res.json({
      status: false,
      message: "Something went wrong"
    })
  }
}

async function trendingPlaylists(req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded.user_id;
  var show = req.query.show || "all";
  var type = req.query.type || "all";
  var sortby = req.query.sortby || "new";
  var type = req.query.type,
    rootCat = req.query.rootCat,
    cat1 = req.query.cat1,
    cat2 = req.query.cat2,
    cat3 = req.query.cat3,
    cat4 = req.query.cat4,
    keyword = req.query.keyword || "",
    page = req.query.page || 1,
    limit = req.query.limit || 15,
    _filter = req.query.filter,
    part = req.query.part,
    fFavorites = req.query.fFavorites,
    filterShow = req.query.filterShow,
    filterFrom = req.query.filterFrom,
    filterTime = req.query.filterTime,
    filterTimeFrom = req.query.filterTimeFrom,
    filterTimeTo = req.query.filterTimeTo,
    itemKind = req.query.itemKind,
    itemType = req.query.itemType,
    tfilterFrom = req.query.tfilterFrom,
    tfilterTime = req.query.tfilterTime,
    tfilterTimeFrom = req.query.tfilterTimeFrom,
    tfilterTimeTo = req.query.tfilterTimeTo,
    TrendingOrderBy = req.query.TrendingOrderBy;
   try {
    var pipeline = [];
    pipeline.push({
      $sort: { create_date: -1 },
    });

    let matchClause = {}; // for search

    if (_filter == "For you") {
      let followings = (await followers.find({ user_id })).map(
        (d) => d.star_id
      );
      console.log(followings);
      let query = {
        author_id: { $in: followings },
      };
      matchClause = {
        $and: [matchClause, query],
      };
    }

    if (keyword != "") {
      let query = {
        $or: [
          { name: { $regex: new RegExp(keyword, "ig") } },
          { description: { $regex: new RegExp(keyword, "ig") } },
        ],
      };
      matchClause = {
        $and: [matchClause, query],
      };
    }

    //

    switch (tfilterFrom) {
      case "Everybody":
        // Do nothing, get all posts
        break;
      case "following":
        let _followings = (await followers.find({ user_id })).map((d) =>
          ObjectID(d.star_id)
        );
        // pipeline.push({ $match: { author_id: { $in: _followings } } });
        matchClause.author_id = { $in: _followings };
        break;
      default:
        break;
    }



    if(part == 'main') {
      let playlist_views = (await playlistViewModel.find({ user_id })).map(
        (d) => d.playlist_id
      );

      switch (filterShow) {
        case "Everything":
          break;
        case "seen":
          matchClause = {
            $and: [
              matchClause,
              { _id: { $in: playlist_views } }
            ]
          }
          break;
        case "notseen":
          matchClause = {
            $and: [
              matchClause,
              { _id: { $nin: playlist_views } }
            ]
          }
          break;
        default:
          break;
      }
      let user = await userModel.findById(user_id);
      switch (filterFrom) {
        case "Everybody":
          break;
        case "following":
          let _followings = (await followers.find({ user_id })).map(
            (d) => d.star_id
          );
          matchClause = {
            $and: [
              matchClause,
              {author_id: { $in: _followings }}
            ]
          }
          break;
        default:
          break;
      }

      switch (filterTime) {
        case "anytime":
          break;
        case "today":
          var date = new Date();
          var startOfToday = new Date(
            date.getFullYear(),
            date.getMonth(),
            date.getDate()
          );
          var endOfToday = new Date(
            startOfToday.getTime() + 24 * 60 * 60 * 1000 - 1
          ); // End of day is one millisecond before start of next day
          matchClause = {
            $and: [
              matchClause,
              {create_date: { $gte: startOfToday, $lt: endOfToday }},
            ]
          }
          break;
        case "thisweek":
          matchClause = {
            $and: [
              matchClause,
              {
                create_date: {
                  $gte: new Date(new Date() - 7 * 24 * 60 * 60 * 1000),
                }
              }
            ]
          }
          break;
        case "thismonth":
          var date = new Date();
          var monthStart = new Date(date.getFullYear(), date.getMonth(), 1); // Get first day of current month
          var monthEnd = new Date(date.getFullYear(), date.getMonth() + 1, 0); // Get last day of current month
          matchClause = {
            $and: [
              matchClause,
              {create_date: { $gte: monthStart, $lte: monthEnd }},
            ]
          }
          break;
        case "range":
          var startDate = new Date(filterTimeFrom);
          var endDate = new Date(filterTimeTo);
          matchClause = {
            $and: [
              matchClause,
              {create_date: { $gte: startDate, $lte: endDate }},
            ]
          }
          break;
        default:
          break;
      }

    }


    pipeline.push({
      $match: matchClause,
    });



    var filter = "play";


    switch (tfilterTime) {
      case "now":
        var date = new Date();
        var datestr = getDateStr(date);
        pipeline.push(
          {
            $addFields: {
              _nowFields: {
                $filter: {
                  input: `$daily_${filter}`,
                  as: "trend",
                  cond: {
                    $eq: ["$$trend.date", datestr],
                  },
                },
              },
            },
          },
          {
            $addFields: {
              nowSum: {
                $sum: {
                  $filter: {
                    input: "$_nowFields.count",
                    cond: [],
                  },
                },
              },
            },
          },
          {
            $sort: { nowSum: -1 },
          }
        );
        break;
      case "yesterday":
        var date = new Date();
        date.setDate(date.getDate() - 1);
        var datestr = getDateStr(date);
        pipeline.push(
          {
            $addFields: {
              _yesterdayFields: {
                $filter: {
                  input: `$daily_${filter}`,
                  as: "trend",
                  cond: {
                    $eq: ["$$trend.date", datestr],
                  },
                },
              },
            },
          },
          {
            $addFields: {
              yesterdaySum: {
                $sum: {
                  $filter: {
                    input: "$_yesterdayFields.count",
                    cond: [],
                  },
                },
              },
            },
          },
          {
            $sort: { yesterdaySum: -1 },
          }
        );
        break;
      case "thisweek":
        var date = new Date();
        var weekAgo = new Date(new Date(new Date() - 7 * 24 * 60 * 60 * 1000));
        var datestr = getDateStr(weekAgo);
        console.log(datestr);
        pipeline.push(
          {
            $addFields: {
              _thisweekFields: {
                $filter: {
                  input: `$daily_${filter}`,
                  as: "trend",
                  cond: {
                    $gte: ["$$trend.date", datestr],
                  },
                },
              },
            },
          },
          {
            $addFields: {
              weeklySum: {
                $sum: {
                  $filter: {
                    input: "$_thisweekFields.count",
                    cond: [],
                  },
                },
              },
            },
          },
          {
            $sort: { weeklySum: -1 },
          }
        );
        break;
      case "thismonth":
        var date = new Date();
        var monthAgo = new Date(
          date.getFullYear(),
          date.getMonth() - 1,
          date.getDate()
        ); // Get date 1 month ago
        var datestr = getDateStr(monthAgo);
        pipeline.push(
          {
            $addFields: {
              _thismonthFields: {
                $filter: {
                  input: `$daily_${filter}`,
                  as: "trend",
                  cond: {
                    $gte: ["$$trend.date", datestr],
                  },
                },
              },
            },
          },
          {
            $addFields: {
              monthlySum: {
                $sum: {
                  $filter: {
                    input: "$_thismonthFields.count",
                    cond: [],
                  },
                },
              },
            },
          },
          {
            $sort: { monthlySum: -1 },
          }
        );
        break;
      case "range":
        var startDate = new Date(tfilterTimeFrom);
        var endDate = new Date(tfilterTimeTo);
        var datestr1 = getDateStr(startDate);
        var datestr2 = getDateStr(endDate);

        pipeline.push(
          {
            $addFields: {
              _rangeFields: {
                $filter: {
                  input: `$daily_${filter}`,
                  as: "trend",
                  cond: {
                    $gte: ["$$trend.date", datestr1],
                    $lt: ["$$trend.date", datestr2],
                  },
                },
              },
            },
          },
          {
            $addFields: {
              rangeSum: {
                $sum: {
                  $filter: {
                    input: "$_rangeFields.count",
                    cond: [],
                  },
                },
              },
            },
          },
          {
            $sort: { rangeSum: -1 },
          }
        );
        break;
      default:
        break;
    }
    

    var offset = page == "1" ? 0 : parseInt(page - 1) * limit;
    const countPipeline = [...pipeline, { $count: "count" }];
    pipeline.push(
      {
        $skip: offset,
      },
      {
        $limit: Number(limit),
      }
    );
    const [docs, countResult] = await Promise.all([
      playlists.aggregate(pipeline).exec(),
      playlists.aggregate(countPipeline).exec(),
    ]);
    const totalDocs = countResult[0] ? countResult[0].count : 0;
    const currentPage = parseInt(req.query.page) || 1;
    const _limit = parseInt(req.query.limit) || 10;
    const totalPages = Math.ceil(totalDocs / limit);
    const hasNextPage = currentPage < totalPages;
    const nextPage = hasNextPage ? currentPage + 1 : null;


    const updatedDocs = await Promise.all(
      docs.map(async (d) => {
        const up_to_next = await playerModel.findOne({
          playlist_id: d._id,
          user_id,
        });

        // check is follower, mute, block
        var _db_follower = await followers.findOne({
          star_id: d?.author_id?._id,
          user_id: user_id,
        });
        var _db_block = await blockModel.findOne({
          block_user_id: d?.author_id?._id,
          user_id: user_id,
        });
        var _db_mute = await muteModel.findOne({
          mute_user_id: d?.author_id?._id,
          user_id: user_id,
        });

        if(d.items) {
          d.items = await Promise.all(d.items?.map(async z => {
            return await items.findById(z).populate("category_id");
          }));
        }

        d.author_id = await userModel.findById(d.author_id);
        if(d.selected_users) {
          d.selected_users = await Promise.all(d.selected_users?.map(async z => {
            return await userModel.findById(z)
          }));
        }

        if(d.manage_users) {
          d.manage_users = await Promise.all(d.manage_users?.map(async z => {
            return {
              user_id: await userModel.findById(z.user_id),
              active: z.active
            }
          }))
        }

        return {
          ...d, // copy all the existing fields
          isUptoNext: up_to_next ? true : false,
          isFollow: _db_follower ? true : false,
          isBlock: _db_block ? true : false,
          isMute: _db_mute ? true : false,
        };
      })
    );

    res.json({
      status: true,
      message: "items retrieved successfully",
      data: {
        docs: updatedDocs,
        totalDocs,
        limit: _limit,
        totalPages,
        currentPage,
        hasNextPage,
        nextPage,
      },
      result: pipeline
    });
  } catch (e) {
    console.log(e);
    res.json({
      status: false,
      message: "something went wrong",
    });
  }

}

exports.get_playlists = async function(req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded.user_id;
  var show = req.query.show || "all";
  var type = req.query.type || "all";
  var sortby = req.query.sortby || "new";
  var type = req.query.type,
    rootCat = req.query.rootCat,
    cat1 = req.query.cat1,
    cat2 = req.query.cat2,
    cat3 = req.query.cat3,
    cat4 = req.query.cat4,
    keyword = req.query.keyword || "",
    page = req.query.page || 1,
    limit = req.query.limit || 15,
    fFavorites = req.query.fFavorites,
    filterShow = req.query.filterShow,
    filterFrom = req.query.filterFrom,
    filterTime = req.query.filterTime,
    filterTimeFrom = req.query.filterTimeFrom,
    filterTimeTo = req.query.filterTimeTo,
    itemKind = req.query.itemKind,
    itemType = req.query.itemType,
    tfilterFrom = req.query.tfilterFrom,
    tfilterTime = req.query.tfilterTime,
    tfilterTimeFrom = req.query.tfilterTimeFrom,
    tfilterTimeTo = req.query.tfilterTimeTo,
    TrendingOrderBy = req.query.TrendingOrderBy;

  if (
    req.query.rootCat == "Trending" ||
    req.query.filter == "For you" ||
    req.query.filter == "Trending"
  ) {
    trendingPlaylists(req, res);
  } else {
    try {
      var query = playlists.find();
      var query = playlists.find();
      var offset = page == "1" ? 0 : parseInt(page - 1) * limit;
      console.log(keyword);
      if (keyword != "") {
        console.log(keyword);
        let search = {
          $or: [
            { name: { $regex: new RegExp(keyword, "ig") } },
            { description: { $regex: new RegExp(keyword, "ig") } },
          ],
        };
        query = query.find(search);
      }
  
      // query = query.find({
      //   $or: [
      //     { selected_users: { $elemMatch: { $eq: user_id } } },
      //     { "manage_users.user_id": user_id },
      //     { "manage_users.active": true },
      //     { author_id: user_id },
      //   ],
      // });
  
      switch (show) {
        case "all":
          break;
        case "my":
          query = query.find({ author_id: user_id });
          break;
        case "other":
          query = query.find({ author_id: { $ne: user_id } });
          break;
        default:
          break;
      }
  
      switch (type) {
        case "all":
          break;
        case "public":
          query = query.find({ view: "everyone" });
          break;
        case "private":
          query = query.find({ view: "me" });
          break;
        case "shared":
          query = query.find({ view: "shared" });
          break;
        default:
          break;
      }
      switch (sortby) {
        case "new":
          query = query.sort({ create_date: -1 });
          break;
        case "old":
          query = query.sort({ create_date: 1 });
          break;
        case "me":
          // work later
          break;
        case "az":
          query = query.sort({ name: -1 });
          break;
        case "za":
          query = query.sort({ name: 1 });
        default:
          query = query.sort({ create_date: -1 });
          break;
      }
  
      let user = await userModel.findById(user_id);
      switch (filterFrom) {
        case "Everybody":
          break;
        case "following":
          let _followings = (await followers.find({ user_id })).map(
            (d) => d.star_id
          );
          query = query.find({ author_id: { $in: _followings } });
          break;
        case "muted":
          query = query.find({
            author_id: { $in: user?.muted_block?.muted_accounts },
          });
          break;
        default:
          break;
      }
  
      switch (filterTime) {
        case "anytime":
          break;
        case "today":
          var date = new Date();
          var startOfToday = new Date(
            date.getFullYear(),
            date.getMonth(),
            date.getDate()
          );
          var endOfToday = new Date(
            startOfToday.getTime() + 24 * 60 * 60 * 1000 - 1
          ); // End of day is one millisecond before start of next day
          query = query.find({
            create_date: { $gte: startOfToday, $lt: endOfToday },
          });
          break;
        case "thisweek":
          query = query.find({
            create_date: {
              $gte: new Date(new Date() - 7 * 24 * 60 * 60 * 1000),
            },
          });
          break;
        case "thismonth":
          var date = new Date();
          var monthStart = new Date(date.getFullYear(), date.getMonth(), 1); // Get first day of current month
          var monthEnd = new Date(date.getFullYear(), date.getMonth() + 1, 0); // Get last day of current month
          query = query.find({
            create_date: { $gte: monthStart, $lte: monthEnd },
          });
          break;
        case "range":
          var startDate = new Date(filterTimeFrom);
          var endDate = new Date(filterTimeTo);
          query = query.find({
            create_date: { $gte: startDate, $lte: endDate },
          });
          break;
        default:
          break;
      }
  
  
      query = query.populate({
        path: "items.item_id",
        model: items,
        populate: [
          {
            path: "category_id",
            model: "category",
          },
          {
            path: "author_id",
            model: "users",
            select:
              "username email first_name last_name profile_image profile_cover metamask_info password status is_idverified create_date",
          },
        ],
      });
  
      query = query.populate({
        path: "author_id",
        model: "users",
        select:
          "_id username first_name last_name profile_image metamask_info is_idverified",
      });
      query = query.populate({
        path: "selected_users",
        model: "users",
        select:
          "_id username first_name last_name profile_image metamask_info is_idverified",
      });
      query = query.populate({
        path: "manage_users.user_id",
        model: "users",
        select:
          "_id username first_name last_name profile_image metamask_info is_idverified",
      });
  
      var options = {
        page: page,
        offset: offset,
        limit: limit,
      };
      playlists.paginate(query, options).then(async function (result) {
        const updatedDocs = await Promise.all(
          result.docs.map(async (d) => {
            // console.log(playLists.some(pl => pl.item_id == d._doc._id && pl.user_id == user_id))
            // check whether this is exited in up to next
            const up_to_next = await playerModel.findOne({
              playlist_id: d._doc._id,
              user_id,
            });
  
            // check is follower, mute, block
            var _db_follower = await followers.findOne({
              star_id: d._doc?.author_id?._id,
              user_id: user_id,
            });
            var _db_block = await blockModel.findOne({
              block_user_id: d._doc?.author_id?._id,
              user_id: user_id,
            });
            var _db_mute = await muteModel.findOne({
              mute_user_id: d._doc?.author_id?._id,
              user_id: user_id,
            });
  
            return {
              ...d._doc, // copy all the existing fields
              isUptoNext: up_to_next ? true : false,
              isFollow: _db_follower ? true : false,
              isBlock: _db_block ? true : false,
              isMute: _db_mute ? true : false,
            };
          })
        );
  
        const updatedResult = { ...result, docs: updatedDocs };
  
        res.json({
          status: true,
          message: "Playlist retrieved successfully",
          data: updatedResult,
        });
      });
  
    } catch (error) {
      console.log(error);
      res.json({
        status: false,
        message: "Something went wrong"
      });
    }
  }


}


exports.increase_trending_score = async function(req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded.user_id;
  var _id = req.body._id;
  try {
    var viewd = await playlistViewModel.findOne({
      playlist_id: _id,
      user_id
    });
    if(viewd) {
      res.json({
        status: false,
        message: 'Already viewd'
      })
    } else {
      var date = new Date();
      var datestr = getDateStr(date);

      var playlist = await playlists.findById(_id);
      if(playlist) {
        var date = new Date();
        var datestr = getDateStr(date);

        let daily_play = playlist.daily_play.find((d) => d.date == datestr);
        if (daily_play) {
          let count = daily_play.count + 1;
          daily_play.count = count;
        } else {
          let newObj = {
            date: datestr,
            count: 1,
          };
          playlist.daily_play.push(newObj);
        }
        await playlist.save();
        res.json({
          status: true,
          message: "Trending score increased successfully"
        })
      } else {
        res.json({
          status: false,
          message: "Can't find playlist"
        })
      }
    }

  } catch (error) {
    console.log(error);
    res.json({
      status: false,
      message: "Something went wrong"
    });
  }
}