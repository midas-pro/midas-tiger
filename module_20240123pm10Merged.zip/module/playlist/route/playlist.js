/*
Project : Cryptotrades
FileName : playlist.js
Author : Indiefire
File Created : 21/07/2021
CopyRights : Indiefire
Purpose : This is the file which used to define all route releated to collecion api request.
*/

var express = require('express')
var router = express.Router();
var playlistController = require("../controller/playlistController")
var auth = require("../../../middleware/auth");
var adminauth = require("../../../middleware/adminauth");
var optionalauth = require("../../../middleware/optionalauth");
const { check } = require('express-validator');

router.post('/add',[check('name').not().isEmpty(),auth],playlistController.add)
router.put('/update', auth ,playlistController.update);
router.get('/fulllist',adminauth,playlistController.getAdminList)
router.get('/list', optionalauth, playlistController.list)
router.get('/detail',playlistController.view)
router.delete('/delete',[check('playlist_id').not().isEmpty(),auth],playlistController.delete)
router.post('/add_item_to_playlist', auth, playlistController.add_item_to_playlist)
router.post('/add_playlist_to_playlist', auth, playlistController.add_playlist_to_playlist)
router.get('/get_info_for_playlist', optionalauth, playlistController.get_info_for_playlist)
router.post('/accept_join_playlist', auth, playlistController.accept_join_playlist)
router.get('/get_playlists', optionalauth, playlistController.get_playlists)

module.exports = router