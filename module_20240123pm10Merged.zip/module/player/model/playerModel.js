/*
Project : Cryptotrades
FileName : loveModel.js
Author : Indiefire
File Created : 21/07/2021
CopyRights : Indiefire
Purpose : This is the file which used to define love schema that will store and reterive party love information.
*/

var mongoose = require('mongoose');
var mongoosePaginate = require('mongoose-paginate-v2');
var uniqueValidator = require('mongoose-unique-validator');
var config = require('../../../helper/config')
const Schema = mongoose.Schema;

var playerSchema = mongoose.Schema({
    user_id: {
        type: Schema.Types.ObjectId, ref: 'users'
    },
    item_id: {
        type: Schema.Types.ObjectId, ref: 'items'
    },
    edition: {
        type: String,
        default: ''
    },
    playlist_id: {
        type: Schema.Types.ObjectId, ref: 'playlist'
    },
    played_date: {
        type: String,
        default: Date.now
    },
    created_date: {
        type: Date,
        default: Date.now
    }
});

playerSchema.plugin(uniqueValidator);
playerSchema.plugin(mongoosePaginate);

module.exports = mongoose.model('players', playerSchema,config.db.prefix+'players');