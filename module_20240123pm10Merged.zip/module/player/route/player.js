var express = require('express')
var router = express.Router();
var playerController = require("../controller/playerController")
var auth = require("../../../middleware/auth");
var adminauth = require("../../../middleware/adminauth");
var optionalauth = require("../../../middleware/optionalauth");
const { check } = require('express-validator');

router.post('/add_to_up_next', auth ,playerController.add_to_player);
router.post('/remove_from_up_next', auth, playerController.remove_from_player);
router.get('/get_up_next', auth, playerController.get_up_next);
router.get('/get_player_history', auth, playerController.get_player_history);
router.post('/add_playlist_to_up_next', auth, playerController.add_playlist_to_up_next);
router.post('/remove_playlist_from_up_next', auth, playerController.remove_playlist_from_up_next);
router.post('/add_to_history', auth, playerController.add_to_history);
router.post('/update_playtime', auth, playerController.update_playtime);
router.post('/create_current_play_item', auth, playerController.create_current_play_item)
router.get('/get_current_play_item', auth, playerController.get_current_play_item)
router.get('/remove_current_play_item', auth, playerController.remove_current_play_item)
router.get('/get_up_next_status', auth, playerController.get_up_next_status)

module.exports = router