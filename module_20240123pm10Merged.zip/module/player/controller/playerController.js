

const rentModel = require('../../item/model/rentModel');
const transactionModel = require('../../item/model/transactionModel');
const playModel = require('../../party/model/playModel');
const currentPlayModel = require('../model/currentPlayModel');
var playerModel = require('../model/playerModel'),
    playlistModel = require('../../playlist/model/playlistModel'),
    playerLoveModel = require('../model/playerloveModel'),
    playerHistoryModel = require('../model/playerhistoryModel'),
    itemModel = require('../../item/model/itemModel'),
    itemloveModel = require('../../item/model/itemloveModel'),
    categoryModel = require('../../category/model/categoryModel');
const { getErrLine } = require("../../helper/helpers");

exports.add_to_player = async function(req, res) {
    var user_id = req.decoded.user_id;
    var item_id = req.body.item_id;
    var edition = req.body.edition;

    try {
        var player = await playerModel.findOne({ user_id, item_id, edition });
        if(player) {
            res.json({
                status: false,
                message: "You have already added this item's edition to up to next"
            });
        } else {
            // check you bought item or check it's yours
            let original_item = await itemModel.findById(item_id);
            if(original_item) {
                if(user_id == original_item.author_id) {
                } else {
                    if(edition == 'free') {

                    } else {
                        let query = {
                            original_id: item_id,
                            current_owner: user_id
                        }
                        switch(edition) {
                            case 'standard':
                                query.es_enabled = true;                            
                                break;
                            case 'collective':
                                query.ec_enabled = true;
                                break;
                            case 'limited':
                                query.el_enabled = true;
                                break;
                            default:
                                break;
                        }
                        let bought_item = await itemModel.findOne(query);
                        if(!bought_item) {
                            res.json({
                                status: false,
                                message: "You didn't purchase this item"
                            });
                            return;
                        }
                    }
                }
                let upNext = new playerModel({
                    item_id, user_id, edition
                });

                await upNext.save();
                res.json({
                    status: true,
                    message: "Saved successfully"
                });


            } else {
                res.json({
                    status: false,
                    message: "No exists"
                });
            }
        }
    } catch (error) {
        console.log(error);
        res.json({
            status: false,
            message: "Something went wrong"
        });
    }
}

exports.remove_from_player = async function(req, res) {
    var user_id = req.decoded.user_id;
    var player_id = req.body.player_id;
    var item_id = req.body.item_id;
    if(player_id) {
        try {
            var player = await playerModel.findById(player_id);
            if(player) {
                if(player.user_id == user_id) {
                    await playerModel.findByIdAndDelete(player_id);
                    res.json({
                        status: true,
                        message: "removed successfully"
                    });
                } else {
                    res.json({
                        status: false,
                        message: "You can't delete this"
                    });
                }
            } else {
                res.json({
                    status: false,
                    message: "Player is not existed"
                });
            }
        } catch (error) {
            console.log(error);
            res.json({
                status: false,
                message: "Something went wrong"
            });
        }
    } else if(item_id) {
        try {
            await playerModel.deleteMany({ item_id, user_id });
            res.json({
                status: true,
                message: "Removed successfully"
            });
        } catch (error) {
            console.log(error);
            res.json({
                status: false,
                message: "Something went wrong"
            });
        }
    } else {
        res.json({
            status: false,
            message: "Something went wrong"
        });
    }
} 

exports.add_to_favorite = async function(req, res) {
    var user_id = req.decoded.user_id;
    var player_id = req.body.player_id;
    try {
        var playerlove = await playerLoveModel.findOne({ user_id, player_id });
        if(playerlove) {
            res.json({
                status: false,
                message: "Already added to your favorite list"
            });
        } else {
            var newLove = new playerLoveModel({
                user_id, player_id
            });
            await newLove.save();
            res.json({
                status: true,
                message: "Added successfully"
            });
        }
    } catch (error) {
        console.log(error);
        res.json({
            status: false,
            message: "Something went wrong"
        });
    }
}

exports.add_to_history = async function(req, res) {
    var user_id = req.decoded.user_id;
    var item_id = req.body.item_id;
    var edition = req.body.edition;
    try {
        let d = new Date();
        let ld = new Date(d.setMinutes(d.getMinutes() - 5));
        let his = await playerHistoryModel.findOne({ item_id, edition, user_id, created_date: { $gt: ld } });
        if(his) {
            res.json({
                status :false,
                message: "Added recently"
            })
        } else {
            var newHistory = new playerHistoryModel({
                item_id, edition, user_id
            });
            await newHistory.save();
            res.json({
                status: true,
                message: "Saved successfully"
            });
        }
    } catch (error) {
        console.log(error);
        res.json({
            status: false,
            message: "Something went wrong"
        });
    }
}

exports.update_playtime = async function(req, res) {
    var user_id = req.decoded.user_id;
    var item_id = req.body.item_id;
    var edition = req.body.edition;
    try {
        let d = new Date();
        let ld = new Date(d.setMinutes(d.getMinutes() - 5));
        let upNextItem = await playerModel.findOne({ item_id, edition, user_id, played_date: { $gt: ld } });
        if(upNextItem) {
            res.json({
                status :false,
                message: "updated recently"
            })
        } else {
            let upNextItem = await playerModel.findOne({ item_id, edition, user_id })
            upNextItem.played_date = new Date();
            await upNextItem.save();
            res.json({
                status: true,
                message: "Saved successfully"
            });
        }
    } catch (error) {
        console.log(error);
        res.json({
            status: false,
            message: "Something went wrong"
        });
    }
}

exports.get_player_history = async function(req, res) {
    var user_id = req.decoded.user_id;
    var keyword = req.query.keyword;
    var show = req.query.show;
    var sort = req.query.sort;

    try {
        var query = playerHistoryModel.find({ user_id }).limit(50);
        let match = { }
        if (keyword != '') {
            match = {
                $or : [ 
                    { name: { $regex: new RegExp(keyword, "ig") }}, 
                    { description: { $regex : new RegExp (keyword , "ig") }}, 
                ]
            }
        } 
        let category;
        switch(show) {
            case 'music':
                category = await categoryModel.findOne({ title: 'Music', level: 1 });
                break;
            case 'podcasts':
                category = await categoryModel.findOne({ title: 'Podcasts', level: 1 });
                break;
            case 'comedygigs':
                category = await categoryModel.findOne({ title: 'Comedy gigs', level: 1 });
                break;
            case 'audiobooks':
                category = await categoryModel.findOne({ title: 'Audiobooks', level: 1 });
                break;
            case 'movies':
                category = await categoryModel.findOne({ title: 'Movies', level: 1 });
                break;
            case 'tvseries':
                category = await categoryModel.findOne({ title: 'TV Series', level: 1 });
                break;
            default:
                break;
        }
        console.log(category);
        if(category) {
            let _items = (await itemModel.find({ category_id:  category._id })).map(d => d._id);
            query = query.find({ item_id: { $in: _items } });
        }
        let option = {  }

        query = query.sort({ created_date: -1 });
        switch(sort) {
            case 'addednew':
                query = query.sort({ created_date: -1 });
                break;
            case 'addedold':
                query = query.sort({ created_date: 1 });
                break;
            case 'playednew':
                query = query.sort({ played_date: -1 });
                break;
            case 'playedold':
                query = query.sort({ played_date: 1 });
                break;
            case 'az':
                option.sort = {
                    filendName: 'name', order: 'desc'
                }
                break;
            case 'za':
                option.sort = {
                    filendName: 'name', order: 'desc'
                }
                break;
            default:
                break;
        }
        var histories = await query.populate({
            path: 'item_id', 
            match: match,
            model: itemModel,
            options: option, 
            populate: [
                {
                    path: 'category_id',
                    model: 'category'
                },
                {
                    path: 'author_id',
                    model: 'users',
                    select: 'username email first_name last_name profile_image profile_cover metamask_info password status is_idverified create_date'
                }
            ]

        }).exec();
        histories =  histories.map(d => {
            return {
                ...d._doc,
                ...{serverDate: new Date()}
            }
        })
        res.json({
            status: true,
            message: "Retrived successfully",
            result: histories
        })
    } catch (error) {
        console.log(error);
        res.json({
            status: false,
            message: "Some thing went wrong"
        });
    }

}

exports.remove_from_favorite = async function(req, res) {
    var user_id = req.decoded.user_id;
    var player_favorite_id = req.body.player_favorite_id;
    try {
        var playerlove = await playerLoveModel.findById(player_favorite_id);
        if(playerlove) {
            if(playerlove.user_id == user_id) {
                await playerLoveModel.findByIdAndDelete(player_favorite_id);
                res.json({
                    status: true,
                    message: "removed successfully"
                });
            } else {
                res.json({
                    status: false,
                    message: "You can't delete this"
                });
            }
        } else {
            res.json({
                status: false,
                message: "Player is not existed"
            });
        }
    } catch (error) {
        console.log(error);
        res.json({
            status: false,
            message: "Something went wrong"
        });
    } 
}

exports.get_up_next = async function(req, res) {
    var user_id = req.decoded.user_id;
    var keyword = req.query.keyword;
    var show = req.query.show;
    var sort = req.query.sort;
    
    try {
        let query = playerModel.find({ user_id })
        let match = { }
        if (keyword != '') {
            match = {
                $or : [ 
                    { name: { $regex: new RegExp(keyword, "ig") }}, 
                    { description: { $regex : new RegExp (keyword , "ig") }}, 
                ]
            }
        } 
        let category;
        switch(show) {
            case 'music':
                category = await categoryModel.findOne({ title: 'Music', level: 1 });
                break;
            case 'podcasts':
                category = await categoryModel.findOne({ title: 'Podcasts', level: 1 });
                break;
            case 'comedygigs':
                category = await categoryModel.findOne({ title: 'Comedy gigs', level: 1 });
                break;
            case 'audiobooks':
                category = await categoryModel.findOne({ title: 'Audiobooks', level: 1 });
                break;
            case 'movies':
                category = await categoryModel.findOne({ title: 'Movies', level: 1 });
                break;
            case 'tvseries':
                category = await categoryModel.findOne({ title: 'TV Series', level: 1 });
                break;
            default:
                break;
        }
        console.log(category);
        if(category) {
            let items = (await itemModel.find({ category_id:  category._id })).map(d => d._id);
            query = query.find({ item_id: { $in: items } })
        }
        let option = {  }

        switch(sort) {
            case 'addednew':
                query = query.sort({ created_date: -1 });
                break;
            case 'addedold':
                query = query.sort({ created_date: 1 });
                break;
            case 'releasenew':
                option.sort = {
                    filendName: 'released_date', order: 'desc'
                }
                break;
            case 'releaseold':
                option.sort = {
                    filendName: 'released_date', order: 'asc'
                }
                break;
            case 'playednew':
                query = query.sort({ played_date: -1 });
                break;
            case 'playedold':
                query = query.sort({ played_date: 1 });
                break;
            case 'custom':
                query = query.sort({ played_date: -1 });
                break;
            default:
                break;
        }

        var players = await query.populate({
                path: 'item_id', 
                match: match,
                model: itemModel,
                options: option, 
                populate: [
                    {
                        path: 'category_id',
                        model: 'category'
                    },
                    {
                        path: 'author_id',
                        model: 'users',
                        select: 'username email first_name last_name profile_image profile_cover metamask_info password status is_idverified create_date'
                    }
                ]

            }).exec();
            const updatedPlayers =  players.filter(d => d.item_id ).map(async d => {
            // check which edition you bought
            let love = await itemloveModel.findOne({ item_id: d?.item_id?._id, user_id });
            var newD = {
                ...d.toObject(),
                isLoved: love ? true: false
            }
            return newD;
        });

        const updatedResults = await Promise.all(updatedPlayers);
        res.json({
            status: true,
            message: "Retrived data successfully",
            result: updatedResults
        })

    } catch (error) {
        console.log(error);
        res.json({
            status: false,
            message: "Something went wrong"
        });
    }

}

// add playlist to up next

exports.add_playlist_to_up_next = async function(req, res) {
    var user_id = req.decoded.user_id;
    var playlist_id = req.body.playlist_id;
    try {
        let playlist = await playlistModel.findById(playlist_id);
        let up_to_nexts = await playerModel.find({ user_id });
        if(playlist) {
            let _items = playlist.items;
            if(_items && _items.length > 0) {
                let _new_up_next_arr = [];
                await Promise.all(_items.map(async d => {
                    let _item_id = d.item_id;
                    let _edition = d.edition;
                    let item = await itemModel.findById(_item_id);
                    if(item) {
                        // check item is belongs to you or else
                        if(item.author_id == user_id) {
                            // check up next already contains the item edition
                            
                        } else {
                            // check whether you purchased the item edition
                            if(_edition == 'free') {

                            } else {
                                let query = {
                                    original_id: item_id,
                                    current_owner: user_id
                                }
                                switch(_edition) {
                                    case 'standard':
                                        query.es_enabled = true;                            
                                        break;
                                    case 'collective':
                                        query.ec_enabled = true;
                                        break;
                                    case 'limited':
                                        query.el_enabled = true;
                                        break;
                                    default:
                                        break;
                                }
                                let bought_item = await itemModel.findOne(query);
                                if(!bought_item) {
                                    return;
                                }
                            }
                        }
                        // check item edition is already added or not
                        if(up_to_nexts.find(up => up.item_id == _item_id && edition == _edition)) {
                            return;
                        } 
                        let new_up_next = {
                            item_id: _item_id,
                            edition: _edition,
                            playlist_id,
                            user_id
                        };
                        console.log("new_up_next")
                        console.log(new_up_next)
                        _new_up_next_arr.push(new_up_next);
                        // return _new_up_next_arr;
                    } 
                })) 
                console.log("_new_up_next_arr")
                console.log(_new_up_next_arr);
                await playerModel.insertMany(_new_up_next_arr);
                res.json({
                    status: true,
                    message: 'Added successfully'
                });
            } else {
                res.json({
                    status: false,
                    message: "Playlist doesn't contain any item."
                });
            }
        } else {
            res.json({
                status: false,
                message: "No playlist"
            });
        }
    } catch (error) {
        console.log(error);
        res.json({
            status: false,
            message: "Something went wrong"
        });
    }
}



exports.remove_playlist_from_up_next = async function(req, res) {
    var user_id =  req.decoded.user_id;
    var playlist_id = req.body.playlist_id;
    try {
        await playerModel.deleteMany({ playlist_id, user_id });
        res.json({
            status: true,
            message: "Removed successfully"
        });
    } catch (error) {
        console.log(error);
        res.json({
            status: false,
            message: "Something went wrong"
        });
    }
}


exports.create_current_play_item = async function(req, res) {
    var user_id = req.decoded.user_id;
    try {
        var currentPlayItem = await currentPlayModel.findOne({ user_id });
        if(currentPlayItem) {
            await currentPlayItem.remove();
        }
        var newCurrentPlayItem = new currentPlayModel(req.body);
        newCurrentPlayItem.user_id = user_id;
        await newCurrentPlayItem.save();
        res.json({
            status: true,
            message: "Saved successfully",
        });
    } catch (error) {
        console.log(error);
        res.json({
            status: false,
            message: "Something went wrong"
        });
    }
}

exports.get_current_play_item = async function(req, res) {
    var user_id = req.decoded.user_id;
    try {
        var currentPlayItem = await currentPlayModel.findOne({ user_id })
        .populate({
            path: 'item',
            model: 'item'
        });
        res.json({
            status: true,
            message: "Retrived successfully",
            result: currentPlayItem
        })
    } catch (error) {
        console.log(error);
        res.json({
            status: false,
            message: "Something went wrong"
        });
    }
}
exports.remove_current_play_item = async function(req, res) {
    var user_id = req.decoded.user_id;
    try {
        await currentPlayModel.deleteMany({ user_id });
        res.json({
            status: true,
            message: "Removed successfully"
        });
    } catch (error) {
        console.log(error);
        res.json({
            status: false,
            message: "Something went wrong"
        });
    }
}

exports.get_up_next_status = async function(req, res) {
    try {
        var user_id = req.decoded.user_id;
        var item_id = req.query.item_id;
        var item = await itemModel.findById(item_id);
        if(item) {
            let upnextStatus = { } 
            let free = await playerModel.findOne({
                item_id, edition: 'free'
            });
            upnextStatus = { ...upnextStatus, free: free ? true: false  }
            if(item.es_enabled) {
                let standard = await playModel.findOne({ item_id, edition: 'standard', user_id });
                //    check you bought this edition or rent
                let bought = await transactionModel.findOne({ item_id, edition: 'standard', user_id });
                let rented = await rentModel.findOne({ item_id, edition: 'standard', user_id });
                upnextStatus = { ...upnextStatus, ...{
                    standard: {
                        enable: (bought || rented) ? true: false,
                        added: standard ? true: false
                    }
                } }
            }
            if(item.ec_enabled) {
                let collective = await playModel.findOne({ item_id, edition: 'collective', user_id });
                //    check you bought this edition or rent
                let bought = await transactionModel.findOne({ item_id, edition: 'collective', user_id });
                let rented = await rentModel.findOne({ item_id, edition: 'collective', user_id });
                upnextStatus = { ...upnextStatus, ...{
                    collective: {
                        enable: (bought || rented) ? true: false,
                        added: collective ? true: false
                    }
                } }
            }
            if(item.el_enabled) {
                let limited = await playModel.findOne({ item_id, edition: 'limited', user_id });
                //    check you bought this edition or rent
                let bought = await transactionModel.findOne({ item_id, edition: 'limited', user_id });
                let rented = await rentModel.findOne({ item_id, edition: 'limited', user_id });
                upnextStatus = { ...upnextStatus, ...{
                    limited: {
                        enable: (bought || rented) ? true: false,
                        added: limited ? true: false
                    }
                } }
            }

            res.json({
                status: true,
                message: "Retrive successfully",
                result: upnextStatus
            })

        } else {
            res.json({
                status: false,
                message: "Item not found"
            })
        }
    } catch (error) {
        res.json({
            status: false,
            message: error?.message
        })
    }
}
