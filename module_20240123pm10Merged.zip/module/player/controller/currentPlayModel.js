/*
Project : Cryptotrades
FileName : loveModel.js
Author : Indiefire
File Created : 21/07/2021
CopyRights : Indiefire
Purpose : This is the file which used to define love schema that will store and reterive party love information.
*/

var mongoose = require('mongoose');
var mongoosePaginate = require('mongoose-paginate-v2');
var uniqueValidator = require('mongoose-unique-validator');
var config = require('../../../helper/config')
const Schema = mongoose.Schema;

var currentPlaySchema = mongoose.Schema({
    type: {
        type: String,
    },
    thumb: {
        type: String
    },
    media: {
        type: String
    },
    from: {
        type: String
    },
    time: {
        type: Number
    },
    id: {
        type: String
    },
    item: {
        type: Schema.Types.ObjectId, ref: 'item'
    },
    edition: {
        type: String,
        default: ''
    },
    user_id: {
        type: Schema.Types.ObjectId, ref: 'users'
    },
    created_date: {
        type: Date,
        default: Date.now
    }
});

currentPlaySchema.plugin(uniqueValidator);
currentPlaySchema.plugin(mongoosePaginate);

module.exports = mongoose.model('current_plays', currentPlaySchema,config.db.prefix+'current_plays');