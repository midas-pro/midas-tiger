/*
Project : Cryptotrades
FileName : fanpostController.js
Author : Indiefire
File Created : 21/07/2021
CopyRights : Indiefire
Purpose : This is the file which used to define all fanpost related api function.
*/
var users = require("./../../user/model/userModel");
var fanposts = require("../model/fanpostModel");
var offers = require("./../../item/model/offerModel");
var likes = require("../model/likeModel");
var loves = require("../model/loveModel");
var comments = require("../model/commentModel");
var reactions = require("../model/reactionModel");
var boosts = require("../model/boostModel");
var fanpost_comment_loves = require("../model/commentLoveModel");
var fanpost_comment_reactions = require("../model/commentReactionModel");
var fanpostHistoryModel = require("../model/fanpostHistoryModel");

var members = require("../../user/model/memberModel"),
  fans = require("../../user/model/fanModel"),
  followers = require("../../user/model/followerModel"),
  blockModel = require("../../user/model/blockModel"),
  muteModel = require("../../user/model/muteModel"),
  subscribers = require("../../user/model/subscriberModel"),
  subscriptionlevels = require("../../user/model/subscriptionlevelModel"),
  fandoms = require("../../user/model/fandomModel");
var validator = require("validator");
const { validationResult } = require("express-validator");
const notificationModel = require("../../notification/model/notificationModel");
const {
  NOTIFICATION_TYPES,
  NOTIFICATION_FILTERS,
} = require("../../helper/notification_config");
const fanpostShareModel = require("../model/fanpostShareModel");
const commentReactionModel = require("../model/commentReactionModel");
const itemModel = require("../../item/model/itemModel");
const add_item_comment = require("../../item/controller/itemController").add_item_comment;
const categoryModel = require("../../category/model/categoryModel");
const itemreactionModel = require("../../item/model/itemreactionModel");
const itemboostModel = require("../../item/model/itemboostModel");
const itemcommentModel = require("../../item/model/itemcommentModel");
const itemcommentreactionModel = require("../../item/model/itemcommentreactionModel");
const itemcommentloveModel = require("../../item/model/itemcommentloveModel");
const itemcommentlikeModel = require("../../item/model/itemcommentlikeModel");
const itemplayModel = require("../../item/model/itemplayModel");
const itemlikeModel = require("../../item/model/itemlikeModel");
const itemloveModel = require("../../item/model/itemloveModel");
const { getErrLine } = require("../../helper/helpers");
const { ObjectID } = require("bson");
const artistModel = require("../../user/model/artistModel");

const { getLinkPreview, getPreviewFromContent } = require("link-preview-js");

//!!20231231 CoderA Speed
global.bLoadPostInfo = false;

/*
 *  This is the function which used to retreive active fanpost list
 */

// return datestr function
function getDateStr(date) {
  var datestr = `${date.getFullYear()}${("0" + (date.getMonth() + 1)).substr(
    -2
  )}${("0" + date.getDate()).substr(-2)}`;
  return datestr;
}
exports.getList = async function (req, res) {
  console.log(getErrLine().str, "apistart.bCache:",global.bLoadPostInfo,req.query);
  try {
    var user_id = req.decoded?.user_id;
    var page = req.query.page ? req.query.page : "1";
    var tab = req.query.tab;
    var posted = req.query.posted;
    var postedFrom = req.query.postedFrom;
    var postedTo = req.query.postedTo;
    var isShow = req.query.isShow;
    var fanId = req.query.user_id;
    var type = req.query.type || 'post';

    var filter = req.query.filter;

    var blocked_accounts = [
      ...(await blockModel.find({ user_id }))?.map(d => d.block_user_id),
      ...(await blockModel.find({ block_user_id: user_id }))?.map(d => d.user_id),
    ];

    let lists = [];
    if (type == 'all' || type == 'post') {
      var query = fanposts.find();

      if (filter == "reactions") {
        query = query.find({ n_reaction: { $gt: 0 } });
      }

      if (req.query.isShow && req.query.isShow != "") {
        switch (req.query.isShow) {
          case "all":
            break;
          case "photo":
            query = query.find({
              $or: [
                { fanpost_image: { $exists: true, $ne: "" } },
                { fanpost_images: { $exists: true, $not: { $size: 0 } } },
              ],
            });
            break;
          case "video":
            query = query.find({
              $and: [
                { fanpost_video: { $ne: "" } },
                { fanpost_video: { $ne: null } },
              ],
            });
            break;
          case "fanOnly":
            query = query.find({
              is_view_only: { $in: ["Fans Only", "fans", "superfans"] },
            });
            break;
          default:
            break;
        }
      }

      switch (posted) {
        case "today":
          var date = new Date();
          var startOfToday = new Date(
            date.getFullYear(),
            date.getMonth(),
            date.getDate()
          );
          var endOfToday = new Date(
            startOfToday.getTime() + 24 * 60 * 60 * 1000 - 1
          ); // End of day is one millisecond before start of next day
          query = query.find({
            create_date: { $gte: startOfToday, $lt: endOfToday },
          });
          break;
        case "thisweek":
          query = query.find({
            create_date: { $gte: new Date(new Date() - 7 * 24 * 60 * 60 * 1000) },
          });
          break;
        case "thismonth":
          var date = new Date();
          var monthStart = new Date(date.getFullYear(), date.getMonth(), 1); // Get first day of current month
          var monthEnd = new Date(date.getFullYear(), date.getMonth() + 1, 0); // Get last day of current month
          query = query.find({
            create_date: { $gte: monthStart, $lte: monthEnd },
          });
          break;
        case "range":
          var startDate = new Date(postedFrom);
          var endDate = new Date(postedTo);
          query = query.find({ create_date: { $gte: startDate, $lte: endDate } });
          break;
      }

      // get share content also
      var shared_fanposts = await (await fanpostShareModel.find({ user_id: fanId, type: 'post' })).map(d => d.item_id)

      // don't display content when fandom is not published
      if (user_id == fanId) {
        query = query.find({
          $or: [
            { creator_id: user_id },
            { _id: { $in: shared_fanposts } }
          ]
        });
      } else {
        //!!20231231 CoderA SPeed
        // filter fan and super fan content if fan's subcription is not enabled
        // let _basic = await subscriptionlevels.findOne({ user_id: fanId, level: 'basic' });
        // let _super = await subscriptionlevels.findOne({ user_id: fanId, level: 'super' });
        // var _fandoms = await fandoms.find({ status: "published" });
        // _fandoms = _fandoms.map((d) => {
        //   return d.user_id;
        // });
        const [_basic,_super,_fandoms1] = await Promise.all([
          await subscriptionlevels.findOne({ user_id: fanId, level: 'basic' }),
          await subscriptionlevels.findOne({ user_id: fanId, level: 'super' }),
          await fandoms.find({ status: "published" }),
        ]);//!!20231231 CoderA SPeed
        _fandoms = _fandoms1.map((d) => {
          return d.user_id;
        });//!!20231231 CoderA SPeed

        // console.log(_fandoms);//!!
        query = query.find({
          $or: [
            {
              creator_id: {
                $in: _fandoms,
                $eq: fanId,
                $nin: blocked_accounts
              },
            },
            { _id: { $in: shared_fanposts } }
          ]
        });

        if (!_super) {
          query = query.find({
            $and: [
              { is_view_only: { $ne: "superfans" } },
              { is_relay_only: { $ne: "superfans" } },
            ]
          })
        }

        if (!_basic && !_super) {
          query = query.find({
            $and: [
              { is_view_only: { $ne: 'fans' } },
              { is_relay_only: { $ne: 'fans' } },
              { is_view_only: { $ne: "superfans" } },
              { is_relay_only: { $ne: "superfans" } },
            ]
          })
        }
      }



      var offset = page == "1" ? 0 : parseInt(page - 1) * 10;
      // query = query.sort({ priority: -1 });
      if (req.query.orderBy && req.query.orderBy != "") {
        if (req.query.orderBy == "new") {
          query = query.sort("-create_date");
        } else {
          query = query.sort("create_date");
        }
      } else {
        query = query.sort("-create_date");
      }
      if (req.query.keyword && req.query.keyword != "") {
        var keyword = req.query.keyword;
        query = query.find({
          $or: [
            { description: { $regex: new RegExp(keyword, "ig") } },
            { fanpost_poll_question: { $regex: new RegExp(keyword, "ig") } },
          ],
        });
      }

      // filter by tab
      switch (tab) {
        case "posts":
          break;
        case "fans":
          query = query.find({ is_view_only: "fans" });
          break;
        case "superfans":
          query = query.find({ is_view_only: "superfans" });
          break;
        case "replies":
          // !!20240121pm6 coderd {(B)something is wrong with replies - it’s not showing the correct items}
          // query = query.find({ $and: [ { n_comment: { $gt: 0 } }]});
          query = query.find({ n_comment: { $gt: 0 } });
        default:
          break;
      }

      switch (posted) {
        case "today":
          var date = new Date();
          var startOfToday = new Date(
            date.getFullYear(),
            date.getMonth(),
            date.getDate()
          );
          var endOfToday = new Date(
            startOfToday.getTime() + 24 * 60 * 60 * 1000 - 1
          ); // End of day is one millisecond before start of next day
          query = query.find({
            create_date: { $gte: startOfToday, $lt: endOfToday },
          });
          break;
        case "thisweek":
          query = query.find({
            create_date: { $gte: new Date(new Date() - 7 * 24 * 60 * 60 * 1000) },
          });
          break;
        case "thismonth":
          var date = new Date();
          var monthStart = new Date(date.getFullYear(), date.getMonth(), 1); // Get first day of current month
          var monthEnd = new Date(date.getFullYear(), date.getMonth() + 1, 0); // Get last day of current month
          query = query.find({
            create_date: { $gte: monthStart, $lte: monthEnd },
          });
          break;
        case "range":
          var startDate = new Date(postedFrom);
          var endDate = new Date(postedTo);
          query = query.find({ create_date: { $gte: startDate, $lte: endDate } });
          break;
        default:
          break;
      }

      query = query.populate({
        path: "author_id",
        model: "users",
        // 20240115am1CoderB "(c ) whole site > verified icon use this spacing "
        // select: "_id first_name last_name username profile_image",
        select: "_id first_name last_name username profile_image is_idverified",
      });
      let result = await query.exec();

      //!!20231231 CoderA SPeed
      //// V1
      // let _reactions = await reactions.find();
      // let _comments = await comments.find({ parent_id: null });
      // let _loves = await loves.find();
      // let _boosts = await fanpostShareModel.find();
      //// V2
      // const [_reactions,_comments,_loves,_boosts] = await Promise.all([
      //   await reactions.find(),
      //   await comments.find({ parent_id: null }),
      //   await loves.find(),
      //   await fanpostShareModel.find(),
      //  ]);
      //// V3
      // const [_reactions,_comments,_loves,_boosts] = await Promise.all([
      //   await reactions.find(),
      //   await comments.find({ parent_id: null }),
      //   await loves.find(),
      //   await fanpostShareModel.find(),
      //  ]);
      let _reactions = global.bLoadPostInfo?global._reactions:await reactions.find();
      let _comments = global.bLoadPostInfo?global._comments:await comments.find({ parent_id: null });
      let _loves = global.bLoadPostInfo?global._loves:await loves.find();
      let _boosts = global.bLoadPostInfo?global._boosts:await fanpostShareModel.find();
      if(!global.bLoadPostInfo)
      {
        global._reactions = _reactions;
        global._comments = _comments;
        global._loves = _loves;
        global._boosts = _boosts;        
        global.bLoadPostInfo = true;
      }

      const updatedDocsPromises = result.map(async (d) => {
        //!!20231231 CoderA SPeed
        // let _members = await members.find({ star_id: d._doc.creator_id });
        // let _fans = await fans.find({ star_id: d._doc.creator_id });
        // let _followers = await followers.find({ star_id: d._doc.creator_id });
        // let _followings = await followers.find({ star_id: user_id });
        const [_members,_fans,_followers,_followings] = await Promise.all([ 
          await members.find({ star_id: d._doc.creator_id }),
          await fans.find({ star_id: d._doc.creator_id }),
          await followers.find({ star_id: d._doc.creator_id }),
          await followers.find({ star_id: user_id })
        ]);

        //!!20231231 CoderA SPeed
        // var _db_follower = await followers.findOne({
        //   star_id: d._doc?.author_id?._id,
        //   user_id: user_id,
        // });
        // var _db_block = await blockModel.findOne({
        //   block_user_id: d._doc?.author_id?._id,
        //   user_id: user_id,
        // });
        // var _db_mute = await muteModel.findOne({
        //   mute_user_id: d._doc?.author_id?._id,
        //   user_id: user_id,
        // });
        const [_db_follower, _db_block, _db_mute] = await Promise.all([
          await followers.findOne({
            star_id: d._doc?.author_id?._id,
            user_id: user_id,
          }),
          await blockModel.findOne({
            block_user_id: d._doc?.author_id?._id,
            user_id: user_id,
          }),
          await muteModel.findOne({
            mute_user_id: d._doc?.author_id?._id,
            user_id: user_id,
          })
         ]);
        //  !!20240123pm8 coderd added below code {debug fandoms}
        let fandomInfo = await fandoms.find({creator_id:d._doc.creator_id})
        let isFan = _fans.some((f) => f.user_id == user_id);
        let membership;
        if (isFan) {
          let _memberships = await subscriptionlevels.find({
            user_id: d._doc?.creator_id,
          });
          _memberships.map((d) => {
            return d._id;
          });
          var _start_date = new Date();
          _start_date.setMonth(_start_date.getMonth() - 1);
          membership = await subscribers
            .findOne({
              user_id: user_id,
              subscription_id: { $in: _memberships },
              unsubscribed: false,
              start_date: { $gte: _start_date },
            })
            .populate("subscription_id");
        }

        let InfoForUser = {
          isMember: _members.some((m) => m.user_id == user_id),
          isFan: isFan,
          membership: membership,
          isFollower: _followers.some((f) => f.user_id == user_id),
          isFollowing: _followings.some((f) => f.user_id == d._doc?.creator_id),
        };

        // check edited
        let histories = await fanpostHistoryModel.find({ fanpost_id: d._id });

        const itemReactions = _reactions.filter(
          (r) => r.fanpost_id == d._id.toString() && r.user_id == user_id
        );
        const reactionNumber = itemReactions.length
          ? itemReactions[0].reaction_number
          : -1;
        // shared check

        var shared = await fanpostShareModel.findOne({ item_id: d._doc?._id, user_id: fanId })
          .populate({
            path: "user_id",
            model: "users",
            select: "_id first_name last_name username profile_image",
          })
          .populate({
            path: "item_comment_id",
            model: "fanpost_comments",
            populate: [
              {
                path: "user_id",
                model: "users",
                select: "_id first_name last_name username profile_image",
              }
            ]
          });

        if (shared?.item_comment_id) {
          // console.log("shared?.item_comment_id?._id");//!!
          // console.log(shared?.item_comment_id?._id);//!!
          var reaction_number;
          var fanpost_comment_reaction = await commentReactionModel.findOne({
            // !!20240115am5 coderd {(CoderD)(B) shared post bugs}
            fanpost_comment_id: shared?.item_comment_id?._id,
            // item_comment_id: shared?.item_comment_id?._id,
            user_id
          });
          // console.log(fanpost_comment_reaction);//!!//!!20231230 CoderA too many log// disable temporarely
          if (fanpost_comment_reaction) {
            reaction_number = fanpost_comment_reaction.reaction_number;
          }
          var isCommented = await comments.findOne({
            parent_id: shared?.item_comment_id?._id,
            user_id
          }) != null ? true : false;
          // console.log("reaction_number:",reaction_number);//!!20231230 CoderA too many log// disable temporarely
          // console.log("isCommented:",isCommented);//!!//!!20231230 CoderA too many log// disable temporarely
          // console.log("shared:",shared);//!!//!!20231230 CoderA too many log// disable temporarely
          var new_fanpost_comment_id = {
            ...shared.item_comment_id._doc,
            reaction_number:reaction_number,
            isCommented
          }
          // console.log(new_fanpost_comment_id);//!!//!!20231230 CoderA too many log// disable temporarely
          shared = {
            ...shared._doc,
            item_comment_id: new_fanpost_comment_id
          }
        }



        return {
          ...d.toObject(), // copy all the existing fields
          __type: 'post',
          shared,
          reaction_number: reactionNumber,
          isCommented: _comments.some(
            (pl) => pl.fanpost_id == d._id.toString() && pl.user_id == user_id
          ),
          isLoved: _loves.some(
            (pl) => pl.fanpost_id == d._id.toString() && pl.user_id == user_id
          ),
          isBoosted: _boosts.some(
            (pl) => pl.fanpost_id == d._id.toString() && pl.user_id == user_id
          ),
          priority: d._doc.priority == 1 && !shared ? 1 : 0,
          InfoForUser: InfoForUser,
          serverDate: new Date(),
          isEdited: histories?.length > 0 ? true : false,
          isFollow: _db_follower ? true : false,
          isBlock: _db_block ? true : false,
          isMute: _db_mute ? true : false,
          fandomInfo:fandomInfo  //!!20240123pm8 coderd added this line {debug fandoms}
        };
      });
      let updatedDocs = await Promise.all(updatedDocsPromises);

      updatedDocs = updatedDocs.sort((a, b) => {
        const aMatchCondition = a.priority == 1 && !a.shared;
        const bMatchCondition = b.priority == 1 && !b.shared;
        if (aMatchCondition && !bMatchCondition) {
          return -1
        } else if (!aMatchCondition && bMatchCondition) {
          return 1
        } else {
          return 0;
        }
      });
      lists = [...updatedDocs]
    }

    if (type == 'item' || type == 'all') {
      var shared_item_ids = (await fanpostShareModel.find({ type: 'item', user_id: fanId }))?.map(d => d.item_id);
      let query = itemModel.find({ _id: { $in: shared_item_ids }, author_id: { $nin: blocked_accounts } });
      if(isShow != 'all') {
        if (isShow == 'Marketplace') {
          let merchandiseCat = await categoryModel.find({
            level: 1,
            type: "Merchandise",
          });
          let mIds = merchandiseCat.map((d) => d._id);
          query = query.find({ category_id: { $in: mIds } });
        } else {
          cat = (await categoryModel.findOne({ title: isShow, level: 1 }))?._id;
          query = query.find({ category_id: cat });
        }
      }
      query = query.sort({ create_date: -1 });
      if (keyword && keyword != "") {
        query = query.find({
          $or: [
            { name: { $regex: new RegExp(keyword, "ig") } },
            { description: { $regex: new RegExp(keyword, "ig") } },
          ],
        });
      }
      query = query
        .populate({ path: "collection_id", model: "collection" })
        .populate({ path: "category_id", model: "category" })
        .populate({ path: "artist", model: artistModel })
        .populate({ path: "catlevel2_id", model: "category"})
        .populate({ path: "catlevel3_id", model: "category" })
        .populate({
          path: "current_owner",
          model: "users",
          select:
            "_id username first_name last_name profile_image metamask_info is_idverified",
        })
        .populate({
          path: "author_id",
          model: "users",
          select:
            "_id username first_name last_name profile_image metamask_info is_idverified",
        })
        .populate({ path: "season_id", model: "seasons" });

      let result = await query.exec();
      let reactions = await itemreactionModel.find();
      let playLists = await itemplayModel.find();
      let comments = await itemcommentModel.find({ parent_id: null });
      let likes = await itemlikeModel.find();
      let loves = await itemloveModel.find();

      const updatedDocsPromises = result.map(async (d) => {
        const itemReactions = reactions.filter(
          (r) => r.item_id == d._doc._id.toString() && r.user_id == user_id
        );
        const reactionNumber = itemReactions.length
          ? itemReactions[0].reaction_number
          : -1;
        const up_to_next = await itemplayModel.findOne({
          item_id: d?._doc?._id?.toString(),
          user_id,
        });
        // check is follower, mute, block
        var _db_follower = await followers.findOne({
          star_id: d._doc?.author_id?._id,
          user_id: user_id,
        });
        //!!20231231 CoderA SpeedUp
        // var _db_block = await blockModel.findOne({
        //   block_user_id: d._doc?.author_id?._id,
        //   user_id: user_id,
        // });
        // var _db_mute = await muteModel.findOne({
        //   mute_user_id: d._doc?.author_id?._id,
        //   user_id: user_id,
        // });

        var date = new Date();

        if (d.es_enabled) {
          if (!d.es_is_auction) {
            if (d.es_enventories?.length > 0) {
            } else {
              if (d.es_b_limited && d.es_n_sell == 0) {
                d.es_enabled = false;
              }
              if (d.es_b_endMode == "noend") {
              } else {
                if (new Date(d.es_b_endDate).getTime() < date.getTime()) {
                  d.es_enabled = false;
                }
              }
            }
          } else {
            // check auction is finished or not
            if (new Date(d.es_a_endDate).getTime() < date.getTime()) {
              d.es_enabled = false;
            }
            // if not
            if (d.es_enabled) {
              // get the current bid
              let c_bid = await offers
                .findOne({
                  type: "bid",
                  item_id: d._id,
                  edition: "standard",
                })
                .sort({ price: -1 })
                .limit(1)
                .exec();
              var currentbid = c_bid?.price;
              if (currentbid) {
                d.es_a_starting_price = currentbid;
              }
            }
          }
        }

        if (d.ec_enabled) {
          if (!d.ec_is_auction) {
            if (d.ec_enventories?.length > 0) {
            } else {
              if (d.ec_b_limited && d.ec_n_sell == 0) {
                d.ec_enabled = false;
              }
              if (d.ec_b_endMode == "noend") {
              } else {
                if (new Date(d.ec_b_endDate).getTime() < date.getTime()) {
                  d.ec_enabled = false;
                }
              }
            }
          } else {
            // check auction is finished or not
            if (new Date(d.ec_a_endDate).getTime() < date.getTime()) {
              d.ec_enabled = false;
            }
            // if not
            if (d.ec_enabled) {
              // get the current bid
              let c_bid = await offers
                .findOne({
                  type: "bid",
                  item_id: d._id,
                  edition: "collective",
                })
                .sort({ price: -1 })
                .limit(1)
                .exec();
              var currentbid = c_bid?.price;
              if (currentbid) {
                d.ec_a_starting_price = currentbid;
              }
            }
          }
        }

        if (d.el_enabled) {
          if (!d.el_is_auction) {
            if (d.el_enventories?.length > 0) {
            } else {
              if (
                (d.el_b_limited && d.el_n_sell == 0) ||
                d.el_n_now_sell == 0
              ) {
                d.el_enabled = false;
              }
              if (d.el_endMode == "noend") {
              } else {
                if (new Date(d.el_b_endDate).getTime() < date.getTime()) {
                  d.el_enabled = false;
                }
              }
            }
          } else {
            // check auction is finished or not
            if (new Date(d.el_a_endDate).getTime() < date.getTime()) {
              d.el_enabled = false;
            }
            // if not
            if (d.el_enabled) {
              // get the current bid
              let c_bid = await offers
                .findOne({
                  type: "bid",
                  item_id: d._id,
                  edition: "limited",
                })
                .sort({ price: -1 })
                .limit(1)
                .exec();
              var currentbid = c_bid?.price;
              if (currentbid) {
                d.el_a_starting_price = currentbid;
              }
            }
          }
        }

        let shared = await fanpostShareModel.findOne({ item_id: d._doc?._id, user_id: fanId })
          .populate({
            path: "user_id",
            model: "users",
            select: "_id first_name last_name username profile_image",
          })
          .populate({
            path: "item_comment_id",
            model: "item_comments",
            populate: [
              {
                path: "user_id",
                model: "users",
                select: "_id first_name last_name username profile_image",
              }
            ]
          });

        if (shared?.item_comment_id) {
          // console.log("shared?.item_comment_id?._id");//!!//!!20231230 CoderA too many log// disable temporarely
          // console.log(shared?.item_comment_id?._id);//!!//!!20231230 CoderA too many log// disable temporarely
          var reaction_number;
          var item_comment_reactions = await itemcommentreactionModel.findOne({
            item_comment_id: shared?.item_comment_id?._id,
            user_id
          });
          // console.log(item_comment_reactions);//!!//!!20231230 CoderA too many log// disable temporarely
          if (item_comment_reactions) {
            reaction_number = item_comment_reactions.reaction_number;
          }
          var isCommented = await itemcommentModel.findOne({
            parent_id: shared?.item_comment_id?._id,
            user_id
          }) != null ? true : false;
          // console.log("reaction_number",reaction_number);//!!//!!20231230 CoderA too many log// disable temporarely
          // console.log("isCommented",isCommented);//!!//!!20231230 CoderA too many log// disable temporarely
          // console.log("shared",shared);//!!//!!20231230 CoderA too many log// disable temporarely
          let new_item_comment_id = {
            ...shared.item_comment_id._doc,
            reaction_number,
            isCommented
          }
          // console.log(new_item_comment_id);//!!//!!20231230 CoderA too many log// disable temporarely
          shared = {
            ...shared._doc,
            item_comment_id: new_item_comment_id
          }
        }

        return {
          ...d.toObject(), // copy all the existing fields
          __type: "item",
          shared,
          reaction_number: reactionNumber,
          isPlayed: playLists.some(
            (pl) =>
              pl.item_id == d._doc._id.toString() && pl.user_id == user_id
          ),
          isCommented: comments.some(
            (pl) =>
              pl.item_id == d._doc._id.toString() && pl.user_id == user_id
          ),
          isLiked: likes.some(
            (pl) =>
              pl.item_id == d._doc._id.toString() && pl.user_id == user_id
          ),
          isLoved: loves.some(
            (pl) =>
              pl.item_id == d._doc._id.toString() && pl.user_id == user_id
          ),
          isBoosted: true,
          isUptoNext: up_to_next ? true : false,
          isFollow: _db_follower ? true : false,

          //!!20231231 CoderA SpeedUp
          isBlock: d._doc?.author_id?.block_list?.includes(user_id), //!!_db_block ? true : false,
          isMute: d._doc?.author_id?.mute_list?.includes(user_id),//!!_db_mute ? true : false,
          // isBlock: _db_block ? true : false,
          // isMute: _db_mute ? true : false,
          
        };
      })
      const updatedResult = await Promise.all(updatedDocsPromises);
      lists = [...lists, ...updatedResult];
    }

    lists = lists.sort((a, b) => ((b?.shared? b?.shared.created_date: b?.create_date) - ( a?.shared? a?.shared.created_date: a?.create_date)))

    console.log(getErrLine().str, "fanpost::getList.apiEnd.listSize:",lists.length,",req:",req.query);
    res.json({
      status: true,
      message: "fanpost retrieved successfully",
      data: lists,
      result: new Date(),
    });

  } catch (err) {
    console.log(err);
    res.json({
      status: false,
      message: err?.message,
    });
  }
};

/*
 *  This is the function which used to retreive fanpost detail by fanpost id
 */
exports.details = function (req, res) {
  console.log(getErrLine().str, "apistart");
  console.log("received params are ", req.params);
  fanposts.findOne({ _id: req.query.fanpost_id }).exec(function (err, fanpost) {
    if (err) {
      res.json({
        status: false,
        message: "Request failed",
        errors: "Fanpost not found",
      });
      return;
    }
    if (!fanpost) {
      res.json({
        status: false,
        message: "Request failed",
        errors: "Fanpost not found",
      });
      return;
    }
    res.json({
      status: true,
      message: "Fanpost info retrieved successfully",
      result: fanpost,
    });
  });
};

/**
 * This is the function which used to list all fanposts
 */
exports.getAdminList = function (req, res) {
  console.log(getErrLine().str, "apistart");
  var page = req.query.page ? req.query.page : "1";
  var limit = req.query.limit ? req.query.limit : "300";
  var query = fanposts.find();
  var offset = page == "1" ? 0 : parseInt(page - 1) * 10;
  query = query.where("creator_id", req.query.user_id);
  query = query.sort("-create_date");
  var options = {
    select:
      "description fanpost_image fanpost_video like_count love_count comment_count create_date",
    page: page,
    offset: offset,
    limit: limit,
  };
  fanposts.paginate(query, options).then(function (result) {
    res.json({
      status: true,
      message: "Fanpost retrieved successfully",
      data: result,
    });
  });
};

/**
 * This is the function which used to add fanpost from admin
 */
/* !!20240107pm11 coderd replace below code {(B) Link Preview : home and fanpage} */ 
exports.add = async function (req, res) {
  console.log(getErrLine().str, "apistart");
  let newfans = new fanposts(req.body);
  try {
    //!!20240117am3 coderd chaged below code {preview link} 
    const linkurls = req.body.description.match(/\b((https?|ftp|file):\/\/|(www|ftp)\.)[-A-Z0-9+&@#\/%?=~_|$!:,.;]*[A-Z0-9+&@#\/%=~_|$]/ig);
     //!!20240109am1 coderd added if  {(B) Link Preview : home and fanpage}
    // !!20240121pm7 coderd {(B) Link Preview}
    let new_linkurls = [];
    if(linkurls != null && linkurls.length != 0){
      for(let i of linkurls){
        if(i.slice(0,3) == "www"){
          new_linkurls.push("http://" + i);
        } else {
          new_linkurls.push(i);
        };
      };
    }
    if(new_linkurls !=null && new_linkurls.length != 0){
      const linkPreviewPromises = new_linkurls.map(url => getLinkPreview(url,
    // if(linkurls !=null && linkurls.length != 0){
    //   const linkPreviewPromises = linkurls.map(url => getLinkPreview(url,
      {
        followRedirects: `manual`,
        imagesPropertyType: "og", //!!20240123am4 coderd added this line {link preview}
        handleRedirects: (baseURL, forwardedURL) => {
          const urlObj = new URL(baseURL);
          const forwardedURLObj = new URL(forwardedURL);
          if (
            forwardedURLObj.hostname === urlObj.hostname ||
            forwardedURLObj.hostname === "www." + urlObj.hostname ||
            "www." + forwardedURLObj.hostname === urlObj.hostname
          ) {
            return true;
          } else {
            return false;
          }
        },
      }));
      await Promise.all(linkPreviewPromises).then(async (result) => {
      // !!20240117am2 coderd link preview
        newfans.previewDatas = result?result:[];
      }).catch(error => {
        res.json({
          status: false,
          "message": error.message
        });
        console.log(error)
      })
    }
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        res.json({
          status: false,
          message: "Request failed",
          errors: errors.array(),
        });
        return;
      }
      await newfans.save();
      let user = await users.findById(req.decoded.user_id);
      const posts_count = user.posts_count ? user.posts_count + 1 : 1;
      user.posts_count = posts_count;
      await user.save();

      // CREATE NOTIFICATION

      // FIND USERS WHO FOLLOW ME AND ENABLE RECEIVE NOTIFICATION
      let _followers = await followers.find({ star_id: req.body.creator_id });
      let _users = (
        await users.find({ _id: { $in: _followers }, "notif_posts.is_new": true })
      ).map((d) => d._id);
      let notif_users = _users;
      if (_users.length > 0) {
        let message = "";
        if (req.body.fanpost_images && req.body.fanpost_images.length > 0) {
          message = `Added ${req.body.fanpost_images.length} ${req.body.fanpost_images.length > 1 ? "images" : "image"
            }`;
        } else if (req.body.fanpost_video && req.body.fanpost_video != "") {
          message = "Added video";
        } else if (req.body.fanpost_audio && req.body.fanpost_audio != "") {
          message = "Added audio";
        } else if (
          req.body.fanpost_poll_question &&
          req.body.fanpost_poll_question != ""
        ) {
          message = "Added poll";
        } else {
          message = "Added a new post";
        }
        await Promise.all(
          _users.map(async (d) => {
            let new_notification = new notificationModel({
              type: NOTIFICATION_TYPES.POST_NEW,
              filter: NOTIFICATION_FILTERS.NEW_POSTS,
              message,
              from_id: user_id,
              to_id: d,
              item_id: newfans._id,
            });
            await new_notification.save();
          })
        );
      }

      res.json({
        status: true,
        message: "Created successfully",
        result: {
          notif_users,
        },
      });
    } catch (error) {
      console.log(error);
      res.json({
        status: false,
        message: "Something went wrong",
        errors: error,
      });
    }
  } catch (error) {
    res.json({
      status: false,
      message: error.message
    });
    throw error;
  };
};
//  exports.add = async function (req, res) {
//   console.log(getErrLine().str, "apistart");
//   var newfans = new fanposts(req.body);
//   // try {
//   //   previewDatas = [];
//   //   const linkurls = req.body.description.match(/\b((https?|ftp|file):\/\/|(www|ftp)\.)[-A-Z0-9+&@#\/%?=~_|$!:,.;]*[A-Z0-9+&@#\/%=~_|$]/ig);
//   //   console.log(linkurls);
//   //   linkurls.map(item => {
//   //     getLinkPreview(item).then(previewData => {
//   //       previewDatas.push(previewData);
//   //     }).catch(error => {
//   //       console.error(error);
//   //     });
//   //   });
//   //   newfans.previewDatas = previewDatas;
//   // } catch (error) {
//   //   console.log(error);
//   // };


  
//   newfans.author_id = req.decoded.user_id;

//   try {
//     const errors = validationResult(req);
//     if (!errors.isEmpty()) {
//       res.json({
//         status: false,
//         message: "Request failed",
//         errors: errors.array(),
//       });
//       return;
//     }
//     await newfans.save();
//     let user = await users.findById(req.decoded.user_id);
//     const posts_count = user.posts_count ? user.posts_count + 1 : 1;
//     user.posts_count = posts_count;
//     await user.save();

//     // CREATE NOTIFICATION

//     // FIND USERS WHO FOLLOW ME AND ENABLE RECEIVE NOTIFICATION
//     let _followers = await followers.find({ star_id: req.body.creator_id });
//     let _users = (
//       await users.find({ _id: { $in: _followers }, "notif_posts.is_new": true })
//     ).map((d) => d._id);
//     let notif_users = _users;
//     if (_users.length > 0) {
//       let message = "";
//       if (req.body.fanpost_images && req.body.fanpost_images.length > 0) {
//         message = `Added ${req.body.fanpost_images.length} ${req.body.fanpost_images.length > 1 ? "images" : "image"
//           }`;
//       } else if (req.body.fanpost_video && req.body.fanpost_video != "") {
//         message = "Added video";
//       } else if (req.body.fanpost_audio && req.body.fanpost_audio != "") {
//         message = "Added audio";
//       } else if (
//         req.body.fanpost_poll_question &&
//         req.body.fanpost_poll_question != ""
//       ) {
//         message = "Added poll";
//       } else {
//         message = "Added a new post";
//       }
//       await Promise.all(
//         _users.map(async (d) => {
//           let new_notification = new notificationModel({
//             type: NOTIFICATION_TYPES.POST_NEW,
//             filter: NOTIFICATION_FILTERS.NEW_POSTS,
//             message,
//             from_id: user_id,
//             to_id: d,
//             item_id: newfans._id,
//           });
//           await new_notification.save();
//         })
//       );
//     }

//     res.json({
//       status: true,
//       message: "Created successfully",
//       result: {
//         notif_users,
//       },
//     });
//   } catch (error) {
//     console.log(error);
//     res.json({
//       status: false,
//       message: "Something went wrong",
//       errors: error,
//     });
//   }
// };

exports.edit_description = async function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded.user_id;
  try {
    let fanpost = await fanposts.findById(req.body._id);
    if (fanpost) {
      if (fanpost.creator_id == user_id || fanpost.author_id == user_id) {
        let newHistory = new fanpostHistoryModel({
          fanpost_id: req.body._id,
          user_id,
          description: fanpost.description,
        });
        fanpost.description = req.body.description;
        await newHistory.save();
        await fanpost.save();
        res.json({
          status: true,
          message: "Updated successfully",
        });
      } else {
        res.json({
          status: false,
          message: "You can't edit",
        });
      }
    } else {
      res.json({
        status: false,
        message: "No list",
      });
    }
  } catch (error) {
    console.log(error);
    res.json({
      status: false,
      message: "Something went wrong",
    });
  }
};

/**
 *  This is the function which used to update fanpost
 */
exports.edit = function (req, res) {
  console.log(getErrLine().str, "apistart");
  fanposts.findOne({ _id: req.body.fanpost_id }, function (err, fanpost) {
    if (err || !fanpost) {
      res.json({
        status: false,
        message: "Fanpost not found",
        errors: err,
      });
      return;
    } else {
      fanpost.description = req.body.description
        ? req.body.description
        : fanpost.description;
      fanpost.fanpost_image = req.body.fanpost_image
        ? req.body.fanpost_image
        : fanpost.fanpost_image;
      fanpost.fanpost_video = req.body.fanpost_video
        ? req.body.fanpost_video
        : fanpost.fanpost_video;
      fanpost.love_count = req.body.love_count
        ? req.body.love_count
        : fanpost.love_count;
      fanpost.like_count = req.body.like_count
        ? req.body.like_count
        : fanpost.like_count;
      fanpost.comment_count = req.body.comment_count
        ? req.body.comment_count
        : fanpost.comment_count;
      fanpost.save(function (err, fanpost) {
        if (err) {
          res.json({
            status: false,
            message: "Request failed",
            errors: err,
          });
          return;
        } else {
          res.json({
            status: true,
            message: "Fanpost updated successfully",
            result: fanpost,
          });
        }
      });
    }
  });
};

/**
 *  This is the function which used to delete fanpost
 */
exports.delete = function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded.user_id;
  fanposts.findOne({ _id: req.body._id }, function (err, fanpost) {
    if (err || !fanpost) {
      res.json({
        status: false,
        message: "Fanpost not found",
        errors: err,
      });
      return;
    } else {
      if (fanpost.author_id == user_id || fanpost.creator_id == user_id) {
        fanpost.delete(function (err, result) {
          if (err) {
            res.json({
              status: false,
              message: "error was occured",
              errors: err,
            });
          } else {
            res.json({
              status: true,
              message: "deleted",
            });
          }
        });
      } else {
        res.json({
          status: false,
          message: "you can delete it.",
        });
      }
      // fanposts.deleteOne({_id:req.body.fanpost_id},function(err) {
      //     res.json({
      //         status: true,
      //         message: "Fanpost deleted successfully"
      //     });
      // })
    }
  });
};

/*
 * This is the function which used to list Loves of FanPost in database
 */
exports.actionLove = function (req, res) {
  console.log(getErrLine().str, "apistart");
  fanposts.findOne({ _id: req.body.fanpost_id }, function (err, post1) {
    if (err || !post1) {
      res.json({
        status: false,
        message: "Post not found",
        errors: err,
      });
      return;
    }
    loves.findOne(
      { fanpost_id: req.body.fanpost_id, user_id: req.body.user_id },
      function (err, retitem) {
        if (req.body.type == "increase") {
          if (!retitem) {
            post1.love_count = post1.love_count + 1;
            var newlove = new loves();
            newlove.user_id = req.body.user_id;
            newlove.fanpost_id = req.body.fanpost_id;
            newlove.save(function (err, result) {
              post1.save(function (err, result) {
                res.json({
                  status: true,
                  message: "Love added successfully",
                });
              });
            });
          } else {
            res.json({
              status: true,
              message: "Love added successfully",
            });
          }
        } else {
          if (!retitem) {
            res.json({
              status: true,
              message: "Love removed successfully",
            });
          } else {
            post1.love_count = post1.love_count - 1;
            loves.deleteOne({ _id: retitem._id }, function (err) {
              post1.save(function (err, result) {
                res.json({
                  status: true,
                  message: "Love removed successfully",
                });
              });
            });
          }
        }
      }
    );
  });
};

/*
 * This is the function which used to list Likes of FanPost in database
 */
exports.actionLike = function (req, res) {
  console.log(getErrLine().str, "apistart");
  fanposts.findOne({ _id: req.body.fanpost_id }, function (err, post1) {
    if (err || !post1) {
      res.json({
        status: false,
        message: "Post not found",
        errors: err,
      });
      return;
    }
    likes.findOne(
      { fanpost_id: req.body.fanpost_id, user_id: req.body.user_id },
      function (err, retitem) {
        if (req.body.type == "increase") {
          if (!retitem) {
            post1.like_count = post1.like_count + 1;
            var newlike = new likes();
            newlike.user_id = req.body.user_id;
            newlike.fanpost_id = req.body.fanpost_id;
            newlike.save(function (err, result) {
              post1.save(function (err, result) {
                res.json({
                  status: true,
                  message: "Like added successfully",
                });
              });
            });
          } else {
            res.json({
              status: true,
              message: "Like added successfully",
            });
          }
        } else {
          if (!retitem) {
            res.json({
              status: true,
              message: "Like removed successfully",
            });
          } else {
            post1.like_count = post1.like_count - 1;
            likes.deleteOne({ _id: retitem._id }, function (err) {
              post1.save(function (err, result) {
                res.json({
                  status: true,
                  message: "Like removed successfully",
                });
              });
            });
          }
        }
      }
    );
  });
};

/*
 * This is the function which used to list post1 in database
 */
exports.actionComment = function (req, res) {
  console.log(getErrLine().str, "apistart");
  fanposts.findOne({ _id: req.body.fanpost_id }, function (err, post1) {
    if (err || !post1) {
      res.json({
        status: false,
        message: "Post not found",
        errors: err,
      });
      return;
    }
    var newcomment = new comments(req.body);
    if (req.body.parent_id) {
      // Define comment_count and increment it before updating the document
      const parent_id = req.body.parent_id;
      comments.findById(parent_id, function (err, parent) {
        if (err) {
          console.error(err);
        } else {
          // Increment comment_count by 1
          if (parent.user_id != req.decoded.user_id) {
            const n_comment = parent.n_comment + 1;
            // Update the parent document with the new comment_count value
            comments.findByIdAndUpdate(
              parent_id,
              { n_comment: n_comment },
              function (err, doc) {
                if (err) {
                  console.error(err);
                } else {
                  console.log(doc);
                  newcomment.save(function (err, result) {
                    post1.save(function (err, result) {
                      res.json({
                        status: true,
                        message: "Comment added successfully",
                      });
                    });
                  });
                }
              }
            );
          }
        }
      });
    } else {
      post1.n_comment = post1.n_comment + 1;
      newcomment.save(function (err, result) {
        post1.save(function (err, result) {
          res.json({
            status: true,
            message: "Comment added successfully",
          });
        });
      });
    }
  });
};

/*
 * This is the function which used to list user who add the post1 as fan post1
 */
exports.listComment = function (req, res) {
  console.log(getErrLine().str, "apistart");
  var keyword = req.query.keyword || ""; // added dreampanda 20230523 pm 9
  var page = req.query.page ? req.query.page : "1";
  var limit = req.query.limit ? req.query.limit : "15";
  var parent_id = req.query.parent_id || "";
  var user_id = req.decoded.user_id;

  var query = comments.find();
  var offset = page == "1" ? 0 : parseInt(page - 1) * 10;
  if (parent_id != "") {
    query = query.find({ parent_id: parent_id });
  } else {
  }
  query = query.where("fanpost_id", req.query.fanpost_id);
  if (keyword != "") {
    query = query.find({ description: { $regex: new RegExp(keyword, "ig") } });
  }
  query = query.sort("-created_date");
  var options = {
    page: page,
    offset: offset,
    limit: limit,
  };
  var match = {};
  if (keyword != "") {
    match = {
      $or: [
        { first_name: { $regex: new RegExp(keyword, "ig") } },
        { last_name: { $regex: new RegExp(keyword, "ig") } },
        { username: { $regex: new RegExp(keyword, "ig") } },
        { email: { $regex: new RegExp(keyword, "ig") } },
      ],
    };
  }
  query = query.populate({
    path: "user_id",
    match: match,
    model: "users",
    select: "_id first_name last_name username profile_image is_idverified",
  });
  comments.paginate(query, options).then(function (result) {
    res.json({
      status: true,
      message: "Comments retrieved successfully",
      data: result,
    });
  });
};

// added by dreampanda 20230516 am 11
exports.vote_answer = function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded.user_id;
  try {
    fanposts
    .findOne({ _id: req.body.item_id }, function (err, fanpost) {
      if (err || !fanpost) {
        res.json({
          status: false,
          message: "Can't find",
          errors: err,
        });
        return;
      } else {
        if (fanpost.creator_id == user_id || fanpost.author_id == user_id) {
          res.json({ status: false, message: "You can't vote" });
          return;
        }

        // check poll vote is finished or not
        let created = new Date(fanpost.create_date);
        let end = new Date(
          created.getTime() +
          (Number(fanpost.fanpost_poll_delay) || 0) * 24 * 60 * 60 * 1000
        );
        let serverDate = new Date();
        if (serverDate.getTime() >= end.getTime()) {
          res.json({
            status: false,
            message: "You can't vote, vote is already finished.",
          });
          return;
        }

        fanpost.fanpost_poll_answer.map((pollAnswer, answerIndex) => {
          var voterIndex = pollAnswer.voters.findIndex((d) => d == user_id);
          // if I already voted on other answers, remove me from the list
          if (voterIndex != -1) {
            const votersArray = fanpost.fanpost_poll_answer[answerIndex].voters;
            const existingUserIndex = votersArray.indexOf(user_id);
            if (existingUserIndex != -1) {
              votersArray.splice(existingUserIndex, 1);
              fanpost.fanpost_poll_answer[answerIndex].voters = votersArray;
              console.log(fanpost);
            }
          }
        });

        // find the answer_idx that i just voted
        const answerIndex = fanpost.fanpost_poll_answer.findIndex(
          (answerObj) => answerObj.answer == req.body.answer
        );
        if (answerIndex != -1) {
          const votersArray = fanpost.fanpost_poll_answer[answerIndex].voters;
          votersArray.push(user_id);
          if(fanpost?.fanpost_poll_answer && fanpost?.fanpost_poll_answer[answerIndex]?.voters ) {
            fanpost.fanpost_poll_answer[answerIndex].voters = votersArray;
          }
          console.log(fanpost);
          try {
            return fanpost.save();  
          } catch (error) { 
            console.log(error.message)           
            return new Error("Answer not found!");
          }
          
        } else {
          // should never happend!
          return new Error("Answer not found");
        }
      }
    })
    .then((savedFanpost) => {
      res.json({
        status: true,
        message: "voted successfully",
      });
    })
    .catch((err) => {
      //!! crashes
      //!! https://copyprogramming.com/howto/node-js-server-crashes-after-put-request
      // res.json({
      //   status: false,
      //   message: "Db operation error",
      //   errors: err,
      // });
    });    
  } catch (error) {
    console.log(error);
    res.json({
      status: false,
      message: error?.message,
      result: false,
    });
  }

};

exports.getPhotoVideo = async function (req, res) {
  console.log(getErrLine().str, "apistart");
  const user_id = req.decoded?.user_id;
  const from_id = req.query.user_id;
  const type = req.query.type;
  const from = req.query.from;
  const page = req.query.page;
  const limit = req.query.limit;

  try {
    let query = fanposts.find();
    if(from_id) {
      query = query.find({ creator_id: from_id })
    } else {
      // get user based on from value;
      let from_ids = [];
      switch(from) {
        case 'Following':
          let _followings = await followers.find({ user_id:user_id }).distinct("star_id");
          from_ids = _followings
          break
        case 'Following you':
          let _followers = await followers.find({ star_id: user_id }).distinct("user_id");
          from_ids = _followers;
          break;
        case 'Fandoms':
          let start_date = new Date(new Date().setMonth(new Date().getMonth() - 1));
          let _subscribers = (await subscribers.find({
            unsubscribed: false,
            start_date: { $gte: start_date },
            user_id
          }))?.map(d => d?.subscription_id);
          let user_ids = (await subscriptionlevels.find({ _id: { $in: _subscribers } }))?.map(d =>{return d.user_id});
          let _fandoms = await fandoms.find({ user_id: { $in: user_ids }, status: 'published' });
          from_ids = _fandoms?.map(d =>{return d.user_id});
          break;
        default:
          break;
      }
      query = query.find({ author_id: { $in: from_ids } })
    }

    if(type == 'photo') {
      query = query.find({
        $or: [
          { fanpost_image: { $exists: true, $ne: "" } },
          { fanpost_images: { $exists: true, $not: { $size: 0 } } },
        ],
      })
    }
    if(type == 'video') {
      query = query.find({
        $and: [
          { fanpost_video: { $ne: "" } },
          { fanpost_video: { $ne: null } },
        ],
      })
    }
    // !!20240121pm11 coderd added below code {(B)desktop • fanpage}
    query = query.sort({ create_date: -1 });
    // let _posts = await query.sort({ create_date: -1 }).exec();
    query.exec((err,data)=>{
      if(err && data.length ==0 ){
        console.log(err);
      } else {
        let res_data = data.slice((page-1) * limit ,page * limit);
        res.json({
          status: true,
          result: res_data,
        })
      }
    })
    
    // let data = [];

    //     var tempD = data.slice((page - 1) * limit, page * limit);
    //     res.json({
    //       status: true,
    //       result: tempD,
    //     });
    
  } catch (error) {
    console.log(error);
        res.json({
      status: false,
      message: error.message
        });
      }
};

async function trendingFanposts(req, res) {
  console.log(getErrLine().str, "apistart");
  try {
    var user_id = req.decoded.user_id;

    // get param
    var type = req.query.type,
      rootCat = req.query.rootCat,
      _filter = req.query.filter,
      cat1 = req.query.cat1,
      cat2 = req.query.cat2,
      cat3 = req.query.cat3,
      cat4 = req.query.cat4,
      keyword = req.query.keyword || "",
      page = req.query.page || 1,
      limit = req.query.limit || 15,
      filterShow = req.query.filterShow,
      filterFrom = req.query.filterFrom,
      filterTime = req.query.filterTime,
      filterTimeFrom = req.query.filterTimeFrom,
      filterTimeTo = req.query.filterTimeTo,
      PostsFilterBy = req.query.PostsFilterBy || "";
      PostsFilterByFrom = req.query.PostsFilterByFrom || "";// 20240111pm8 CoderB "(B) discover - test “trending” and “for you” - I don’t think it’s working correctly"

    (tfilterFrom = req.query.tfilterFrom),
      (tfilterTime = req.query.tfilterTime),
      (tfilterTimeFrom = req.query.tfilterTimeFrom),
      (tfilterTimeTo = req.query.tfilterTimeTo),
      (TrendingOrderBy = req.query.TrendingOrderBy);

    
    if (type == "Marketplace") {
      cat1 = cat2;
      cat2 = cat3;
      cat3 = null;
    }
   console.log("filter",_filter);

    var pipeline = [];
   // 20240111pm8 CoderB "(B) discover - test “trending” and “for you” - I don’t think it’s working correctly"
   
  // pipeline.push({
  //   $sort: { create_date: -1 },
  // });

   switch (tfilterTime) {
      case "now":
        var date = new Date();
        var datestr = getDateStr(date);
        pipeline.push(
          {
            $addFields: {
              _nowFields: {
                $filter: {
                  input: `$daily_trending`,
                  as: "trend",
                  cond: {
                    $eq: ["$$trend.date", datestr],
                  },
                },
              },
            },
          },
          {
            $addFields: {
              nowSum: {
                // 20240112pm9 CoderB
                $sum: {
                  $filter: {
                    input: "$_nowFields.count",
                    as:"item",
                    cond: {
                      $ne:["$$item",null]
                    },
                  },
                },
                // $sum: {
                //   $filter: {
                //     input: "$_nowFields.count",
                //     cond: [],
                //   },
                // },
              },
            },
          },
          // {
          //   $sort: { nowSum: -1 },
          // }
        );
        break;
      case "yesterday":
        var date = new Date();
        date.setDate(date.getDate() - 1);
        var datestr = getDateStr(date);
        pipeline.push(
          {
            $addFields: {
              _yesterdayFields: {
                $filter: {
                  input: `$daily_trending`,
                  as: "trend",
                  cond: {
                    $eq: ["$$trend.date", datestr],
                  },
                },
              },
            },
          },
          {
            $addFields: {
              yesterdaySum: {
                // 20240112pm9 CoderB
                $sum: {
                  $filter: {
                    input: "$_yesterdayFields.count",
                    as:"item",
                    cond: {
                      $ne:["$$item",null]
                    },
                  },
                },
                // $sum: {
                //   $filter: {
                //     input: "$_yesterdayFields.count",
                //     cond: [],
                //   },
                // },
              },
            },
          },
          // {
          //   $sort: { yesterdaySum: -1 },
          // }
        );
        break;
      case "thisweek":
        var date = new Date();
        var weekAgo = new Date(new Date(new Date() - 7 * 24 * 60 * 60 * 1000));
        var datestr = getDateStr(weekAgo);
        console.log(datestr);
        pipeline.push(
          {
            $addFields: {
              _thisweekFields: {
                $filter: {
                  input: `$daily_trending`,
                  as: "trend",
                  cond: {
                    $gte: ["$$trend.date", datestr],
                  },
                },
              },
            },
          },
          {
            $addFields: {
              weeklySum: {
                // 20240112pm9 COderB
                $sum: {
                  $filter: {
                    input: "$_thisweekFields.count",
                    as:"item",
                    cond: {
                      $ne:["$$item",null]
                    },
                  },
                },
                // $sum: {
                //   $filter: {
                //     input: "$_thisweekFields.count",
                //     cond: [],
                //   },
                // },
              },
            },
          },
          // {
          //   $sort: { weeklySum: -1 },
          // }
        );
        break;
      case "thismonth":
        var date = new Date();
        var monthAgo = new Date(
          date.getFullYear(),
          date.getMonth() - 1,
          date.getDate()
        ); // Get date 1 month ago
        var datestr = getDateStr(monthAgo);
        pipeline.push(
          {
            $addFields: {
              _thismonthFields: {
                $filter: {
                  input: `$daily_trending`,
                  as: "trend",
                  cond: {
                    $gte: ["$$trend.date", datestr],
                  },
                },
              },
            },
          },
          {
            $addFields: {
              monthlySum: {
                // 20240112pm9 CoderB
                $sum: {
                  $filter: {
                    input: "$_thismonthFields.count",
                    as:"item",
                    cond: {
                      $ne:["$$item",null]
                    },
                  },
                },
                // $sum: {
                //   $filter: {
                //     input: "$_thismonthFields.count",
                //     cond: [],
                //   },
                // },
              },
            },
          },
          // {
          //   $sort: { monthlySum: -1 },
          // }
        );
        break;
      case "range":
        var startDate = new Date(tfilterTimeFrom);
        var endDate = new Date(tfilterTimeTo);
        var datestr1 = getDateStr(startDate);
        var datestr2 = getDateStr(endDate);

        pipeline.push(
          {
            $addFields: {
              _rangeFields: {
                $filter: {
                  input: `$daily_trending`,
                  as: "trend",
                  cond: {
                    $gte: ["$$trend.date", datestr1],
                    $lt: ["$$trend.date", datestr2],
                  },
                },
              },
            },
          },
          {
            $addFields: {
              rangeSum: {
                $sum: {
                  $filter: {
                    input: "$_rangeFields.count",
                    as:"item",
                    cond: {
                      $ne:["$$item",null]
                    },
                  },
                },
                // $sum: {
                //   $filter: {
                //     input: "$_rangeFields.count",
                //     cond: [],
                //   },
                // },
              },
            },
          },
          // {
          //   $sort: { rangeSum: -1 },
          // }
        );
        break;
      default:
        break;
    }

    let matchClause = {}; // for search
    let blocked_accounts = [
      ...(await blockModel.find({ user_id }))?.map(d => d?.block_user_id),
      ...(await blockModel.find({ block_user_id: user_id }))?.map(d => d?.user_id),
    ]
    if (_filter == "For you") {
      let followings = (await followers.find({ user_id })).map(
        (d) => d.star_id
      );
      // 20240112am1 CoderB "(B) discover - test “trending” and “for you” - I don’t think it’s working correctly"
      // let query = {
      //   creator_id: { $in: followings, $nin: blocked_accounts },
      // };
      
      matchClause = { ...matchClause, creator_id: { $in: followings, $nin: blocked_accounts } };
      console.log("matchClause",matchClause);
    }

    switch (PostsFilterBy) {
      case "Posts":
        break;
      case "Pictures":
        matchClause = {
          $or: [
            { fanpost_image: { $exists: true, $ne: "" } },
            { fanpost_images: { $exists: true, $not: { $size: 0 } } },
          ],
        };
        break;
      case "Videos":
        matchClause = {
          $and: [
            { fanpost_video: { $ne: "" } },
            { fanpost_video: { $ne: null } },
          ],
        };
        break;
      case "Fans only":
        matchClause = {
          is_view_only: { $in: ["Fans Only", "fans", "superfans"] },
        };
        break;
      default:
        break;
    }
    switch (PostsFilterByFrom) {
      case "everybody":
        break;
      case "fans":
        matchClause = { ...matchClause,
          is_view_only: "fans",
        };
        break;
      case "superfans":
        matchClause = { ...matchClause,
          is_view_only: "superfans",
        };
        break;
      case "fansuperfans":
        matchClause = { ...matchClause,
          is_view_only: { $in: ["Fans Only", "fans", "superfans"] },
        };
        break;
      default:
        break;
    }
   

    switch (tfilterFrom) {
      case "Everybody":
        // Do nothing, get all posts
        break;
      case "following":
        let _followings = (await followers.find({ user_id })).map((d) =>
          ObjectID(d.star_id)
        );
        // pipeline.push({ $match: { author_id: { $in: _followings } } });
        matchClause.author_id = { $in: _followings };
        break;
      default:
        break;
    }

    // don't display content when fandom is not published
    var _fandoms = await fandoms.find({ status: "published" });
    _fandoms = _fandoms.map((d) => {
      return d.user_id;
    });
    // 20240105am2 CoderB "(B)Discover > posts isn’t showing all posts" : All video posts isn't working
    // disabled following line in order to fix issues.
    // matchClause.creator_id = { $in: _fandoms };

    // don't display content depend on subscription levels
    let users_with_fans = (await subscriptionlevels.find({ level: 'basic' })).map(d => d.user_id);
    let users_with_superfans = (await subscriptionlevels.find({ level: 'super' })).map(d => d.user_id);

    let filter_ids_by_super = (await fanposts.find({
      creator_id: {
        $nin: [...users_with_superfans, ...blocked_accounts]
      },
      $or: [
        { is_view_only: 'superfans' },
        { is_relay_only: 'superfans' }
      ]
    })).map(d => d._id);

    let filter_ids_by_basic = (await fanposts.find({
      $and: [
        { creator_id: { $nin: users_with_fans } },
        { creator_id: { $nin: users_with_superfans } },
        { creator_id: { $nin: blocked_accounts } },
      ],
      $or: [
        { is_view_only: 'fans' },
        { is_relay_only: 'fans' }
      ]
    })).map(d => d._id);
    // 20240105am2 CoderB "(B)Discover > posts isn’t showing all posts" : All video posts isn't working
    // disabled following line in order to fix issues.
    // matchClause._id = { $in: filter_ids_by_basic };
    // matchClause._id = { $in: filter_ids_by_super };
   // 20240112pm8 CoderB "(B) discover - test “trending” and “for you” - I don’t think it’s working correctly"
 
  if(_filter == "Trending"&&tfilterTime=="now"){
    console.log('Trending')
    pipeline.push({
      $sort: {nowSum:-1,n_love:-1,n_like:-1,n_play:-1},
    });
  }else if(_filter == "Trending"&&tfilterTime=="yesterday"){
    console.log('Trending')
    pipeline.push({
      $sort: {yesterdaySum:-1,n_love:-1,n_like:-1,n_play:-1},
    });
  }else if(_filter == "Trending"&&tfilterTime=="thisweek"){
    console.log('Trending')
    pipeline.push({
      $sort: {weeklySum:-1,n_love:-1,n_like:-1,n_play:-1},
    });
  }else if(_filter == "Trending"&&tfilterTime=="thismonth"){
    console.log('Trending')
    pipeline.push({
      $sort: {monthlySum:-1,n_love:-1,n_like:-1,n_play:-1},
    });
  }else if(_filter == "Trending"&&tfilterTime=="range"){
    console.log('Trending')
    pipeline.push({
      $sort: {rangeSum:-1,n_love:-1,n_like:-1,n_play:-1},
    });
  }else{
    // pipeline.push({
    //   $sort: { create_date: -1 },
    // });
  }

    pipeline.push({
      $match: matchClause,
    });
  
    var offset = page == "1" ? 0 : parseInt(page - 1) * limit;
    const countPipeline = [...pipeline, { $count: "count" }];
    pipeline.push(
      {
        $skip: offset,
      },
      {
        $limit: Number(limit),
      }
    );
    const [docs, countResult] = await Promise.all([
      fanposts.aggregate(pipeline).exec(),
      fanposts.aggregate(countPipeline).exec(),
    ]);


    const totalDocs = countResult[0] ? countResult[0].count : 0;
    const currentPage = parseInt(req.query.page) || 1;
    const _limit = parseInt(req.query.limit) || 10;
    const totalPages = Math.ceil(totalDocs / limit);
    const hasNextPage = currentPage < totalPages;
    const nextPage = hasNextPage ? currentPage + 1 : null;

    let _reactions = await reactions.find();
    let _comments = await comments.find({ parent_id: null });
    let _loves = await loves.find();
    let _boosts = await fanpostShareModel.find();
    const updatedDocs = await Promise.all(
      docs.map(async (d) => {
        let author_id = await users.findById(d.author_id, {
          first_name: 1,
          last_name: 1,
          username: 1,
          is_idverified: 1,
          profile_image: 1,
        });

        let _members = await members.find({ star_id: d?.creator_id });
        let _fans = await fans.find({ star_id: d?.creator_id });
        let _followers = await followers.find({ star_id: d?.creator_id });
        let _followings = await followers.find({ star_id: user_id });
        let isFan = _fans.some((f) => f.user_id == user_id);
        let membership;
        if (isFan) {
          let _memberships = await subscriptionlevels.find({
            user_id: d?.creator_id,
          });
          _memberships.map((d) => {
            return d._id;
          });
          var _start_date = new Date();
          _start_date.setMonth(_start_date.getMonth() - 1);
          membership = await subscribers
            .findOne({
              user_id: user_id,
              subscription_id: { $in: _memberships },
              unsubscribed: false,
              start_date: { $gte: _start_date },
            })
            .populate("subscription_id");
        }

        let histories = await fanpostHistoryModel.find({ fanpost_id: d._id });

        let InfoForUser = {
          isMember: _members.some((m) => m.user_id == user_id),
          isFan: isFan,
          membership: membership,
          isFollower: _followers.some((f) => f.user_id == user_id),
          isFollowing: _followings.some((f) => f.user_id == d.creator_id),
        };

        // check edited or not

        const fanpostReactions = _reactions.filter(
          (r) => r.fanpost_id == d._id.toString() && r.user_id == user_id
        );
        const reactionNumber = fanpostReactions.length
          ? fanpostReactions[0].reaction_number
          : -1;

        var _db_follower = await followers.findOne({
          star_id: d._doc?.author_id?._id,
          user_id: user_id,
        });
        var _db_block = await blockModel.findOne({
          block_user_id: d._doc?.author_id?._id,
          user_id: user_id,
        });
        var _db_mute = await muteModel.findOne({
          mute_user_id: d._doc?.author_id?._id,
          user_id: user_id,
        });

        return {
          ...d,
          author_id: author_id,
          reaction_number: reactionNumber,
          isCommented: _comments.some(
            (pl) => pl.fanpost_id == d._id.toString() && pl.user_id == user_id
          ),
          isLoved: _loves.some(
            (pl) => pl.fanpost_id == d._id.toString() && pl.user_id == user_id
          ),
          isBoosted: _boosts.some(
            (pl) => pl.fanpost_id == d._id.toString() && pl.user_id == user_id
          ),
          InfoForUser,
          serverDate: new Date(),
          isEdited: histories.length > 0 ? true : false,
          isFollow: _db_follower ? true : false,
          isBlock: _db_block ? true : false,
          isMute: _db_mute ? true : false,
        };
      })
    );

    res.json({
      status: true,
      message: "fanposts trend retrieved successfully",
      data: {
        docs: updatedDocs,
        totalDocs,
        limit: _limit,
        totalPages,
        currentPage,
        hasNextPage,
        nextPage,
        matchClause
      },
    });
  } catch (e) {
    console.log(e);
    res.json({
      status: false,
      message: "something went wrong",
    });
  }
}

exports.fanposts = async function (req, res) {
  console.log(getErrLine().str, "apistart");
  if (
    req.query.rootCat == "Trending" ||
    req.query.filter == "For you" ||
    req.query.filter == "Trending"
  ) {
    trendingFanposts(req, res);
  } else {
    try {
      var user_id = req.decoded.user_id;
      // get param
      var type = req.query.type,
        rootCat = req.query.rootCat,
        cat1 = req.query.cat1,
        cat2 = req.query.cat2,
        cat3 = req.query.cat3,
        cat4 = req.query.cat4,
        keyword = req.query.keyword || "",
        page = req.query.page || 1,
        limit = req.query.limit || 15,
        PostsFilterBy = req.query.PostsFilterBy || "";
      PostsFilterByFrom = req.query.PostsFilterByFrom || "";

      fFavorites = req.query.fFavorites;

      (filterShow = req.query.filterShow),
        (filterFrom = req.query.filterFrom),
        (filterTime = req.query.filterTime),
        (filterTimeFrom = req.query.filterTimeFrom),
        (filterTimeTo = req.query.filterTimeTo);
      // new parameter will be added

      var blocked_accounts = [
        ...(await blockModel.find({ user_id }))?.map(d => d?.block_user_id),
        ...(await blockModel.find({ block_user_id: user_id }))?.map(d => d?.user_id)
      ]

      var query = fanposts.find();

      /*!!20240103am2 coderd {(B) discover -  if you have blocked a user or you have been blocked - you both can’t see each others items in discover }*/
      query = query.find({ creator_id: { $nin: blocked_accounts } });

      query = query.sort({ create_date: -1 });
      query = query.sort({ priority: -1 });

      if (rootCat == "Trending") {
        query.sort("-n_trending");
      }
      query.populate({
        path: "author_id",
        model: "users",
        select: "_id username first_name last_name profile_image metamask_info",
      });
      if (keyword != "") {
        query.find({
          $or: [{ description: { $regex: new RegExp(keyword, "ig") } }],
        });
      }

      // filter I made favorite
      if (fFavorites) {
        var itemIds = (await loves.find({ user_id })).map((d) => d.fanpost_id);
        query = query.find({ _id: { $in: itemIds } });
      }

      switch (PostsFilterBy) {
        case "Posts":
          break;
        case "Pictures":
          query = query.find({
            $or: [
              { fanpost_image: { $exists: true, $ne: "" } },
              { fanpost_images: { $exists: true, $not: { $size: 0 } } },
            ],
          });
          break;
        case "Videos":
          console.log("fanpost::fanpost-PostsFilterBy:Videos")
          query = query.find({
            $and: [
              { fanpost_video: { $ne: "" } },
              { fanpost_video: { $ne: null } },
            ],
          });
          break;
        case "Fans only":
          query = query.find({
            is_view_only: { $in: ["Fans Only", "fans", "superfans"] },
          });
          break;
        default:
          break;
      }

      switch (PostsFilterByFrom) {
        case "everybody":
          break;
        case "fans":
          query = query.find({
            is_view_only: "fans",
          });
          break;
        case "superfans":
          console.log("superFans")
          query = query.find({
            is_view_only: "superfans",
          });
          break;
        case "fansuperfans":
          query = query.find({
            is_view_only: { $in: ["Fans Only", "fans", "superfans"] },
          });
          break;
        default:
          break;
      }

      let _reactions = await reactions.find();
      let _comments = await comments.find();
      let _loves = await loves.find();
      let _boosts = await fanpostShareModel.find();

      _m_reactions = _reactions
        .filter((d) => d.user_id == user_id)
        .map((d) => d.fanpost_id);
      _m_comments = _comments
        .filter((d) => d.user_id == user_id)
        .map((d) => d.fanpost_id);
      _m_loves = _loves
        .filter((d) => d.user_id == user_id)
        .map((d) => d.fanpost_id);
      _m_boosts = _boosts
        .filter((d) => d.user_id == user_id)
        .map((d) => d.fanpost_id);

      switch (filterShow) {
        case "Everything":
          break;

        case "seen":
          query = query.find({
            $or: [
              { _id: { $in: _m_reactions } },
              { _id: { $in: _m_comments } },
              { _id: { $in: _m_loves } },
              { _id: { $in: _m_boosts } },
            ],
          });
          break;
        case "notseen":
          query = query.find({
            $and: [
              { _id: { $nin: _m_reactions } },
              { _id: { $nin: _m_comments } },
              { _id: { $nin: _m_loves } },
              { _id: { $nin: _m_boosts } },
            ],
          });
          break;
        default:
          break;
      }

      let user = await users.findById(user_id);
      switch (filterFrom) {
        case "Everybody":
          break;
        case "following":
          let _followings = (await followers.find({ user_id })).map(
            (d) => d.star_id
          );
          query = query.find({ author_id: { $in: _followings } });
          break;
        case "muted":
          query = query.find({
            author_id: { $in: user?.muted_block?.muted_accounts },
          });
          break;
        default:
          break;
      }

      switch (filterTime) {
        case "anytime":
          break;
        case "today":
          var date = new Date();
          var startOfToday = new Date(
            date.getFullYear(),
            date.getMonth(),
            date.getDate()
          );
          var endOfToday = new Date(
            startOfToday.getTime() + 24 * 60 * 60 * 1000 - 1
          ); // End of day is one millisecond before start of next day
          query = query.find({
            create_date: { $gte: startOfToday, $lt: endOfToday },
          });
          break;
        case "thisweek":
          query = query.find({
            create_date: {
              $gte: new Date(new Date() - 7 * 24 * 60 * 60 * 1000),
            },
          });
          break;
        case "thismonth":
          var date = new Date();
          var monthStart = new Date(date.getFullYear(), date.getMonth(), 1); // Get first day of current month
          var monthEnd = new Date(date.getFullYear(), date.getMonth() + 1, 0); // Get last day of current month
          query = query.find({
            create_date: { $gte: monthStart, $lte: monthEnd },
          });
          break;
        case "range":
          var startDate = new Date(filterTimeFrom);
          var endDate = new Date(filterTimeTo);
          query = query.find({
            create_date: { $gte: startDate, $lte: endDate },
          });
          break;
        default:
          break;
      }

      // don't display content when fandom is not published
      /*-- 20240103am6 CoderX '(B) when I added a new post, it does not show up in Discover - Post New' --*/
      var _fandoms = await fandoms.find();
      // var _fandoms = await fandoms.find({ status: "published" });
      _fandoms = _fandoms.map((d) => {
        return d.user_id;
      });
      query = query.find({ creator_id: { $in: _fandoms } });


      // don't display content depend on subscription levels
      let users_with_fans = (await subscriptionlevels.find({ level: 'basic' })).map(d => d.user_id);
      let users_with_superfans = (await subscriptionlevels.find({ level: 'super' })).map(d => d.user_id);

      let filter_ids_by_super = (await fanposts.find({
        creator_id: {
          $nin: [...users_with_superfans, ...blocked_accounts]
        },
        $or: [
          { is_view_only: 'superfans' },
          { is_relay_only: 'superfans' }
        ]
      })).map(d => d._id);

      let filter_ids_by_basic = (await fanposts.find({
        $and: [
          { creator_id: { $nin: users_with_fans } },
          { creator_id: { $nin: users_with_superfans } },
          { creator_id: { $nin: blocked_accounts } }
        ],
        $or: [
          { is_view_only: 'fans' },
          { is_relay_only: 'fans' }
        ]
      })).map(d => d._id);


      //?? 2024.1.8 CoderA "(B)Discover > posts isn’t showing all posts"
      // query = query.find({
      //   $and: [
      //     { _id: { $nin: filter_ids_by_basic } },
      //     { _id: { $nin: filter_ids_by_super } },
      //   ]
      // });



      var offset = page == "1" ? 0 : parseInt(page - 1) * limit;
      var options = {
        page: page,
        offset: offset,
        limit: limit,
      };
      fanposts.paginate(query, options).then(async function (result) {
        const updatedDocsPromises = result.docs.map(async (d) => {
          // console.log(playLists.some(pl => pl.fanpost_id == d._doc._id && pl.user_id == user_id))
          // !!20240123pm6 coderd added below code {debug fandoms}
          let fandomInfo = await fandoms.find({user_id : d._doc?.creator_id});

          let _members = await members.find({ star_id: d._doc?.creator_id });
          let _fans = await fans.find({ star_id: d._doc?.creator_id });
          let _followers = await followers.find({
            star_id: d._doc?.creator_id,
          });
          let _followings = await followers.find({ star_id: user_id });

          let isFan = _fans.some((f) => f.user_id == user_id);
          let membership;
          if (isFan) {
            let _memberships = await subscriptionlevels.find({
              user_id: d._doc?.creator_id,
            });
            _memberships.map((d) => {
              return d._id;
            });
            var _start_date = new Date();
            _start_date.setMonth(_start_date.getMonth() - 1);
            membership = await subscribers
              .findOne({
                user_id: user_id,
                subscription_id: { $in: _memberships },
                unsubscribed: false,
                start_date: { $gte: _start_date },
              })
              .populate("subscription_id");
          }

          let InfoForUser = {
            isMember: _members.some((m) => m.user_id == user_id),
            isFan: isFan,
            membership: membership,
            isFollower: _followers.some((f) => f.user_id == user_id),
            isFollowing: _followings.some((f) => f.user_id == d.creator_id),
          };

          let histories = await fanpostHistoryModel.find({ fanpost_id: d._id });

          const itemReactions = _reactions.filter(
            (r) => r.fanpost_id == d._doc._id.toString() && r.user_id == user_id
          );
          const reactionNumber = itemReactions.length
            ? itemReactions[0].reaction_number
            : -1;
          return {
            ...d._doc, // copy all the existing fields
            reaction_number: reactionNumber,
            isCommented: _comments.some(
              (pl) =>
                pl.fanpost_id == d._doc._id.toString() && pl.user_id == user_id
            ),
            isLoved: _loves.some(
              (pl) =>
                pl.fanpost_id == d._doc._id.toString() && pl.user_id == user_id
            ),
            isBoosted: _boosts.some(
              (pl) =>
                pl.fanpost_id == d._doc._id.toString() && pl.user_id == user_id
            ),
            InfoForUser: InfoForUser,
            serverDate: new Date(),
            isEdited: histories?.length > 0 ? true : false,
            fandomInfo:fandomInfo //!!20240123pm6 coder added below code {debug fandoms}
          };
        });
        const updatedDocs = await Promise.all(updatedDocsPromises);
        const updatedResult = { ...result, docs: updatedDocs };

        res.json({
          status: true,
          message: "Fanpost retrieved successfully",
          data: updatedResult,
        });
      });
    } catch (err) {
      console.log(err);
      res.json({
        status: false,
        message: "Something went wrong",
      });
    }
  }
};

exports.create_fanpost_reaction = function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded.user_id;
  var fanpost_id = req.body.fanpost_id;
  var reaction_number = req.body.reaction_number;
  reactions.findOne({ fanpost_id, user_id }, function (err, result) {
    if (err) {
      res.json({
        status: false,
        message: "db error",
      });
    }
    if (result) {
      if (result.reaction_number == reaction_number) {
        fanposts.findById(fanpost_id, function (err, fanpost) {
          if (err || !fanpost) {
            res.json({
              status: false,
              message: "Item not found",
            });
            return;
          }
          const n_reaction = fanpost.n_reaction - 1;
          fanpost.n_reaction = n_reaction;
          const n_reaction_detail =
            fanpost.n_reaction_detail[`r_${reaction_number}`] - 1;
          fanpost.n_reaction_detail[`r_${reaction_number}`] = n_reaction_detail;

          var date = new Date();
          var datestr = getDateStr(date);

          let daily_trending = fanpost.daily_trending.find(
            (d) => d.date == datestr
          );
          if (daily_trending) {
            let count = daily_trending.count - 1;
            daily_trending.count = count;
          } else {
            let newObj = {
              date: datestr,
              count: -1,
            };
            fanpost.daily_trending.push(newObj);
          }

          fanpost.save(function (err, fanpostSaved) {
            reactions.remove({ _id: result._id }, function (err, result) {
              if (err || !result) {
                res.json({
                  status: false,
                  message: "Something went wrong",
                });
              } else {
                res.json({
                  status: true,
                  message: "Removed successfully",
                });
              }
            });
          });
        });
      } else {
        fanposts.findById(fanpost_id, function (err, fanpost) {
          if (err || !fanpost) {
            res.json({
              status: false,
              message: "Item not found",
            });
            return;
          }
          const n_reaction_detail =
            fanpost.n_reaction_detail[`r_${reaction_number}`] + 1;
          fanpost.n_reaction_detail[`r_${reaction_number}`] = n_reaction_detail;
          const last_n_reaction_detail =
            fanpost.n_reaction_detail[`r_${result.reaction_number}`] - 1;
          fanpost.n_reaction_detail[`r_${result.reaction_number}`] =
            last_n_reaction_detail;
          fanpost.save(function (err, fanpostSaved) {
            result.reaction_number = reaction_number;
            result.save(async function (err, result) {
              if (err || !result) {
                res.json({
                  status: false,
                  message: "Update error",
                });
                return;
              }

              let notif_users = [];
              let user = await users.findById(fanpost.creator_id);
              if (user.notif_posts?.is_reactions) {
                // CHECK WHETHER HE READ HIS NOTIFICATION OR NOT
                let notification = await notificationModel.findOne({
                  type: NOTIFICATION_TYPES.POST_REACTION,
                  filter: NOTIFICATION_FILTERS.NEW_REACTIONS,
                  item_id: fanpost._id,
                  to_id: fanpost.creator_id,
                  is_read: false,
                });
                if (notification) {
                  if (notification.from_id != user_id) {
                    const n_user = notification.n_user + 1;
                    notification.n_user = n_user;
                  } else {
                    notification.reaction_number = reaction_number;
                  }
                  notification.create_date = new Date();
                  await notificationModel.findByIdAndUpdate(
                    notification._id,
                    notification
                  );
                  notif_users.push(fanpost.creator_id);
                } else {
                  let new_notification = new notificationModel({
                    type: NOTIFICATION_TYPES.POST_REACTION,
                    filter: NOTIFICATION_FILTERS.NEW_REACTIONS,
                    message: `Reacted to your post`,
                    from_id: user_id,
                    to_id: fanpost.creator_id,
                    item_id: fanpost._id,
                    reaction_number,
                  });
                  await new_notification.save();
                  notif_users.push(fanpost.creator_id);
                }
              }

              res.json({
                status: true,
                message: "updated successfully",
                result: {
                  notif_users,
                },
              });
            });
          });
        });
      }
    } else {
      var newOne = reactions({ fanpost_id, user_id, reaction_number });
      fanposts.findById(fanpost_id, async function (err, fanpost) {
        if (err || !fanpost) {
          res.json({
            status: false,
            message: "Item not found",
          });
          return;
        }
        const n_reaction = fanpost.n_reaction + 1;
        fanpost.n_reaction = n_reaction;
        const n_reaction_detail =
          fanpost.n_reaction_detail[`r_${reaction_number}`] + 1;
        fanpost.n_reaction_detail[`r_${reaction_number}`] = n_reaction_detail;

        var date = new Date();
        var datestr = getDateStr(date);

        let daily_trending = fanpost.daily_trending.find(
          (d) => d.date == datestr
        );
        if (daily_trending) {
          let count = daily_trending.count + 1;
          daily_trending.count = count;
        } else {
          let newObj = {
            date: datestr,
            count: 1,
          };
          fanpost.daily_trending.push(newObj);
        }

        // let n_trending = fanpost.daily_trending[datestr] || 0;
        // fanpost.daily_trending[datestr] = n_trending + 1;
        try {
          await fanpost.save();
          await newOne.save();

          // CREATE REACT NOTIFICATION
          // CHECK WHETNER CREATEROR SET HIS NOTIFICATION SETTING
          let notif_users = [];
          let user = await users.findById(fanpost.creator_id);
          if (user.notif_posts?.is_reactions) {
            // CHECK WHETHER HE READ HIS NOTIFICATION OR NOT
            let notification = await notificationModel.findOne({
              type: NOTIFICATION_TYPES.POST_REACTION,
              filter: NOTIFICATION_FILTERS.NEW_REACTIONS,
              item_id: fanpost._id,
              to_id: fanpost.creator_id,
              is_read: false,
            });
            if (notification) {
              if (notification.from_id != user_id) {
                const n_user = notification.n_user + 1;
                notification.n_user = n_user;
              } else {
                notification.reaction_number = reaction_number;
              }
              notification.create_date = new Date();
              await notificationModel.findByIdAndUpdate(
                notification._id,
                notification
              );
              notif_users.push(fanpost.creator_id);
            } else {
              let new_notification = new notificationModel({
                type: NOTIFICATION_TYPES.POST_REACTION,
                filter: NOTIFICATION_FILTERS.NEW_REACTIONS,
                message: `Reacted to your post`,
                from_id: user_id,
                to_id: fanpost.creator_id,
                item_id: fanpost._id,
                reaction_number,
              });
              await new_notification.save();
              notif_users.push(fanpost.creator_id);
            }
          }

          res.json({
            status: true,
            message: "Saved successfully",
            result: {
              notif_users,
            },
          });
        } catch (e) {
          console.log(e);
          res.json({
            status: false,
            message: "Item save error",
          });
        }
      });
    }
  });
};

exports.read_fanpost_reactions = function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded.user_id;
  var fanpost_id = req.query.fanpost_id;
  fanposts.findById(fanpost_id, function (err, result) {
    if (err) {
      res.json({
        status: false,
        message: "db error",
      });
      return;
    }
    reactions.findOne({ fanpost_id, user_id }, function (err, reaction) {
      if (err) {
        res.json({
          status: false,
          message: "Db error",
        });
      } else {
        var resData = {
          data: result,
          reaction: reaction,
        };
        res.json({
          status: true,
          message: "retrieved successfully",
          result: resData,
        });
      }
    });
  });
};

exports.create_fanpost_play = function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded.user_id;
  var fanpost_id = req.body.fanpost_id;

  fanposts.findById(fanpost_id, function (err, fanpost) {
    if (err || !fanpost) {
      res.json({
        status: false,
        message: "Db error or not found fanpost",
      });
      return;
    }
    fanpost_plays.findOne(
      { fanpost_id: fanpost_id, user_id: user_id },
      function (err, result) {
        if (err || result) {
          res.json({ status: false, message: "Db error or already done" });
          return;
        } else {
          var newOne = new fanpost_plays({
            fanpost_id: fanpost_id,
            user_id: user_id,
          });
          const n_play = fanpost.n_play + 1;
          fanpost.n_play = n_play;
          newOne.save(function (err, result) {
            fanpost.save(function (err, result) {
              res.json({
                status: true,
                message: "Saved successfully",
              });
            });
          });
        }
      }
    );
  });
};

exports.read_fanpost_plays = function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded.user_id;
  fanpost_plays.find({ user_id: user_id }, function (err, result) {
    if (err) {
      res.json({
        status: false,
        message: "db error",
      });
      return;
    }
    res.json({
      status: true,
      message: "retrieved successfully",
      result: result,
    });
  });
};

exports.create_fanpost_comment_like = function (req, res) {
  console.log(getErrLine().str, "apistart");
  var comment_id = req.body.comment_id;
  var user_id = req.decoded.user_id;
  comments.findById(comment_id, function (err, fanpost_comment) {
    comments.findOne(
      { _id: comment_id, user_id: user_id },
      function (err, result) {
        if (err || result) {
          res.json({
            status: false,
            message: "Db error or already done",
          });
          return;
        }
        const n_comment = fanpost_comment.n_comment;
        fanpost_comment.n_comment = n_comment;
        fanpost_comment.save(function (err, result) {
          var newOne = new fanpost_comment_likes({
            comment_id: comment_id,
            user_id: user_id,
          });
          newOne.save(function (err, result) {
            if (err) {
              res.json({
                status: false,
                message: "Db error",
              });
              return;
            }
            res.json({
              status: true,
              message: "Saved successfully.",
            });
          });
        });
      }
    );
  });
};

exports.create_fanpost_comment_love = function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded.user_id;
  var fanpost_comment_id = req.body.fanpost_comment_id;
  fanpost_comment_loves.findOne(
    { fanpost_comment_id, user_id },
    async function (err, result) {
      if (err) {
        res.json({
          status: false,
          message: "Db error or already done",
        });
        return;
      } else {
        if (result) {
          try {
            let fanpost_comment = await comments.findById(fanpost_comment_id);
            if (fanpost_comment) {
              // decrease the love number
              const n_love = fanpost_comment.n_love - 1;
              fanpost_comment.n_love = n_love;
              fanpost_comment.save();
              result.remove();
              res.json({
                status: true,
                message: "Removed successfully.",
              });
            } else {
              res.json({
                status: false,
                message: "Not found fanpost comment",
              });
            }
          } catch (error) {
            res.json({
              status: false,
              message: "Something weng wrong",
            });
          }
        } else {
          var newOne = fanpost_comment_loves({
            fanpost_comment_id,
            user_id,
          });
          comments.findById(
            fanpost_comment_id,
            function (err, fanpost_comment) {
              if (err || !fanpost_comment) {
                res.json({
                  status: false,
                  message: "Db error or not found fanpost comment",
                });
                return;
              } else {
                let n_love = fanpost_comment.n_love + 1;
                fanpost_comment.n_love = n_love;
                fanpost_comment.save(function (err, result) {
                  if (err) {
                    res.json({
                      status: false,
                      message: "fanpost comment update error",
                    });
                    return;
                  }
                  newOne.save(function (err, result) {
                    if (err) {
                      res.json({
                        status: false,
                        message: "New love is not save correctly",
                      });
                      return;
                    }
                    res.json({
                      status: true,
                      message: "Saved successfully",
                    });
                  });
                });
              }
            }
          );
        }
      }
    }
  );
};

exports.create_fanpost_comment_reaction = function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded.user_id;
  var fanpost_comment_id = req.body.fanpost_comment_id;
  var reaction_number = req.body.reaction_number;
  fanpost_comment_reactions.findOne(
    { fanpost_comment_id, user_id },
    function (err, result) {
      if (err) {
        res.json({
          status: false,
          message: "db error",
        });
      }
      if (result) {
        if (result.reaction_number == reaction_number) {
          comments.findById(
            fanpost_comment_id,
            function (err, fanpost_comment) {
              if (err || !fanpost_comment) {
                res.json({
                  status: false,
                  message: "Item Comment not found",
                });
                return;
              }
              const n_reaction = fanpost_comment.n_reaction - 1;
              fanpost_comment.n_reaction = n_reaction;
              const n_reaction_detail =
                fanpost_comment.n_reaction_detail[`r_${reaction_number}`] - 1;
              fanpost_comment.n_reaction_detail[`r_${reaction_number}`] =
                n_reaction_detail;
              fanpost_comment.save(function (err, fanpostSaved) {
                result.reaction_number = reaction_number;
                result.save(function (err, result) {
                  if (err || !result) {
                    res.json({
                      status: false,
                      message: "Update error",
                    });
                    return;
                  }
                  fanpost_comment_reactions.remove(
                    { fanpost_comment_id, user_id },
                    function (err, result) {
                      if (err) {
                        res.json({
                          status: false,
                          message: "fanpost comment reaction remove failed",
                        });
                      } else {
                        res.json({
                          status: true,
                          message: "updated successfully",
                        });
                      }
                    }
                  );
                });
              });
            }
          );
        } else {
          comments.findById(
            fanpost_comment_id,
            function (err, fanpost_comment) {
              if (err || !fanpost_comment) {
                res.json({
                  status: false,
                  message: "Item Comment not found",
                });
                return;
              }
              const n_reaction_detail =
                fanpost_comment.n_reaction_detail[`r_${reaction_number}`] + 1;
              fanpost_comment.n_reaction_detail[`r_${reaction_number}`] =
                n_reaction_detail;
              const last_n_reaction_detail =
                fanpost_comment.n_reaction_detail[
                `r_${result.reaction_number}`
                ] - 1;
              fanpost_comment.n_reaction_detail[`r_${result.reaction_number}`] =
                last_n_reaction_detail;
              fanpost_comment.save(function (err, fanpostSaved) {
                result.reaction_number = reaction_number;
                result.save(async function (err, result) {

                  if (err || !result) {
                    res.json({
                      status: false,
                      message: "Update error",
                    });
                    return;
                  }
                  // CREATE NOTIFICATION
                  let notif_users = []
                  let user = await users.findOne({ _id: fanpost_comment.user_id, "notif_posts.is_comment_reply_reaction": true });
                  if (user) {
                    let notification = await notificationModel.findOne({
                      type: fanpost_comment.parent_id ? NOTIFICATION_TYPES.POST_REPLY_REACTION : NOTIFICATION_TYPES.POST_COMMENT_REACTION,
                      filter: NOTIFICATION_FILTERS.NEW_REACTIONS,
                      item_id: fanpost_comment._id,
                      to_id: fanpost_comment.user_id,
                      is_read: false,
                    });

                    if (notification) {
                      if (notification.from_id != user_id) {
                        notification.n_user = notification.n_user + 1;
                      }
                      notification.create_date = new Date();
                      await notification.save();
                    } else {
                      let new_notification = new notificationModel({
                        type: fanpost_comment.parent_id ? NOTIFICATION_TYPES.POST_REPLY_REACTION : NOTIFICATION_TYPES.POST_COMMENT_REACTION,
                        filter: NOTIFICATION_FILTERS.NEW_REACTIONS,
                        message: `Reacted to your ${fanpost_comment.parent_id ? 'reply' : 'comment'}`,
                        item_id: fanpost_comment._id,
                        from_id: user_id,
                        to_id: fanpost_comment.user_id,
                        reaction_number
                      });
                      await new_notification.save();
                    }
                    notif_users.push(fanpost_comment.user_id)
                  }
                  res.json({
                    status: true,
                    message: "updated successfully",
                    result: {
                      notif_users
                    }
                  });
                });
              });
            }
          );
        }
      } else {
        var newOne = new fanpost_comment_reactions({
          fanpost_comment_id,
          user_id,
          reaction_number,
        });
        comments.findById(fanpost_comment_id, function (err, fanpost_comment) {
          if (err || !fanpost_comment) {
            res.json({
              status: false,
              message: "fanpost_comment not found",
            });
            return;
          }
          const n_reaction = fanpost_comment.n_reaction + 1;
          fanpost_comment.n_reaction = n_reaction;
          const n_reaction_detail =
            fanpost_comment.n_reaction_detail[`r_${reaction_number}`] + 1;
          fanpost_comment.n_reaction_detail[`r_${reaction_number}`] =
            n_reaction_detail;
          fanpost_comment.save(function (err, result) {
            newOne.save(async function (err, result) {


              // CREATE NOTIFICATION
              let notif_users = []
              let user = await users.findOne({ _id: fanpost_comment.user_id, "notif_posts.is_comment_reply_reaction": true });
              if (user) {
                let notification = await notificationModel.findOne({
                  type: fanpost_comment.parent_id ? NOTIFICATION_TYPES.POST_REPLY_REACTION : NOTIFICATION_TYPES.POST_COMMENT_REACTION,
                  filter: NOTIFICATION_FILTERS.NEW_REACTIONS,
                  item_id: fanpost_comment._id,
                  to_id: fanpost_comment.user_id,
                  is_read: false,
                });

                if (notification) {
                  if (notification.from_id != user_id) {
                    notification.n_user = notification.n_user + 1;
                  }
                  notification.create_date = new Date();
                  await notification.save();
                } else {
                  let new_notification = new notificationModel({
                    type: fanpost_comment.parent_id ? NOTIFICATION_TYPES.POST_REPLY_REACTION : NOTIFICATION_TYPES.POST_COMMENT_REACTION,
                    filter: NOTIFICATION_FILTERS.NEW_REACTIONS,
                    message: `Reacted to your ${fanpost_comment.parent_id ? 'reply' : 'comment'}`,
                    item_id: fanpost_comment._id,
                    from_id: user_id,
                    to_id: fanpost_comment.user_id,
                    reaction_number
                  });
                  await new_notification.save();
                }

                notif_users.push(fanpost_comment.user_id)

              }

              res.json({
                status: true,
                message: "Saved successfully",
                result: {
                  notif_users
                }
              });
            });
          });
        });
      }
    }
  );
};

exports.read_fanpost_comment_reaction = function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded.user_id;
  var fanpost_comment_id = req.query.fanpost_comment_id;
  comments.findById(fanpost_comment_id, function (err, result) {
    if (err) {
      res.json({
        status: false,
        message: "db error",
      });
      return;
    }
    fanpost_comment_reactions.findOne(
      { fanpost_comment_id, user_id },
      function (err, reaction) {
        if (err) {
          res.json({
            status: false,
            message: "db error",
          });
        } else {
          var resData = {
            data: result,
            reaction: reaction,
          };
          res.json({
            status: true,
            message: "retrieved successfully",
            result: resData,
          });
        }
      }
    );
  });
};

function add_fanpost_comment(user_id, fanpost_id, description, parent_id = null, replyImages = [], replyVideo = null) {
  console.log(getErrLine().str, "apistart");
  return new Promise(async (resolve, reject) => {
    try {
      console.log("THIS PROMISE IS CALLED HERE.")
      var fanpost = await fanposts.findById(fanpost_id);
      if (fanpost) {
        var new_comment = new comments({
          fanpost_id,
          parent_id,
          description,
          user_id,
          replyImages, replyVideo
        });

        if (parent_id) {
          var parent = await comments.findById(parent_id);
          if (parent) {
            const n_comment = parent.n_comment || 0 + 1;
            parent.n_comment = n_comment;
            await parent.save();
          }
        }

        if (fanpost.creator_id != user_id) {
          var date = new Date();
          var datestr = getDateStr(date);

          let daily_trending = fanpost.daily_trending.find(
            (d) => d.date == datestr
          );
          if (daily_trending) {
            let count = daily_trending.count + 3;
            daily_trending.count = count;
          } else {
            let newObj = {
              date: datestr,
              count: 1,
            };
            fanpost.daily_trending.push(newObj);
          }
        }
        // CREATE NOTIFICATION REPLY

        let notif_users = [];
        if (user_id != fanpost.creator_id) {
          let user = await users.findOne({ _id: fanpost.creator_id, "notif_posts.is_comments_replies": true });
          if (user) {
            if (parent_id) {
              let notification = await notificationModel.findOne({
                type: NOTIFICATION_TYPES.POST_COMMENT_REPLY,
                filter: NOTIFICATION_FILTERS.NEW_COMMENTS_REPLIES,
                to_id: fanpost.creator_id,
                item_id: fanpost._id,
                is_read: false
              })
              if (notification) {
                if (notification.from_id != user_id) {
                  const n_user = notification.n_user + 1;
                  notification.n_user = n_user;
                }
                notification.create_date = new Date();
                await notification.save();
              } else {
                let new_notification = new notificationModel({
                  type: NOTIFICATION_TYPES.POST_COMMENT_REPLY,
                  filter: NOTIFICATION_FILTERS.NEW_COMMENTS_REPLIES,
                  message: "Replied to this comment",
                  from_id: user_id,
                  to_id: fanpost.creator_id,
                  item_id: fanpost._id,
                });
                await new_notification.save();
              }
              notif_users.push(fanpost.creator_id);
            } else {
              // CHECK THIS NOTIFICAITON IS READ OR NOT
              let notification = await notificationModel.findOne({
                type: NOTIFICATION_TYPES.POST_COMMENT,
                filter: NOTIFICATION_FILTERS.NEW_COMMENTS_REPLIES,
                to_id: fanpost.creator_id,
                item_id: fanpost._id,
                is_read: false
              });

              if (notification) {
                if (notification.from_id != user_id) {
                  const n_user = notification.n_user + 1;
                  notification.n_user = n_user;
                }
                notification.create_date = new Date();
                await notification.save();
              } else {
                let new_notification = new notificationModel({
                  type: NOTIFICATION_TYPES.POST_COMMENT,
                  filter: NOTIFICATION_FILTERS.NEW_COMMENTS_REPLIES,
                  message: `Commented to your post`,
                  from_id: user_id,
                  to_id: fanpost.creator_id,
                  item_id: fanpost._id,
                });
                await new_notification.save();
              }

              notif_users.push(fanpost.creator_id);
            }
          }
        }
        await new_comment.save();
        resolve({
          new_comment,
          notif_users
        });

      } else {
        reject(false)
      }
    } catch (error) {
      console.log(error);
      reject(error);
    }
  })
}

exports.create_fanpost_comment = function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded.user_id;

  fanposts.findOne({ _id: req.body.fanpost_id }, async function (err, post1) {
    if (err || !post1) {
      res.json({
        status: false,
        message: "Post not found",
        errors: err,
      });
      return;
    }
    var newcomment = new comments(req.body);
    if (req.body.parent_id) {
      // Define comment_count and increment it before updating the document
      const parent_id = req.body.parent_id;
      comments.findById(parent_id, async function (err, parent) {
        if (err) {
          console.log(err);
          res.json({
            status: false,
            message: "error",
            errors: error,
          });
        } else {
          // Increment comment_count by 1
          // if(parent.user_id != req.decoded.user_id) {
          // post1.n_comment = post1.n_comment + 1;
          const n_comment = parent.n_comment + 1;
          // Update the parent document with the new comment_count value
          if (post1.creator_id != user_id) {
            var date = new Date();
            var datestr = getDateStr(date);

            let daily_trending = post1.daily_trending.find(
              (d) => d.date == datestr
            );
            if (daily_trending) {
              let count = daily_trending.count + 3;
              daily_trending.count = count;
            } else {
              let newObj = {
                date: datestr,
                count: 1,
              };
              post1.daily_trending.push(newObj);
            }
          }
          try {
            await comments.findByIdAndUpdate(parent_id, {
              n_comment: n_comment,
            });
            await newcomment.save();
            await post1.save();

            // CREATE POST COMMENT REPLY NOTIFICATION
            // CHECK CREATOR'S NTIFICATION SETTING IS ENABLED
            let notif_users = []
            let user = await users.findOne({ _id: post1.creator_id, "notif_posts.is_comments_replies": true });
            if (user) {
              let notification = await notificationModel.findOne({
                type: NOTIFICATION_TYPES.POST_COMMENT_REPLY,
                filter: NOTIFICATION_FILTERS.NEW_COMMENTS_REPLIES,
                to_id: post1.creator_id,
                item_id: post1._id,
                is_read: false
              })
              if (notification) {
                if (notification.from_id != user_id) {
                  const n_user = notification.n_user + 1;
                  notification.n_user = n_user;
                }
                notification.create_date = new Date();
                await notification.save();
              } else {
                let new_notification = new notificationModel({
                  type: NOTIFICATION_TYPES.POST_COMMENT_REPLY,
                  filter: NOTIFICATION_FILTERS.NEW_COMMENTS_REPLIES,
                  message: "Replied to this comment",
                  from_id: user_id,
                  to_id: post1.creator_id,
                  item_id: post1._id,
                });
                await new_notification.save();
              }
              notif_users.push(post1.creator_id);
            }

            let new_comment = await comments.findById(newcomment._id)
              .populate({
                path: "user_id",
                model: "users",
                select: "_id first_name last_name username profile_image is_idverified",
              });

            res.json({
              status: true,
              message: "Saved sccessfully",
              result: {
                new_comment,
                notif_users
              }
            });
          } catch (error) {
            res.json({
              status: false,
              message: "error was occured",
            });
          }
        }
      }).sort({create_date:-1});
      /* !!20240110pm3 coderd added sort query {( b ) fully test and debug comments and replies for shared posts and items} */ 
    } else {
      post1.n_comment = post1.n_comment + 1;

      if (post1.creator_id != user_id) {
        var date = new Date();
        var datestr = getDateStr(date);

        let daily_trending = post1.daily_trending.find(
          (d) => d.date == datestr
        );
        if (daily_trending) {
          let count = daily_trending.count + 3;
          daily_trending.count = count;
        } else {
          let newObj = {
            date: datestr,
            count: 1,
          };
          post1.daily_trending.push(newObj);
        }
      }

      try {
        await newcomment.save();
        await post1.save();

        let notif_users = [];

        if (user_id != post1.creator_id) {
          // CREATE NOTIFICATION
          // CHECK CREATOR NOTIFICATION SETTING IS ENABLED
          let user = await users.findOne({
            _id: post1.creator_id,
            "notif_posts.is_comments_replies": true
          });
          if (user) {
            // CHECK THIS NOTIFICAITON IS READ OR NOT
            let notification = await notificationModel.findOne({
              type: NOTIFICATION_TYPES.POST_COMMENT,
              filter: NOTIFICATION_FILTERS.NEW_COMMENTS_REPLIES,
              to_id: post1.creator_id,
              item_id: post1._id,
              is_read: false
            });

            if (notification) {
              if (notification.from_id != user_id) {
                const n_user = notification.n_user + 1;
                notification.n_user = n_user;
              }
              notification.create_date = new Date();
              await notification.save();
            } else {
              let new_notification = new notificationModel({
                type: NOTIFICATION_TYPES.POST_COMMENT,
                filter: NOTIFICATION_FILTERS.NEW_COMMENTS_REPLIES,
                message: `Commented to your post`,
                from_id: user_id,
                to_id: post1.creator_id,
                item_id: post1._id,
              });
              await new_notification.save();
            }

            notif_users.push(post1.creator_id);

          }
        }

        let new_comment = await comments.findById(newcomment._id)
          .populate({
            path: "user_id",
            model: "users",
            select: "_id first_name last_name username profile_image is_idverified",
          });
        res.json({
          status: true,
          message: "Comment added successfully",
          result: {
            notif_users,
            new_comment
          }
        });
      } catch (e) {
        res.json({
          status: false,
          message: e.message
        });
      }
    }
  });
};

exports.read_fanpost_comments = async function (req, res) {
  console.log(getErrLine().str, "apistart");
  var keyword = req.query.keyword || ""; // added dreampanda 20230523 pm 9
  var page = req.query.page ? req.query.page : "1";
  var limit = req.query.limit ? req.query.limit : "15";
  var parent_id = req.query.parent_id || "";
  var user_id = req.decoded.user_id;
  var sortKey = req.query.sortKey;
  var query = comments.find();
  var offset = page == "1" ? 0 : parseInt(page - 1) * 10;
  if (parent_id != "") {
    query = query.find({ parent_id: parent_id });
  } else {
    query = query.where("fanpost_id", req.query.fanpost_id);
    query = query.find({ parent_id: null });
  }
  if (keyword != "") {
    query = query.find({ description: { $regex: new RegExp(keyword, "ig") } });
  }
  if (sortKey && sortKey == "newest") {
    query = query.sort("-created_date");
  } else {
    query = query.sort("created_date");
  }
  var options = {
    page: page,
    offset: offset,
    limit: limit,
  };

  let reactions = await fanpost_comment_reactions.find();
  let _comments = await comments.find({ parent_id: { $ne: null } });
  let loves = await fanpost_comment_loves.find();
  let boosts = []; // temporary
  query = query.populate({
    path: "user_id",
    model: "users",
    select: "_id first_name last_name username profile_image is_idverified",
  });
  comments.paginate(query, options).then(function (result) {
    const updatedDocs = result.docs.map((d) => {
      // console.log(playLists.some(pl => pl.fanpost_id == d._doc._id && pl.user_id == user_id))
      const fanpostReactions = reactions.filter(
        (r) =>
          r.fanpost_comment_id == d._doc._id.toString() && r.user_id == user_id
      );
      const reactionNumber = fanpostReactions.length
        ? fanpostReactions[0].reaction_number
        : -1;
      const date = new Date();
      return {
        ...d._doc, // copy all the existing fields
        reaction_number: reactionNumber,
        isCommented: _comments.some(
          (pl) => pl.parent_id == d._doc._id.toString() && pl.user_id == user_id
        ),
        isLoved: loves.some(
          (pl) =>
            pl.fanpost_comment_id == d._doc._id.toString() &&
            pl.user_id == user_id
        ),
        isBoosted: boosts.some(
          (pl) =>
            pl.fanpost_comment_id == d._doc._id.toString() &&
            pl.user_id == user_id
        ),
        serverDate: date,
      };
    });

    const updatedResult = { ...result, docs: updatedDocs };

    res.json({
      status: true,
      message: "fanpost_comments retrieved successfully",
      data: updatedResult,
    });
  });
};

exports.create_fanpost_love = function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded.user_id;
  var fanpost_id = req.body.fanpost_id;

  loves.findOne(
    { fanpost_id: fanpost_id, user_id: user_id },
    async function (err, result) {
      if (err) {
        res.json({ status: false, message: "Db error or else already done." });
        return;
      }
      if (result) {
        try {
          let fanpost = await fanposts.findById(fanpost_id);
          if (fanpost) {
            const n_love = fanpost.n_love - 1; // decrease fanpost love count
            fanpost.n_love = n_love;
            // handle daily trending
            var date = new Date();
            var datestr = getDateStr(date);
            let daily_trending = fanpost.daily_trending.find(
              (d) => d.date == datestr
            );
            if (daily_trending) {
              let count = daily_trending.count - 2;
              daily_trending.count = count;
            } else {
              let newObj = {
                date: datestr,
                count: -2,
              };
              fanpost.daily_trending.push(newObj);
            }

            fanpost.save();
            result.remove();
            res.json({
              status: true,
              message: "Removed successfully",
            });
          } else {
            res.json({
              status: false,
              message: "fanpost not found",
            });
          }
        } catch (e) {
          console.log(e);
          res.json({
            status: false,
            message: "Something went wrong.",
          });
        }
      } else {
        fanposts.findById(fanpost_id, async function (err, fanpost) {
          if (err || !fanpost) {
            res.json({
              status: false,
              message: "Db error or fanpost not found",
            });
            return;
          }
          try {
            const n_love = fanpost.n_love + 1;
            fanpost.n_love = n_love;

            // handle trending
            var date = new Date();
            var datestr = getDateStr(date);

            let daily_trending = fanpost.daily_trending.find(
              (d) => d.date == datestr
            );
            if (daily_trending) {
              let count = daily_trending.count + 2;
              daily_trending.count = count;
            } else {
              let newObj = {
                date: datestr,
                count: 1,
              };
              fanpost.daily_trending.push(newObj);
            }

            await fanpost.save();

            // create new love user agianst that fanpost
            var newOne = new loves({
              fanpost_id: fanpost_id,
              user_id: user_id,
            });
            await newOne.save();

            // CREATE NOTIFICATION FOR FANPOST LOVE
            // CHECK CREATOR'S NOTIFICATION SETTING IS ENABLED
            let notif_users = []
            if(fanpost?.creator_id != user_id) {
              let user = await users.findOne({ _id: fanpost.creator_id, "notif_posts.is_added_favorites": true });
              if (user) {
                let notification = await notificationModel.findOne({
                  type: NOTIFICATION_TYPES.POST_FAVORITE,
                  filter: NOTIFICATION_FILTERS.NEW_FAVORITES,
                  to_id: user._id,
                  item_id: fanpost._id,
                  is_read: false
                });
                if (notification) {
                  if (notification.from_id != user_id) {
                    const n_user = notification.n_user + 1;
                    notification.n_user = n_user
                  }
                  notification.create_date = new Date();
                  await notification.save();
                } else {
                  let new_notification = new notificationModel({
                    type: NOTIFICATION_TYPES.POST_FAVORITE,
                    filter: NOTIFICATION_FILTERS.NEW_FAVORITES,
                    message: "Added this to their favorite",
                    from_id: user_id,
                    to_id: user._id,
                    item_id: fanpost._id,
                  });
                  await new_notification.save();
                }
                notif_users.push(user._id)
              }
            }


            res.json({
              status: true,
              message: "saved successfully",
              result: {
                notif_users
              }
            });
          } catch (error) {
            res.json({
              status: false,
              message: "error was occured while saving data",
            });
          }
        });
      }
    }
  );
};

exports.read_fanpost_loves = function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded.user_id;
  loves.find({ user_id: user_id }, function (err, result) {
    if (err) {
      res.json({ status: false, message: "DB error" });
      return;
    }
    res.json({
      status: true,
      message: "Retrived successfully",
      result: result,
    });
  });
};

exports.create_fanpost_boost = function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded.user_id;
  var fanpost_id = req.body.fanpost_id;

  boosts.findOne(
    { fanpost_id: fanpost_id, user_id: user_id },
    function (err, result) {
      if (err || result) {
        res.json({ status: false, message: "Db error or already done action" });
        return;
      }
      fanposts.findById(fanpost_id, function (err, fanpost) {
        if (err || !fanpost) {
          res.json({
            status: false,
            message: "Db error or fanpost not found",
          });
          return;
        }
        const n_boost = fanpost.n_boost + 1;
        fanpost.n_boost = n_boost;
        var newOne = new boosts({
          fanpost_id: fanpost_id,
          user_id: user_id,
        });
        fanpost.save(function (err, result) {
          newOne.save(function (err, result) {
            res.json({
              status: true,
              message: "created successfully",
            });
          });
        });
      });
    }
  );
};

exports.read_fanpost_boosts = function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded.user_id;
  boosts.find({ user_id: user_id }, function (err, result) {
    if (err) {
      res.json({
        status: false,
        message: "Db error",
      });
      return;
    }
    res.json({
      status: true,
      message: "Retrived successfully",
      result: result,
    });
  });
};

exports.deleteAll = async function (req, res) {
  console.log(getErrLine().str, "apistart");
  try {
    await fanposts.deleteMany({});
    res.json({
      status: true,
      message: "deleted",
    });
  } catch (error) {
    res.json({
      status: false,
      message: "Error",
    });
  }
};

// 2023 08 20
exports.get_content_for_home = async function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded.user_id;

  var query = fanposts.find().sort({ create_date: -1 });

  if (req.query.keyword && req.query.keyword != "") {
    var keyword = req.query.keyword;
    // console.log(keyword)
    // var search = {
    //     $or: [{
    //             description: {
    //                 $regex: new RegExp(keyword, "ig")
    //             }
    //         }, {
    //             fanpost_poll_question: {
    //                 $regex: new RegExp(keyword, "ig")
    //             }
    //         },
    //         {
    //             fanpost_poll_answer: {
    //                 $elemMatch: {
    //                     $regex: new RegExp(keyword, "ig")
    //                   }
    //             }
    //         }
    //     ]
    // };
    // console.log(search)
    query = query.find({
      $or: [
        { description: { $regex: new RegExp(keyword, "ig") } },
        { fanpost_poll_question: { $regex: new RegExp(keyword, "ig") } },
      ],
    });
    // console.log(query)
  }

  var type = req.query.type;
  var date = new Date(new Date().setMonth(new Date().getMonth() - 1));

  // what I joined the subscription level
  var my_subscribers = await subscribers
    .find({ user_id, start_date: { $gte: date }, unsubscribed: false })
    .populate({ path: "subscription_id" });

  switch (type) {
    case "For you":
      var my_following_users = await followers.find({ user_id });
      my_following_users_ids = my_following_users.map((d) => d.star_id);
      query = query.find({ author_id: { $in: my_following_users_ids } });
      break;
    case "Following":
      var me_follow_users = await followers.find({ star_id: user_id });
      var me_follow_users_ids = me_follow_users.map((d) => d.user_id);
      query = query.find({ author_id: { $in: me_follow_users_ids } });
      break;
    case "Fans":
      var your_fans = my_subscribers
        .filter((d) => d.subscription_id?.level == "basic")
        .map((d) => d.subscription_id?.user_id?.toString());
      console.log(my_subscribers);
      console.log("your_fans");
      console.log(your_fans);
      query = query.find({ author_id: { $in: your_fans } });
      break;
    case "Superfans":
      var your_superfans = my_subscribers
        .filter((d) => d.subscription_id?.level == "super")
        .map((d) => d.subscription_id?.user_id?.toString());
      query = query.find({ author_id: { $in: your_superfans } });
      break;
    default:
      break;
  }

  query = query.populate({
    path: "author_id",
    model: "users",
    select: "_id first_name last_name username profile_image",
  });

  query = query.limit(100);

  query.exec(async function (error, result) {
    if (!error) {
      try {
        let _reactions = await reactions.find();
        let _comments = await comments.find({ parent_id: null });
        let _loves = await loves.find();
        let _boosts = await fanpostShareModel.find();

        const updatedDocsPromises = result.map(async (d) => {
          let _members = await members.find({ star_id: d.creator_id });
          let _fans = await fans.find({ star_id: d.creator_id });
          let _followers = await followers.find({ star_id: d.creator_id });
          let _followings = await followers.find({ star_id: user_id });

          let isFan = _fans.some((f) => f.user_id == user_id);
          let membership;
          if (isFan) {
            let _memberships = await subscriptionlevels.find({
              user_id: d._doc?.creator_id,
            });
            _memberships.map((d) => {
              return d._id;
            });
            var _start_date = new Date();
            _start_date.setMonth(_start_date.getMonth() - 1);
            membership = await subscribers
              .findOne({
                user_id: user_id,
                subscription_id: { $in: _memberships },
                unsubscribed: false,
                start_date: { $gte: _start_date },
              })
              .populate("subscription_id");
          }

          let InfoForUser = {
            isMember: _members.some((m) => m.user_id == user_id),
            isFan: isFan,
            membership: membership,
            isFollower: _followers.some((f) => f.user_id == user_id),
            isFollowing: _followings.some(
              (f) => f.user_id == d._doc?.creator_id
            ),
          };

          const itemReactions = _reactions.filter(
            (r) => r.fanpost_id == d._id.toString() && r.user_id == user_id
          );
          const reactionNumber = itemReactions.length
            ? itemReactions[0].reaction_number
            : -1;
          return {
            ...d.toObject(), // copy all the existing fields
            reaction_number: reactionNumber,
            isCommented: _comments.some(
              (pl) => pl.fanpost_id == d._id.toString() && pl.user_id == user_id
            ),
            isLoved: _loves.some(
              (pl) => pl.fanpost_id == d._id.toString() && pl.user_id == user_id
            ),
            isBoosted: _boosts.some(
              (pl) => pl.fanpost_id == d._id.toString() && pl.user_id == user_id
            ),
            InfoForUser: InfoForUser,
            serverDate: new Date(),
          };
        });
        const updatedDocs = await Promise.all(updatedDocsPromises);
        res.json({
          status: true,
          message: "Data retrived successfully",
          result: updatedDocs,
        });
      } catch (error) {
        console.log(error);
        res.json({
          status: false,
          message: "Sonething went wrong",
        });
      }
    } else {
      res.json({
        status: false,
        message: "Sonething went wrong",
      });
    }
  });
};

exports.get_reactions = async function (req, res) {
  console.log(getErrLine().str, "apistart");
  var star_id = req.query.star_id;
  var page = req.query.page || 1;
  var limit = req.query.limit || 15;
  var keyword = req.query.keyword || "";

  try {
    var fanposts = await fanposts.find({ n_reaction: { $gt: 0 } });
    // no pagniation
  } catch (error) {
    console.log(error);
    res.json({
      status: false,
      message: "Something went wrong",
    });
  }
};

exports.update_audience_setting = async function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded.user_id;
  try {
    await fanposts.findByIdAndUpdate(req.body._id, req.body);
    res.json({
      status: true,
      message: "Updated successfully",
    });
  } catch (error) {
    res.json({
      status: false,
      message: "Something went wrong",
    });
  }
};

exports.update_priority = async function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded.user_id;
  var _id = req.body._id;
  var type = req.body.type;

  try {
    var post = await fanposts.findById(_id);
    if (post) {
      if (type == "pin") {
        post.priority = 1;
      } else {
        post.priority = 0;
      }
      await post.save();
      res.json({
        status: true,
        message: "Updated successfully",
      });
    } else {
      res.json({
        status: false,
        message: "No post",
      });
    }
  } catch (error) {
    console.log(errro);
    res.json({
      status: false,
      message: "Something went wrong",
    });
  }
};

exports.get_history = async function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded.user_id;
  var fanpost_id = req.body._id;
  try {
    var histories = await fanpostHistoryModel
      .find({ fanpost_id })
      .sort({ created_date: -1 })
      .populate({
        path: "user_id",
        model: "users",
        select: "_id first_name last_name username profile_image is_idverified",
      });
    histories = histories.map((d) => {
      return {
        ...d._doc,
        serverDate: new Date(),
      };
    });
    res.json({
      status: true,
      message: "retrived successfully",
      result: histories,
    });
  } catch (error) {
    console.log(error);
    res.json({
      status: false,
      message: "Something went wrong",
    });
  }
};



exports.get_fanpost_detail = async function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded.user_id;
  var id = req.query.id;

  try {
    var fanpost = await fanposts.findById(id)
      .populate({
        path: 'author_id',
        model: "users",
        select: "_id first_name last_name username profile_image",
      });

    if (fanpost) {
      if (user_id) {
        let _member = await members.findOne({ star_id: fanpost._doc?.creator_id });
        let _fan = await fans.findOne({ star_id: fanpost._doc?.creator_id });
        let _follower = await followers.findOne({
          star_id: fanpost._doc?.creator_id,
        });
        let _following = await followers.findOne({ star_id: user_id });

        let isFan = _fan ? true : false;
        let membership;
        if (isFan) {
          let _memberships = await subscriptionlevels.findOne({
            user_id: fanpost._doc?.creator_id,
          }).distinct("_id"); //!!20240122pm11 coderd commented below code {(B)Notifications - when clicking on any it’s supposed to load}
          // !!20240122pm11 coderd commented below code {(B)Notifications - when clicking on any it’s supposed to load}
          // _memberships.map((d) => {
          //   return d._id;
          // });
          var _start_date = new Date();
          _start_date.setMonth(_start_date.getMonth() - 1);
          membership = await subscribers
            .findOne({
              user_id: user_id,
              subscription_id: { $in: _memberships },
              unsubscribed: false,
              start_date: { $gte: _start_date },
            })
            .populate("subscription_id");
        }

        let InfoForUser = {
          isMember: _member ? true : false,
          isFan: isFan && membership,
          membership: membership,
          isFollower: _follower ? true : false,
          isFollowing: _following ? true : false,
        };

        let histories = await fanpostHistoryModel.find({ fanpost_id: id });

        let _reaction = await reactions.findOne({ fanpost_id: id, user_id });
        let _love = await loves.findOne({ fanpost_id: id, user_id })
        let _comment = await comments.findOne({ fanpost_id: id, user_id })


        res.json({
          status: true,
          message: "retrived successfully",
          result: {
            ...fanpost._doc, // copy all the existing fields
            reaction_number: _reaction ? _reaction.reaction_number : -1,
            isCommented: _comment ? true : false,
            isLoved: _love ? true : false,
            InfoForUser: InfoForUser,
            serverDate: new Date(),
            isEdited: histories?.length > 0 ? true : false,
          }
        })

      } else {
        res.json({
          status: true,
          message: "Retrived successfully",
          result: {
            ...fanpost._doc,
            serverDate: new Date()
          }
        })
      }

    } else {
      res.json({
        status: false,
        message: "Fanpost doesn't exist"
      })
    }

  } catch (error) {
    console.log(error);
    res.json({
      status: false,
      message: "Something went wrong"
    });
  }


}


exports.share_on_my_fanpage = async function (req, res) {
  var user_id = req.decoded.user_id;
  console.log(getErrLine().str, "apistart");
  var _id = req.body._id;
  var description = req.body.description;
  var type = req.body.type || "post";
  var shared = req.body.shared;
  if(!shared) {
    try {
      var shared = await fanpostShareModel.findOne({ user_id, item_id: _id, type });
      if (shared) {
        res.json({
          status: false,
          message: `You've already shared this ${type} on your page`
        })
      } else {
        let notif_users = [];
        let item_comment_id = null;
        console.log("DESCRIOTION:", description);
        if (description && description.trim() != "") {
          console.log("DESCRIOTION:", description);
          try {
            if (type == 'post') {
              let result = await add_fanpost_comment(user_id, _id, description);
              console.log("Result:", result);
              notif_users = result?.notif_users;
              item_comment_id = result?.new_comment?._id;
            } else if (type == 'item') {
              let result = await add_item_comment(user_id, _id, description);
              console.log("Result:", result);
              notif_users = result?.notif_users;
              item_comment_id = result?.new_comment?._id;
            }
          } catch (error) {
            throw error;
          }
        }
        console.log("item_comment_id", item_comment_id);
        var new_shared_content = new fanpostShareModel({
          item_id: _id,
          item_comment_id,
          type,
          user_id,
        });
  
        // increase share count
        if (type == 'post') {
          let fanpost = await fanposts.findById(_id);
          if (fanpost) {
            const n_boost = fanpost.n_boost || 0 + 1;
            fanpost.n_boost = n_boost;
            await fanpost.save();
          }
        } else if (type == 'item') {
          let item = await itemModel.findById(_id);
          if (item) {
            const n_boost = item.n_boost || 0 + 1;
            item.n_boost = n_boost;
            await item.save();
          }
        }
        await new_shared_content.save();
        console.log("new_shared_content", new_shared_content);
        res.json({
          status: true,
          message: "Shared successfully",
          result: {
            notif_users
          }
        });
      }
    } catch (error) {
      console.log(error);
      res.json({
        statfus: false,
        message: error.message
      })
    }
  } else {
    try {
      var shared = await fanpostShareModel.findOne({ user_id, item_id: _id, type });
      if(shared) {
        await shared.remove();
        res.json({
          status: true,
          message: "Undo successfully"
        })
      } else {
        res.json({
          status: true,
          message: "Undo successfully"
        });
      }
    } catch (error) {
      
    }
  }
}

