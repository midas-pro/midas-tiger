/*
Project : Cryptotrades
FileName : loveModel.js
Author : Indiefire
File Created : 21/07/2021
CopyRights : Indiefire
Purpose : This is the file which used to define love schema that will store and reterive fanpost love information.
*/

var mongoose = require('mongoose');
var mongoosePaginate = require('mongoose-paginate-v2');
var uniqueValidator = require('mongoose-unique-validator');
var config = require('../../../helper/config')
const Schema = mongoose.Schema;

var fanpost_love_schema = mongoose.Schema({
    fanpost_id: { type: Schema.Types.ObjectId, ref: 'fanpost' },
    user_id: { type: Schema.Types.ObjectId, ref: 'users' },
    created_date: {
        type: Date,
        default: Date.now
    },
});

fanpost_love_schema.plugin(uniqueValidator);
fanpost_love_schema.plugin(mongoosePaginate);

module.exports = mongoose.model('fanpost_loves', fanpost_love_schema,config.db.prefix+'fanpost_loves');