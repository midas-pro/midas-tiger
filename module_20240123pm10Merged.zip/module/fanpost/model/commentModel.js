/*
Project : Cryptotrades
FileName : commentModel.js
Author : Indiefire
File Created : 21/07/2021
CopyRights : Indiefire
Purpose : This is the file which used to define comment schema that will store and reterive fanpost comment information.
*/

var mongoose = require('mongoose');
var mongoosePaginate = require('mongoose-paginate-v2');
var uniqueValidator = require('mongoose-unique-validator');
var config = require('../../../helper/config')
const Schema = mongoose.Schema;

var commentSchema = mongoose.Schema({
    fanpost_id: { type: Schema.Types.ObjectId, ref: 'fanpost' },
    parent_id: { type: Schema.Types.ObjectId, ref: 'fanpost_comments', default: null },
    replyImages: {
        type: Array,
        default: []
    },
    replyVideo: {
        type: String,
        default: ''
    },
    user_id: { type: Schema.Types.ObjectId, ref: 'users' },
    description: {
        type: String,
        default: ''
    },    
    
    n_reaction: {
        type: Number,
        default: 0
    },
    n_reaction_detail: {
        r_1: { type: Number, default: 0 },
        r_2: { type: Number, default: 0 },
        r_3: { type: Number, default: 0 },
        r_4: { type: Number, default: 0 },
        r_5: { type: Number, default: 0 },
        r_6: { type: Number, default: 0 },
        r_7: { type: Number, default: 0 },
        r_8: { type: Number, default: 0 },
        r_9: { type: Number, default: 0 },
        r_10: { type: Number, default: 0 },
        r_11: { type: Number, default: 0 },
        r_12: { type: Number, default: 0 },
        r_13: { type: Number, default: 0 },
        r_14: { type: Number, default: 0 },
        r_15: { type: Number, default: 0 },
        r_16: { type: Number, default: 0 },
        r_17: { type: Number, default: 0 },
        r_18: { type: Number, default: 0 },
        r_19: { type: Number, default: 0 },
        r_20: { type: Number, default: 0 },
        r_21: { type: Number, default: 0 },
        r_22: { type: Number, default: 0 },
    },


    n_comment: {
        type: Number,
        default: 0
    },
    
    n_love: {
        type: Number,
        default: 0
    },



    
    n_boost: {
        type: Number,
        default: 0
    },
    created_date: {
        type: Date,
        default: Date.now
    },
});

commentSchema.plugin(uniqueValidator);
commentSchema.plugin(mongoosePaginate);

module.exports = mongoose.model('fanpost_comments', commentSchema,config.db.prefix+'fanpost_comments');