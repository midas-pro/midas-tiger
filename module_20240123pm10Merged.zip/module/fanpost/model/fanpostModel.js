/*
Project : Cryptotrades
FileName : fanpostModel.js
Author : Indiefire
File Created : 21/07/2021
CopyRights : Indiefire
Purpose : This is the file which used to define fanpost collection that will communicate and process fanpost information with mongodb through mongoose ODM.
*/

var mongoose = require('mongoose');
var mongoosePaginate = require('mongoose-paginate-v2');
var uniqueValidator = require('mongoose-unique-validator');
var config = require('../../../helper/config')
const Schema = mongoose.Schema;

// Setup schema
var fanpostSchema = mongoose.Schema({
    creator_id: { type: Schema.Types.ObjectId, ref: 'users' },
    author_id: { type: Schema.Types.ObjectId, ref: 'users' },

    // added by dreampanda 20230510 am 10 start

    preview: {
        type: String,
        default: ''
    },
    // added by dreampanda 20230510 am 10 end

    description: {
        type: String,
    },    
    fanpost_image: {
        // type: String, removed by dream 20230509 pm11
        type: String, //added by dreampanda 20230509 pm 11
        default: '' //added by dreampanda 20230509 pm 11
    },
    fanpost_images: {
        // type: String, removed by dream 20230509 pm11
        type: Array, //added by dreampanda 20230509 pm 11
        default: [] //added by dreampanda 20230509 pm 11
    },
    previewDatas: {
        type: Array, //added by coderd 20240105am3
        default: [] //added by coderd 20240105am3
    },
    fanpost_video: {
        type: String,
        default: ''
    },
    fanpost_audio: {
        type: String,
        default: ''
    },
    fanpost_audio_duration: {
        type: Number,
        default: 0
    },
    // added by dreampanda 20230510 am 10 start
    fanpost_poll_question: {
        type: String,
        default: ''
    },
    // fanpost_poll_answer: {
    //     type: Array,
    //     default: []
    // }, removed by dreampanda 20230516 am 7
    fanpost_poll_answer: [
        { 
            answer: { type: String, default: '' },
            voters: { type: Array, default: [] }  
        }
    ],
    fanpost_poll_delay: {
        type: String,
        default: ''
    },

    is_view_only: {
        type: String,
        default: ''
    },
    is_relay_only: {
        type: String,
        default: ''
    },

    unlock_date: {
        type: String,
        default: ''
    },
    unlock_time: {
        type: String,
        default: ''
    },
    fanpost_fan_early: {
        type: Boolean,
        default: false
    },
    // added by dreampanda 20230510 am 10 end
 


    is_fanonly: {
        type: Boolean,
        default: false
    },    
    
    n_reaction: {
        type: Number,
        default: 0
    },
    n_reaction_detail: {
        r_1: { type: Number, default: 0 },
        r_2: { type: Number, default: 0 },
        r_3: { type: Number, default: 0 },
        r_4: { type: Number, default: 0 },
        r_5: { type: Number, default: 0 },
        r_6: { type: Number, default: 0 },
        r_7: { type: Number, default: 0 },
        r_8: { type: Number, default: 0 },
        r_9: { type: Number, default: 0 },
        r_10: { type: Number, default: 0 },
        r_11: { type: Number, default: 0 },
        r_12: { type: Number, default: 0 },
        r_13: { type: Number, default: 0 },
        r_14: { type: Number, default: 0 },
        r_15: { type: Number, default: 0 },
        r_16: { type: Number, default: 0 },
        r_17: { type: Number, default: 0 },
        r_18: { type: Number, default: 0 },
        r_19: { type: Number, default: 0 },
        r_20: { type: Number, default: 0 },
        r_21: { type: Number, default: 0 },
        r_22: { type: Number, default: 0 },
    },


    
    n_comment: {
        type: Number,
        default: 0
    },
    
    n_love: {
        type: Number,
        default: 0
    },



    n_trending: {
        type: Number,
        default: 0
    },

    daily_trending: [
        {
            date: {
                type: String,
                default: ""
            },
            count: {
                type: Number,
                default: 0
            }
        }
    ],
    
    n_boost: {
        type: Number,
        default: 0
    },

    priority: {
        type: Number,
        default: 0
    },

    create_date: {
        type: Date,
        default: Date.now
    },
});

fanpostSchema.plugin(uniqueValidator);
fanpostSchema.plugin(mongoosePaginate);

module.exports = mongoose.model('fanpost', fanpostSchema,config.db.prefix+'fanpost');