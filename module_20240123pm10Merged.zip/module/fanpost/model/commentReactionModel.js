/*
Project : Cryptotrades
FileName : favouriteModel.js
Author : Indiefire
File Created : 21/07/2021
CopyRights : Indiefire
Purpose : This is the file which used to define favourite schema that will store and reterive item favourite information.
*/

var mongoose = require('mongoose');
var mongoosePaginate = require('mongoose-paginate-v2');
var uniqueValidator = require('mongoose-unique-validator');
var config = require('./../../../helper/config')
const Schema = mongoose.Schema;

var fanpost_comment_reaction_schema = mongoose.Schema({
    fanpost_comment_id: { type: Schema.Types.ObjectId, ref: 'item_comments' },
    user_id: { type: Schema.Types.ObjectId, ref: 'users' },
    reaction_number: { type: Number, default: -1 },
    created_date: {
        type: Date,
        default: Date.now
    },
});

fanpost_comment_reaction_schema.plugin(uniqueValidator);
fanpost_comment_reaction_schema.plugin(mongoosePaginate);

module.exports = mongoose.model('fanpost_comment_reactions', fanpost_comment_reaction_schema,config.db.prefix+'fanpost_comment_reactions');