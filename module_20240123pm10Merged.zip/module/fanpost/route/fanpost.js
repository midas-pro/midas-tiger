/*
Project : Cryptotrades
FileName : route.js
Author : Indiefire
File Created : 21/07/2021
CopyRights : Indiefire
Purpose : This is the file which used to define all route releated to fanpost api request.
*/

var express = require('express')
var router = express.Router();
var fanpostController = require("../controller/fanpostController")
var adminauth = require("../../../middleware/adminauth");
var auth = require("./../../../middleware/auth");
var optionalauth = require("./../../../middleware/optionalauth");
const { check } = require('express-validator');

router.get('/list', [auth], fanpostController.getList)
router.get('/detail',fanpostController.details);
router.get('/fulllist',auth,fanpostController.getAdminList)
router.post('/add',auth,fanpostController.add)
router.post('/edit_description',auth,fanpostController.edit_description)
router.post('/addlike',auth,fanpostController.actionLike)
router.post('/addlove',auth,fanpostController.actionLove)
router.post('/addcomment',auth,fanpostController.create_fanpost_comment)
router.get('/listcomment', [auth],fanpostController.read_fanpost_comments)
router.put('/edit',[check('fanpost_id').not().isEmpty(),auth],fanpostController.edit)
router.delete('/delete', auth ,fanpostController.delete)
router.post('/vote_answer', auth, fanpostController.vote_answer)
router.get('/photo_video', optionalauth, fanpostController.getPhotoVideo)
router.get('/fanposts', auth, fanpostController.fanposts)


router.post('/create_fanpost_comment_reaction', auth, fanpostController.create_fanpost_comment_reaction);
router.get('/read_fanpost_comment_reaction', auth, fanpostController.read_fanpost_comment_reaction);

router.post('/create_fanpost_comment_love', auth, fanpostController.create_fanpost_comment_love);


router.post('/create_fanpost_reaction', auth, fanpostController.create_fanpost_reaction);
router.get('/read_fanpost_reaction', auth, fanpostController.read_fanpost_reactions);

router.post('/create_fanpost_love', auth, fanpostController.create_fanpost_love);
router.get('/read_fanpost_love', auth, fanpostController.read_fanpost_loves);

router.post('/create_fanpost_boost', auth, fanpostController.create_fanpost_boost);
router.get('/read_fanpost_boost', auth, fanpostController.read_fanpost_boosts);
router.get('/deleteall', fanpostController.deleteAll)
router.get('/get_content_for_home', optionalauth, fanpostController.get_content_for_home );

router.put('/update_audience_setting', auth, fanpostController.update_audience_setting);
router.put('/update_priority', auth, fanpostController.update_priority);

router.post('/get_history', auth, fanpostController.get_history);
router.get('/get_fanpost_detail', optionalauth, fanpostController.get_fanpost_detail);

router.post('/share_on_my_fanpage', auth, fanpostController.share_on_my_fanpage)

module.exports = router