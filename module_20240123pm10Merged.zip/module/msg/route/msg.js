/*
Project : Cryptotrades
FileName : route.js
Author : Indiefire
File Created : 21/07/2021
CopyRights : Indiefire
Purpose : This is the file which used to define all route releated to msg api request.
*/

var express = require('express')
var router = express.Router();
var msgController = require("../controller/msgController")
var adminauth = require("../../../middleware/adminauth");
var auth = require("../../../middleware/auth");
const { check } = require('express-validator');

router.get('/list',msgController.getList)
router.get('/listMyAll',auth, msgController.getAllMsgs);
router.get('/detail',msgController.details);
router.get('/fulllist',auth,msgController.getAdminList)
router.post('/add',auth,msgController.add)
router.put('/edit',[check('msg_id').not().isEmpty(),auth],msgController.edit)
router.get('/get_message_unread_count', auth, msgController.get_unread_count);
router.post('/markasread',[check('msg_id').not().isEmpty(),auth],msgController.markAsRead)
router.delete('/delete',[check('msg_id').not().isEmpty(),auth],msgController.delete);
router.post('/get_target_user_dm_status', auth, msgController.get_target_user_dm_status); // 20240105pm11 CoderX
module.exports = router