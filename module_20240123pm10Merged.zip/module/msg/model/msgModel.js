/*
Project : Cryptotrades
FileName : msgModel.js
Author : Indiefire
File Created : 21/07/2021
CopyRights : Indiefire
Purpose : This is the file which used to define msg collection that will communicate and process msg information with mongodb through mongoose ODM.
*/

var mongoose = require('mongoose');
var mongoosePaginate = require('mongoose-paginate-v2');
var uniqueValidator = require('mongoose-unique-validator');
var config = require('../../../helper/config')
const Schema = mongoose.Schema;

// Setup schema
var msgSchema = mongoose.Schema({
    sender_id: { type: Schema.Types.ObjectId, ref: 'users' },
    recver_id: { type: Schema.Types.ObjectId, ref: 'users' },
    group_id: { type: Schema.Types.ObjectId, ref: 'groups' },
    msg_text: {
        type: String,
    },    
    msg_image: {
        type: String,
    },
    msg_video: {
        type: String,
    },
    msg_audio: {
        type: String,
    },
    create_date: {
        type: Date,
        default: Date.now
    },
    is_unread: {
        type: Boolean,
        default: true,
    },
    readers: {
        type: Array,
        default: []
    },
});

msgSchema.plugin(uniqueValidator);
msgSchema.plugin(mongoosePaginate);

module.exports = mongoose.model('msg', msgSchema,config.db.prefix+'msg');