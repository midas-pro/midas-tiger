/*
Project : Cryptotrades
FileName : msgController.js
Author : Indiefire
File Created : 21/07/2021
CopyRights : Indiefire
Purpose : This is the file which used to define all msg related api function.
*/
var users = require('../../user/model/userModel');
var msgs = require('../model/msgModel');
var groups = require('../../group/model/groupModel');
var validator = require('validator');
const { validationResult } = require('express-validator');
const { forEach } = require('lodash');
const blockModel = require('../../user/model/blockModel');
const { getErrLine } = require("../../helper/helpers");
/*
*  This is the function which used to retreive active msg list
*/
exports.getAllMsgs = async function(req,res) {
    console.log(getErrLine().str, "apistart");
    try {
        var query;    
        var qryGrp;
        // qryGrp = groups.find();
        if(req.decoded.user_id)
        {
            qryGrp = groups.find({members: {$in: [req.decoded.user_id]}}, {_id: 1, name:0, members:0, author_id:0, create_date:0});//OK, but returns create_date, too
    
            ////!! failed to filter only 1 field ( _id )
            // const projection = { _id: 1 };
            // groups.find({members: {$in: [req.decoded.user_id]}}).projection(projection).toArray(function(err, results) {
            //     res.json({
            //         status: true,
            //         message: "Message retrieved successfully",
            //         params: req.decoded.user_id,
            //         data: results
            //     });
            //     return;
            // });
            // return;
    
            ////!! will be slow
            // qryGrp = qryGrp.or(
            //     {
            //         $or:[
            //             // {
            //             //     'sender_id':req.decoded.user_id
            //             // },
            //             // {
            //             //     'recver_id':req.decoded.user_id
            //             // },
            //             {
            //                 "members": {
            //                   "$in": [ req.decoded.user_id ]
            //                 }
            //             }
            //         ]
            //     }
            // );
        } else {
            res.json({
                status: false,
                message: "Auth required",
                params: req.decoded.user_id,
                data: ''
            });
            return;
        }
        qryGrp.exec(async function (err,result){
            if (err) {
                res.json({
                    status: false,
                    message: "Request failed",
                    errors:"Api failed:msg.listAll.group"
                });
                return;
            }
            
            if(false) //!! true if want test for group search.: OK
            {
                res.json({
                    status: true,
                    message: "Message retrieved successfully",
                    params: req.decoded.user_id,
                    data: result
                });    
                return;
            }
    
            var myGroups=[];
            result.forEach(element => {
                myGroups.push(element);
              });
            // query = msgs.find({group_id: {$in: myGroups}});
            
    
            var user_id = req.decoded?.user_id;
            let blocked_accounts = [
                ...(await blockModel.find( { user_id } ))?.map(d => d.from_id),
                ...(await blockModel.find({ block_user_id: req.decoded.user_id }))?.map(d => d.user_id)
            ];
    
            query = msgs.find({ sender_id: { $nin: blocked_accounts } });
            query = query.find({ recver_id: { $nin: blocked_accounts } });
            query = query.or(
                {
                    $or:[
                        {
                            'sender_id':req.decoded.user_id
                        },
                        {
                            'recver_id':req.decoded.user_id
                        },
                        {
                            "group_id": {
                              "$in": myGroups
                            }
                        }
                    ]
                }
            );        
            query = query.sort({'-create_date':1})
            query.exec(function(err,result){
                if (err) {
                    res.json({
                        status: false,
                        message: "Request failed",
                        errors:"Api failed:msg.listAll.msg"
                    });
                    return;
                }
                res.json({
                    status: true,
                    message: "Message retrieved successfully",
                    params: req.decoded.user_id,
                    data: result
                });    
                return;
            });
            
        })
        
        
        // query = query.where('sender_id',req.query.sender_id);
        // query = query.where('recver_id',req.query.recver_id);
    
        // query = query
        //     .populate({path: 'recver_id', model: users, select:'_id first_name last_name username profile_image ' })
        //     .populate({path: 'sender_id', model: users, select:'_id first_name last_name username profile_image ' })
        //     .populate({path: 'group_id', model: groups, select:'_id name members author_id' })
            
    } catch (error) {
        console.log(error);
        res.json({
            status: false,
            message: "Something went wrong",
        });
    }

}

/*
*  This is the function which used to retreive active msg list
*/
exports.getList = async function(req,res) {
    console.log(getErrLine().str, "apistart");
    var page = req.query.page ? req.query.page : '1';  
    var query;    
    if(req.query.is_imageonly=='true')
    {
        query = msgs.find({"msg_image":{$ne:null},"msg_video":{$e:null}});
    } else if(req.query.is_videoonly=='true')
    {
        query = msgs.find({"msg_video":{$ne:null}});   
    } else 
    {        
        query = msgs.find();
    }
    var offset = ( page == '1' ) ? 0 : ((parseInt(page-1))*10);
    if(req.query.group_id != null) //if(req.body.group_id !== undefined)
    {
        query = query.where('group_id',req.query.group_id)
    } else 
    {
        query = query.or(
            {
                $or:[
                    {
                        'sender_id':req.query.sender_id,
                        'recver_id':req.query.recver_id
                    },
                    {
                        'sender_id':req.query.recver_id,
                        'recver_id':req.query.sender_id
                    }
                ]
            }
        );
    }

    // query = query.where('sender_id',req.query.sender_id);
    // query = query.where('recver_id',req.query.recver_id);
    // query = query.populate({path: 'recver_id', model: users, select:'_id first_name last_name username profile_image ' })

    query = query.sort({'-create_date':1})
    query.exec(function(err,result){
        res.json({
            status: true,
            message: "Message retrieved successfully",
            data: result
        });
    })
}


/*
*  This is the function which used to retreive msg detail by msg id
*/
exports.details = function(req,res) {
    console.log(getErrLine().str, "apistart");
    console.log("received params are ", req.params)
    msgs.findOne({_id:req.query.msg_id}).exec( function (err, msg) {
        if (err) {
            res.json({
                status: false,
                message: "Request failed",
                errors:"Message not found"
            });
            return;
        }
        if(!msg) {
            res.json({
                status: false,
                message: "Request failed",
                errors:"Message not found"
            });
            return;
        } 
        res.json({
            status: true,
            message: "Message info retrieved successfully",
            result: msg
        });
    })
}

/**
 * This is the function which used to list all msgs
 */
exports.getAdminList  = function(req,res) {
    console.log(getErrLine().str, "apistart");
    var page = req.query.page ? req.query.page : '1';  
    var limit = req.query.limit ? req.query.limit : '300';  
    var query = msgs.find();
    var offset = ( page == '1' ) ? 0 : ((parseInt(page-1))*10); 
    query = query.where('sender_id',req.query.user_id)
    query = query.sort('-create_date')
    var options = {
    select:   'msg_text msg_image msg_video msg_audio create_date',
    page:page,
    offset:offset,
    limit:limit,    
    };  
    msgs.paginate(query, options).then(function (result) {
        res.json({
            status: true,
            message: "Message retrieved successfully",
            data: result
        });
    }); 
}

/**
 * This is the function which used to add msg from admin
 */
exports.add  = async function(req,res) {
    console.log(getErrLine().str, "apistart");
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        res.json({
            status: false,
            message: "Request failed",
            errors:errors.array()
        });
        return;
    }  

    var block = await blockModel.findOne({ $or: [
        { block_user_id: req.body.recver_id, user_id: req.body.sender_id },
        { block_user_id: req.body.sender_id, user_id: req.body.recver_id },
    ] });

    if(block) {
        res.json({
            status: false,
            message: "You can't send a message to him.",
            errors: "The connection have been blocked with him"
        });
        return;
    } 
    

    var msg = new msgs();
    msg.msg_text = req.body.msg_text;
    msg.msg_image = req.body.msg_image;
    msg.msg_video = req.body.msg_video;
    msg.msg_audio = req.body.msg_audio;
    msg.recver_id = req.body.recver_id;
    msg.sender_id = req.body.sender_id;
    msg.group_id = req.body.group_id;
    msg.readers.push(req.decoded.user_id);
    msg.save(function (err , msgObj) {
        if (err) {
            res.json({
                status: false,
                message: "Request failed",
                errors:err
            });
            return;
        }
        res.json({
            status: true,
            message: "Message created successfully",
            result: msgObj
        });
    });
}



/**
 *  This is the function which used to update msg 
 */
exports.edit  = function(req,res) {
    console.log(getErrLine().str, "apistart");
    msgs.findOne({_id:req.body.msg_id}, function (err, msg) {
        if (err || !msg) {
            res.json({
                status: false,
                message: "Message not found",
                errors:err
            });
            return;
        } else {
            msg.msg_text = req.body.msg_text ?  req.body.msg_text : msg.msg_text;
            msg.msg_image = req.body.msg_image ?  req.body.msg_image : msg.msg_image;
            msg.msg_video = req.body.msg_video ?  req.body.msg_video : msg.msg_video;
            msg.msg_audio = req.body.msg_audio ?  req.body.msg_audio : msg.msg_audio;
            msg.save(function (err , msg) {
                if (err) {
                    res.json({
                        status: false,
                        message: "Request failed",
                        errors:err
                    });
                    return;
                } else {
                    res.json({
                        status: true,
                        message: "Message updated successfully",
                        result: msg 
                    });  
                }
            });
        }
    });
}

/**
 *  This is the function which used to mark msg as Read status by logined user_id
 *  Todo: unread -> read if recver read the msg
 */
exports.markAsRead  = async function(req,res) {
    console.log(getErrLine().str, "apistart");
    var user_id = req.decoded.user_id;

    try {
        var msg = await msgs.findById(req.body.msg_id);
        if(msg.group_id) {
            var _msgs = await msgs.find({ group_id: msg.group_id, readers: { $nin: [user_id] }  });
            console.log(_msgs);
            await Promise.all(_msgs.map( async d => {
                if(!(d?._doc?.readers || d?.readers).find(r => r == user_id)) {
                    let readers = [...(d?._doc?.readers || d?.readers || []), user_id];
                    console.log(readers);
                    let _msg = await msgs.findById(d?._doc?._id || d?._id);
                    _msg.readers = readers;
                    console.log(_msg);
                    await _msg.save();
                }
                // await msgs.findByIdAndUpdate((d?._doc?._id || d?._id), readers);
            }));
            res.json({
                status: true,
                message: "updated successfully",
            });
        } else {
            await msgs.updateMany({ recver_id: user_id}, { is_unread: false });
            res.json({
                status: true,
                message: "updated successfully",
            });
        }
    } catch (error) {
        res.json({
            status: false,
            message: "Something went wrong"
        });    
    }

    // msgs.findOne({_id:req.body.msg_id}, function (err, msg) {
    //     if (err || !msg) {
    //         res.json({
    //             status: false,
    //             message: "Message not found",
    //             errors:err
    //         });
    //         return;
    //     } else {
    //         if(msg.group_id)
    //         {
    //             if(req.decoded.user_id)
    //             {
    //                 if(msg.readers.indexOf(req.decoded.user_id) == -1 )
    //                 {
    //                     msg.readers.push(req.decoded.user_id);
    //                 }    
    //             }    
    //         } else 
    //         {
    //             msg.is_unread = false;
    //         }
    //         msg.save(function (err , msg) {
    //             if (err) {
    //                 res.json({
    //                     status: false,
    //                     message: "Request failed",
    //                     errors:err
    //                 });
    //                 return;
    //             } else {
    //                 res.json({
    //                     status: true,
    //                     message: "Message mark as Read for your id:"+req.decoded.user_id,
    //                     result: msg 
    //                 });  
    //             }
    //         });
    //     }
    // });
}

/**
 *  This is the function which used to delete msg 
 */
 exports.delete  = function(req,res) {
    console.log(getErrLine().str, "apistart");
    msgs.findOne({_id:req.body.msg_id}, function (err, msg) {
        if (err || !msg) {
            res.json({
                status: false,
                message: "Message not found",
                errors:err
            });
            return;
        } else {
            msgs.deleteOne({_id:req.body.msg_id},function(err) {
                res.json({
                    status: true,
                    message: "Message deleted successfully"
                }); 
            })
        }
    });
 }


exports.get_unread_count = async function(req, res) {
    console.log(getErrLine().str, "apistart");
    var user_id = req.decoded.user_id;
    try {
        let m_count = await msgs.count({ group_id: { $eq: null }, recver_id: user_id, is_unread: true });
        
        // console.log("m_count", m_count);//!!20231230 CoderA too many log// disable temporarely
        let group_ids = (await groups.find({ members: { $elemMatch: { $eq: user_id } } })).map(d => d._id);
        // console.log(group_ids);//!!20231230 CoderA too many log// disable temporarely
        let group_count = await msgs.count({ group_id: { $in: group_ids }, readers: { $nin: [user_id] } });
        // console.log("group_count", group_count);//!!20231230 CoderA too many log// disable temporarely
        res.json({
            status: true,
            message: "Retrived successfully",
            result: m_count + group_count
        })
    } catch (error) {
        console.log(error);
        res.json({
            status: false,
            message: "Something went wrong"
        })
    }
}
/* 20240105pm11 CoderX */
exports.get_target_user_dm_status = async function(req, res) {
    try {
        //??? let dmStatus = await users.find({_id: req.body.data},{"privacy_safety.direct_message": 1});
        let dmStatus = await users.find({_id: req.body.params },{"privacy_safety.direct_message": 1});
        res.json({
            status: true,
            dmstatus: dmStatus
        })
    } catch (error) {
        res.json({
            status: false,
            message:"Something went wrong",
            error: error
        })
    }
    
}


