/*
Project : Cryptotrades
FileName : collection.js
Author : Indiefire
File Created : 21/07/2021
CopyRights : Indiefire
Purpose : This is the file which used to define all route releated to collecion api request.
*/

var express = require('express')
var router = express.Router();
var collectionController = require("./../controller/collectionController")
var auth = require("./../../../middleware/auth");
var adminauth = require("./../../../middleware/adminauth");
var optionalauth = require("./../../../middleware/optionalauth");
const { check } = require('express-validator');

router.post('/add',[check('name').not().isEmpty(),auth],collectionController.add)
router.put('/update',[check('collection_id').not().isEmpty(),auth],collectionController.update);
router.get('/fulllist',adminauth,collectionController.getAdminList)
router.get('/list',optionalauth,collectionController.list)
router.get('/detail', optionalauth, collectionController.view)
router.delete('/delete',[check('collection_id').not().isEmpty(),auth],collectionController.delete)
router.post('/generateabi',collectionController.generateABI)

router.get('/collections',optionalauth,collectionController.getCollections) // added by dreampanda 20230528 pm 9

router.post('/create_collection_comment_reaction', auth, collectionController.create_collection_comment_reaction);
router.get('/read_collection_comment_reaction', auth, collectionController.read_collection_comment_reaction);

router.post('/create_collection_comment_love', auth, collectionController.create_collection_comment_love);

router.post('/create_collection_reaction', auth, collectionController.create_collection_reaction);
router.get('/read_collection_reaction', auth, collectionController.read_collection_reactions);

router.post('/create_collection_play', auth, collectionController.create_collection_play);
router.get('/read_collection_play', auth, collectionController.read_collection_plays);

router.post('/create_collection_comment', auth, collectionController.create_collection_comment);
router.get('/read_collection_comment', auth, collectionController.read_collection_comments);
// !!20240118pm7 coderd added below route { (B) comments - edit and delete not working}
router.post('/remove_collection_comment',auth,collectionController.remove_collection_comments)

router.post('/create_collection_love', auth, collectionController.create_collection_love);
router.get('/read_collection_love', auth, collectionController.read_collection_loves);

router.post('/create_collection_like', auth, collectionController.create_collection_like);
router.get('/read_collection_like', auth, collectionController.read_collection_likes);

router.post('/create_collection_boost', auth, collectionController.create_collection_boost);
router.get('/read_collection_boost', auth, collectionController.read_collection_boosts);



module.exports = router