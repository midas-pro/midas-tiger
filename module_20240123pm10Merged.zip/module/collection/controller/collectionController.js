/*
Project : Cryptotrades
FileName : collectionController.js
Author : Indiefire
File Created : 21/07/2021
CopyRights : Indiefire
Purpose : This is the file which used to define all collection related api function.
*/

var collections = require('../model/collectionModel');
var items = require('../../item/model/itemModel');
var users = require('../../user/model/userModel');
var userController = require('./../../user/controller/userController');
var validator = require('validator');
const { validationResult } = require('express-validator');
var cp = require('child_process');
var Web3 = require('web3');
const config = require('../../../helper/config');
var fs = require('fs');

var followers = require('../../user/model/followerModel')

var collection_reactions = require('../model/collectionreactionModel'),
    collection_plays = require('../model/collectionplayModel'),
    collection_comments = require('../model/collectioncommentModel'),
    collection_loves = require('../model/collectionloveModel'),
    collection_likes = require('../model/collectionlikeModel'),
    collection_boosts = require('../model/collectionboostModel'),
    collection_comment_reactions = require('../model/collectioncommentreactionModel'),
    collection_comment_loves = require('../model/collectioncommentloveModel')

const { getErrLine } = require("../../helper/helpers");

function getDateStr(date) {
    var datestr = `${date.getFullYear()}${ ("0" + (date.getMonth() + 1)).substr(-2) }${ ("0" + date.getDate()).substr(-2) }`;
    return datestr
}
/*
* This is the function which used to add collection in database
*/



exports.add = function(req,res) {
    console.log(getErrLine().str, "apistart");
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        res.json({
            status: false,
            message: "Request failed:"+errors.message,
            errors:errors.array()
        });
        return;
    }  
    // var symbol = req.body.name.replace(" ", "_")
    // var collection = new collections();
    // collection.name = req.body.name;
    // collection.description = req.body.description ? req.body.description : '';
    // collection.shortUrl = req.body.shortUrl ? req.body.shortUrl : '';
    // collection.blockchain = req.body.blockchain ? req.body.blockchain : '';
    // collection.blockchain = config.blockchain;
    // collection.royalties = req.body.royalties ? req.body.royalties : 0;
    // collection.banner = req.body.banner ? req.body.banner : '';
    // collection.image = req.body.image ? req.body.image : '';
    // collection.status = 0;
    // collection.multiQty = req.body.multiQty ? req.body.multiQty : 0;
    // collection.author_id = req.decoded.user_id;
    // collection.contract_symbol = symbol;
    var collection = new collections(req.body);
    collection.symbol = req.body.name.replace(" ", "_");
    collection.blockchain = config.blockchain;
    collection.author_id = req.decoded.user_id;
    collection.status = 0
    
    collection.save(function (err ,collectionObj) {
        if (err) {
            res.json({
                status: false,
                message: "Request failed",
                errors:err
            });
            return;
        }
        res.json({
            status: true,
            message: "Collection created successfully",
            result: collectionObj
        });
    });

}

/*
* This is the function which used to update collection in database
*/
exports.update = function(req,res) {
    console.log(getErrLine().str, "apistart");
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        res.json({
            status: false,
            message: "Request failed",
            errors:errors.array()
        });
        return;
    }  
    collections.findOne({_id:req.body.collection_id, author_id: req.decoded.user_id}, function (err, collection) {
        if (err || !collection) {
            res.json({
                status: false,
                message: "Collection not found",
                errors:err
            });
            return;
        } else {
            collection.name = req.body.name ?  req.body.name : collection.name;
            collection.image = req.body.image ?  req.body.image : collection.image;
            collection.banner = req.body.banner ? req.body.banner : collection.banner;
            collection.royalties = req.body.royalties ? req.body.royalties : collection.royalties;
            collection.description = req.body.description ? req.body.description : collection.description;
            collection.shortUrl = req.body.shortUrl ? req.body.shortUrl : '';
            collection.blockchain = req.body.blockchain ? req.body.blockchain : collection.blockchain;
            collection.blockchain = config.blockchain;
            collection.contract_address = req.body.contract_address ? req.body.contract_address : collection.contract_address;
            if(collection.contract_address) {
                collection.status = 1;
            }
            collection.save(function (err , collection) {
                if (err) {
                    res.json({
                        status: false,
                        message: "Request failed",
                        errors:err
                    });
                    return;
                } else {
                    res.json({
                        status: true,
                        message: "Collection updated successfully",
                        result: collection 
                    });  
                }
            });
        }
    });
}

/*
* This is the function which used to delete collection in database
*/
exports.delete = function(req,res) {
    console.log(getErrLine().str, "apistart");
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        res.json({
            status: false,
            message: "Request failed",
            errors:errors.array()
        });
        return;
    }  
    collections.findOne({_id:req.body.collection_id, author_id:req.decoded.user_id}, function (err, collection) {
        if (err || !collection) {
            res.json({
                status: false,
                message: "Collection not found",
                errors:err
            });
            return;
        } 
        items.count({_id:req.body.collection_id},function(err,count) {
            if(count == 0) {
                collections.deleteOne({_id:req.body.collection_id},function(err) {
                    res.json({
                        status: true,
                        message: "Collection deleted successfully"
                    }); 
                })
            } else {
                res.json({
                    status: true,
                    message: "Collection has items and you can't delete it"
                }); 
            }

        })
    });
}

/**
 *  This is the function which used to view collection
 */
exports.view = async function(req, res) {
    console.log(getErrLine().str, "apistart");
    try {
        var user_id = req.decoded?.user_id
        var collection_id = req.query.collection_id;
        var collection = await collections.findById(collection_id)
        .populate({ 
            path: 'author_id', 
            model: 'users', 
            select:   'username email profile_image first_name last_name profile_cover status create_date bio is_idverified',
        });
        if(collection) {
            // handle other data
            let _reaction;
            let _comment;
            let _love;
            let _boost;
            if(user_id) {
                _reaction = await collection_reactions.findOne({ collection_id, user_id });
                _comment = await collection_comments.findOne({ collection_id, user_id, parent_id: { $ne: null } });
                _love = await collection_loves.findOne({ collection_id, user_id });
            }
            let updatedCollection = {
                ...(collection._doc || collection),
                reaction_number: _reaction?.reaction_number || -1,
                isCommented: _comment ? true: false,
                isLoved: _love ? true: false,
                isBoosted: _boost ? true: false
            }
            res.json({
                status: true,
                message: "retrived successfully",
                result: updatedCollection
            })
        } else {
            res.json({
                status: false,
                message: "Collection not found"
            })
        }
    } catch (error) {
        console.log(error);
        res.json({
            status: false,
            message: error?.message
        })
    }
}

/**
 * This is the function which used to list collection with filters
 */
exports.list = function(req,res) {
    console.log(getErrLine().str, "apistart");
    var keyword = req.query.keyword ? req.query.keyword : ''; 
    keyword = keyword.replace("+"," ");     
    var page = req.query.page ? req.query.page : '1';  
    var limit = req.query.limit ? req.query.limit : '10';  
    var query  = collections.find();
    var offset = ( page == '1' ) ? 0 : ((parseInt(page-1))*10);
    if ( keyword != '' ) {
        search = { $or: [ { 
            name :   {
                $regex: new RegExp(keyword, "ig")
        }  } , {
            description : {
                $regex : new RegExp ( keyword , "ig")
            }
        }] }
       query = query.or(search)
    }    
    query = query.where('blockchain',config.blockchain);
    if(req.query.type == "my") {
        if(req.decoded.user_id != null) {
            query = query.where('author_id',req.decoded.user_id).sort('-create_date');
        }
    } else if(req.query.type == "item") {
        if(req.decoded.user_id != null) {
            query = query.sort('-item_count');
        }
    } else {
        query = query.where('status' , 1).sort('-create_date')
    }

    var options = {
        page:page,
        offset:offset,
        limit:limit,    
    };  
    collections.paginate(query, options).then(function (result) {
        res.json({
            status: true,
            message: "Collection retrieved successfully",
            data: result
        });
    }); 
}

/**
 * This is the function which used to list all items for admin
 */
exports.getAdminList = function(req,res) {
    console.log(getErrLine().str, "apistart");
    var keyword = req.query.keyword ? req.query.keyword : ''; 
    keyword = keyword.replace("+"," ");     
    var page = req.query.page ? req.query.page : '1';  
    var limit = req.query.limit ? req.query.limit : '10';  
    var query  = collections.find();
    var offset = ( page == '1' ) ? 0 : ((parseInt(page-1))*10);
    if ( keyword != '' ) {
        search = { $or: [ { 
            name :   {
                $regex: new RegExp(keyword, "ig")
        }  } , {
            description : {
                $regex : new RegExp ( keyword , "ig")
            }
        }] }
       query = query.or(search)
    }    
    query = query.where('blockchain',config.blockchain);
    query = query.sort('-create_date')
    var options = {
    select:   'name description blockchain banner image royalties item_count multiQty shortUrl',
    page:page,
    offset:offset,
    limit:limit,    
    };  
    collections.paginate(query, options).then(function (result) {
        res.json({
            status: true,
            message: "Collection retrieved successfully",
            data: result
        });
    });
}


/**
 * This is the function which used to generate abi for create contract
 */

 exports.generateABI = function(req,res) {
    console.log(getErrLine().str, "apistart");
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        res.json({
            status: false,
            message: "Request failed : generateABI",
            errors:errors.array()
        });
        return;
    } 
    const rootPath = __dirname.replace("module/collection/controller","");
    var symbol = req.body.symbol.replace(" ", "_")
    var symbolsol = symbol+'.sol';
    fs.stat(rootPath+symbol+'.bin', function (fileerr, stats) {
        if(fileerr) {
            //var command = 'sh generate.sh '+symbol + ' "' + req.body.name + '" ' +  symbolsol;
            var contract_name = req.body.name.replace(" ", "_")
            var command = 'sh generate.sh '+symbol + ' "' + contract_name + '" ' +  symbolsol +' ' + config.rpcurl;
            if(req.body.multiQty==1)
            {
                command = 'sh generate_1155.sh '+symbol + ' "' + contract_name + '" ' +  symbolsol +' ' + config.rpcurl;
            }
            cp.exec(command, function(err, stdout, stderr) {
                console.log('stderr ',stderr)
                console.log('stdout ',stdout)
                if(err) {
                    res.json({
                        status: false,
                        message: err.toString().split('ERROR: ').pop().replace(/\n|\r/g, "")
                    });
                    return
                }
                fs.readFile(rootPath+symbol+'.bin', 'utf8' , (err, data) => {
                    if (err) {
                      res.json({
                          status: false,
                          message: err.toString().split('ERROR: ').pop().replace(/\n|\r/g, "")
                      });
                      console.error(err)
                      return
                    }

                    // if(IsNew20220907)
                    fs.readFile(rootPath+symbol+'.abi', 'utf8' , (err, dataabi) => {
                        if (err) {
                        res.json({
                            status: false,
                            message: err.toString().split('ERROR: ').pop().replace(/\n|\r/g, "")
                        });
                        console.error(err)
                        return
                        }
                        res.json({
                            status: true,
                            message: 'generate abi successful',
                            result:data,
                            resultabi:dataabi
                        });
                    })                    
                    // res.json({
                    //     status: true,
                    //     message: 'generate abi successful',
                    //     result:data
                    // });
                })
            });
        } else {
            fs.readFile(rootPath+symbol+'.bin', 'utf8' , (err, data) => {
                if (err) {
                  res.json({
                      status: false,
                      message: err.toString().split('ERROR: ').pop().replace(/\n|\r/g, "")
                  });
                  console.error(err)
                  return
                }

                // if(IsNew20220907)
                fs.readFile(rootPath+symbol+'.abi', 'utf8' , (err, dataabi) => {
                    if (err) {
                      res.json({
                          status: false,
                          message: err.toString().split('ERROR: ').pop().replace(/\n|\r/g, "")
                      });
                      console.error(err)
                      return
                    }
                    res.json({
                        status: true,
                        message: 'generate abi successful',
                        result:data,
                        resultabi:dataabi
                    });
                })

                // if(IsOld)
                // res.json({
                //     status: true,
                //     message: 'generate abi successful',
                //     result:data
                // });
            })
        }
    })
}


async function trendingCollections(req, res) {
    console.log(getErrLine().str, "apistart");
    try {
        var user_id = req.decoded.user_id;

    // get param
    var type = req.query.type,
        rootCat = req.query.rootCat,
        _filter = req.query.filter,
        cat1 = req.query.cat1,
        cat2 = req.query.cat2,
        cat3 = req.query.cat3,
        cat4 = req.query.cat4,

        keyword = req.query.keyword || '',
        page = req.query.page || 1,
        limit = req.query.limit || 15,

        filterShow = req.query.filterShow,
        filterFrom = req.query.filterFrom,
        filterTime = req.query.filterTime,
        filterTimeFrom = req.query.filterTimeFrom,
        filterTimeTo = req.query.filterTimeTo,

        tfilterFrom = req.query.tfilterFrom,
        tfilterTime = req.query.tfilterTime,
        tfilterTimeFrom = req.query.tfilterTimeFrom,
        tfilterTimeTo = req.query.tfilterTimeTo,
        TrendingOrderBy = req.query.TrendingOrderBy;
        if(type == 'Marketplace') {
            cat1 = cat2; cat2 = cat3; cat3 = null;
        }
        
        var pipeline = [];
        pipeline.push({
            $sort: { create_date: -1 }
        })
       
        switch(tfilterTime) {
            case 'now':
                var date = new Date();
                var datestr = getDateStr(date)
                pipeline.push(
                    {
                        $addFields: {
                            _nowFields: {
                                $filter: {
                                    input: `$daily_trending`,
                                    as: "trend",
                                    cond: {
                                        $eq: ["$$trend.date",  datestr]
                                    }
                                }
                            }
                        }
                    },{
                        $addFields: {
                            nowSum: {
                                $sum: {
                                    $filter: {
                                        input: "$_nowFields.count",
                                        cond: []
                                    }
                                }
                            }
                        }
                    },
                    {
                        $sort: { nowSum: -1 }
                    }
                )
                break;
            case 'yesterday':
                var date = new Date();
                date.setDate(date.getDate() - 1);
                var datestr = getDateStr(date)
                pipeline.push(
                    {
                        $addFields: {
                            _yesterdayFields: {
                                $filter: {
                                    input: `$daily_trending`,
                                    as: "trend",
                                    cond: {
                                        $eq: ["$$trend.date",  datestr]
                                    }
                                }
                            }
                        }
                    },{
                        $addFields: {
                            yesterdaySum: {
                                $sum: {
                                    $filter: {
                                        input: "$_yesterdayFields.count",
                                        cond: []
                                    }
                                }
                            }
                        }
                    },
                    {
                        $sort: { yesterdaySum: -1 }
                    }
                )
                break;
            case 'thisweek':
                var date = new Date();
                var weekAgo = new Date(new Date(new Date() - 7 * 24 * 60 * 60 * 1000));
                var datestr = getDateStr(weekAgo)
                console.log(datestr)
                pipeline.push(
                    {
                        $addFields: {
                            _thisweekFields: {
                                $filter: {
                                    input: `$daily_trending`,
                                    as: "trend",
                                    cond: {
                                        $gte: ["$$trend.date",  datestr]
                                    }
                                }
                            }
                        }
                    },{
                        $addFields: {
                            weeklySum: {
                                $sum: {
                                    $filter: {
                                        input: "$_thisweekFields.count",
                                        cond: []
                                    }
                                }
                            }
                        }
                    },
                    {
                        $sort: { weeklySum: -1 }
                    }
                )
                break;
            case 'thismonth':
                var date = new Date();
                var monthAgo = new Date(date.getFullYear(), date.getMonth() - 1, date.getDate()); // Get date 1 month ago
                var datestr = getDateStr(monthAgo)
                pipeline.push(
                    {
                        $addFields: {
                            _thismonthFields: {
                                $filter: {
                                    input: `$daily_trending`,
                                    as: "trend",
                                    cond: {
                                        $gte: ["$$trend.date",  datestr]
                                    }
                                }
                            }
                        }
                    },{
                        $addFields: {
                            monthlySum: {
                                $sum: {
                                    $filter: {
                                        input: "$_thismonthFields.count",
                                        cond: []
                                    }
                                }
                            }
                        }
                    },
                    {
                        $sort: { monthlySum: -1 }
                    }
                )
                break;
            case 'range':
                var startDate = new Date(tfilterTimeFrom);
                var endDate = new Date(tfilterTimeTo);
                var datestr1 = getDateStr(startDate);
                var datestr2 = getDateStr(endDate);

                pipeline.push(
                    {
                        $addFields: {
                            _rangeFields: {
                                $filter: {
                                    input: `$daily_trending`,
                                    as: "trend",
                                    cond: {
                                        $gte: ["$$trend.date",  datestr1],
                                        $lt: ["$$trend.date", datestr2]
                                        
                                    }
                                }
                            }
                        }
                    },{
                        $addFields: {
                            rangeSum: {
                                $sum: {
                                    $filter: {
                                        input: "$_rangeFields.count",
                                        cond: []
                                    }
                                }
                            }
                        }
                    },
                    {
                        $sort: { rangeSum: -1 }
                    }
                )
                break;
            default: 
                break;    
        }

        var matchClause = {  }

        if(_filter == 'For you') {
            let followings = (await followers.find({ user_id })).map(d => d.star_id);
            let query = {
                author_id: { $in: followings }
            }
            matchClause = { ...matchClause,  query }
        }

        switch(tfilterFrom) {
            case 'Everybody':
            // Do nothing, get all posts
                break;
            case 'following':
                let _followings = (await followers.find({ user_id })).map(d => ObjectID(d.star_id) );
                // pipeline.push({ $match: { author_id: { $in: _followings } } });
                matchClause.author_id = { $in: _followings }
                break;
            default:
                break;
        }

        pipeline.push({
            $match: matchClause,
        });

        
        var offset = (page == '1') ? 0 : ((parseInt(page - 1)) * limit);
        const countPipeline = [ ...pipeline, { $count: "count" } ];
        pipeline.push(
            {
                $skip: offset
            },
            {
                $limit: Number(limit)
            }
        )
        const [ docs, countResult ] = await Promise.all([
            collections.aggregate(pipeline).exec(),
            collections.aggregate(countPipeline).exec()
        ]);
        const totalDocs = countResult[0] ? countResult[0].count : 0;
        const currentPage = parseInt(req.query.page) || 1;
        const _limit = parseInt(req.query.limit) || 10;
        const totalPages = Math.ceil(totalDocs / limit);
        const hasNextPage = currentPage < totalPages;
        const nextPage = hasNextPage ? currentPage + 1 : null;

        let reactions = await collection_reactions.find();
        let playLists = await collection_plays.find();
        let comments = await collection_comments.find({ parent_id: null });
        let likes = await collection_likes.find();
        let loves = await collection_loves.find();
        let boosts = await collection_boosts.find();

        const updatedDocs = await Promise.all(docs.map(async (d) => {
            let author_id = await users.findById(d.author_id, { first_name: 1, last_name: 1, username: 1, is_idverified: 1, profile_image: 1 });
            const collectionReactions = reactions.filter(r => r.collection_id == d._id.toString() && r.user_id == user_id);
            const reactionNumber = collectionReactions.length ? collectionReactions[0].reaction_number : -1;
            return {
                ...d,
                author_id: author_id,
                reaction_number: reactionNumber,
                isPlayed: playLists.some(pl => pl.collection_id == d._id.toString() && pl.user_id == user_id),
                isCommented: comments.some(pl => pl.collection_id == d._id.toString() && pl.user_id == user_id),
                isLiked: likes.some(pl => pl.collection_id == d._id.toString() && pl.user_id == user_id),
                isLoved: loves.some(pl => pl.collection_id == d._id.toString() && pl.user_id == user_id),
                isBoosted: boosts.some(pl => pl.collection_id == d._id.toString() && pl.user_id == user_id)
            }
        }));

        res.json({
            status: true,
            message: "collections retrieved successfully",
            data: {
                docs: updatedDocs,
                totalDocs,
                limit: _limit,
                totalPages,
                currentPage,
                hasNextPage,
                nextPage
            }
        });
       
    } catch(e) {
        console.log(e)
        res.json({
            status: false,
            message: "something went wrong",
        });
    }
}

exports.getCollections = async function(req, res) {
    console.log(getErrLine().str, "apistart");
    if(req.query.rootCat == 'Trending' || req.query.filter == 'For you' || req.query.filter == 'Trending') {
        trendingCollections(req, res);
    } else {
        try {
            var user_id = req.decoded.user_id;
            // get param
            var type = req.query.type,
                rootCat = req.query.rootCat,
                cat1 = req.query.cat1,
                cat2 = req.query.cat2,
                cat3 = req.query.cat3,
                cat4 = req.query.cat4,

                keyword = req.query.keyword || '',
                page = req.query.page || 1,
                limit = req.query.limit || 15,

                fFavorites = req.query.fFavorites,

                filterShow = req.query.filterShow,
                filterFrom = req.query.filterFrom,
                filterTime = req.query.filterTime,
                filterTimeFrom = req.query.filterTimeFrom,
                filterTimeTo = req.query.filterTimeTo;
                // new parameter will be added
            var query = collections.find();
            query = query.sort({ create_date: -1 });
            if(rootCat == 'Trending') {
                query.sort('-n_trending');
            }
            query = query.populate({
                path: 'author_id',
                model: users,
                select: '_id username first_name last_name profile_image metamask_info'
            });

            // filter I made favorite
            console.log(fFavorites);
            if(fFavorites) {
                var itemIds = (await collection_loves.find({user_id})).map(d => d.collection_id);
                console.log(itemIds);
                query = query.find({ _id: { $in: itemIds } });
            }

            if(keyword != '') {
                query = query.find({ $or: [
                    { name: { $regex: new RegExp(keyword, "ig") }  },
                    { description:  { $regex: new RegExp(keyword, "ig") } }
                ] })
            }

        
            let play_lists = (await collection_plays.find({ user_id })).map(d => d.collection_id);
            switch(filterShow) {
                case 'Everything': break;
                case 'seen': 
                    query = query.find({ _id: { $in: play_lists } });
                    break;
                case 'notseen':
                    query = query.find({ _id: { $nin: play_lists } });
                    break;
                default:
                    break;
            }
            let user = await users.findById(user_id);
            switch(filterFrom) {
                case 'Everybody':
                    break;
                case 'following':
                    let _followings = (await followers.find({ user_id })).map(d => d.star_id);
                    query = query.find({ author_id: { $in: _followings } })
                    break;
                case 'muted':
                    query = query.find({ author_id: { $in: user?.muted_block?.muted_accounts } })
                    break;
                default: 
                    break;
            }

            switch(filterTime) {
                case 'anytime':
                    break;
                case 'today':
                    var date = new Date();
                    var startOfToday = new Date(date.getFullYear(), date.getMonth(), date.getDate());
                    var endOfToday = new Date(startOfToday.getTime() + 24 * 60 * 60 * 1000 - 1); // End of day is one millisecond before start of next day
                    query = query.find({ create_date: { $gte: startOfToday, $lt: endOfToday } })
                    break;
                case 'thisweek':
                    query = query.find({ create_date: { $gte: new Date(new Date() - 7 * 24 * 60 * 60 * 1000) } })
                    break;
                case 'thismonth':
                    var date = new Date();
                    var monthStart = new Date(date.getFullYear(), date.getMonth(), 1); // Get first day of current month
                    var monthEnd = new Date(date.getFullYear(), date.getMonth() + 1, 0); // Get last day of current month
                    query = query.find({ create_date: { $gte: monthStart, $lte: monthEnd }});
                    break;
                case 'range':
                    var startDate = new Date(filterTimeFrom);
                    var endDate = new Date(filterTimeTo);
                    query = query.find({ create_date: { $gte: startDate, $lte: endDate } })
                    break;
                default:
                    break;
            }
            let reactions = await collection_reactions.find();
            let playLists = await collection_plays.find();
            let comments = await collection_comments.find();
            let likes = await collection_likes.find();
            let loves = await collection_loves.find();
            let boosts = await collection_boosts.find();
            
            var offset = (page == '1') ? 0 : ((parseInt(page - 1)) * limit);
            var options = {
                page: page,
                offset: offset,
                limit: limit,
            };
            collections.paginate(query, options).then(function (result) {
                const updatedDocs = result.docs.map(d => {
                    // console.log(playLists.some(pl => pl.collection_id == d._doc._id && pl.user_id == user_id))
                    const collectionReactions = reactions.filter(r => r.collection_id == d._doc._id.toString() && r.user_id == user_id);
                    const reactionNumber = collectionReactions.length ? collectionReactions[0].reaction_number : -1;
                    return {
                        ...d._doc,  // copy all the existing fields
                        reaction_number: reactionNumber,
                        isPlayed: playLists.some(pl => pl.collection_id == d._doc._id.toString() && pl.user_id == user_id),
                        isCommented: comments.some(pl => pl.collection_id == d._doc._id.toString() && pl.user_id == user_id),
                        isLiked: likes.some(pl => pl.collection_id == d._doc._id.toString() && pl.user_id == user_id),
                        isLoved: loves.some(pl => pl.collection_id == d._doc._id.toString() && pl.user_id == user_id),
                        isBoosted: boosts.some(pl => pl.collection_id == d._doc._id.toString() && pl.user_id == user_id)
                    }
                });
            
                const updatedResult = { ...result, docs: updatedDocs };
            
                res.json({
                    status: true,
                    message: "collections retrieved successfully",
                    data: updatedResult
                });

            });
        } catch(err) {
            console.log(err)
            res.json({
                status: false,
                message: 'Something went wrong.'
            })
        }   
    }

    
}



exports.create_collection_reaction = function(req, res) {
    console.log(getErrLine().str, "apistart");
    var user_id = req.decoded.user_id;
    var collection_id = req.body.collection_id;
    var reaction_number = req.body.reaction_number;
    collection_reactions.findOne({ collection_id, user_id }, function(err, result) {
        if(err) {
            res.json({
                status: false,
                message: "db error"
            });
        }
        if(result) {
            if(result.reaction_number == reaction_number) {
                collections.findById(collection_id, function(err, collection) {
                    if(err || !collection) {
                        res.json({
                            status: false,
                            message: 'collection not found'
                        });
                        return;
                    }
                    const n_reaction = collection.n_reaction - 1;
                    collection.n_reaction = n_reaction;
                    const n_reaction_detail = collection.n_reaction_detail[`r_${reaction_number}`] - 1;
                    collection.n_reaction_detail[`r_${reaction_number}`] = n_reaction_detail;

                    var date = new Date();
                    var datestr = getDateStr(date)
    
                    let daily_trending = collection.daily_trending.find(d => d.date == datestr)
                    if(daily_trending) {
                        let count = daily_trending.count - 1;
                        daily_trending.count = count
                    } else {
                        let newObj = {
                            date: datestr,
                            count: -1
                        }
                        collection.daily_trending.push(newObj)
                    }

                    collection.save(function(err, collectionSaved) {
                        collection_reactions.remove({ _id: result._id }, function(err, result) {
                            if(err || !result) {
                                res.json({
                                    status: false,
                                    message: "Something went wrong"
                                })
                            } else {
                                res.json({
                                    status: true,
                                    message: "Removed successfully"
                                })
                            }
                        })
                    })
                })
            } else {
                collections.findById(collection_id, function(err, collection) {
                    if(err || !collection) {
                        res.json({
                            status: false,
                            message: 'Item not found'
                        });
                        return;
                    }
                    const n_reaction_detail = collection.n_reaction_detail[`r_${reaction_number}`] + 1;
                    collection.n_reaction_detail[`r_${reaction_number}`] = n_reaction_detail;
                    const last_n_reaction_detail = collection.n_reaction_detail[`r_${result.reaction_number}`] - 1;
                    collection.n_reaction_detail[`r_${result.reaction_number}`] = last_n_reaction_detail;
                    collection.save(function(err, collectionSaved) {
                        result.reaction_number = reaction_number;
                        result.save(function(err, result) {
                            if(err || !result) {
                                res.json({
                                    status: false,
                                    message: "Update error"
                                })
                                return
                            }
                            res.json({
                                status: true,
                                message: "updated successfully"
                            })
                        })
                    })
                })
            }
            
        } else {
            var newOne = collection_reactions({ collection_id, user_id, reaction_number });
            collections.findById(collection_id, async function(err, collection) {
                if(err || !collection) {
                    res.json({
                        status: false,
                        message: 'Item not found'
                    });
                    return;
                }
                const n_reaction = collection.n_reaction + 1;
                collection.n_reaction = n_reaction;
                const n_reaction_detail = collection.n_reaction_detail[`r_${reaction_number}`] + 1;
                collection.n_reaction_detail[`r_${reaction_number}`] = n_reaction_detail;

                var date = new Date();
                var datestr = getDateStr(date)

                let daily_trending = collection.daily_trending.find(d => d.date == datestr)
                if(daily_trending) {
                    let count = daily_trending.count + 1;
                    daily_trending.count = count
                } else {
                    let newObj = {
                        date: datestr,
                        count: 1
                    }
                    collection.daily_trending.push(newObj)
                }
                
                // let n_trending = collection.daily_trending[datestr] || 0;
                // collection.daily_trending[datestr] = n_trending + 1; 
                try {
                    await collection.save();
                    await newOne.save();
                    res.json({
                        status: true,
                        message: "Saved successfully"
                    })
                } catch(e) {
                    res.json({
                        status: false,
                        message: "collection save error"
                    })
                }
            })
        }
    })
}

exports.read_collection_reactions = function(req, res) {
    console.log(getErrLine().str, "apistart");
    var user_id = req.decoded.user_id;
    var collection_id = req.query.collection_id;
    collections.findById(collection_id, function(err, result) {
        if(err) {
            res.json({
                status: false,
                message: "db error"
            })
            return
        }
        collection_reactions.findOne({ collection_id, user_id }, function(err, reaction) {
            if(err) {
                res.json({
                    status: false,
                    message: "Db error"
                })
            } else {
                var resData = {
                    data: result,
                    reaction: reaction
                }
                res.json({
                    status: true,
                    message: 'retrieved successfully',
                    result: resData
                })
            }
        })
        
    })
}


exports.create_collection_play = function(req, res) {
    console.log(getErrLine().str, "apistart");
    var user_id = req.decoded.user_id;
    var collection_id = req.body.collection_id;

    collections.findById(collection_id, function(err, collection) {
        if(err || !collection) {
            res.json({
                status: false,
                message: 'Db error or not found collection'
            });
            return;
        }
        collection_plays.findOne({ collection_id: collection_id, user_id: user_id }, function(err, result) {
            if(err || result) { 
                res.json({ status: false, message: 'Db error or already done' }); 
                return; 
            } else {
                var newOne = new collection_plays({
                    collection_id: collection_id,
                    user_id: user_id
                });
                const n_play = collection.n_play + 1;
                collection.n_play = n_play;
                newOne.save(function(err, result) {
                    collection.save(function(err, result) {
                        res.json({
                            status: true,
                            message: 'Saved successfully'
                        })
                    })
                })    
            }
        })
    })
}

exports.read_collection_plays = function(req, res) {
    console.log(getErrLine().str, "apistart");
    var user_id = req.decoded.user_id;
    collection_plays.find({ user_id:  user_id }, function(err, result) {
        if(err) {
            res.json({
                status: false,
                message: "db error"
            })
            return
        }
        res.json({
            status: true,
            message: 'retrieved successfully',
            result: result
        })
    })
}

exports.create_collection_comment_reaction = function(req, res) {
    console.log(getErrLine().str, "apistart");
    var user_id = req.decoded.user_id;
    var collection_comment_id = req.body.collection_comment_id;
    var reaction_number = req.body.reaction_number;
    collection_comment_reactions.findOne({ collection_comment_id, user_id }, function(err, result) {
        if(err) {
            res.json({
                status: false,
                message: "db error"
            });
        }
        if(result) {
            if(result.reaction_number == reaction_number) {
                collection_comments.findById(collection_comment_id, function(err, collection_comment) {
                    if(err || !collection_comment) {
                        res.json({
                            status: false,
                            message: 'Item Comment not found'
                        });
                        return;
                    }
                    const n_reaction = collection_comment.n_reaction - 1;
                    collection_comment.n_reaction = n_reaction;
                    const n_reaction_detail = collection_comment.n_reaction_detail[`r_${reaction_number}`] - 1;
                    collection_comment.n_reaction_detail[`r_${reaction_number}`] = n_reaction_detail;
                    collection_comment.save(function(err, collectionSaved) {
                        result.reaction_number = reaction_number;
                        result.save(function(err, result) {
                            if(err || !result) {
                                res.json({
                                    status: false,
                                    message: "Update error"
                                })
                                return
                            }
                            collection_comment_reactions.remove({ collection_comment_id, user_id }, function(err, result) {
                                if(err) {
                                    res.json({
                                        status: false,
                                        message: 'collection comment reaction remove failed'
                                    })
                                } else {
                                    res.json({
                                        status: true,
                                        message: "updated successfully"
                                    })
                                }
                            })
                            
                        })
                    })
                })
            } else {
                collection_comments.findById(collection_comment_id, function(err, collection_comment) {
                    if(err || !collection_comment) {
                        res.json({
                            status: false,
                            message: 'Item Comment not found'
                        });
                        return;
                    }
                    const n_reaction_detail = collection_comment.n_reaction_detail[`r_${reaction_number}`] + 1;
                    collection_comment.n_reaction_detail[`r_${reaction_number}`] = n_reaction_detail;
                    const last_n_reaction_detail = collection_comment.n_reaction_detail[`r_${result.reaction_number}`] - 1;
                    collection_comment.n_reaction_detail[`r_${result.reaction_number}`] = last_n_reaction_detail;
                    collection_comment.save(function(err, collectionSaved) {
                        result.reaction_number = reaction_number;
                        result.save(function(err, result) {
                            if(err || !result) {
                                res.json({
                                    status: false,
                                    message: "Update error"
                                })
                                return
                            }
                            res.json({
                                status: true,
                                message: "updated successfully"
                            })
                        })
                    })
                })
            }

           
            
        } else {
            var newOne = collection_comment_reactions({ collection_comment_id, user_id, reaction_number });
            collection_comments.findById(collection_comment_id, function(err, collection_comment) {
                if(err || !collection_comment) {
                    res.json({
                        status: false,
                        message: 'collection_comment not found'
                    });
                    return;
                }
                const n_reaction = collection_comment.n_reaction + 1;
                collection_comment.n_reaction = n_reaction;
                const n_reaction_detail = collection_comment.n_reaction_detail[`r_${reaction_number}`] + 1;
                collection_comment.n_reaction_detail[`r_${reaction_number}`] = n_reaction_detail;
                collection_comment.save(function(err, result) {
                    newOne.save(function(err, result) {
                        res.json({
                            status: true,
                            message: "Saved successfully"
                        })
                    })
    
                })
            })
        }
    })
}

exports.read_collection_comment_reaction = function(req, res) {
    console.log(getErrLine().str, "apistart");
    var user_id = req.decoded.user_id;
    var collection_comment_id = req.query.collection_comment_id;
    collection_comments.findById(collection_comment_id, function(err, result) {
        if(err) {
            res.json({
                status: false,
                message: "db error"
            })
            return
        }
        collection_comment_reactions.findOne({ collection_comment_id, user_id }, function(err, reaction) {
            if(err) {
                res.json({
                    status: false,
                    message: "db error"
                })
            } else {
                var resData = {
                    data: result,
                    reaction: reaction
                }
                res.json({
                    status: true,
                    message: 'retrieved successfully',
                    result: resData
                })
            }
        })
       
    })
}


exports.create_collection_comment_like = function(req, res) {
    console.log(getErrLine().str, "apistart");
    var comment_id = req.body.comment_id;
    var user_id = req.decoded.user_id;
    collection_comments.findById(comment_id, function(err, collection_comment) {
        collection_comments.findOne({ _id: comment_id, user_id: user_id }, function(err, result) {
            if(err || result) {
                res.json({
                    status: false,
                    message: "Db error or already done"
                })
                return;
            } 
            const n_comment = collection_comment.n_comment;
            collection_comment.n_comment = n_comment;
            collection_comment.save(function(err, result) {
                var newOne = new collection_comment_likes({
                    comment_id: comment_id,
                    user_id: user_id
                });
                newOne.save(function(err, result) {
                    if(err) {
                        res.json({
                            status: false,
                            message: 'Db error'
                        })
                        return ;
                    }
                    res.json({
                        status: true,
                        message: 'Saved successfully.'
                    })
                })
            })
        })
    })
    
}


exports.create_collection_comment_love = function(req, res) {
    console.log(getErrLine().str, "apistart");
    var user_id = req.decoded.user_id;
    var collection_comment_id = req.body.collection_comment_id;
    collection_comment_loves.findOne({ collection_comment_id, user_id }, async function(err, result) {
        if(err) {
            res.json({
                status: false,
                message: "Db error or already done"
            })
            return
        } else {
            if(result) {
                try {
                    let collection_comment = await collection_comments.findById(collection_comment_id);
                    if(collection_comment) {
                        // decrease the love number
                        const n_love = collection_comment.n_love - 1;
                        collection_comment.n_love = n_love;
                        collection_comment.save();
                        result.remove();
                        res.json({
                            status: true,
                            message: "Removed successfully."
                        });

                    } else {
                        res.json({
                            status: false,
                            message: "Not found collection comment"
                        });
                    }
                } catch (error) {
                    res.json({
                        status: false,
                        message: "Something weng wrong"
                    })
                }
            } else {
                var newOne = collection_comment_loves({
                    collection_comment_id, user_id
                });
                collection_comments.findById(collection_comment_id, function(err, collection_comment) {
                    if(err || !collection_comment) {
                        res.json({
                            status: false,
                            message: "Db error or not found collection comment"
                        });
                        return;
                    } else {
                        let n_love = collection_comment.n_love + 1;
                        collection_comment.n_love = n_love;
                        collection_comment.save(function(err, result) {
                            if(err) {
                                res.json({
                                    status: false,
                                    message: "collection comment update error"
                                });
                                return;
                            }
                            newOne.save(function(err, result) {
                                if(err) {
                                    res.json({
                                        status: false,
                                        message: "New love is not save correctly"
                                    })
                                    return
                                }
                                res.json({
                                    status: true,
                                    message: "Saved successfully"
                                })
                            })
                        })
                    }
                })
            }
        }
    })
}


exports.create_collection_comment = function(req, res) {
    console.log(getErrLine().str, "apistart");
    var user_id = req.decoded.user_id
    collections.findOne({_id:req.body.collection_id}, async function (err, post1) {
        if (err || !post1) {
            res.json({
                status: false,
                message: "Post not found",
                errors:err
            });
            return;
        }
        var newcomment = new collection_comments(req.body);
        if(req.body.parent_id) {
            // Define comment_count and increment it before updating the document
            const parent_id = req.body.parent_id;
            collection_comments.findById(parent_id, async function(err, parent) {
                if (err) {
                    console.log(err);
                    res.json({
                        status: false,
                        message: 'error',
                        errors: err //20240119am3
                        // errors: error
                    })
                } else {
                    // Increment comment_count by 1
                    // if(parent.user_id != req.decoded.user_id) {
                        // post1.n_comment = post1.n_comment + 1;
                        const n_comment = parent.n_comment + 1;
                        // Update the parent document with the new comment_count value
                        // increase trending number if collection is not belong to u
                        if(post1.creator_id != user_id) {
                            var date = new Date();
                            var datestr = getDateStr(date)
                            
                            let daily_trending = post1.daily_trending.find(d => d.date == datestr)
                            if(daily_trending) {
                                let count = daily_trending.count + 3;
                                daily_trending.count = count
                            } else {
                                let newObj = {
                                    date: datestr,
                                    count: 1
                                }
                                post1.daily_trending.push(newObj)
                            }
                        }
                        try {
                            await newcomment.save();
                            await collection_comments.findByIdAndUpdate(parent_id, { n_comment: n_comment });   
                            await post1.save(); 
                            let new_comment = await collection_comments.findById(new_comment._id)
                            query.populate({
                                path: 'user_id',
                                model: 'users',
                                select: '_id first_name last_name username profile_image is_idverified'
                            })  
                            res.json({
                                status: true,
                                message: "Saved successfully",
                                result: {
                                    new_comment
                                }
                            });
                        } catch (error) {
                            res.json({
                                status: false,
                                message: "error was occured"
                            })
                        }
                    // } else {
                    //     res.json({
                    //         status: false,
                    //         message: "That is yours, you can reply this "
                    //     })
                    // }
                }
            });

        } else {
             if(post1.creator_id != user_id) {
                var date = new Date();
                var datestr = getDateStr(date)
                
                let daily_trending = post1.daily_trending.find(d => d.date == datestr)
                if(daily_trending) {
                    let count = daily_trending.count + 3;
                    daily_trending.count = count
                } else {
                    let newObj = {
                        date: datestr,
                        count: 1
                    }
                    post1.daily_trending.push(newObj)
                }
            }

            try {
                await newcomment.save();
                await post1.save();
                let new_comment = await collection_comments.findById(new_comment._id)
                query.populate({
                    path: 'user_id',
                    model: 'users',
                    select: '_id first_name last_name username profile_image is_idverified'
                }) 
                res.json({
                    status: true,
                    message: "Comment added successfully",
                    result: {
                        new_comment
                    }
                });
            } catch(e) {
                res.json({
                    status: false,
                    message: "Comment added unsuccessfully",
                });
            }
        }
       
        
    });
}

exports.read_collection_comments = async function(req,res) {
    console.log(getErrLine().str, "apistart");
    var keyword = req.query.keyword || ''; // added dreampanda 20230523 pm 9
    var page = req.query.page ? req.query.page : '1';  
    var limit = req.query.limit ? req.query.limit : '15';  
    var parent_id = req.query.parent_id || '';
    var user_id = req.decoded.user_id;
    var sortKey = req.query.sortKey;
    var query = collection_comments.find();
    var offset = ( page == '1' ) ? 0 : ((parseInt(page-1))*10);
    if(parent_id != '') {
        query = query.find({ parent_id: parent_id });
    } else {
        query = query.where('collection_id',req.query.collection_id);
        query = query.find({ parent_id: null })
    }
    if(keyword != '') {
        query = query.find({ description: { $regex: new RegExp(keyword, "ig") } })
    } 

    if(sortKey && sortKey == 'newest') {
        query = query.sort('-created_date')
    } else {
        query = query.sort('created_date')
    }
    var options = {
        page:page,
        offset:offset,
        limit:limit,    
    };

    let reactions = await collection_comment_reactions.find();
    let comments = await collection_comments.find({ parent_id: { $ne: null } });
    let loves = await collection_comment_loves.find();
    let boosts = []; // temporary
    query = query.populate({
        path: 'user_id',
        model: 'users',
        select: '_id first_name last_name username profile_image is_idverified'
    })  
    collection_comments.paginate(query, options).then(function (result) {
        const updatedDocs = result.docs.map(d => {
            // console.log(playLists.some(pl => pl.collection_id == d._doc._id && pl.user_id == user_id))
            const collectionReactions = reactions.filter(r => r.collection_comment_id == d._doc._id.toString() && r.user_id == user_id);
            const reactionNumber = collectionReactions.length ? collectionReactions[0].reaction_number : -1;
            const date = new Date();
            return {
                ...d._doc,  // copy all the existing fields
                reaction_number: reactionNumber,
                isCommented: comments.some(pl => pl.parent_id == d._doc._id.toString() && pl.user_id == user_id),
                isLoved: loves.some(pl => pl.collection_comment_id == d._doc._id.toString() && pl.user_id == user_id),
                isBoosted: boosts.some(pl => pl.collection_comment_id == d._doc._id.toString() && pl.user_id == user_id),
                serverDate: date
            }
        });
    
        const updatedResult = { ...result, docs: updatedDocs };
    
        res.json({
            status: true,
            message: "collection_comments retrieved successfully",
            data: updatedResult
        });
    }); 
}


exports.create_collection_like = function(req, res) {
    console.log(getErrLine().str, "apistart");
    var user_id = req.decoded.user_id;
    var collection_id = req.body.collection_id;
    if(!collection_id) {
        res.json({
            status: false,
            message: "Request error"
        })
    } else {
        collection_likes.findOne({ collection_id: collection_id, user_id: user_id }, async function(err, result) {
            if(err) { res.json({ status: false, message: 'Something went wrong' }); return; }
            if(result) {
                const n_like = collection.n_like - 1;
                collection.n_like = n_like;
                try {
                    await collection.save();
                    await result.remove();
                    res.json({
                        status: true,
                        message: "removed successfully"
                    });
                } catch(e) {
                    console.log(e);
                    res.json({
                        status: false,
                        message: "Something went wrong"
                    });
                }
            } else {
                collections.findById(collection_id, function(err, collection) {
                    if(err || !collection) {
                        res.json({
                            status: false,
                            message: 'Db error or not find collection'
                        })
                        return;
                    }
                    const n_like = collection.n_like + 1;
                    collection.n_like = n_like;
                    collection.save(function(err, result) {
                        var newOne = new collection_likes({
                            collection_id: collection_id,
                            user_id: user_id
                        });
                        newOne.save(function(err, result) {
                            res.json({
                                status: true,
                                message: 'saved successfully'
                            })
                        })
                    })
                })
            }
        })
    }
}

exports.read_collection_likes = function(req, res) {
    console.log(getErrLine().str, "apistart");
    var user_id = req.decoded.user_id;
    collection_likes.find({ user_id: user_id }, function(err, result) {
        if(err) {
            res.json({ status: false, message: 'DB error' })
            return;
        }
        res.json({
            status: true, 
            message: 'Retrived successfully',
            result: result
        })
    })
}


exports.create_collection_love = function(req, res) {
    console.log(getErrLine().str, "apistart");
    var user_id = req.decoded.user_id;
    var collection_id = req.body.collection_id;

    collection_loves.findOne({ collection_id: collection_id, user_id: user_id }, async function(err, result) {
        if(err) { res.json({ status: false, message: 'Db error or else already done.' }); return; }
        if(result) {
            try {
                let collection = await collections.findById(collection_id);
                if(collection) {
                    const n_love = collection.n_love - 1; // decrease collection love count
                    collection.n_love = n_love;
                    // handle daily trending
                    var date = new Date();
                    var datestr = getDateStr(date); 
                    let daily_trending = collection.daily_trending.find(d => d.date == datestr)
                    if(daily_trending) {
                        let count = daily_trending.count - 2;
                        daily_trending.count = count
                    } else {
                        let newObj = {
                            date: datestr,
                            count: -2
                        }
                        collection.daily_trending.push(newObj)
                    }

                    collection.save();
                    result.remove();
                    res.json({
                        status: true,
                        message: "Removed successfully"
                    });
                } else {
                    res.json({
                        status: false,
                        message: "collection not found"
                    });
                }
            } catch(e) {
                console.log(e);
                res.json({
                    status: false,
                    message: "Something went wrong."
                })
            }
        } else {
            collections.findById(collection_id, async function(err, collection) {
                if(err || !collection) {
                    res.json({
                        status: false,
                        message: "Db error or collection not found"
                    })
                    return
                }
               try {
                    const n_love = collection.n_love + 1;
                    collection.n_love = n_love;
    
                    // handle trending
                    var date = new Date();
                    var datestr = getDateStr(date)
    
                    let daily_trending = collection.daily_trending.find(d => d.date == datestr)
                    if(daily_trending) {
                        let count = daily_trending.count + 2;
                        daily_trending.count = count
                    } else {
                        let newObj = {
                            date: datestr,
                            count: 1
                        }
                        collection.daily_trending.push(newObj)
                    }
    
                    await collection.save();
    
                    // create new love user agianst that collection
                    var newOne = new collection_loves({
                        collection_id: collection_id,
                        user_id: user_id
                    });
                    await newOne.save();
                    res.json({
                        status: true,
                        message: 'saved successfully'
                    })
    
                } catch (error) {
                    console.log(error)
                    res.json({
                        status: false,
                        message: "error was occured while saving data"
                    })
                }
            })
        }
    })
}

exports.read_collection_loves = function(req, res) {
    console.log(getErrLine().str, "apistart");
    var user_id = req.decoded.user_id;
    collection_loves.find({ user_id: user_id }, function(err, result) {
        if(err) {
            res.json({ status: false, message: 'DB error' })
            return;
        }
        res.json({
            status: true, 
            message: 'Retrived successfully',
            result: result
        })
    })
}


exports.create_collection_boost = function(req, res) {
    console.log(getErrLine().str, "apistart");
    var user_id = req.decoded.user_id;
    var collection_id = req.body.collection_id;

    collection_boosts.findOne({ collection_id: collection_id, user_id: user_id }, function(err, result) {
        if(err || result) { res.json({ status: false, message: 'Db error or already done action' }); return; }
        collections.findById(collection_id, function(err, collection) {
            if(err || !collection) {
                res.json({
                    status: false,
                    message: "Db error or collection not found"
                })
                return
            }
            const n_boost = collection.n_boost + 1;
            collection.n_boost = n_boost;
            var newOne = new collection_boosts({
                collection_id: collection_id,
                user_id: user_id
            });
            collection.save(function(err, result) {
                newOne.save(function(err, result) {
                    res.json({
                        status: true,
                        message: 'created successfully',
                    })
                })
            })
        })
    })
}

exports.read_collection_boosts = function(req, res) {
    console.log(getErrLine().str, "apistart");
    var user_id = req.decoded.user_id;
    collection_boosts.find({ user_id: user_id }, function(err, result) {
        if(err) {
            res.json({
                status: false,
                message: 'Db error'
            })
            return;
        }
        res.json({
            status: true, 
            message: 'Retrived successfully',
            result: result
        })
    })
}