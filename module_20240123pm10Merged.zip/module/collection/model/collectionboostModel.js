/*
Project : Cryptotrades
FileName : likeModel.js
Author : Indiefire
File Created : 21/07/2021
CopyRights : Indiefire
Purpose : This is the file which used to define like schema that will store and reterive fanpost like information.
*/

var mongoose = require('mongoose');
var mongoosePaginate = require('mongoose-paginate-v2');
var uniqueValidator = require('mongoose-unique-validator');
var config = require('../../../helper/config')
const Schema = mongoose.Schema;

var collection_boost_schema = mongoose.Schema({
    collection_id: { type: Schema.Types.ObjectId, ref: 'collections' },
    user_id: { type: Schema.Types.ObjectId, ref: 'users' },
    created_date: {
        type: Date,
        default: Date.now
    },
});

collection_boost_schema.plugin(uniqueValidator);
collection_boost_schema.plugin(mongoosePaginate);

module.exports = mongoose.model('collection_boosts', collection_boost_schema,config.db.prefix+'collection_boosts');