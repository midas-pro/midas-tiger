/*
Project : Cryptotrades
FileName : collectionModel.js
Author : Indiefire
File Created : 21/07/2021
CopyRights : Indiefire
Purpose : This is the file which used to define collection schema that will communicate and process collection information with mongodb through mongoose ODM.
*/

var mongoose = require('mongoose');
var mongoosePaginate = require('mongoose-paginate-v2');
var uniqueValidator = require('mongoose-unique-validator');
var config = require('./../../../helper/config');
const { ObjectId } = require('bson');
const Schema = mongoose.Schema;
// Setup schema
var collectionSchema = mongoose.Schema({
    name: {
        type: String,
        minlength: [3, 'Name must be 3 characters or more'],
        maxlength: [255, "Name can't exceed 255 characters"],
        unique: [ true , 'Name already exists. Please try a different name'],
        required: [ true , 'Name is required'], 
    },   
    description: {
        type: String,
        maxlength: [1000, "Description can't exceed 1000 characters"]
    },   
    shortUrl: {
        type: String,
        default: ''
    },   
    blockchain:{
        type: String,
        default: ''
    },

    category_id: { type: Schema.Types.ObjectId, ref: 'category' },
    catlevel2_id: { type: Schema.Types.ObjectId, ref: 'category' },
    catlevel3_id: { type: Schema.Types.ObjectId, ref: 'category' },

    contract_symbol:{
        type:String,
        default: ''
    },
    contract_address: {
        type: String,
        default: ''
    },
    banner: {
        type: String,
        default: ''
    }, 
    image: {
        type: String,
        default: ''
    },
    royalties:{
        type: Number,
        default:0
    },
    volume_traded:{
        type: Number,
        default:0
    },
    item_count:{
        type: Number,
        default:0
    },
    status:{
        type: Number,
        enum : [0,1],
        default: 1
    },
    multiQty:{
        type: Number,
        enum : [0,1],
        default: 0,
    },
    author_id: { type: Schema.Types.ObjectId, ref: 'users' },
    create_date: {
        type: Date,
        default: Date.now
    },
    // added by dreampanda 
    n_reaction: {
        type: Number,
        default: 0
    },
    n_reaction_detail: {
        r_1: { type: Number, default: 0 },
        r_2: { type: Number, default: 0 },
        r_3: { type: Number, default: 0 },
        r_4: { type: Number, default: 0 },
        r_5: { type: Number, default: 0 },
        r_6: { type: Number, default: 0 },
        r_7: { type: Number, default: 0 },
        r_8: { type: Number, default: 0 },
        r_9: { type: Number, default: 0 },
        r_10: { type: Number, default: 0 },
        r_11: { type: Number, default: 0 },
        r_12: { type: Number, default: 0 },
        r_13: { type: Number, default: 0 },
        r_14: { type: Number, default: 0 },
        r_15: { type: Number, default: 0 },
        r_16: { type: Number, default: 0 },
        r_17: { type: Number, default: 0 },
        r_18: { type: Number, default: 0 },
        r_19: { type: Number, default: 0 },
        r_20: { type: Number, default: 0 },
        r_21: { type: Number, default: 0 },
        r_22: { type: Number, default: 0 },
    },

    n_play: {
        type: Number,
        default: 0
    },
    
    n_comment: {
        type: Number,
        default: 0
    },
    
    n_love: {
        type: Number,
        default: 0
    },

    n_like: {
        type: Number,
        default: 0
    },

    n_trending: {
        type: Number,
        default: 0
    },
    
    
    daily_trending: [
        {
            date: {
                type: String,
                default: ""
            },
            count: {
                type: Number,
                default: 0
            }
        }
    ],

    n_boost: {
        type: Number,
        default: 0
    }



});

collectionSchema.plugin(uniqueValidator);
collectionSchema.plugin(mongoosePaginate);

module.exports = mongoose.model('collection', collectionSchema,config.db.prefix+'collection');