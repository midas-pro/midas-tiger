
var livenowModel = require('../model/livenowModel');
var users = require('../../user/model/userModel');
var livenowMessageModel = require('../model/livenowMessageModel');
var livenowBlockModel = require('../model/livenowBlockModel');
var livenowKickModel = require('../model/livenowKickModel');
var livenowMuteModel = require('../model/livenowMuteModel');
var livenowNotificationModel = require('../model/livenowNotificationModel');
var livenowTipModel = require('../model/livenowTipModel');
var tipModel = require('../../user/model/tipModel');
var followerModel = require('../../user/model/followerModel');
var blockModel = require('../../user/model/blockModel');
var muteModel = require('../../user/model/muteModel');
var tiplistModel = require('../model/tiplistModel');
var notificationModel = require('../../notification/model/notificationModel');
var { NOTIFICATION_FILTERS, NOTIFICATION_TYPES } = require('../../helper/notification_config');
const onlineModel = require('../../user/model/onlineModel');

const { getVideoDurationInSeconds } = require('get-video-duration')
const { getErrLine } = require("../../helper/helpers");

exports.update_livenow_automatically = async function() {
    console.log(getErrLine().str, "apistart");
    async function callback() {
        // find active livenow
        // let _livenows = await livenowModel.find({ status: { $in: ['online', 'beback', 'custom'] } });
        // let ONLINE_USERS = await onlineModel.find();
        // await Promise.all(_livenows.map(async d => {
        //     // remove online users
        //     let _online_users = d.onlines.filter(o => ONLINE_USERS.some(u => u.user_id.toString() == o.user_id.toString()));
        //     if(JSON.stringify(_online_users) != JSON.stringify(d.onlines)) {
        //         await livenowModel.findById(d._id, {onlines: _online_users.map(_o => ({ user_id: _o }))});
        //     }
        //     if(!ONLINE_USERS.some(u => u.user_id.toString() == d.user_id.toString())) {
        //         await livenowModel.findByIdAndUpdate(d._id, { status: 'offline', openCount: 2 })
        //     }
        // }));
        

        // find active livenow
        try {
            let _livenows = await livenowModel.find({ status: { $in: ['online', 'beback', 'custom'] } });
            let date = new Date();
            await Promise.all(_livenows.map(async d => {
                console.log(d);
                console.log(d._doc);
                if((d._doc?.stream_link || d.stream_link) == "") {
                    await livenowModel.findByIdAndUpdate(d._id, { status: 'offline', openCount: 2 })
                } else {
                    let duration = await getVideoDurationInSeconds((d._doc?.stream_link || d.stream_link ));
                    let distance = (date.getTime() - new Date(d._doc?.created_date || d.created_date).getTime())/1000;
                    if(duration + 30 < distance) {
                        await livenowModel.findByIdAndUpdate(d._id, { status: 'offline', openCount: 2 })
                    }
                }
            }))
        } catch (error) {
            console.log(error);
        }
    }
    setInterval(() => {
        callback();
    }, 5000);
}

exports.create_live_now = async function(req, res) {
    console.log(getErrLine().str, "apistart");
    var user_id = req.decoded.user_id;

    var newLivenow = new livenowModel(req.body);
    newLivenow.user_id = user_id;
    try {
        await newLivenow.save();

        let notif_users = [];
        // GET FOLLOWERS
        let _followers = (await followerModel.find({ star_id: user_id })).map(d => d.user_id);
        let _users = (await users.find({ _id: { $in: _followers }, "notif_live_now.is_new": true })).map(d => d._id);

        if(_users && _users.length > 0) {
            await Promise.all(_users.map(async d => {
                let new_notification = new notificationModel({
                    type: NOTIFICATION_TYPES.LIVENOW_NEW,
                    filter: NOTIFICATION_FILTERS.NEW_LIVENOW,
                    from_id: user_id,
                    to_id: d,
                    item_id: newLivenow._id,
                    message: "Started streaming"
                });
                await new_notification.save();
            }));
            notif_users = _users;
        }

        res.json({
            status: true,
            message: "Saved successfully",
            result: {
                newLivenow,
                notif_users
            } 
            
        })
    } catch(e) {
        console.log(e);
        res.json({
            status: false,
            message: "Something went wrong"
        });
    }

}

// create tip list for use

exports.create_tiplist = async function(req, res) {
    console.log(getErrLine().str, "apistart");
    var user_id = req.decoded.user_id;
    try {
        var tiplist = new tiplistModel(req.body);
        tiplist.user_id = user_id;
        await tiplist.save();
        res.json({
            status: true,
            message: "Saved successfully",
            result: tiplist
        });
    } catch (error) {
        console.log(error);
        res.json({
            status: false,
            message: "Something went wrong",
        });
    }
}

exports.edit_tiplist = async function(req, res) {
    console.log(getErrLine().str, "apistart");
    var user_id = req.decoded.user_id;
    try {
        let tip = await tipModel.findOne({ tip_id: req.body._id });
        if(tip) {
            res.json({
                status: false,
                message: "You can edit this tip item"
            });
        } else {
            await tiplistModel.findByIdAndUpdate(req.body._id, req.body);
            res.json({
                status: true,
                message: "Updated successfully",
                result: req.body
            });
        }
        // await tiplistModel.findByIdAndUpdate(req.body._id, req.body);
        // res.json({
        //     status: true,
        //     message: "Updated successfully",
        //     result: req.body
        // });
    } catch (error) {
        console.log(error);
        res.json({
            status: false,
            message: "Something went wrong",
        });
    }
}




exports.read_tiplist = async function(req, res) {
    console.log(getErrLine().str, "apistart");
    var user_id = req.decoded.user_id;
    try {
        var tiplists = await tiplistModel.find({user_id});
        res.json({
            status: true,
            message: "Retrived successfully",
            result: tiplists 
        });
    } catch (error) {
        console.log(error);
        res.json({
            status: false,
            message: "Something went wrong"
        });
    }
}

exports.delete_tiplist = async function(req, res) {
    console.log(getErrLine().str, "apistart");
    var user_id = req.decoded.user_id;
    try {
        
        await tiplistModel.findByIdAndRemove(req.body._id);
        res.json({
            status: true,
            message: "Removed successfully"
        });
    } catch (error) {
        console.log(error);
        res.json({
            status: false,
            message: "Something went wrong"
        });
    }
}

exports.delete_tiplists = async function(req, res) {
    console.log(getErrLine().str, "apistart");
    var user_id = req.decoded.user_id;
    console.log(req.body.idArray);
    try {
        let idArray = req.body.idArray.filter(async d => {
            return await tipModel.findOne({ tip_id: d }) ? false : true
        });
        console.log(idArray);
        await tiplistModel.deleteMany({ _id: { $in: req.body.idArray } });
        res.json({
            status: true,
            message: "Removed successfully",
            result: idArray
        });
    } catch (error) {
        console.log(error);
        res.json({
            status: false,
            message: "Something went wrong"
        });
    }
}

exports.set_active_tiplist = async function(req, res) {
    console.log(getErrLine().str, "apistart");
    var user_id = req.decoded.user_id;

    try {
        var livenow_id = req.body.livenow_id;
        var tip_id = req.body.tip_id;
        var active = req.body.active;

        var livenow = await livenowModel.findById(livenow_id);
        if(livenow) {
            if(active) {
                let tips = livenow.tips;
                if(!tips.find(d => d.toString() == tip_id)) {
                    tips.push(tip_id);
                }
                livenow.tips = tips;
                await livenow.save();
                res.json({
                    status: true,
                    message: "Saved sucessfully"
                });
            } else {
                // check this tip is received on this livenow or in others
                let tip = await livenowTipModel.findOne({ livenow_id,  tip_id });
                if(tip) {
                    res.json({
                        status: false,
                        message: "You can't deactive this tip item"
                    });
                } else {
                    let tips = livenow.tips;
                    tips = tips.filter(d => d._id != tip_id);
                    livenow.tips = tips;
                    await livenow.save();
                    res.json({
                        status: true,
                        message: "Saved successfully"
                    });
                }
            }

        } else {
            res.json({
                status: false,
                message: "No in list"
            });
        }
        


    } catch (error) {
        console.log(error);
        res.json({
            status: false,
            message: "Something went wrong"
        });
    }
}



// update tips
exports.update_tips = async function(req, res) {
    console.log(getErrLine().str, "apistart");
    var user_id = req.decoded.user_id;
    try {
        var livenow = await livenowModel.findById(req.body.livenow_id);
        if(livenow) {
            if(livenow.user_id == user_id) {
                livenow.tips = req.body.tips;
                await livenow.save();
                res.json({
                    status: true,
                    message: "Updated successfully"
                });
            } else {
                res.json({
                    status: false,
                    message: "You can't update"
                });
            }
        } else {
            res.json({
                status: false,
                message: "Something went wrong"
            });
        }
    } catch (error) {
        console.log(error);
        res.json({
            status: false,
            message: "Error was occured"
        });
    }
}


exports.set_me_as_active = async function(req, res) {
    console.log(getErrLine().str, "apistart");
    var user_id = req.decoded.user_id;
    var livenow_id = req.body.livenow_id;
    var type = req.body.type;
    console.log('This is called');
    console.log(type);
    if(livenow_id) {
        try {
            var livenow = await livenowModel.findById(livenow_id);
            if(livenow.user_id == user_id) {
                switch(type) {
                    case 'join':
                        livenow.status = 'online';
                        if(!livenow.onlines.find(d => d.user_id == user_id)) {
                            livenow.onlines.push({
                                user_id: user_id,
                            });
                        }
                        livenow.start_date = new Date();
                        break;
                    case 'leave':
                        livenow.status = 'offline';
                        livenow.openCount = 2;
                        livenow.onlines = livenow.onlines.filter(d => d.user_id != user_id)
                        break;
                    case 'beback':
                        livenow.status = 'beback';
                        livenow.statusMin = req.body.statusMin
                        livenow.statusImage = req.body.statusImage
                        break;
                    case 'custom':
                        livenow.status = 'custom'
                        livenow.statusText = req.body.statusText;
                        livenow.statusImage = req.body.statusImage
                    default:
                        break;
                } 
                
            } else {
                if(type == 'join') {
                    if(!livenow.onlines.find(d => d.user_id == user_id)) {
                        livenow.onlines.push({
                            user_id: user_id,
                        });
                    }
                } else {
                    livenow.onlines = livenow.onlines.filter(d => d.user_id != user_id)
                }
            }
            console.log('status', livenow.status);
            await livenow.save();
            res.json({
                status: true,
                message: "Saved successfully",
                result: livenow
            })
        } catch (error) {
            console.log(error);
            res.json({
                status: false,
                message: "Something went wrong",
                errors: error
            })
        }
    } else {
        res.json({
            status: false,
            message: "Something went wrong"
        });
    } 
}

exports.get_live_now = async function(req, res) {
    console.log(getErrLine().str, "apistart");
    var user_id = req.decoded.user_id;
    var id = req.query.id;
    if(id) {
        livenowModel
        .findById(id)
        .populate({
            path: 'user_id',
            model: 'users',
            select: '_id first_name last_name username profile_image is_idverified'
        })
        .populate({
            path: 'co_hosts',
            model: 'users',
            select: '_id first_name last_name username profile_image is_idverified'
        })
        .populate({
            path: 'guests',
            model: 'users',
            select: '_id first_name last_name username profile_image is_idverified'
        })
        .populate({
            path: 'tips',
            model: 'tiplists'
        })
        .exec(async function(err, result) {
            if(err) {
                res.json({
                    status: false,
                    message: 'error was occured'
                })
            } else {
                // handle tip manager
                if (result?.tips) {
                  for (let i = 0; i < result.tips.length; i++) {
                    let sum = 0;
                    const d = result.tips[i];
                    
                    if (d.f_set_goal) {
                      let _tips = await livenowTipModel.find({
                        livenow_id: id,
                        receiver: result.user_id,
                        tip_id: d._id
                      });
                      _tips.forEach(t => {
                        sum += t.coin;
                      });
                    }

                    console.log(d);
                    console.log(d.doc);
                    console.log(sum);
                    var newObj = {
                        ...d.toObject(), ...{ sum }
                    }
                    console.log(newObj);
                    result.tips[i] = newObj
                  }
                }
                
                res.json({
                  status: true,
                  message: 'get data successfully',
                  result: result
                });
                
            }
        })
        
    } else {    
        res.json({
            status: false,
            message: "Something went wrong"
        });
    }

}
exports.get_status = function(req, res) {
    console.log(getErrLine().str, "apistart");
    var livenow_id = req.query.livenow_id;
    if(livenow_id) {
        livenowModel.findById(livenow_id, function(err, result) {
            if(err) {
                res.json({
                    status: false,
                    message: "Error was occured",
                    errors: err
                });
            } else {
                if(result) {
                    var resData = {
                        status: result.status,
                        statusText: result.statusText,
                        statusMin: result.statusMin,
                        statusImage: result.statusImage
                    }
                    res.json({
                        status: true,
                        message: "Retrived successfully",
                        result: resData
                    })
                } else {
                    res.json({
                        status: false,
                        message: "No list",
                        result: null
                    })
                }
            }
        })
    } else {
        res.json({
            status: false,
            message: "Something went wrong"
        })
    }
}

exports.get_my_status = async function(req, res) {
    console.log(getErrLine().str, "apistart");
    var livenow_id = req.query.livenow_id;
    var user_id = req.query.user_id;
    
    try {
        var kicked = await livenowKickModel.findOne({
            livenow_id,
            kick_user_id: user_id
        });
        var resD = {
            isKicked: kicked ? true: false
        }
        res.json({
            status: true,
            message: "Data retrived successfully",
            result: resD
        });
    } catch (error) {
        console.log(error);
        res.json({
            status: false,
            message: "Something went wrong"
        });
    }

    
}

exports.get_online = function(req, res) {
    console.log(getErrLine().str, "apistart");
    var livenow_id = req.query.livenow_id;
    if(livenow_id) {
        livenowModel.findById(livenow_id).populate({
            path: 'onlines.user_id',
            model: 'users',
            select: '_id first_name last_name username profile_image is_idverified bio'
        }).exec(function(err, result) {
            if(err) {
                res.json({
                    status:  false,
                    message: "Error was occured",
                    errors: err
                })
            } else {
                res.json({
                    status: true,
                    message: "Data retrived successfully",
                    result: result?.onlines || []
                })
            }
        });
    } else {
        res.json({
            status: false,
            message: "Something went wrong"
        })
    }
}

exports.get_muted_users = async function(req, res) {
    console.log(getErrLine().str, "apistart");
    var user_id = req.decoded.user_id || req.query.user_id;
    var livenow_id = req.query.livenow_id;
    try {
        var muted_users = await livenowMuteModel.find({
            livenow_id, user_id
        }).populate({
            path: 'mute_user_id',
            model: 'users',
            select: '_id first_name last_name username profile_image is_idverified bio'
        });
        res.json({
            status: true,
            message: "Data retrived successfully",
            result: muted_users
        });
    } catch (error) {
        console.log(error);
        res.json({
            status: false,
            message: "Error was occured",
            errors: error
        });
    }

}


exports.get_kicked_users = async function(req, res) {
    console.log(getErrLine().str, "apistart");
    var livenow_id = req.query.livenow_id;
    try {
        var kicked_users = await livenowKickModel.find({
            livenow_id
        }).populate({
            path: 'kick_user_id',
            model: 'users',
            select: '_id first_name last_name username profile_image is_idverified bio'
        });
        res.json({
            status: true,
            message: "Data retrived successfully",
            result: kicked_users
        });
    } catch (error) {
        console.log(error);
        res.json({
            status: false,
            message: "Error was occured",
            errors: error
        });
    }
}


exports.read_live_now = async function(req, res) {
    console.log(getErrLine().str, "apistart");
    var user_id = req.decoded.user_id;
    var keyword = req.query.keyword || ''; // added dreampanda 20230523 pm 9
    var page = req.query.page ? req.query.page : '1';  
    var limit = req.query.limit ? req.query.limit : '15';  
    
    var query = livenowModel.find();
    query = query.sort({ created_date: -1 });
    query = query.find({ status: { $in: ['online', 'away', 'beback'] } })
    if(keyword != '') {
        query = query.find({
            description:  { $regex: new RegExp(keyword, "ig") }
        })
    }

    var offset = ( page == '1' ) ? 0 : ((parseInt(page-1))*10);
    var options = {
        page:page,
        offset:offset,
        limit:limit,    
    };
    query = query.populate({
        path: 'user_id',
        model: 'users',
        select: '_id first_name last_name username profile_image is_idverified'
    });
    query = query.populate({
        path: 'co_hosts',
        model: 'users',
        select: '_id first_name last_name username profile_image is_idverified'
    });
    query = query.populate({
        path: 'guests',
        model: 'users',
        select: '_id first_name last_name username profile_image is_idverified'
    });
    query = query.populate({
        path: 'onlines.user_id',
        model: 'users',
        select: '_id first_name last_name username profile_image is_idverified'
    });
    
    livenowModel.paginate(query, options).then(async function (result) {

        const updatedDocs = await Promise.all(
            result.docs.map(async (d) => {
                // check is follower, mute, block
                var _db_follower = await followerModel.findOne({
                    star_id: d._doc?.author_id?._id,
                    user_id: user_id,
                });
                var _db_block = await blockModel.findOne({
                    block_user_id: d._doc?.author_id?._id,
                    user_id: user_id,
                });
                var _db_mute = await muteModel.findOne({
                    mute_user_id: d._doc?.author_id?._id,
                    user_id: user_id,
                });
                return {
                    ...d._doc,
                    isFollow: _db_follower ? true : false,
                    isBlock: _db_block ? true : false,
                    isMute: _db_mute ? true : false,
                }        
            })
        )

        const updatedResult = { ...result, docs: updatedDocs };

        res.json({
            status: true,
            message: "retrived successfully",
            data: updatedResult
        });
    });
}

exports.update_stream = async function(req, res) {
    console.log(getErrLine().str, "apistart");
    var id = req.body._id;
    if(id) {
        try {
            var livenow = await livenowModel.findById(id);
            livenow.stream_link = req.body.stream_link;
            livenow.img_link = req.body.img_link;
            livenow.save();
            res.json({
                status: true,
                message: "Saved successfully"
            })
        } catch(e) {
            console.log(e);
            res.json({
                status: false,
                message: "Something went wrong"
            })
        }
    } else {
        res.json({
            status: false,
            message: "Something went wrong"
        })
    }
}


exports.add_message = function(req, res) {
    console.log(getErrLine().str, "apistart");
    var user_id = req.decoded.user_id;
    if(!req.body.livenow_id) {
        res.json({
            status: false,
            message: "Something went wrong"
        })
    } else {
        var livenowMessage = new livenowMessageModel(req.body);
        livenowMessage.user_id = user_id;
        livenowMessage.save(function(err, result) {
            if(err) {
                res.json({
                    status: false,
                    message: "Error was occured"
                })
            } else {
                res.json({
                    status: true,
                    message: "Saved successfully",
                    result: livenowMessage
                })
            }
        });
    }
}

exports.read_messages = function(req, res) {
    console.log(getErrLine().str, "apistart");
    var keyword = req.query.keyword; 
    var page = req.query.page || 1;
    var limit = req.query.limit || 15;
    var livenow_id = req.query.livenow_id;
    if(livenow_id) {
        var query = livenowMessageModel.find({ livenow_id, receiver: null });
        if(keyword && keyword.trim() != '') {
            query = query.find(
                { description:  { $regex: new RegExp(keyword, "ig") } }
            )
        } 
        var offset = page == "1" ? 0 : parseInt(page - 1) * limit;
        var options = {
            page: page,
            offset: offset,
            limit: limit,
        };

        query = query.populate({
            path: 'user_id',
            model: 'users',
            select: '_id first_name last_name username profile_image is_idverified'
        });
        query = query.sort({ created_date: -1 })

        livenowMessageModel.paginate(query, options).then(result => {
            res.json({
                status: true,
                message: "Data retrived successfully",
                data: result
            })
        })
    } else {
        res.json({
            status: false,
            message: "Something went wrong"
        })
    }
}

// send tip
exports.send_tip = async function(req, res) {
    console.log(getErrLine().str, "apistart");
    var user_id = req.decoded.user_id;
    var livenow_id = req.body.livenow_id;
    var receiver = req.body.receiver;
    var tip_id = req.body.tip_id;
    var coin = req.body.coin;
    try {
        var user = await users.findById(user_id);
        var livenow = await livenowModel.findById(livenow_id).populate({ 
            path: "tips",
            model: "tiplists"
        });
        if(livenow) {
            var tips = livenow.tips;
            var tip = tips.find(d => d._id == tip_id); 
            if(tip) {
                try {
                    var newlivenowTip = new livenowTipModel({
                        livenow_id,
                        sender: user_id,
                        receiver,
                        tip_id,
                        coin
                    });
                    
                    var newTip = new tipModel({
                        sender: user_id,
                        receiver,
                        coin
                    });

                    let description;
                    if(tip.f_set_goal) {
                        description = `Sent ${Math.floor(tip.price)} ${ tip.price > 1 ? 'coins' : 'coin' } for unlocking ${tip.title}`
                    } else {
                        description = `Sent ${Math.floor(tip.price)} ${ tip.price > 1 ? 'coins' : 'coin' } for ${tip.title}`
                    }

                    // make notification
                    var newNotification = new livenowNotificationModel({
                        livenow_id,
                        user_id,
                        receiver,
                        description
                    });

                    await newlivenowTip.save();
                    await newTip.save();
                    await newNotification.save();
    
                    if(tip.f_set_goal) {
                        let _tip_histories = await livenowTipModel.find({ livenow_id, tip_id });
                        let sum = _tip_histories.reduce((total, obj) => total + obj.coin, 0);
                        if(sum >= tip.price) {
                            let new_notification = {
                                livenow_id,
                                user_id,
                                receiver,
                                description: `${tip.title} unlocked ● Goal reached of ${sum} coins`
                            }
                            await new_notification.save()
                        }
                    }

                    res.json({
                        status: true,
                        message: "Sent tip successfully",
                    });
                } catch(e) {
                    console.log(e);
                    res.json({
                        status: false,
                        message: "Error was occured",
                        errors: e
                    })
                }
            } else {
                res.json({
                    status: false,
                    message: "No tip or deactivated"
                });
            }
        } else {
            res.json({
                status: false,
                message: "Can't find livenow"
            });
        }      
    } catch (error) {
        console.log(error);
        res.json({
            status: false,
            message: "Something went wrong"
        });
    }
}


// add and remove block

exports.manageBlock = async function(req, res) {
    console.log(getErrLine().str, "apistart");
    var user_id = req.decoded.user_id;
    var livenow_id = req.body.livenow_id;
    var block_user_id = req.body.block_user_id;
    var type = req.body.type;

    try {
        var user = await users.findById(user_id);
        if(type == 'block') {
            var newBlock = new livenowBlockModel({
                livenow_id,
                user_id,
                block_user_id
            });
            var newNotification = new livenowNotificationModel({
                livenow_id,
                user_id,
                receiver: block_user_id,
                description: `You are blocked by ${user.username}`
            });
            await newBlock.save();
            await newNotification.save();
            res.json({
                status: true,
                message: "Blocked successfully",
            });
        } else {
            await livenowBlockModel.findOneAndDelete({
                livenow_id,
                user_id,
                block_user_id
            });
            var newNotification = new livenowNotificationModel({
                livenow_id,
                user_id,
                receiver: block_user_id,
                description: `You are unblocked by ${user.username}`
            });
            await newNotification.save();
            res.json({
                status: true,
                message: "UnBlocked successfully",
            });
        }
    } catch (error) {
        console.log(error);
        res.json({
            status: false,
            message: "Someting went wrong"
        })
    }
}


// manage mute
exports.manageMute = async function(req, res) {
    console.log(getErrLine().str, "apistart");
    var user_id = req.decoded.user_id;
    var livenow_id = req.body.livenow_id;
    var mute_user_id = req.body.mute_user_id;
    var type = req.body.type;

    try {
        var user = await users.findById(user_id);
        if(type == 'mute') {
            var newMute = new livenowMuteModel({
                livenow_id,
                user_id,
                mute_user_id
            });
            var newNotification = new livenowNotificationModel({
                livenow_id,
                user_id,
                receiver: mute_user_id,
                description: `You are muted by ${user.username}`
            });
            await newMute.save();
            await newNotification.save();
            res.json({
                status: true,
                message: "Muted successfully",
            });
        } else {
            await livenowMuteModel.findOneAndDelete({
                livenow_id,
                user_id,
                mute_user_id
            });
            var newNotification = new livenowNotificationModel({
                livenow_id,
                user_id,
                receiver: mute_user_id,
                description: `You are unmuted by ${user.username}`
            });
            await newNotification.save();
            res.json({
                status: true,
                message: "Unmuted successfully",
            });
        }
    } catch (error) {
        console.log(error);
        res.json({
            status: false,
            message: "Someting went wrong"
        })
    }
}

// manage kick account


exports.manageKick = async function(req, res) {
    console.log(getErrLine().str, "apistart");
    var user_id = req.decoded.user_id;
    var livenow_id = req.body.livenow_id;
    var kick_user_id = req.body.kick_user_id;
    var type = req.body.type;

    try {
        var user = await users.findById(user_id);
        if(type == 'kick') {
            var newKick = new livenowKickModel({
                livenow_id,
                user_id,
                kick_user_id
            });
            var newNotification = new livenowNotificationModel({
                livenow_id,
                user_id,
                receiver: kick_user_id,
                description: `You are kicked by ${user.username}`
            });
            await newKick.save();
            await newNotification.save();
            res.json({
                status: true,
                message: "Kicked successfully",
            });
        } else {
            await livenowKickModel.findOneAndDelete({
                livenow_id,
                kick_user_id
            });
            var newNotification = new livenowNotificationModel({
                livenow_id,
                user_id,
                receiver: kick_user_id,
                description: `You are unkicked by ${user.username}`
            });
            await newNotification.save();
            res.json({
                status: true,
                message: "UnKicked successfully",
            });
        }
    } catch (error) {
        console.log(error);
        res.json({
            status: false,
            message: "Someting went wrong"
        })
    }
}

// check if user is blocked, muted, kicked

exports.get_userinfo_for_livenow = async function(req, res) {
    console.log(getErrLine().str, "apistart");
    var user_id = req.decoded?.user_id || req.query.user_id;
    var livenow_id = req.query.livenow_id;
    var other_id = req.query.other_id;


    try {
        var blocked = await livenowBlockModel.findOne({
            livenow_id, user_id, block_user_id: other_id
        });
        var muted = await livenowMuteModel.findOne({
            livenow_id, user_id, mute_user_id: other_id
        });

        var kicked = await livenowKickModel.findOne({
            livenow_id, kick_user_id: other_id
        });

        var resData = {
            isBlocked: blocked ? true: false,
            isMuted: muted ? true: false,
            isKicked: kicked ? true: false
        }
        res.json({
            status: true,
            message: "Retrived successfully",
            result: resData
        });
    } catch (error) {
        console.log(error);
        res.json({
            status: false,
            message: "Something went wrong."
        });
    }
}

// get notifications
exports.get_livenow_notifications = async function(req, res) {
    console.log(getErrLine().str, "apistart");
    var user_id = req.decoded.user_id;
    var livenow_id = req.query.livenow_id;
    var is_new = req.query.is_new
    try {
        let notifications;
        if(is_new) {
            notifications = await livenowNotificationModel.find({ livenow_id, receiver: user_id }).populate({
                path: "user_id",
                model: "users",
                select: '_id first_name last_name username profile_image is_idverified'
            }).sort({ created_date: -1 }).limit(10);
        } else {
            notifications = await livenowNotificationModel.find({ livenow_id, receiver: user_id }).populate({
                path: "user_id",
                model: "users",
                select: '_id first_name last_name username profile_image is_idverified'
            }).sort({ created_date: -1 });
        }
        res.json({
            status: true,
            message: "retrived successfully",
            result: notifications
        });
    } catch (error) {
        console.log(error);
        res.json({
            status: false,
            message: "Something went wrong"
        })
    }
}