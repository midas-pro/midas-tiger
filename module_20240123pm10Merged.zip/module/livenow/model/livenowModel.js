/*
Project : Cryptotrades
FileName :  priceModel.js
Author : Indiefire
File Created : 21/07/2021
CopyRights : Indiefire
Purpose : This is the file which used to define view schema that will store and reterive item price information.
*/

var mongoose = require('mongoose');
var mongoosePaginate = require('mongoose-paginate-v2');
var uniqueValidator = require('mongoose-unique-validator');
var config = require('./../../../helper/config')
const Schema = mongoose.Schema;


const onlineSchema = new Schema({
    user_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'users'
    },
    last_date: {
        type: Date,
        default: Date.now
    }
})

var livenow = mongoose.Schema({
    description: {
        type: String,
        default: ""
    },
    stream_link: {
        type: String, 
        default: ''
    },
    img_link: {
        type: String,
        default: ''
    },
    onlines: {
        type: [onlineSchema],
        default: []
    }, 
    status: {
        type: String,
        default: 'offline'
    },
    statusMin: {
        type: Number,
        default: 1
    },
    statusText: {
        type: String,
    },
    statusImage: {
        type: String,
        default: ''
    },
    openCount: {
        type: Number,
        default: 1,
    },
    f_allow_talk: {
        type: Boolean,
        default: false
    },
    f_join_muted: {
        type: Boolean,
        default: false
    },
    co_hosts: [
        {
            type: mongoose.Schema.Types.ObjectId,
            ref: 'users'
        }
    ],
    guests: [
        {
            type: mongoose.Schema.Types.ObjectId,
            ref: 'users'
        }
    ],
    f_allow_chat: {
        type: Boolean,
        default: false
    },
    tips: [
        {
            type: Schema.Types.ObjectId, ref: 'tiplists'
        }
    ],
    user_id: {
        type: Schema.Types.ObjectId, ref: 'users'
    },
    start_date: {
        type: Date,
        default: Date.now
    },
    created_date: {
        type: Date,
        default: Date.now
    },
});

livenow.plugin(uniqueValidator);
livenow.plugin(mongoosePaginate);

module.exports = mongoose.model('livenows', livenow,config.db.prefix+'livenows');