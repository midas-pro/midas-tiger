var express = require('express')
var router = express.Router();
var auth = require("./../../../middleware/auth");
var adminauth = require("./../../../middleware/adminauth");
var optionalauth = require("./../../../middleware/optionalauth");
var livenowController = require('../controller/livenowController');
const { check } = require('express-validator');

router.post('/create_live_now', auth ,livenowController.create_live_now);

// manage tip list for user
router.post('/create_tiplist', auth, livenowController.create_tiplist);
router.get('/read_tiplist', auth, livenowController.read_tiplist);
router.put('/edit_tiplist', auth, livenowController.edit_tiplist);
router.delete('/delete_tiplist', auth, livenowController.delete_tiplist);
router.post('/delete_tiplists', auth, livenowController.delete_tiplists);
router.post('/set_active_tiplist', auth, livenowController.set_active_tiplist);
// manage tip list for user


router.post('/update_tips', auth, livenowController.update_tips);
router.get('/get_live_now', auth ,livenowController.get_live_now);
router.get('/read_live_now', optionalauth, livenowController.read_live_now);
router.post('/update_stream', auth ,livenowController.update_stream);
router.post('/add_message', auth ,livenowController.add_message);
router.get('/read_messages', livenowController.read_messages);
router.post('/set_me_as_active', auth, livenowController.set_me_as_active);
router.get('/get_status', livenowController.get_status);
router.get('/get_my_status', livenowController.get_my_status);
router.get('/get_online', livenowController.get_online);
router.get('/get_muted_users', optionalauth, livenowController.get_muted_users);
router.get('/get_kicked_users', optionalauth, livenowController.get_kicked_users);
router.post('/send_tip', auth, livenowController.send_tip);
router.post('/manage_block', auth, livenowController.manageBlock);
router.post('/manage_mute', auth, livenowController.manageMute);
router.post('/manage_kick', auth, livenowController.manageKick);
router.get('/get_userinfo_for_livenow', optionalauth, livenowController.get_userinfo_for_livenow);
router.get('/get_livenow_notifications', auth, livenowController.get_livenow_notifications)

module.exports = router
