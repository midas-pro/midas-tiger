/*
Project : Cryptotrades
FileName : categoryController.js
Author : Indiefire
File Created : 21/07/2021
CopyRights : Indiefire
Purpose : This is the file which used to define all category related api function.
*/

var categories = require('./../model/categoryModel');
var validator = require('validator');
const { validationResult } = require('express-validator');
const { getErrLine } = require("../../helper/helpers");
const itemModel = require('../../item/model/itemModel');
const playlistModel = require('../../playlist/model/playlistModel');

/*
*  This is the function which used to retreive active category list
*/
exports.getList = async function (req, res) {
    /* !!20210107am1 corderd {(New) hide categories in discover that have no items.} */
    
    let used_category = [
        ...(await itemModel.find({}, { category_id: 1 }).distinct("category_id")),
        ...(await itemModel.find({}, { catlevel2_id: 1 }).distinct("catlevel2_id")),
        ...(await itemModel.find({}, { catlevel3_id: 1 }).distinct("catlevel3_id"))
    ];

    console.log(getErrLine().str, "apistart");
    var page = req.query.page ? req.query.page : '1';
    /* !!20210107am1 corderd {(New) hide categories in discover that have no items.} */
    var query = categories.find({ _id: { $in: used_category }});
    // !!20240121pm5 coderd commented below code {(B)(New) hide categories in discover that have no items.}
    // var query = categories.find();
    var offset = (page == '1') ? 0 : ((parseInt(page - 1)) * 10);
  
  
    query = query.where('status', 'active')
    query = query.sort('-create_date')
    
    query.exec(function (err, result) {
        if(err){
            throw err;
        } else {
            res.json({
                status: true,
                message: "Category retrieved successfully",
                data: result
            });
        }
    })
}


/*
*  This is the function which used to retreive category detail by category id
*/
exports.details = function (req, res) {
    console.log(getErrLine().str, "apistart");
    console.log("received params are ", req.params)
    categories.findOne({ _id: req.query.category_id }).exec(function (err, category) {
        if (err) {
            res.json({
                status: false,
                message: "Request failed",
                errors: "Category not found"
            });
            return;
        }
        if (!category) {
            res.json({
                status: false,
                message: "Request failed",
                errors: "Category not found"
            });
            return;
        }
        res.json({
            status: true,
            message: "Category info retrieved successfully",
            result: category
        });
    })
}

/**
 * This is the function which used to list all categories
 */
exports.getAdminList = function (req, res) {
    console.log(getErrLine().str, "apistart");
    var page = req.query.page ? req.query.page : '1';
    var limit = req.query.limit ? req.query.limit : '1300';
    var query = categories.find();
    var offset = (page == '1') ? 0 : ((parseInt(page - 1)) * 10);
    query = query.sort('-create_date')
    var options = {
        select: 'title category_image status create_date subCategories level',
        page: page,
        offset: offset,
        limit: limit,
    };
    categories.paginate(query, options).then(function (result) {
        res.json({
            status: true,
            message: "Category retrieved successfully",
            data: result
        });
    });
}

/**
 * This is the function which used to add category from admin
 */
// 20240111am1 CoderB added
exports.deleteQuery = function (req,res){
    categories.deleteMany({create_date:{$gte:Number(new Date("2024-01-09"))}}).exec((err,data)=>{
        res.json({
            status:true,data:data.length
        })
    })
}
exports.getItem = function (req,res){
    categories.findOne({_id:req.body.id},(err,data)=>{
        if(err)console.log(err)
        else{
    res.json({
        status:true,
        data:data
    })}
    })
}
exports.bulk_add = async function (req, res){
    console.log(getErrLine().str, "apistart");
    console.log('params',req.body);
    var childlevel;
    if(req.body.level ==1){
        childlevel = 2;
    }else if(req.body.level ==2){
        childlevel = 3;
    }
    var titles = req.body.titles;
    var subCategories = [];

    for(let i = 0; i < titles.length;i++){
        if(titles[i]){
            
        try{     
                        console.log("new category");
                        const category = new categories();
                        category.title = titles[i];
                        category.category_image = "PsfYcRZxTP_1704831362572.png";
                        category.status = "active";
                        category.level = childlevel;
                        category.subCategories = [];
                        category.type = req.body.type;
                        await category.save();
                        
                        console.log("save ok");
                        console.log(category);
                        // const newCategory = await categories.findOne({ title: titles[i] }).exec();
                        // console.log("push new item");
                        subCategories.push(category._id);
                            
        } catch(err){
                    console.log("error:",err)
                }
            
            
        }else{
            console.log('null value')
        }
    }
    console.log("subCategories",subCategories);
   await categories.findOne({title:req.body.category,_id:req.body.id},(err,data)=>{
        if(!err){
            if(data){
               var newSubCategories = data.subCategories.concat(subCategories);
               categories.update({title:req.body.category,_id:req.body.id},{subCategories:newSubCategories}).exec(err=>{
                if(!err){
                    console.log('updated subcategory successfully!!!');
                    res.json({
                        status:true,
                        message:"updated successfully!"
                    })
                }
               })
            }else{
                var parentCategory = new categories();
                parentCategory.title = req.body.category;
                parentCategory.category_image = "PsfYcRZxTP_1704831362572.png";
                parentCategory.status = "active";
                parentCategory.level = req.body.level;
                parentCategory.subCategories = subCategories;
                parentCategory.type = req.body.type;
                parentCategory.save();
                res.json({
                    status: true,
                    message: "Category created successfully",
                });
            }
        }else{
            console.log(err)
        }
    })
}

exports.add = function (req, res) {
    console.log(getErrLine().str, "apistart");
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        res.json({
            status: false,
            message: "Request failed",
            errors: errors.array()
        });
        return;
    }
    var category = new categories();
    category.title = req.body.title;
    category.category_image = req.body.category_image;
    category.status = req.body.status;
    category.level = req.body.level;
    category.subCategories = [];
    category.save(function (err, categoryObj) {
        if (err) {
            res.json({
                status: false,
                message: "Request failed",
                errors: err
            });
            return;
        }
        res.json({
            status: true,
            message: "Category created successfully",
            result: categoryObj
        });
    });
}



/**
 *  This is the function which used to update category 
 */
exports.edit = function (req, res) {
    console.log(getErrLine().str, "apistart");
    categories.findOne({ _id: req.body.category_id }, function (err, category) {
        if (err || !category) {
            res.json({
                status: false,
                message: "Category not found",
                errors: err
            });
            return;
        } else {
            category.title = req.body.title ? req.body.title : category.title;
            category.category_image = req.body.category_image ? req.body.category_image : category.category_image;
            category.status = req.body.status;
            category.subCategories = req.body.subCategory;
            category.save(function (err, category) {
                if (err) {
                    res.json({
                        status: false,
                        message: "Request failed",
                        errors: err
                    });
                    return;
                } else {
                    res.json({
                        status: true,
                        message: "Category updated successfully",
                        result: category
                    });
                }
            });
        }
    });
}

/**
 *  This is the function which used to delete category 
 */
//20240111 am 1 coderB changed
exports.delete =async function (req, res) {
    console.log("DELETE",req.body);
    console.log(getErrLine().str, "apistart");
    categories.findOne({ _id: req.body.category_id }, function (err, category) {
        if (err || !category) {
            res.json({
                status: false,
                message: "Category not found",
                errors: err
            });
            return;
        } 
        else {
            if(category.subCategories.length){
                category.subCategories.map(element => {
                    console.log("1---",category.subCategories);
                    categories.findOne({_id:element},function(err,category1){
                        if (err ||!category1) {
                            res.json({
                                status: false,
                                message: "childCategory not found",
                                errors: err
                            });
                            return;
                        } else{
                            if(category1.subCategories.length){
                                console.log("2----",category1.subCategories);
                                 category1.subCategories.map((item)=>{
                                    categories.deleteOne({_id:item},(err)=>{
                                        if(!err)console.log("deleted!!!");
                                    });
                                })
                                categories.deleteOne({_id:category1._id},(err)=>{
                                   if(!err)console.log("category.subCategories deleted316!!!");
                                });
                            }else{
                                categories.deleteOne({_id:category1._id},(err)=>{
                                    if(!err)console.log("category.subCategories deleted320!!!");
                                 })
                            }
                        }
                    })
                });
                categories.deleteOne({_id:category._id}).exec((err)=>{
                    if(!err){
                        res.json({
                            status:true,
                            message:"deleted successfully"
                        })
                    }
                })
            }else{
                categories.deleteOne({ _id: req.body.category_id }, function (err) {
                    res.json({
                        status: true,
                        message: "Category deleted successfully"
                    });
                })
            }
               
            
            
        }
    });
}
// 20240113pm4 CoderB get all categories.
exports.getAll =async function(req,res){
    var Digital = [];
    var Merchandise = [];
    await categories.find({type:"Digital",level:1},(err,data)=>{
        if(err)console.log(err)
        else{
            if(data.length){
                Digital = data;
            }
        }
    })
    await categories.find({type:"Merchandise",level:1},(err,data)=>{
        if(err)console.log(err)
        else{
            if(data.length){
                Merchandise = data;
            }
        }
    })
    await categories.find({status:'active'}).sort({create_date:-1}).exec((err,data)=>{
        if(err)console.log(err)
        else{
    if(data.length){
        res.json({
            status:true,
            message:"Get all Categories successfully",
            Digital:Digital,
            Merchandise:Merchandise,
            data:data
        })
    }}
    })
    
}
exports.updateType = function(req,res){
    categories.update({create_date:{$gte:Number(new Date("2024-01-09"))}},{type:"Merchandise"}).exec((err,data)=>{
        res.json({
            status:true,message:"updated  successfully!!"
        })
    })
}







