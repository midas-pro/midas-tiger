/*
Project : Cryptotrades
FileName : route.js
Author : Indiefire
File Created : 21/07/2021
CopyRights : Indiefire
Purpose : This is the file which used to define all route releated to party api request.
*/

var express = require('express')
var router = express.Router();
var partyController = require("../controller/partyController")
var adminauth = require("../../../middleware/adminauth");
var auth = require("../../../middleware/auth");
const { check } = require('express-validator');

router.get('/list',partyController.getList)
router.get('/detail',partyController.details);
router.get('/fulllist',auth,partyController.getAdminList)
router.post('/add',auth,partyController.add)
router.post('/addlove',auth,partyController.actionLove)
router.post('/addcomment',auth,partyController.actionComment)
router.get('/listcomment',partyController.listComment)
router.put('/edit',[check('party_id').not().isEmpty(),auth],partyController.edit)
router.delete('/delete',[check('party_id').not().isEmpty(),auth],partyController.delete)

router.get('/partys',auth,partyController.partys) // added by dreampanda 20230521 am 10

router.post('/create_party_comment_reaction', auth, partyController.create_party_comment_reaction);
router.get('/read_party_comment_reaction', auth, partyController.read_party_comment_reaction);

router.post('/create_party_comment_love', auth, partyController.create_party_comment_love);

router.post('/create_party_reaction', auth, partyController.create_party_reaction);
router.get('/read_party_reaction', auth, partyController.read_party_reactions);

router.post('/create_party_play', auth, partyController.create_party_play);
router.get('/read_party_play', auth, partyController.read_party_plays);

router.post('/create_party_comment', auth, partyController.create_party_comment);
router.get('/read_party_comment', auth, partyController.read_party_comments);

router.post('/create_party_love', auth, partyController.create_party_love);
router.get('/read_party_love', auth, partyController.read_party_loves);

router.post('/create_party_like', auth, partyController.create_party_like);
router.get('/read_party_like', auth, partyController.read_party_likes);

router.post('/create_party_boost', auth, partyController.create_party_boost);
// router.get('/read_party_boost', auth, partyController.read_party_boosts);

module.exports = router