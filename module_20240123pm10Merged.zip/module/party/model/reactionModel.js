/*
Project : Cryptotrades
FileName : likeModel.js
Author : Indiefire
File Created : 21/07/2021
CopyRights : Indiefire
Purpose : This is the file which used to define like schema that will store and reterive fanpost like information.
*/

var mongoose = require('mongoose');
var mongoosePaginate = require('mongoose-paginate-v2');
var uniqueValidator = require('mongoose-unique-validator');
var config = require('../../../helper/config')
const Schema = mongoose.Schema;

var party_reaction_schema = mongoose.Schema({
    party_id: { type: Schema.Types.ObjectId, ref: 'party' },
    user_id: { type: Schema.Types.ObjectId, ref: 'users' },
    reaction_number: { type: Number, default: -1 },
    created_date: {
        type: Date,
        default: Date.now
    },
});

party_reaction_schema.plugin(uniqueValidator);
party_reaction_schema.plugin(mongoosePaginate);

module.exports = mongoose.model('reactions4party', party_reaction_schema,config.db.prefix+'reactions4party');