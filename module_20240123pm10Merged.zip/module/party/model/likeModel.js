/*
Project : Cryptotrades
FileName : loveModel.js
Author : Indiefire
File Created : 21/07/2021
CopyRights : Indiefire
Purpose : This is the file which used to define love schema that will store and reterive party love information.
*/

var mongoose = require('mongoose');
var mongoosePaginate = require('mongoose-paginate-v2');
var uniqueValidator = require('mongoose-unique-validator');
var config = require('../../../helper/config')
const Schema = mongoose.Schema;

var likeSchema = mongoose.Schema({
    party_id: { type: Schema.Types.ObjectId, ref: 'party' },
    user_id: { type: Schema.Types.ObjectId, ref: 'users' },
    created_date: {
        type: Date,
        default: Date.now
    },
});

likeSchema.plugin(uniqueValidator);
likeSchema.plugin(mongoosePaginate);

module.exports = mongoose.model('likes4party', likeSchema,config.db.prefix+'likes4party');