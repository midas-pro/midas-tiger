/*
Project : Cryptotrades
FileName : partyController.js
Author : Indiefire
File Created : 21/07/2021
CopyRights : Indiefire
Purpose : This is the file which used to define all party related api function.
*/
var users = require('../../user/model/userModel');
var partys = require('../model/partyModel');
var loves = require('../model/loveModel');
var comments = require('../model/commentModel');
var validator = require('validator');

var party_reactions = require('../model/reactionModel'),
    party_plays = require('../model/playModel'),
    party_comments = require('../model/commentModel'),
    party_loves = require('../model/loveModel'),
    party_likes = require('../model/likeModel'),
    party_boosts = require('../model/boostModel'),
    party_comment_reactions = require('../model/commentreactionModel'),
    party_comment_loves = require('../model/commentloveModel')

var moment = require('moment');
const { validationResult } = require('express-validator');
const { getErrLine } = require("../../helper/helpers");
function getDateStr(date) {
    var datestr = `${date.getFullYear()}${ ("0" + (date.getMonth() + 1)).substr(-2) }${ ("0" + date.getDate()).substr(-2) }`;
    return datestr
}

/*
*  This is the function which used to retreive active party list
*/
exports.getList = async function(req,res) {
    console.log(getErrLine().str, "apistart");
    // var page = req.query.page ? req.query.page : '1';  
    // var limit = req.query.limit ? req.query.limit : '300';  
    // var query;    
    // {        
    //     query = partys.find();
    // }
    // var offset = ( page == '1' ) ? 0 : ((parseInt(page-1))*10);
    // // query = query.where('creator_id',req.query.user_id);
    // query = query.sort('-create_date')
    // query.exec(function(err,result){
    //     res.json({
    //         status: true,
    //         message: "Party retrieved successfully",
    //         data: result
    //     });
    // })
    var page = req.query.page ? req.query.page : '1';  
    var limit = req.query.limit ? req.query.limit : '300';  
    var query = partys.find();
    var offset = ( page == '1' ) ? 0 : ((parseInt(page-1))*limit); 

    var end = new Date();
    var start = new Date();
    end.setHours(23,59,59,999);
    if( req.query.daterange == 'today' )
    {       
        start.setHours(0,0,0,0);        
    }else if( req.query.daterange == 'yesterday' )
    {
        start.setHours(0,0,0,0);
        start.setDate(start.getDate() - 1);
    }else if( req.query.daterange == 'week' )
    {
        start = moment().startOf('isoweek').toDate();
    }else if( req.query.daterange == 'month' )
    {
        start = new Date(start.getFullYear(), start.getMonth(), 1);
        start.setHours(0,0,0,0);
    }

    if( req.query.daterange)
    {
        query = partys.find({create_date: {$gte: start, $lt: end}});
    } else { // All
        query = partys.find();
    }

    // query = query.where('creator_id',req.query.user_id)
    
    if( req.query.sort == 'newest' )
    {
        query = query.sort({create_date: -1})
    } else if( req.query.sort == 'oldest' ) 
    {
        query = query.sort({create_date: 1})
    } else if ( req.query.sort == 'popular' )
    {
        query = query.sort({love_count: -1})
    }

    
    var options = {
        select:   'creator_id description stream_link img_link love_count comment_count create_date tags',
        populate: {path:'creator_id',select:'first_name last_name username profile_image'},
        page:page,
        offset:offset,
        limit:limit,    
    };  
    partys.paginate(query, options).then(function (result) {
        res.json({
            status: true,
            message: "Party retrieved successfully",
            data: result
        });
    });     
}


/*
*  This is the function which used to retreive party detail by party id
*/
exports.details = function(req,res) {
    console.log(getErrLine().str, "apistart");
    console.log("received params are ", req.params)
    partys.findOne({_id:req.query.party_id}).exec( function (err, party) {
        if (err) {
            res.json({
                status: false,
                message: "Request failed",
                errors:"Party not found"
            });
            return;
        }
        if(!party) {
            res.json({
                status: false,
                message: "Request failed",
                errors:"Party not found"
            });
            return;
        } 
        res.json({
            status: true,
            message: "Party info retrieved successfully",
            result: party
        });
    })
}

/**
 * This is the function which used to list all partys
 */
exports.getAdminList  = function(req,res) {
    console.log(getErrLine().str, "apistart");
    var page = req.query.page ? req.query.page : '1';  
    var limit = req.query.limit ? req.query.limit : '300';  
    var query = partys.find();
    var offset = ( page == '1' ) ? 0 : ((parseInt(page-1))*limit); 
    // query = query.where('creator_id',req.query.user_id)
    query = query.sort('-create_date')
    var options = {
    select:   'description stream_link img_link love_count comment_count create_date',
    page:page,
    offset:offset,
    limit:limit,    
    };  
    partys.paginate(query, options).then(function (result) {
        res.json({
            status: true,
            message: "Party retrieved successfully",
            data: result
        });
    }); 
}

/**
 * This is the function which used to add party from admin
 */
exports.add  = function(req,res) {
    console.log(getErrLine().str, "apistart");
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        res.json({
            status: false,
            message: "Request failed",
            errors:errors.array()
        });
        return;
    }  
    var party = new partys();
    party.stream_link = req.body.stream_link;
    party.img_link = req.body.img_link;
    party.creator_id = req.body.creator_id;
    party.description = req.body.description;
    party.tags = req.body.tags;
    party.save(function (err , partyObj) {
        if (err) {
            res.json({
                status: false,
                message: "Request failed",
                errors:err
            });
            return;
        }
        res.json({
            status: true,
            message: "Party created successfully",
            result: partyObj
        });
    });
}



/**
 *  This is the function which used to update party 
 */
exports.edit  = function(req,res) {
    console.log(getErrLine().str, "apistart");
    partys.findOne({_id:req.body.party_id}, function (err, party) {
        if (err || !party) {
            res.json({
                status: false,
                message: "Party not found",
                errors:err
            });
            return;
        } else {
            party.description = req.body.description ?  req.body.description : party.description;
            party.stream_link = req.body.stream_link ?  req.body.stream_link : party.stream_link;
            party.img_link = req.body.img_link ?  req.body.img_link : party.img_link;
            party.love_count = req.body.love_count ?  req.body.love_count : party.love_count;
            party.comment_count = req.body.comment_count ?  req.body.comment_count : party.comment_count;
            party.save(function (err , party) {
                if (err) {
                    res.json({
                        status: false,
                        message: "Request failed",
                        errors:err
                    });
                    return;
                } else {
                    res.json({
                        status: true,
                        message: "Party updated successfully",
                        result: party 
                    });  
                }
            });
        }
    });
}

/**
 *  This is the function which used to delete party 
 */
 exports.delete  = function(req,res) {
    console.log(getErrLine().str, "apistart");
    partys.findOne({_id:req.body.party_id}, function (err, party) {
        if (err || !party) {
            res.json({
                status: false,
                message: "Party not found",
                errors:err
            });
            return;
        } else {
            partys.deleteOne({_id:req.body.party_id},function(err) {
                res.json({
                    status: true,
                    message: "Party deleted successfully"
                }); 
            })
        }
    });
 }

 /*
* This is the function which used to list Loves of FanPost in database
*/
exports.actionLove = function(req,res) {
    console.log(getErrLine().str, "apistart");
    partys.findOne({_id:req.body.party_id}, function (err, post1) {
        if (err || !post1) {
            res.json({
                status: false,
                message: "Post not found",
                errors:err
            });
            return;
        }
        loves.findOne({party_id:req.body.party_id, user_id:req.body.user_id}, function (err, retitem) {
            if(req.body.type == "increase") {
                if (!retitem) {
                    post1.love_count = post1.love_count + 1;
                    var newlove = new loves();
                    newlove.user_id = req.body.user_id;
                    newlove.party_id = req.body.party_id;
                    newlove.save(function(err,result){
                        post1.save(function(err,result){
                            res.json({
                                status: true,
                                message: "Love added successfully",
                            });
                        })
                    })
                } else {
                    res.json({
                        status: true,
                        message: "Love added successfully",
                    });
                }
            } else {
                if (!retitem) {
                    res.json({
                        status: true,
                        message: "Love removed successfully",
                    });
                } else {
                    post1.love_count = post1.love_count - 1;
                    loves.deleteOne({_id:retitem._id},function(err) {
                        post1.save(function(err,result){
                            res.json({
                                status: true,
                                message: "Love removed successfully",
                            });
                        })
                    })
                }
            }
            
        })
        
    });
}

/*
* This is the function which used to list post1 in database
*/
exports.actionComment = function(req,res) {
    console.log(getErrLine().str, "apistart");
    partys.findOne({_id:req.body.party_id}, function (err, post1) {
        if (err || !post1) {
            res.json({
                status: false,
                message: "Post not found",
                errors:err
            });
            return;
        }
        post1.comment_count = post1.comment_count + 1;
        var newcomment = new comments();
        newcomment.user_id = req.body.user_id;
        newcomment.party_id = req.body.party_id;
        newcomment.description = req.body.description;
        newcomment.save(function(err,result){
            post1.save(function(err,result){
                res.json({
                    status: true,
                    message: "Comment added successfully",
                });
            })
        })
        
    });
}


/*
* This is the function which used to list user who add the post1 as fan post1
*/
exports.listComment = function(req,res) {
    console.log(getErrLine().str, "apistart");
    var page = req.query.page ? req.query.page : '1';  
    var limit = req.query.limit ? req.query.limit : '10000';  
    var query = comments.find();
    var offset = ( page == '1' ) ? 0 : ((parseInt(page-1))*10);
    query = query.where('party_id',req.query.party_id);
    query = query.populate({path: 'user_id', model: users, select:'_id username first_name last_name profile_image is_idverified' });
    // query = query.sort('-created_date');
    query = query.sort({created_date: 1})
    var options = {
    page:page,
    offset:offset,
    limit:limit,    
    };  
    comments.paginate(query, options).then(function (result) {
        res.json({
            status: true,
            message: "Comments retrieved successfully",
            data: result
        });
    }); 
}








// added by dreampanda


exports.partys = async function(req, res) {
    console.log(getErrLine().str, "apistart");
    try {

        var user_id = req.decoded.user_id;

        // get param
        var type = req.query.type,
            rootCat = req.query.rootCat,
            cat1 = req.query.cat1,
            cat2 = req.query.cat2,
            cat3 = req.query.cat3,
            cat4 = req.query.cat4,

            keyword = req.query.keyword || '',
            page = req.query.page || 1,
            limit = req.query.limit || 15,

            fFavorites = req.query.fFavorites,

            filterShow = req.query.filterShow,
            filterFrom = req.query.filterFrom,
            filterTime = req.query.filterTime,
            filterTimeFrom = req.query.filterTimeFrom,
            filterTimeTo = req.query.filterTimeTo;
            // new parameter will be added

        var query = partys.find();
        query = query.sort({ create_date: -1 });

      
        if(rootCat == 'Trending') {
            query.sort('n_trending');
        }
        if(keyword != '') query.find({ $or: [
            { name:  { $regex: new RegExp(keyword, "ig") } },
            { description:  { $regex: new RegExp(keyword, "ig") } }
        ]})

        // filter I made favorite
        if(fFavorites) {
            var itemIds = (await party_loves.find({user_id})).map(d => d.party_id);
            query = query.find({ _id: { $in: itemIds } });
        }

        let play_lists = (await party_plays.find({ user_id })).map(d => d.party_id);
        switch(filterShow) {
            case 'Everything': break;
            case 'seen': 
                query = query.find({ _id: { $in: play_lists } });
                break;
            case 'notseen':
                query = query.find({ _id: { $nin: play_lists } });
                break;
            default:
                break;
        }
        let user = await users.findById(user_id);
        switch(filterFrom) {
            case 'Everybody':
                break;
            case 'following':
                let _followings = (await followers.find({ user_id })).map(d => d.star_id);
                query = query.find({ creator_id: { $in: _followings } })
                break;
            case 'muted':
                query = query.find({ creator_id: { $in: user?.muted_block?.muted_accounts } })
                break;
            default: 
                break;
        }

        switch(filterTime) {
            case 'anytime':
                break;
            case 'today':
                var date = new Date();
                var startOfToday = new Date(date.getFullYear(), date.getMonth(), date.getDate());
                var endOfToday = new Date(startOfToday.getTime() + 24 * 60 * 60 * 1000 - 1); // End of day is one millisecond before start of next day
                query = query.find({ create_date: { $gte: startOfToday, $lt: endOfToday } })
                break;
            case 'thisweek':
                query = query.find({ create_date: { $gte: new Date(new Date() - 7 * 24 * 60 * 60 * 1000) } })
                break;
            case 'thismonth':
                var date = new Date();
                var monthStart = new Date(date.getFullYear(), date.getMonth(), 1); // Get first day of current month
                var monthEnd = new Date(date.getFullYear(), date.getMonth() + 1, 0); // Get last day of current month
                query = query.find({ create_date: { $gte: monthStart, $lte: monthEnd }});
                break;
            case 'range':
                var startDate = new Date(filterTimeFrom);
                var endDate = new Date(filterTimeTo);
                query = query.find({ create_date: { $gte: startDate, $lte: endDate } })
                break;
            default:
                break;
        }
        query = query.sort("-create_date");
        let reactions = await party_reactions.find();
        let playLists = await party_plays.find();
        let comments = await party_comments.find({ parent_id: null });
        let likes = await party_likes.find();
        let loves = await party_loves.find();
        let boosts = await party_boosts.find();
        
        var offset = (page == '1') ? 0 : ((parseInt(page - 1)) * limit);
        var options = {
            page: page,
            offset: offset,
            limit: limit,
        };
        query = query.populate({ path: 'creator_id', model: users, select: '_id username first_name last_name profile_image is_idverified' })
        partys.paginate(query, options).then(function (result) {
            const updatedDocs = result.docs.map(d => {
                // console.log(playLists.some(pl => pl.party_id == d._doc._id && pl.user_id == user_id))
                const partyReactions = reactions.filter(r => r.party_id == d._doc._id.toString() && r.user_id == user_id);
                const reactionNumber = partyReactions.length ? partyReactions[0].reaction_number : -1;
                return {
                    ...d._doc,  // copy all the existing fields
                    reaction_number: reactionNumber,
                    isPlayed: playLists.some(pl => pl.party_id == d._doc._id.toString() && pl.user_id == user_id),
                    isCommented: comments.some(pl => pl.party_id == d._doc._id.toString() && pl.user_id == user_id),
                    isLiked: likes.some(pl => pl.party_id == d._doc._id.toString() && pl.user_id == user_id),
                    isLoved: loves.some(pl => pl.party_id == d._doc._id.toString() && pl.user_id == user_id),
                    isBoosted: boosts.some(pl => pl.party_id == d._doc._id.toString() && pl.user_id == user_id)
                }
            });
        
            const updatedResult = { ...result, docs: updatedDocs };
        
            res.json({
                status: true,
                message: "partys retrieved successfully",
                data: updatedResult
            });

        });
        
        
        
    } catch(err) {
        console.log(err)
        res.json({
            status: false,
            message: "Something went wrong",
            errors: err,
        })
    }
  


}



exports.create_party_reaction = function(req, res) {
    console.log(getErrLine().str, "apistart");
    var user_id = req.decoded.user_id;
    var party_id = req.body.party_id;
    var reaction_number = req.body.reaction_number;
    party_reactions.findOne({ party_id, user_id }, function(err, result) {
        if(err) {
            res.json({
                status: false,
                message: "db error"
            });
        }
        if(result) {
            if(result.reaction_number == reaction_number) {
                partys.findById(party_id, function(err, party) {
                    if(err || !party) {
                        res.json({
                            status: false,
                            message: 'Item not found'
                        });
                        return;
                    }
                    const n_reaction = party.n_reaction - 1;
                    party.n_reaction = n_reaction;
                    const n_reaction_detail = party.n_reaction_detail[`r_${reaction_number}`] - 1;
                    party.n_reaction_detail[`r_${reaction_number}`] = n_reaction_detail;
                    party.save(function(err, partySaved) {
                        party_reactions.remove({ _id: result._id }, function(err, result) {
                            if(err || !result) {
                                res.json({
                                    status: false,
                                    message: "Something went wrong"
                                })
                            } else {
                                res.json({
                                    status: true,
                                    message: "Removed successfully"
                                })
                            }
                        })
                    })
                })
            } else {
                partys.findById(party_id, function(err, party) {
                    if(err || !party) {
                        res.json({
                            status: false,
                            message: 'Item not found'
                        });
                        return;
                    }
                    const n_reaction_detail = party.n_reaction_detail[`r_${reaction_number}`] + 1;
                    party.n_reaction_detail[`r_${reaction_number}`] = n_reaction_detail;
                    const last_n_reaction_detail = party.n_reaction_detail[`r_${result.reaction_number}`] - 1;
                    party.n_reaction_detail[`r_${result.reaction_number}`] = last_n_reaction_detail;
                    party.save(function(err, partySaved) {
                        result.reaction_number = reaction_number;
                        result.save(function(err, result) {
                            if(err || !result) {
                                res.json({
                                    status: false,
                                    message: "Update error"
                                })
                                return
                            }
                            res.json({
                                status: true,
                                message: "updated successfully"
                            })
                        })
                    })
                })
            }
            
        } else {
            var newOne = party_reactions({ party_id, user_id, reaction_number });
            partys.findById(party_id, function(err, party) {
                if(err || !party) {
                    res.json({
                        status: false,
                        message: 'Item not found'
                    });
                    return;
                }
                const n_reaction = party.n_reaction + 1;
                party.n_reaction = n_reaction;
                const n_reaction_detail = party.n_reaction_detail[`r_${reaction_number}`] + 1;
                party.n_reaction_detail[`r_${reaction_number}`] = n_reaction_detail;
                party.save(function(err, result) {
                    newOne.save(function(err, result) {
                        res.json({
                            status: true,
                            message: "Saved successfully"
                        })
                    })
    
                })
            })
        }
    })
}

exports.read_party_reactions = function(req, res) {
    console.log(getErrLine().str, "apistart");
    var user_id = req.decoded.user_id;
    var party_id = req.query.party_id;
    partys.findById(party_id, function(err, result) {
        if(err) {
            res.json({
                status: false,
                message: "db error"
            })
            return
        }
        party_reactions.findOne({ party_id, user_id }, function(err, reaction) {
            if(err) {
                res.json({
                    status: false,
                    message: "Db error"
                })
            } else {
                var resData = {
                    data: result,
                    reaction: reaction
                }
                res.json({
                    status: true,
                    message: 'retrieved successfully',
                    result: resData
                })
            }
        })
        
    })
}


exports.create_party_play = function(req, res) {
    console.log(getErrLine().str, "apistart");
    var user_id = req.decoded.user_id;
    var party_id = req.body.party_id;

    partys.findById(party_id, function(err, party) {
        if(err || !party) {
            res.json({
                status: false,
                message: 'Db error or not found party'
            });
            return;
        }
        party_plays.findOne({ party_id: party_id, user_id: user_id }, function(err, result) {
            if(err || result) { 
                res.json({ status: false, message: 'Db error or already done' }); 
                return; 
            } else {
                var newOne = new party_plays({
                    party_id: party_id,
                    user_id: user_id
                });
                const n_play = party.n_play + 1;
                party.n_play = n_play;
                newOne.save(function(err, result) {
                    party.save(function(err, result) {
                        res.json({
                            status: true,
                            message: 'Saved successfully'
                        })
                    })
                })    
            }
        })
    })
}

exports.read_party_plays = function(req, res) {
    console.log(getErrLine().str, "apistart");
    var user_id = req.decoded.user_id;
    party_plays.find({ user_id:  user_id }, function(err, result) {
        if(err) {
            res.json({
                status: false,
                message: "db error"
            })
            return
        }
        res.json({
            status: true,
            message: 'retrieved successfully',
            result: result
        })
    })
}

exports.create_party_comment_reaction = function(req, res) {
    console.log(getErrLine().str, "apistart");
    var user_id = req.decoded.user_id;
    var party_comment_id = req.body.party_comment_id;
    var reaction_number = req.body.reaction_number;
    party_comment_reactions.findOne({ party_comment_id, user_id }, function(err, result) {
        if(err) {
            res.json({
                status: false,
                message: "db error"
            });
        }
        if(result) {
            if(result.reaction_number == reaction_number) {
                party_comments.findById(party_comment_id, function(err, party_comment) {
                    if(err || !party_comment) {
                        res.json({
                            status: false,
                            message: 'Item Comment not found'
                        });
                        return;
                    }
                    const n_reaction = party_comment.n_reaction - 1;
                    party_comment.n_reaction = n_reaction;
                    const n_reaction_detail = party_comment.n_reaction_detail[`r_${reaction_number}`] - 1;
                    party_comment.n_reaction_detail[`r_${reaction_number}`] = n_reaction_detail;
                    party_comment.save(function(err, partySaved) {
                        result.reaction_number = reaction_number;
                        result.save(function(err, result) {
                            if(err || !result) {
                                res.json({
                                    status: false,
                                    message: "Update error"
                                })
                                return
                            }
                            party_comment_reactions.remove({ party_comment_id, user_id }, function(err, result) {
                                if(err) {
                                    res.json({
                                        status: false,
                                        message: 'party comment reaction remove failed'
                                    })
                                } else {
                                    res.json({
                                        status: true,
                                        message: "updated successfully"
                                    })
                                }
                            })
                            
                        })
                    })
                })
            } else {
                party_comments.findById(party_comment_id, function(err, party_comment) {
                    if(err || !party_comment) {
                        res.json({
                            status: false,
                            message: 'Item Comment not found'
                        });
                        return;
                    }
                    const n_reaction_detail = party_comment.n_reaction_detail[`r_${reaction_number}`] + 1;
                    party_comment.n_reaction_detail[`r_${reaction_number}`] = n_reaction_detail;
                    const last_n_reaction_detail = party_comment.n_reaction_detail[`r_${result.reaction_number}`] - 1;
                    party_comment.n_reaction_detail[`r_${result.reaction_number}`] = last_n_reaction_detail;
                    party_comment.save(function(err, partySaved) {
                        result.reaction_number = reaction_number;
                        result.save(function(err, result) {
                            if(err || !result) {
                                res.json({
                                    status: false,
                                    message: "Update error"
                                })
                                return
                            }
                            res.json({
                                status: true,
                                message: "updated successfully"
                            })
                        })
                    })
                })
            }

           
            
        } else {
            var newOne = party_comment_reactions({ party_comment_id, user_id, reaction_number });
            party_comments.findById(party_comment_id, function(err, party_comment) {
                if(err || !party_comment) {
                    res.json({
                        status: false,
                        message: 'party_comment not found'
                    });
                    return;
                }
                const n_reaction = party_comment.n_reaction + 1;
                party_comment.n_reaction = n_reaction;
                const n_reaction_detail = party_comment.n_reaction_detail[`r_${reaction_number}`] + 1;
                party_comment.n_reaction_detail[`r_${reaction_number}`] = n_reaction_detail;
                party_comment.save(function(err, result) {
                    newOne.save(function(err, result) {
                        res.json({
                            status: true,
                            message: "Saved successfully"
                        })
                    })
    
                })
            })
        }
    })
}

exports.read_party_comment_reaction = function(req, res) {
    console.log(getErrLine().str, "apistart");
    var user_id = req.decoded.user_id;
    var party_comment_id = req.query.party_comment_id;
    party_comments.findById(party_comment_id, function(err, result) {
        if(err) {
            res.json({
                status: false,
                message: "db error"
            })
            return
        }
        party_comment_reactions.findOne({ party_comment_id, user_id }, function(err, reaction) {
            if(err) {
                res.json({
                    status: false,
                    message: "db error"
                })
            } else {
                var resData = {
                    data: result,
                    reaction: reaction
                }
                res.json({
                    status: true,
                    message: 'retrieved successfully',
                    result: resData
                })
            }
        })
       
    })
}

exports.create_party_comment_love = function(req, res) {
    console.log(getErrLine().str, "apistart");
    var user_id = req.decoded.user_id;
    var party_comment_id = req.body.party_comment_id;
    party_comment_loves.findOne({ party_comment_id, user_id }, async function(err, result) {
        if(err) {
            res.json({
                status: false,
                message: "Db error or already done"
            })
            return
        } else {
            if(result) {
                try {
                    let party_comment = await party_comments.findById(party_comment_id);
                    if(party_comment) {
                        // decrease the love number
                        const n_love = party_comment.n_love - 1;
                        party_comment.n_love = n_love;
                        party_comment.save();
                        result.remove();
                        res.json({
                            status: true,
                            message: "Removed successfully."
                        });

                    } else {
                        res.json({
                            status: false,
                            message: "Not found party comment"
                        });
                    }
                } catch (error) {
                    res.json({
                        status: false,
                        message: "Something weng wrong"
                    })
                }
            } else {
                var newOne = party_comment_loves({
                    party_comment_id, user_id
                });
                party_comments.findById(party_comment_id, function(err, party_comment) {
                    if(err || !party_comment) {
                        res.json({
                            status: false,
                            message: "Db error or not found party comment"
                        });
                        return;
                    } else {
                        let n_love = party_comment.n_love + 1;
                        party_comment.n_love = n_love;
                        party_comment.save(function(err, result) {
                            if(err) {
                                res.json({
                                    status: false,
                                    message: "party comment update error"
                                });
                                return;
                            }
                            newOne.save(function(err, result) {
                                if(err) {
                                    res.json({
                                        status: false,
                                        message: "New love is not save correctly"
                                    })
                                    return
                                }
                                res.json({
                                    status: true,
                                    message: "Saved successfully"
                                })
                            })
                        })
                    }
                })
            }
        }
    })
}

exports.create_party_comment_like = function(req, res) {
    console.log(getErrLine().str, "apistart");
    var comment_id = req.body.comment_id;
    var user_id = req.decoded.user_id;
    party_comments.findById(comment_id, function(err, party_comment) {
        party_comments.findOne({ _id: comment_id, user_id: user_id }, function(err, result) {
            if(err || result) {
                res.json({
                    status: false,
                    message: "Db error or already done"
                })
                return;
            } 
            const n_comment = party_comment.n_comment;
            party_comment.n_comment = n_comment;
            party_comment.save(function(err, result) {
                var newOne = new party_comment_likes({
                    comment_id: comment_id,
                    user_id: user_id
                });
                newOne.save(function(err, result) {
                    if(err) {
                        res.json({
                            status: false,
                            message: 'Db error'
                        })
                        return ;
                    }
                    res.json({
                        status: true,
                        message: 'Saved successfully.'
                    })
                })
            })
        })
    })
    
}



exports.create_party_comment = function(req, res) {
    console.log(getErrLine().str, "apistart");
    partys.findOne({_id:req.body.party_id}, function (err, post1) {
        if (err || !post1) {
            res.json({
                status: false,
                message: "Post not found",
                errors:err
            });
            return;
        }
        var newcomment = new party_comments(req.body);
        if(req.body.parent_id) {
            // Define comment_count and increment it before updating the document
            const parent_id = req.body.parent_id;
            party_comments.findById(parent_id, function(err, parent) {
                if (err) {
                    console.log(err);
                    res.json({
                        status: false,
                        message: 'error',
                        errors: error
                    })
                } else {
                    // Increment comment_count by 1
                    // if(parent.user_id != req.decoded.user_id) {
                        // post1.n_comment = post1.n_comment + 1;
                        const n_comment = parent.n_comment + 1;
                        // Update the parent document with the new comment_count value
                        party_comments.findByIdAndUpdate(parent_id, { n_comment: n_comment }, function(err, doc) {
                        if (err) {
                            console.log(err);
                        } else {
                            console.log(doc);
                            newcomment.save(function(err,result){
                                if(err) {
                                    console.log(err)
                                }
                                console.log(result)
                                // post1.save(function(err,result){
                                    res.json({
                                        status: true,
                                        message: "Comment added successfully",
                                    });
                                // })
                            })
                        }
                        });
                    // } else {
                    //     res.json({
                    //         status: false,
                    //         message: "That is yours, you can reply this "
                    //     })
                    // }
                }
            });

        } else {
            post1.n_comment = post1.n_comment + 1;
            newcomment.save(function(err,result){
                post1.save(function(err,result){
                    res.json({
                        status: true,
                        message: "Comment added successfully",
                    });
                })
            })
        }
       
        
    });
}


exports.read_party_comments = async function(req,res) {
    console.log(getErrLine().str, "apistart");
    var keyword = req.query.keyword || ''; // added dreampanda 20230523 pm 9
    var page = req.query.page ? req.query.page : '1';  
    var limit = req.query.limit ? req.query.limit : '15';  
    var parent_id = req.query.parent_id || '';
    var user_id = req.decoded.user_id;
    var sortKey = req.query.sortKey;

    var query = party_comments.find();
    var offset = ( page == '1' ) ? 0 : ((parseInt(page-1))*10);
    if(parent_id != '') {
        query = query.find({ parent_id: parent_id });
    } else {
        query = query.where('party_id',req.query.party_id);
        query = query.find({ parent_id: null })
    }
    if(keyword != '') {
        query = query.find({ description: { $regex: new RegExp(keyword, "ig") } })
    } 
    if(sortKey && sortKey == 'newest') {
        query = query.sort('-created_date')
    } else {
        query = query.sort('created_date')
    }
    var options = {
        page:page,
        offset:offset,
        limit:limit,    
    };

    let reactions = await party_comment_reactions.find();
    let comments = await party_comments.find({ parent_id: { $ne: null } });
    let loves = await party_comment_loves.find();
    let boosts = []; // temporary
    query = query.populate({
        path: 'user_id',
        model: 'users',
        select: '_id first_name last_name username profile_image is_idverified'
    })  
    party_comments.paginate(query, options).then(function (result) {
        const updatedDocs = result.docs.map(d => {
            // console.log(playLists.some(pl => pl.party_id == d._doc._id && pl.user_id == user_id))
            const partyReactions = reactions.filter(r => r.party_comment_id == d._doc._id.toString() && r.user_id == user_id);
            const reactionNumber = partyReactions.length ? partyReactions[0].reaction_number : -1;
            const date = new Date();
            return {
                ...d._doc,  // copy all the existing fields
                reaction_number: reactionNumber,
                isCommented: comments.some(pl => pl.parent_id == d._doc._id.toString() && pl.user_id == user_id),
                isLoved: loves.some(pl => pl.party_comment_id == d._doc._id.toString() && pl.user_id == user_id),
                isBoosted: boosts.some(pl => pl.party_comment_id == d._doc._id.toString() && pl.user_id == user_id),
                serverDate: date
            }
        });
    
        const updatedResult = { ...result, docs: updatedDocs };
    
        res.json({
            status: true,
            message: "party_comments retrieved successfully",
            data: updatedResult
        });
    }); 
}


exports.create_party_like = function(req, res) {
    console.log(getErrLine().str, "apistart");
    var user_id = req.decoded.user_id;
    var party_id = req.body.party_id;
    if(!party_id) {
        res.json({
            status: false,
            message: "Request error"
        })
    } else {
        party_likes.findOne({ party_id: party_id, user_id: user_id }, function(err, result) {
            if(err) { res.json({ status: false, message: 'Something went wrong' }); return; }
            if(result) {
                res.json({
                    status: false,
                    message: 'already done'
                });
                return;
            }
            partys.findById(party_id, function(err, party) {
                if(err || !party) {
                    res.json({
                        status: false,
                        message: 'Db error or not find party'
                    })
                    return;
                }
                const n_like = party.n_like + 1;
                party.n_like = n_like;
                party.save(function(err, result) {
                    var newOne = new party_likes({
                        party_id: party_id,
                        user_id: user_id
                    });
                    newOne.save(function(err, result) {
                        res.json({
                            status: true,
                            message: 'saved successfully'
                        })
                    })
                })
            })
        })
    }
}

exports.read_party_likes = function(req, res) {
    console.log(getErrLine().str, "apistart");
    var user_id = req.decoded.user_id;
    party_likes.find({ user_id: user_id }, function(err, result) {
        if(err) {
            res.json({ status: false, message: 'DB error' })
            return;
        }
        res.json({
            status: true, 
            message: 'Retrived successfully',
            result: result
        })
    })
}


exports.create_party_love = function(req, res) {
    console.log(getErrLine().str, "apistart");
    var user_id = req.decoded.user_id;
    var party_id = req.body.party_id;

    party_loves.findOne({ party_id: party_id, user_id: user_id }, async function(err, result) {
        if(err) { res.json({ status: false, message: 'Db error or else already done.' }); return; }
        if(result) {
            try {
                let party = await partys.findById(party_id);
                if(party) {
                    const n_love = party.n_love - 1; // decrease party love count
                    party.n_love = n_love;
                    // handle daily trending
                    var date = new Date();
                    var datestr = getDateStr(date); 
                    let daily_trending = party.daily_trending.find(d => d.date == datestr)
                    if(daily_trending) {
                        let count = daily_trending.count - 2;
                        daily_trending.count = count
                    } else {
                        let newObj = {
                            date: datestr,
                            count: -2
                        }
                        party.daily_trending.push(newObj)
                    }

                    party.save();
                    result.remove();
                    res.json({
                        status: true,
                        message: "Removed successfully"
                    });
                } else {
                    res.json({
                        status: false,
                        message: "party not found"
                    });
                }
            } catch(e) {
                console.log(e);
                res.json({
                    status: false,
                    message: "Something went wrong."
                })
            }
        } else {
            partys.findById(party_id, function(err, party) {
                if(err || !party) {
                    res.json({
                        status: false,
                        message: "Db error or party not found"
                    })
                    return
                }
                const n_love = party.n_love + 1;
                party.n_love = n_love;
                party.save(function(err, result) {
                    var newOne = new party_loves({
                        party_id: party_id,
                        user_id: user_id
                    });
                    newOne.save(function(err, result) {
                        res.json({
                            status: true,
                            message: 'saved successfully'
                        })
                    })
                })
            })
        }
    })
}

exports.read_party_loves = function(req, res) {
    console.log(getErrLine().str, "apistart");
    var user_id = req.decoded.user_id;
    party_loves.find({ user_id: user_id }, function(err, result) {
        if(err) {
            res.json({ status: false, message: 'DB error' })
            return;
        }
        res.json({
            status: true, 
            message: 'Retrived successfully',
            result: result
        })
    })
}


exports.create_party_boost = function(req, res) {
    console.log(getErrLine().str, "apistart");
    var user_id = req.decoded.user_id;
    var party_id = req.body.party_id;

    party_boosts.findOne({ party_id: party_id, user_id: user_id }, function(err, result) {
        if(err || result) { res.json({ status: false, message: 'Db error or already done action' }); return; }
        partys.findById(party_id, function(err, party) {
            if(err || !party) {
                res.json({
                    status: false,
                    message: "Db error or party not found"
                })
                return
            }
            const n_boost = party.n_boost + 1;
            party.n_boost = n_boost;
            var newOne = new party_boosts({
                party_id: party_id,
                user_id: user_id
            });
            party.save(function(err, result) {
                newOne.save(function(err, result) {
                    res.json({
                        status: true,
                        message: 'created successfully',
                    })
                })
            })
        })
    })
}


