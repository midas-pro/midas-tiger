/*
Project : Cryptotrades
FileName : itemController.js
Author : Indiefire
File Created : 21/07/2021
CopyRights : Indiefire
Purpose : This is the file which used to define all item related api function.
*/

//20231212am11 CoderD pric print format "toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })" use to "toFixed(2)"
var fs = require("fs");

var items = require("../model/itemModel");
var favourites = require("../model/favouriteModel");
var options = require("./../../common/model/optionsModel");
var offers = require("../model/offerModel");
var views = require("../model/viewModel");
var histories = require("../model/historyModel");
var prices = require("../model/priceModel");
var users = require("./../../user/model/userModel");
var collections = require("./../../collection/model/collectionModel");
var category = require("./../../category/model/categoryModel");
var item_reactions = require("../model/itemreactionModel"),
  item_plays = require("../model/itemplayModel"),
  item_comments = require("../model/itemcommentModel"),
  item_loves = require("../model/itemloveModel"),
  item_likes = require("../model/itemlikeModel"),
  item_boosts = require("../model/itemboostModel"),
  item_comment_reactions = require("../model/itemcommentreactionModel"),
  item_comment_loves = require("../model/itemcommentloveModel"),
  item_comment_likes = require("../model/itemcommentlikeModel"),
  seasons = require("../model/seasonModel"),
  rents = require("../model/rentModel"),
  shipaddrs = require("../../user/model/addressModel");

var followers = require("../../user/model/followerModel");
var bids = require("../model/bidModel");
var transactionModel = require("../model/transactionModel");

var fanpostModel = require("../../fanpost/model/fanpostModel"),
  fanpostReactionModel = require("../../fanpost/model/reactionModel"),
  fanpostCommentModel = require("../../fanpost/model/commentModel"),
  fanpostLoveModel = require("../../fanpost/model/loveModel");

var partyModel = require("../../party/model/partyModel"),
  partyReactionModel = require("../../party/model/reactionModel"),
  partyPlayModel = require("../../party/model/playModel"),
  partyCommentModel = require("../../party/model/commentModel"),
  partyLoveModel = require("../../party/model/loveModel"),
  partyLikeModel = require("../../party/model/likeModel");

var livenowModel = require("../../livenow/model/livenowModel");
var subscribers = require("../../user/model/subscriberModel");
var fanModel = require("../../user/model/fanModel"),
  followerModel = require("../../user/model/followerModel"),
  memberModel = require("../../user/model/memberModel");
var subscriptionlevelModel = require("../../user/model/subscriptionlevelModel"),
  subscriberModel = require("../../user/model/subscriberModel");
var blockModel = require("../../user/model/blockModel");
var muteModel = require("../../user/model/muteModel");
var playerModel = require("../../player/model/playerModel");
var fandomModel = require("../../user/model/fandomModel");
var playlistModel = require("../../playlist/model/playlistModel");
var transactionModel = require("../model/transactionModel");

const { validationResult } = require("express-validator");
var userController = require("./../../user/controller/userController");
const config = require("../../../helper/config");
var Web3 = require("web3");
var web3 = new Web3(new Web3.providers.HttpProvider(config.rpcurl));
var cp = require("child_process");
var mailer = require("./../../common/controller/mailController");
const { ObjectID } = require("bson");

const e = require("express");
const categoryModel = require("./../../category/model/categoryModel");
const {
  NOTIFICATION_TYPES,
  NOTIFICATION_FILTERS,
} = require("../../helper/notification_config");
const notificationModel = require("../../notification/model/notificationModel");
const SHIPCARRIER = require("../../helper/shipCarriers");
const boostModel = require("../../fanpost/model/boostModel");
const fanpostHistoryModel = require("../../fanpost/model/fanpostHistoryModel");
const fanpostShareModel = require("../../fanpost/model/fanpostShareModel");
const cartModel = require("../model/cartModel");
const itemShippingRuleModel = require("../../user/model/itemShippingRuleModel");
const { getErrLine } = require("../../helper/helpers");
const artistModel = require("../../user/model/artistModel");
const mediaModel = require("../../media/model/mediaModel");
global.nOrderId = 2;
/*
 * This is the function which used to add item in database
 */

// return datestr function
function getDateStr(date) {
  var datestr = `${date.getFullYear()}${("0" + (date.getMonth() + 1)).substr(
    -2
  )}${("0" + date.getDate()).substr(-2)}`;
  return datestr;
}

exports.add = async function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded.user_id;
  var item = new items(req.body);
  item.author_id = user_id;
  item.current_owner = user_id;



  try {
    await item.save();
    // save item to shipping_rule
    if (req.body.rule) {
      let rule = await itemShippingRuleModel.findById(req.body.rule?._id);
      rule.items.push(item._id);
      await rule.save();
    }

    if (req.body.collection_id && req.body.collection_id != "") {
      let collection = await collections.findById(req.body.collection_id);
      if (collection) {
        collection.item_count = collection.item_count + 1;
        await collection.save();
      }
    }

    // MANAGE ITEM CREATE NOTIFICATION
    let notif_users = [];
    let cat = await category.findById(req.body.category_id);
    // USERS WHO FOLLOWS ME AND THEIR NOTIFICATION SETTING IS ENABLED
    let _followers = await (
      await followers.find({ star_id: user_id })
    ).map((d) => d.user_id);
    let query = {
      _id: { $in: _followers },
    };
    let filter;
    if (cat.type == "Digital") {
      switch (cat.title) {
        case "Music":
          query = {
            ...query,
            "notif_music.is_new": true,
          };
          filter = NOTIFICATION_FILTERS.NEW_MUSIC;
          break;
        case "Podcasts":
          query = {
            ...query,
            "notif_podcasts.is_new": true,
          };
          filter = NOTIFICATION_FILTERS.NEW_PODCAST;
          break;
        case "Comedy gigs":
          query = {
            ...query,
            "notif_standUpComedy.is_new": true,
          };
          filter = NOTIFICATION_FILTERS.NEW_COMEDY_GIGS;
          break;
        case "Audiobooks":
          query = {
            ...query,
            "notif_audioBooks.is_new": true,
          };
          filter = NOTIFICATION_FILTERS.NEW_AUDIOBOOKS;
          break;
        case "Movies":
          query = {
            ...query,
            "notif_movies.is_new": true,
          };
          filter = NOTIFICATION_FILTERS.NEW_MOVIES;
          break;
        case "TV Series":
          query = {
            ...query,
            "notif_tv_series.is_new": true,
          };
          filter = NOTIFICATION_FILTERS.NEW_TV_SERIES;
          break;
        default:
          break;
      }
    } else {
    }

    let _users = await (await users.find(query)).map((d) => d._id);
    if (_users && _users.length > 0) {
      await Promise.all(
        _users.map(async (d) => {
          let new_notification = new notificationModel({
            type: NOTIFICATION_TYPES.ITEM_NEW,
            filter,
            from_id: user_id,
            to_id: d,
            /*
             20231216p4coderd modify
            message: `Added a new ${
              category?.type == "Digital" ? category.title : "Merchandise"
            }`,
            */
            message: `Added a new ${category.title
              }`,
            item_id: item._id
          });
          await new_notification.save();
        })
      );
      notif_users = _users;
    }

    res.json({
      status: true,
      message: "Created successfully",
      result: {
        notif_users,
      },
    });
  } catch (error) {
    console.log(error);
    res.json({
      status: false,
      message: "Something went wrong",
    });
  }
};
// get editable status
exports.get_editable_status = async function (req, res) {
  console.log(getErrLine().str, "apistart");
  var item_id = req.query.item_id;
  var user_id = req.decoded.user_id;
  try {
    // check is made offer, order, bid
    let item = await items.findById(item_id);
    if (item) {
      let role;
      let standard = true;
      let collective = true;
      let limited = true;
      if (item.author_id == user_id) {
        role = 'author'
      } else if (item.current_owner == user_id) {
        role = 'owner'
      }

      if (item.es_enabled) {
        if (item.es_is_auction) {
          let s_bids = await offers.find({
            item_id,
            edition: 'standard'
          });
          if (s_bids.length > 0) {
            standard = false;
          }
        } else {
          let s_orders = await offers.find({
            "items.item_id": item_id,
            "items.edition": "standard"
          });
          if (s_orders.length > 0) {
            standard = false;
          }
        }
      }

      if (item.ec_enabled) {
        if (item.ec_is_auction) {
          let c_bids = await offers.find({
            item_id,
            edition: 'collective'
          });
          if (c_bids.length > 0) {
            collective = false;
          }
        } else {
          let c_orders = await offers.find({
            "items.item_id": item_id,
            "items.edition": "collective"
          });
          if (c_orders.length > 0) {
            collective = false;
          }
        }
      }

      if (item.el_enabled) {
        if (item.el_is_auction) {
          let l_bids = await offers.find({
            item_id,
            edition: 'limited'
          });
          if (l_bids.lenght > 0) {
            limited = false;
          }
        } else {
          let l_orders = await offers.find({
            "items.item_id": item_id,
            "items.edition": "limited"
          });
          if (l_orders.length > 0) {
            limited = false;
          }
        }
      }


      res.json({
        status: true,
        message: "Retrived successfully",
        result: {
          role,
          standard,
          collective,
          limited
        }
      })



    } else {
      res.json({
        status: false,
        message: "Not found item"
      });
    }
  } catch (error) {
    console.log(error);
    res.json({
      status: false,
      message: "Something went wrong",
    });
  }
};

// get by id
exports.get_by_id = function (req, res) {
  console.log(getErrLine().str, "apistart");
  var item_id = req.query.item_id;
  items
    .findById(item_id)
    .populate({
      path: "collection_id",
      model: collections,
      populate: [
        {
          path: "author_id",
          model: users,
          select:
            "_id username first_name last_name profile_image metamask_info is_idverified",
        },
      ],
    })
    .populate({ path: "collection_id.author_id", model: users })
    .populate({ path: "category_id", model: category })
    .populate({ path: "catlevel2_id", model: category })
    .populate({ path: "catlevel3_id", model: category })
    .populate({ path: "season_id", model: seasons })
    .populate({ path: "artist", model: artistModel }) //202312coderb add artistmodel populate
    .populate({
      path: "current_owner",
      model: users,
      select:
        "_id username first_name last_name profile_image metamask_info is_idverified",
    })
    .populate({
      path: "author_id",
      model: users,
      select:
        "_id username first_name last_name profile_image metamask_info is_idverified",
    })
    .exec((err, result) => {
      if (err) {
        res.json({
          status: false,
          message: "DB error",
        });
      } else {
        if (result) {
          res.json({
            status: true,
            message: "retrived successfully",
            result,
          });
        } else {
          res.json({
            status: false,
            message: "Can't find item",
          });
        }
      }
    });
};

// 
exports.item = async function (req, res) {
  console.log(getErrLine().str, "apistart");
  var item_id = req.query.item_id;
  try {
    var item = await items.findById(item_id).select("name thumb description");
    res.json({
      status: true,
      message: "retrived successfully",
      result: item
    })
  } catch (error) {
    console.log(error);
    res.json({
      status: false,
      message: "Something went wrong"
    })
  }
}
/*
 * This is the function which used to update item in database
 */
exports.update = function (req, res) {
  console.log(getErrLine().str, "apistart");
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    res.json({
      status: false,
      message: "Request failed",
      errors: errors.array(),
    });
    return;
  }
  items.findOne(
    {
      _id: req.body.item_id,
      author_id: req.body.user_id /*, status:"inactive"*/,
    },
    function (err, item) {
      if (err || !item) {
        res.json({
          status: false,
          message: "Item not found",
          errors: err,
        });
        return;
      }

      item.name = req.body.name ? req.body.name : item.name;
      item.description = req.body.description
        ? req.body.description
        : item.description;
      item.blockchain = req.body.blockchain
        ? req.body.blockchain
        : item.blockchain;
      item.blockchain = config.blockchain;
      item.royalties = req.body.royalties ? req.body.royalties : item.royalties;
      item.lyrics = req.body.lyrics ? req.body.lyrics : item.lyrics;
      item.price = req.body.price ? req.body.price : item.price;
      item.is_auction = req.body.is_auction ? true : item.is_auction;
      item.is_ended = req.body.is_ended ? true : item.is_ended;
      item.start_date = req.body.start_date
        ? req.body.start_date
        : item.start_date;
      item.end_date = req.body.end_date ? req.body.end_date : item.end_date;
      item.media = req.body.media ? req.body.media : item.media;
      item.thumb = req.body.thumb ? req.body.thumb : item.thumb;
      item.external_link = req.body.external_link
        ? req.body.external_link
        : item.external_link;
      item.unlock_content_url = req.body.unlock_content_url
        ? req.body.unlock_content_url
        : item.unlock_content_url;
      item.attributes = req.body.attributes
        ? req.body.attributes
        : item.attributes;
      item.levels = req.body.levels ? req.body.levels : item.levels;
      item.stats = req.body.stats ? req.body.stats : item.stats;
      item.category_id = req.body.category_id
        ? req.body.category_id
        : item.category_id;
      item.catlevel2_id = req.body.catlevel2_id
        ? req.body.catlevel2_id
        : item.catlevel2_id;
      item.catlevel3_id = req.body.catlevel3_id
        ? req.body.catlevel3_id
        : item.catlevel3_id;

      item.es_enabled = req.body.es_enabled
        ? req.body.es_enabled
        : item.es_enabled;
      item.es_fImage = req.body.es_fImage ? req.body.es_fImage : item.es_fImage;
      item.es_fItem = req.body.es_fItem ? req.body.es_fItem : item.es_fItem;
      item.es_fFile = req.body.es_fFile ? req.body.es_fFile : item.es_fFile;
      item.es_fAudio = req.body.es_fAudio ? req.body.es_fAudio : item.es_fAudio;
      item.es_fVideo = req.body.es_fVideo ? req.body.es_fVideo : item.es_fVideo;
      item.es_title = req.body.es_title ? req.body.es_title : item.es_title;
      item.es_description = req.body.es_description
        ? req.body.es_description
        : item.es_description;
      item.es_isUnlimited = req.body.es_isUnlimited
        ? req.body.es_isUnlimited
        : item.es_isUnlimited;
      item.es_isAcceptOffer = req.body.es_isAcceptOffer
        ? req.body.es_isAcceptOffer
        : item.es_isAcceptOffer;
      item.es_price = req.body.es_price ? req.body.es_price : item.es_price;
      item.es_amount = req.body.es_amount ? req.body.es_amount : item.es_amount;
      item.es_balance = req.body.es_balance
        ? req.body.es_balance
        : item.es_balance;
      item.es_is_auction = req.body.es_is_auction
        ? req.body.es_is_auction
        : item.es_is_auction;
      item.es_is_ended = req.body.es_is_ended
        ? req.body.es_is_ended
        : item.es_is_ended;
      item.es_start_date = req.body.es_start_date
        ? req.body.es_start_date
        : item.es_start_date;
      item.es_end_date = req.body.es_end_date
        ? req.body.es_end_date
        : item.es_end_date;
      item.es_end_mode = req.body.es_end_mode
        ? req.body.es_end_mode
        : item.es_end_mode;

      item.ec_enabled = req.body.ec_enabled
        ? req.body.ec_enabled
        : item.ec_enabled;
      item.ec_fImage = req.body.ec_fImage ? req.body.ec_fImage : item.ec_fImage;
      item.ec_fItem = req.body.ec_fItem ? req.body.ec_fItem : item.ec_fItem;
      item.ec_fFile = req.body.ec_fFile ? req.body.ec_fFile : item.ec_fFile;
      item.ec_fAudio = req.body.ec_fAudio ? req.body.ec_fAudio : item.ec_fAudio;
      item.ec_fVideo = req.body.ec_fVideo ? req.body.ec_fVideo : item.ec_fVideo;
      item.ec_title = req.body.ec_title ? req.body.ec_title : item.ec_title;
      item.ec_description = req.body.ec_description
        ? req.body.ec_description
        : item.ec_description;
      item.ec_isUnlimited = req.body.ec_isUnlimited
        ? req.body.ec_isUnlimited
        : item.ec_isUnlimited;
      item.ec_isAcceptOffer = req.body.ec_isAcceptOffer
        ? req.body.ec_isAcceptOffer
        : item.ec_isAcceptOffer;
      item.ec_price = req.body.ec_price ? req.body.ec_price : item.ec_price;
      item.ec_amount = req.body.ec_amount ? req.body.ec_amount : item.ec_amount;
      item.ec_balance = req.body.ec_balance
        ? req.body.ec_balance
        : item.ec_balance;
      item.ec_is_auction = req.body.ec_is_auction
        ? req.body.ec_is_auction
        : item.ec_is_auction;
      item.ec_is_ended = req.body.ec_is_ended
        ? req.body.ec_is_ended
        : item.ec_is_ended;
      item.ec_start_date = req.body.ec_start_date
        ? req.body.ec_start_date
        : item.ec_start_date;
      item.ec_end_date = req.body.ec_end_date
        ? req.body.ec_end_date
        : item.ec_end_date;

      item.el_enabled = req.body.el_enabled
        ? req.body.el_enabled
        : item.el_enabled;
      item.el_fImage = req.body.el_fImage ? req.body.el_fImage : item.el_fImage;
      item.el_fItem = req.body.el_fItem ? req.body.el_fItem : item.el_fItem;
      item.el_fFile = req.body.el_fFile ? req.body.el_fFile : item.el_fFile;
      item.el_fAudio = req.body.el_fAudio ? req.body.el_fAudio : item.el_fAudio;
      item.el_fVideo = req.body.el_fVideo ? req.body.el_fVideo : item.el_fVideo;
      item.el_title = req.body.el_title ? req.body.el_title : item.el_title;
      item.el_description = req.body.el_description
        ? req.body.el_description
        : item.el_description;
      item.el_isUnlimited = req.body.el_isUnlimited
        ? req.body.el_isUnlimited
        : item.el_isUnlimited;
      item.el_isAcceptOffer = req.body.el_isAcceptOffer
        ? req.body.el_isAcceptOffer
        : item.el_isAcceptOffer;
      item.el_price = req.body.el_price ? req.body.el_price : item.el_price;
      item.el_amount = req.body.el_amount ? req.body.el_amount : item.el_amount;
      item.el_balance = req.body.el_balance
        ? req.body.el_balance
        : item.el_balance;
      item.el_is_auction = req.body.el_is_auction
        ? req.body.el_is_auction
        : item.el_is_auction;
      item.el_is_ended = req.body.el_is_ended
        ? req.body.el_is_ended
        : item.el_is_ended;
      item.el_start_date = req.body.el_start_date
        ? req.body.el_start_date
        : item.el_start_date;
      item.el_end_date = req.body.el_end_date
        ? req.body.el_end_date
        : item.el_end_date;

      item.save(function (err, itemObj) {
        if (err) {
          res.json({
            status: false,
            message: "Request failed",
            errors: err,
          });
          return;
        } else {
          res.json({
            status: true,
            message: "Item updated successfully",
            result: itemObj,
          });
        }
      });
    }
  );
};

exports._update = async function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded.user_id;
  console.log(req.body)
  console.log(req.body.shipping_method)
  try {
    var item_id = req.body.item_id;
    var item = await items.findById(item_id);
    if (item) {
      if (item.current_owner == user_id) {
        // validation is needed
        // var transaction = this.item
        // full - edit
        await items.findByIdAndUpdate(item_id, req.body);

        // manage shipping rule
        if (req.body.rule) {
          var dbrule = await itemShippingRuleModel.findOne({
            $and: [
              {
                items: {
                  $elemMatch: item_id
                }
              }, {
                _id: { $ne: req.body.rule?._id }
              }
            ]
          });

          if (!dbrule) {
            let rule = await itemShippingRuleModel.findById(req.body.rule?._id);
            if (!rule.items.find(d => d == item_id)) {
              rule.items.push(item_id);
              await rule.save();
            }
          }

        }


        res.json({
          status: true,
          message: "Updated successfully",
        });
        // par - edit
      } else {
        res.json({
          status: false,
          message: "You cannot edit this item",
        });
      }
    } else {
      res.json({
        status: false,
        message: "Can't find item",
      });
    }
  } catch (error) {
    console.log(error);
    res.json({
      status: false,
      message: "something went wrong",
    });
  }
};

/*
 * This is the function which used to publish item in ethereum network
 */
exports.publish = function (req, res) {
  console.log(getErrLine().str, "apistart");
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    res.json({
      status: false,
      message: "Request failed",
      errors: errors.array(),
    });
    return;
  }
  items
    .findOne({
      _id: req.body.item_id,
      author_id: req.decoded.user_id,
      status: "inactive",
    })
    .populate("collection_id")
    .exec(function (err, item) {
      if (err || !item) {
        res.json({
          status: false,
          message: "Item not found",
          errors: err,
        });
        return;
      }
      userController.getUserInfoByID(req.decoded.user_id, function (err, user) {
        item.token_id = req.body.token_id;
        if (item.collection_id.multiQty == 1) {
          item.token_id = item.collection_id.item_count;
        }
        item.minted_date = new Date();
        item.status = "active";
        item.save(function (err, itemObj) {
          if (err) {
            res.json({
              status: false,
              message: "Request failed",
              errors: err,
            });
            return;
          }
          var history = new histories();
          history.item_id = item._id;
          history.collection_id = item.collection_id._id;
          history.from_id = "000000000000000000000000";
          history.to_id = user._id;
          history.transaction_hash = req.body.transaction_hash;
          history.price = item.price;
          history.history_type = "minted";
          history.save(function (err, historyObj) {
            var price = new prices();
            price.item_id = item._id;
            price.price = item.price;
            price.user_id = user._id;
            price.save(function (err, priceObj) {
              res.json({
                status: true,
                message: "Item published successfully",
                result: itemObj,
              });
            });
          });
        });
      });
    });
};

/*
 * This is the function which used to update item price
 */

exports.updatePrice = function (req, res) {
  console.log(getErrLine().str, "apistart");
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    res.json({
      status: false,
      message: "Request failed",
      errors: errors.array(),
    });
    return;
  }

  items
    .findOne({ _id: req.body.item_id, status: "active" })
    .populate("collection_id")
    .exec(function (err, item) {
      if (err || !item) {
        res.json({
          status: false,
          message: "Item not found",
          errors: err,
        });
        return;
      }
      userController.getUserInfoByID(
        req.decoded.user_id,
        function (err, sender) {
          item.price = req.body.price;
          item.save(function (err, itemObj) {
            var price = new prices();
            price.item_id = itemObj._id;
            price.price = itemObj.price;
            price.user_id = sender._id;
            price.save(function (err, priceObj) {
              res.json({
                status: true,
                message: "Item price updated successfully",
                result: itemObj,
              });
            });
          });
        }
      );
    });
};

/*
 * This is the function which used to purchase item in ethereum network
 */
exports.purchase = function (req, res) {
  console.log(getErrLine().str, "apistart");
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    res.json({
      status: false,
      message: "Request failed",
      errors: errors.array(),
    });
    return;
  }
  items
    .findOne({ _id: req.body.item_id, status: "active" })
    .populate("collection_id")
    .exec(function (err, item) {
      if (err || !item) {
        res.json({
          status: false,
          message: "Item not found",
          errors: err,
        });
        return;
      }
      if (item.balance <= 0) {
        res.json({
          status: false,
          message: "Not enough balance to sell",
          errors: err,
        });
        return;
      }
      userController.getUserInfoByID(
        item.current_owner,
        function (err, receiver) {
          userController.getUserInfoByID(
            req.decoded.user_id,
            function (err, sender) {
              var sender_address = sender.metamask_info;
              var receiver_address = receiver.metamask_info;
              this.transferAdminComission(item, function (error, comission) {
                this.transferBalance(
                  sender,
                  receiver,
                  item,
                  comission,
                  function (is_transferred) {
                    var symbolabi = item.collection_id.contract_symbol + ".abi";
                    console.log(
                      "!!!transfer recv:",
                      receiver_address,
                      ", send:",
                      sender_address
                    );
                    /*var command = 'sh transaction.sh '+ receiver_address.id +' '+ sender_address.id +' '+item.token_id + ' ' + item.collection_id.contract_address + ' ' +  symbolabi+' ' +  config.owner.key*/
                    var command =
                      "sh transaction.sh " +
                      receiver_address.id +
                      " " +
                      sender_address.id +
                      " " +
                      item.token_id +
                      " " +
                      item.collection_id.contract_address +
                      " " +
                      symbolabi +
                      " " +
                      config.owner.key +
                      " " +
                      config.rpcurl;
                    if (item.amount > 1) {
                      command =
                        "sh transaction1155.sh " +
                        receiver_address.id +
                        " " +
                        sender_address.id +
                        " " +
                        item.token_id +
                        " " +
                        item.collection_id.contract_address +
                        " " +
                        symbolabi +
                        " " +
                        config.owner.key +
                        " " +
                        config.rpcurl +
                        " " +
                        "1" +
                        " " +
                        "0x";
                    }
                    cp.exec(command, function (err, stdout, stderr) {
                      console.log("stderr ", stderr);
                      console.log("stdout ", stdout);
                      // handle err, stdout, stderr
                      if (err) {
                        console.log("err", err);
                        res.json({
                          status: false,
                          message:
                            err
                              .toString()
                              .split("ERROR: ")
                              .pop()
                              .replace(/\n|\r/g, "") +
                            " cmd:" +
                            command.toString() +
                            ",,stdout:" +
                            stdout.toString(),
                        });
                        return;
                      }

                      var t_array = stdout
                        .toString()
                        .split("Transaction hash: ")
                        .pop()
                        .replace(/\n|\r/g, "")
                        .split(" ");
                      var transaction_hash = t_array[0].replace("Waiting", "");

                      var status_array = stdout
                        .toString()
                        .split("Status: ")
                        .pop()
                        .replace(/\n|\r/g, " ")
                        .split(" ");
                      var status_block = status_array[0];
                      if (status_block == "Failed") {
                        res.json({
                          status: false,
                          message: "NFT item transferred failed in network",
                          data: {
                            transaction_hash: transaction_hash,
                            status: JSON.stringify(status_array),
                          },
                        });
                      } else {
                        collections.findOne(
                          { _id: item.collection_id._id },
                          function (err, collection) {
                            collection.volume_traded =
                              collection.volume_traded + item.price;
                            collection.save(function (err, collectionsaveObj) {
                              if (item.amount > 1) {
                                if (item.balance > 0) {
                                  item.balance -= 1;
                                }
                              } else {
                                item.current_owner = req.decoded.user_id;
                              }
                              if (req.body.price) {
                                item.price = req.body.price;
                              }
                              item.buyers.push({
                                buyer: req.decoded.user_id,
                                amount: 1,
                                price: item.price,
                              });

                              // added by dreampanda
                              const n_sale = item.n_sale + 1;
                              item.n_sale = n_sale;

                              var date = new Date();
                              var datestr = getDateStr(date);

                              let daily_sale = item.daily_sale.find(
                                (d) => d.date == datestr
                              );
                              if (daily_sale) {
                                let count = daily_sale.count
                                  ? daily_sale.count + 1
                                  : 1;
                                daily_sale.count = count;
                              } else {
                                let newObj = {
                                  date: datestr,
                                  count: 1,
                                };
                                item.daily_sale.push(newObj);
                              }

                              item.save(function (err, itemObj) {
                                var history = new histories();
                                history.item_id = item._id;
                                history.collection_id = item.collection_id._id;
                                history.from_id = receiver._id;
                                history.to_id = sender._id;
                                history.transaction_hash = transaction_hash;
                                history.history_type = "transfer";
                                history.price = item.price;
                                history.amount = req.body.amount
                                  ? req.body.amount
                                  : 1; //2020.10.25
                                history.save(function (err, historyObj) {
                                  var price = new prices();
                                  price.item_id = item._id;
                                  price.price = item.price;
                                  price.amount = req.body.amount
                                    ? req.body.amount
                                    : 1; //2020.10.25
                                  price.user_id = sender._id;
                                  price.save(function (err, priceObj) {
                                    offers.deleteMany(
                                      { item_id: req.body.item_id },
                                      function (err, deleteResult) {
                                        res.json({
                                          status: true,
                                          message: "Item Transfer successfully",
                                          result: itemObj,
                                        });
                                      }
                                    );
                                  });
                                });
                              });
                            });
                          }
                        );
                      }
                    });
                  }
                );
              });
            }
          );
        }
      );
    });
};

/*
 * This is the function which used to bulk purchase item in ethereum network
 */
exports.bulkpurchase = function (req, res) {
  console.log(getErrLine().str, "apistart");
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    res.json({
      status: false,
      message: "Request failed",
      errors: errors.array(),
    });
    return;
  }
  items
    .findOne({ _id: req.body.item_id, status: "active" })
    .populate("collection_id")
    .exec(function (err, item) {
      if (err || !item) {
        res.json({
          status: false,
          message: "Item not found",
          errors: err,
        });
        return;
      }
      userController.getUserInfoByID(
        item.current_owner,
        function (err, receiver) {
          userController.getUserInfoByID(
            req.decoded.user_id,
            function (err, sender) {
              var sender_address = sender.metamask_info;
              var receiver_address = receiver.metamask_info;
              this.transferAdminComission(item, function (error, comission) {
                this.transferBalance(
                  sender,
                  receiver,
                  item,
                  comission,
                  function (is_transferred) {
                    var symbolabi = item.collection_id.contract_symbol + ".abi";
                    /*var command = 'sh transaction.sh '+ receiver_address.id +' '+ sender_address.id +' '+item.token_id + ' ' + item.collection_id.contract_address + ' ' +  symbolabi+' ' +  config.owner.key*/
                    var command =
                      "sh transaction.sh " +
                      receiver_address.id +
                      " " +
                      sender_address.id +
                      " " +
                      item.token_id +
                      " " +
                      item.collection_id.contract_address +
                      " " +
                      symbolabi +
                      " " +
                      config.owner.key +
                      " " +
                      config.rpcurl;
                    cp.exec(command, function (err, stdout, stderr) {
                      console.log("stderr ", stderr);
                      console.log("stdout ", stdout);
                      // handle err, stdout, stderr
                      /*if(err) {
                console.log("err",err)
                res.json({
                  status: false,
                  message: err.toString().split('ERROR: ').pop().replace(/\n|\r/g, "")
                });
                return
              }*/

                      var t_array = stdout
                        .toString()
                        .split("Transaction hash: ")
                        .pop()
                        .replace(/\n|\r/g, "")
                        .split(" ");
                      var transaction_hash = t_array[0].replace("Waiting", "");

                      var status_array = stdout
                        .toString()
                        .split("Status: ")
                        .pop()
                        .replace(/\n|\r/g, " ")
                        .split(" ");
                      var status_block = status_array[0];
                      if (status_block == "Failed") {
                        res.json({
                          status: false,
                          message: "NFT item transferred failed in network",
                          data: {
                            transaction_hash: transaction_hash,
                          },
                        });
                      } else {
                        item.current_owner = req.decoded.user_id;
                        collections.findOne(
                          { _id: item.collection_id._id },
                          function (err, collection) {
                            collection.volume_traded =
                              collection.volume_traded + item.price;
                            collection.save(function (err, collectionsaveObj) {
                              if (req.body.price) {
                                item.price = req.body.price;
                              }
                              item.save(function (err, itemObj) {
                                var history = new histories();
                                history.item_id = item._id;
                                history.collection_id = item.collection_id._id;
                                history.from_id = receiver._id;
                                history.to_id = sender._id;
                                history.transaction_hash = transaction_hash;
                                history.history_type = "transfer";
                                history.price = item.price;
                                history.save(function (err, historyObj) {
                                  var price = new prices();
                                  price.item_id = item._id;
                                  price.price = item.price;
                                  price.user_id = sender._id;
                                  price.save(function (err, priceObj) {
                                    offers.deleteMany(
                                      { item_id: req.body.item_id },
                                      function (err, deleteResult) {
                                        res.json({
                                          status: true,
                                          message: "Item Transfer successfully",
                                          result: itemObj,
                                        });
                                      }
                                    );
                                  });
                                });
                              });
                            });
                          }
                        );
                      }
                    });
                  }
                );
              });
            }
          );
        }
      );
    });
};

/*
 * This is the function which used to purchase item in ethereum network
 */
exports.purchase1155 = function (req, res) {
  console.log(getErrLine().str, "apistart");
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    res.json({
      status: false,
      message: "Request failed",
      errors: errors.array(),
    });
    return;
  }
  items
    .findOne({ _id: req.body.item_id, status: "active" })
    .populate("collection_id")
    .exec(function (err, item) {
      if (err || !item) {
        res.json({
          status: false,
          message: "Item not found",
          errors: err,
        });
        return;
      }
      userController.getUserInfoByID(
        item.current_owner,
        function (err, receiver) {
          userController.getUserInfoByID(
            req.decoded.user_id,
            function (err, sender) {
              var sender_address = sender.metamask_info;
              var receiver_address = receiver.metamask_info;
              this.transferAdminComission(item, function (error, comission) {
                this.transferBalance(
                  sender,
                  receiver,
                  item,
                  comission,
                  function (is_transferred) {
                    var symbolabi = item.collection_id.contract_symbol + ".abi";
                    console.log(
                      "!!!transfer recv:",
                      receiver_address,
                      ", send:",
                      sender_address
                    );
                    /*var command = 'sh transaction.sh '+ receiver_address.id +' '+ sender_address.id +' '+item.token_id + ' ' + item.collection_id.contract_address + ' ' +  symbolabi+' ' +  config.owner.key*/
                    var command =
                      "sh transaction.sh " +
                      receiver_address.id +
                      " " +
                      sender_address.id +
                      " " +
                      item.token_id +
                      " " +
                      item.collection_id.contract_address +
                      " " +
                      symbolabi +
                      " " +
                      config.owner.key +
                      " " +
                      config.rpcurl;
                    cp.exec(command, function (err, stdout, stderr) {
                      console.log("stderr ", stderr);
                      console.log("stdout ", stdout);
                      // handle err, stdout, stderr
                      /*if(err) {
                console.log("err",err)
                res.json({
                  status: false,
                  message: err.toString().split('ERROR: ').pop().replace(/\n|\r/g, "")
                });
                return
              }*/

                      var t_array = stdout
                        .toString()
                        .split("Transaction hash: ")
                        .pop()
                        .replace(/\n|\r/g, "")
                        .split(" ");
                      var transaction_hash = t_array[0].replace("Waiting", "");

                      var status_array = stdout
                        .toString()
                        .split("Status: ")
                        .pop()
                        .replace(/\n|\r/g, " ")
                        .split(" ");
                      var status_block = status_array[0];
                      if (status_block == "Failed") {
                        res.json({
                          status: false,
                          message: "NFT item transferred failed in network",
                          data: {
                            transaction_hash: transaction_hash,
                            status: JSON.stringify(status_array),
                          },
                        });
                      } else {
                        // item.current_owner = req.decoded.user_id;
                        collections.findOne(
                          { _id: item.collection_id._id },
                          function (err, collection) {
                            collection.volume_traded =
                              collection.volume_traded + item.price;
                            collection.save(function (err, collectionsaveObj) {
                              if (req.body.price) {
                                item.price = req.body.price;
                              }
                              item.buyers.push({
                                buyer: req.decoded.user_id,
                                amount: 1,
                                price: item.price,
                              });
                              item.save(function (err, itemObj) {
                                var history = new histories();
                                history.item_id = item._id;
                                history.collection_id = item.collection_id._id;
                                history.from_id = receiver._id;
                                history.to_id = sender._id;
                                history.transaction_hash = transaction_hash;
                                history.history_type = "transfer";
                                history.price = item.price;
                                history.amount = req.body.amount
                                  ? req.body.amount
                                  : 1; //2020.10.25
                                history.save(function (err, historyObj) {
                                  var price = new prices();
                                  price.item_id = item._id;
                                  price.price = item.price;
                                  price.amount = req.body.amount
                                    ? req.body.amount
                                    : 1; //2020.10.25
                                  price.user_id = sender._id;
                                  price.save(function (err, priceObj) {
                                    offers.deleteMany(
                                      { item_id: req.body.item_id },
                                      function (err, deleteResult) {
                                        res.json({
                                          status: true,
                                          message: "Item Transfer successfully",
                                          result: itemObj,
                                        });
                                      }
                                    );
                                  });
                                });
                              });
                            });
                          }
                        );
                      }
                    });
                  }
                );
              });
            }
          );
        }
      );
    });
};

/*
 * This is the function which used to purchase item in ethereum network
 */
exports.history = function (req, res) {
  console.log(getErrLine().str, "apistart");
  var page = req.query.page ? req.query.page : "1";

  var query;
  if (req.query.type == "item") {
    query = histories.find({ item_id: req.query.item_id });
  } else if (req.query.type == "collection") {
    query = histories.find({ collection_id: req.query.collection_id });
  } else if (req.query.type == "profile") {
    query = histories.find({ to_id: req.query.user_id });
  } else if (req.query.type == "sold") {
    query = histories.find({ from_id: req.query.user_id });
  } else {
    query = histories.find();
  }

  if (req.query.filter) {
    query = query.where("history_type", req.query.filter);
  }

  var offset = page == "1" ? 0 : parseInt(page - 1) * 10;
  query = query.populate({
    path: "to_id",
    model: users,
    select: "_id username first_name last_name profile_image",
  });
  query = query.populate({
    path: "from_id",
    model: users,
    select: "_id username first_name last_name profile_image",
  });
  query = query.populate({
    path: "item_id",
    model: items,
    select: "_id name thumb price",
  });
  query = query.populate({ path: "collection_id", model: collections });
  query = query.sort("-created_date");
  var options = {
    page: page,
    offset: offset,
    limit: 10,
  };
  histories.paginate(query, options).then(function (result) {
    res.json({
      status: true,
      message: "Histories retrieved successfully",
      data: result,
    });
  });
};

/*
 * This is the function which used to show price list
 */
exports.pricelist = function (req, res) {
  console.log(getErrLine().str, "apistart");
  var page = req.query.page ? req.query.page : "1";
  var limit = req.query.limit ? req.query.limit : "10";
  var query = prices.find({ item_id: req.query.item_id });
  var offset = page == "1" ? 0 : parseInt(page - 1) * 10;
  query = query.populate({
    path: "user_id",
    model: users,
    select: "_id username first_name last_name profile_image",
  });
  query = query.sort("-created_date");
  var options = {
    page: page,
    offset: offset,
    limit: limit,
  };
  prices.paginate(query, options).then(function (result) {
    res.json({
      status: true,
      message: "Prices retrieved successfully",
      data: result,
    });
  });
};

/*
 * This is the function which used to delete item in database
 */
exports.delete = function (req, res) {
  console.log(getErrLine().str, "apistart");
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    res.json({
      status: false,
      message: "Request failed",
      errors: errors.array(),
    });
    return;
  }
  items.findOne(
    {
      _id: req.body.item_id,
      author_id: req.decoded.user_id,
      status: "inactive",
    },
    function (err, item) {
      if (err || !item) {
        res.json({
          status: false,
          message: "Item not found",
          errors: err,
        });
        return;
      } else {
        collections.findOne(
          { _id: item.collection_id },
          function (err, collection) {
            items.deleteOne({ _id: req.body.item_id }, function (err) {
              collection.item_count = collection.item_count - 1;
              collection.save(function (err, collectionObj) {
                res.json({
                  status: true,
                  message: "Item deleted successfully",
                });
              });
            });
          }
        );
      }
    }
  );
};

/*
 * This is the function which used to get more from collection for item detail page
 */
exports.moreFromCollection = function (req, res) {
  console.log(getErrLine().str, "apistart");
  query = users.find({ _id: { $nin: [req.query.item_id] } });
  var recentquery = items
    .find({
      collection_id: req.query.collection_id,
      status: "active",
      _id: { $nin: [req.query.item_id] },
    })
    .select("name description royalties thumb n_like create_date status price");
  recentquery = recentquery.sort("-create_date").limit(5);
  recentquery.exec(function (err, recentresult) {
    res.json({
      status: true,
      message: "Collection Item retrieved successfully",
      data: recentresult,
    });
  });
};

/*
 * This is the function which used to check list item by collection for collection home page
 */
exports.listByCollection = function (req, res) {
  console.log(getErrLine().str, "apistart");
  var result = {};
  var recentquery = items
    .find({ collection_id: req.query.collection_id, status: "active" })
    .select(
      "name description royalties thumb n_like create_date status price n_play current_owner"
    )
    .populate({
      path: "current_owner",
      model: users,
      select: "_id username first_name last_name profile_image",
    });
  recentquery = recentquery.sort("-create_date").limit(5);
  recentquery.exec(function (err, recentresult) {
    result["recent"] = recentresult;
    var mintedquery = items
      .find({ collection_id: req.query.collection_id, status: "active" })
      .select(
        "name description royalties thumb n_like create_date status price n_play current_owner"
      )
      .populate({
        path: "current_owner",
        model: users,
        select: "_id username first_name last_name profile_image",
      });

    mintedquery = mintedquery.sort("-minted_date").limit(5);
    mintedquery.exec(function (err, mintedresult) {
      result["minted"] = mintedresult;
      var autcionquery = items
        .find({
          collection_id: req.query.collection_id,
          status: "active",
          has_offer: true,
        })
        .select(
          "name description royalties thumb n_like create_date status price n_play current_owner"
        )
        .populate({
          path: "current_owner",
          model: users,
          select: "_id username first_name last_name profile_image",
        });

      autcionquery = autcionquery.sort("-create_date").limit(5);
      autcionquery.exec(function (err, auctionresult) {
        result["onauction"] = auctionresult;
        res.json({
          status: true,
          message: "Collection Item retrieved successfully",
          data: result,
        });
      });
    });
  });
};

/*
 * This is the function which used to list item in database
 */
exports.list = function (req, res) {
  console.log(getErrLine().str, "apistart");
  var keyword = req.query.keyword ? req.query.keyword : "";
  keyword = keyword.replace("+", " ");
  var page = req.query.page ? req.query.page : "1";
  var limit = req.query.limit ? req.query.limit : "10";
  var query = items.find();
  var offset = page == "1" ? 0 : parseInt(page - 1) * 10;
  if (keyword != "") {
    search = {
      $or: [
        {
          name: {
            $regex: new RegExp(keyword, "ig"),
          },
        },
        {
          description: {
            $regex: new RegExp(keyword, "ig"),
          },
        },
      ],
    };
    query = query.or(search);
  }
  // query = query.where('blockchain', config.blockchain);
  if (req.query.type == "mycollection" && req.decoded.user_id != null) {
    query = query.where("collection_id", req.query.collection_id);
    query = query.sort("-create_date");
  } else if (req.query.type == "view" && req.decoded.user_id != null) {
    console.log("item_list:view_with_user_id");
    query = query.where("_id", req.query.item_id);
  } else {
    if (req.query.user && req.decoded.user_id != null) {
      if (req.decoded.role == 1 && req.query.user == "admin") {
      } else {
        query = query.where("status", "active");
        console.log("item_list:status=active1");
      }
    } else {
      console.log("item_list:status=active2");
      // query = query.where("status", "active");//!!//?? 
    }

    if (req.query.type == "my") {
      query = query.where("author_id", req.query.user_id).sort("-create_date");
    } else if (req.query.type == "collected") {
      // query = query.where('current_owner',req.query.user_id).where("author_id",{"$ne":req.query.user_id}).sort('-create_date');
      query = query
        .where({
          $or: [
            { current_owner: req.query.user_id },
            { "buyers.buyer": req.query.user_id },
          ],
        })
        .where("author_id", { $ne: req.query.user_id })
        .sort("-create_date");
    } else if (req.query.type == "view") {
      console.log("item_list:view_withoutSignedUser");
      query = query.where("_id", req.query.item_id);
    } else if (req.query.type == "offer") {
      query = query.where("has_offer", true);
    } else if (req.query.type == "collection") {
      query = query.where("collection_id", req.query.collection_id);
    } else if (req.query.type == "category") {
      query = query.where("category_id", req.query.category_id);
    } else if (req.query.type == "price") {
      query = query.where("price", { $gte: req.query.price_range });
    } else if (req.query.type == "mostviewed") {
      query = query.sort("-n_play");
    } else if (req.query.type == "mostliked") {
      query = query.sort("-n_like");
    } else {
      // query = query.sort('-create_date')
    }

    if (req.query.sort == "mostviewed") {
      // query = query.sort('-n_play');
      query = query.sort({ n_play: -1 });
    } else if (req.query.sort == "mostliked") {
      // query = query.sort('-n_like')
      query = query.sort({ n_like: -1 });
    } else if (req.query.sort == "create_date") {
      // query = query.sort('-n_like')
      query = query.sort({ create_date: -1 });
    }
  }
  var options;
  if (req.query.type != "view") {
    options = {
      // select:  'name description royalties thumb media category_id collection_id n_like create_date status price current_owner author_id is_auction is_ended start_date end_date',
      populate:
        "current_owner author_id collection_id category_id catlevel2_id catlevel3_id",
      page: page,
      offset: offset,
      limit: limit,
    };
  } else {
    query = query
      .populate({ path: "collection_id", model: collections })
      .populate({ path: "category_id", model: category })
      .populate({ path: "catlevel2_id", model: category })
      .populate({ path: "catlevel3_id", model: category })
      .populate({
        path: "current_owner",
        model: users,
        select: "_id username first_name last_name profile_image metamask_info",
      })
      .populate({ path: "author_id", model: users });
    options = {
      page: page,
      offset: offset,
      limit: limit,
    };
  }

  items.paginate(query, options).then(function (result) {
    if (req.query.type != "view") {
      res.json({
        status: true,
        message: "Item retrieved successfully",
        log: "item_list:noview",
        data: result,
        return_id: 0,
      });
    } else {
      var is_liked = 0;
      if (req.decoded.user_id != null) {
        console.log("item_list:view_withSignedUser_fav");
        favourites.findOne(
          { item_id: req.query.item_id, user_id: req.decoded.user_id },
          function (err, favourite) {
            if (favourite) {
              is_liked = 1;
            }
            console.log("item_list:view_withSignedUser_fav.ret");
            res.json({
              status: true,
              message: "Item retrieved successfully",
              log: "item_list:view_withSignedUser_fav.ret",
              data: result,
              return_id: is_liked,
            });
          }
        );
      } else {
        console.log("item_list:view_withSignedUser_nofav.ret");
        res.json({
          status: true,
          message: "Item retrieved successfully",
          log: "item_list:view_withSignedUser_nofav.ret",
          data: result,
          return_id: is_liked,
        });
      }
    }
  });
};

/*
 * This is the function which used to list item in database
 */
exports.actionFavourite = function (req, res) {
  console.log(getErrLine().str, "apistart");
  items.findOne(
    { _id: req.body.item_id, status: "active" },
    function (err, item) {
      if (err || !item) {
        res.json({
          status: false,
          message: "Item not found",
          errors: err,
        });
        return;
      }
      favourites.findOne(
        { item_id: req.body.item_id, user_id: req.decoded.user_id },
        function (err, favourite) {
          if (req.body.type == "increase") {
            if (!favourite) {
              item.n_like = item.n_like + 1;
              var newfavourite = new favourites();
              newfavourite.user_id = req.decoded.user_id;
              newfavourite.item_id = req.body.item_id;
              newfavourite.save(function (err, result) {
                item.save(function (err, result) {
                  res.json({
                    status: true,
                    message: "Favoruite added successfully",
                  });
                });
              });
            } else {
              res.json({
                status: true,
                message: "Favoruite added successfully",
              });
            }
          } else {
            if (!favourite) {
              res.json({
                status: true,
                message: "Favoruite removed successfully",
              });
            } else {
              item.n_like = item.n_like - 1;
              favourites.deleteOne({ _id: favourite._id }, function (err) {
                item.save(function (err, result) {
                  res.json({
                    status: true,
                    message: "Favoruite removed successfully",
                  });
                });
              });
            }
          }
        }
      );
    }
  );
};

exports.isFavourite = function (req, res) {
  console.log(getErrLine().str, "apistart");
  var is_liked = 0;
  if (req.decoded.user_id != null) {
    favourites.findOne(
      { item_id: req.query.item_id, user_id: req.decoded.user_id },
      function (err, favourite) {
        if (favourite) {
          is_liked = 1;
        }
        res.json({
          status: true,
          message: "Item retrieved successfully",
          return_id: is_liked,
        });
      }
    );
  } else {
    res.json({
      status: true,
      message: "Item retrieved successfully",
      return_id: is_liked,
    });
  }
};

/*
 * This is the function which used to list user who add the item as favourite item
 */
exports.listFavourite = function (req, res) {
  console.log(getErrLine().str, "apistart");
  var page = req.query.page ? req.query.page : "1";
  var limit = req.query.limit ? req.query.limit : "15";
  var query = favourites.find();
  var offset = page == "1" ? 0 : parseInt(page - 1) * 10;
  query = query.where("user_id", req.query.user_id);
  query = query.populate({
    path: "item_id",
    model: items,
    select: "_id name thumb price",
  });
  query = query.sort("-created_date");
  var options = {
    page: page,
    offset: offset,
    limit: limit,
  };
  favourites.paginate(query, options).then(function (result) {
    res.json({
      status: true,
      message: "Favourites retrieved successfully",
      data: result,
    });
  });
};

/*
 * This is the function which used to add views for user
 */
exports.addViews = function (req, res) {
  console.log(getErrLine().str, "apistart");
  items.findOne(
    { _id: req.body.item_id, status: "active" },
    function (err, item) {
      if (err || !item) {
        res.json({
          status: false,
          message: "Item not found",
          errors: err,
        });
        return;
      }
      views.findOne(
        { item_id: req.body.item_id, user_id: req.decoded.user_id },
        function (err, view) {
          if (!view) {
            item.n_play = item.n_play + 1;
            var newview = new views();
            newview.user_id = req.decoded.user_id;
            newview.item_id = req.body.item_id;
            newview.save(function (err, result) {
              item.save(function (err, result) {
                res.json({
                  status: true,
                  message: "View added successfully",
                });
              });
            });
          } else {
            res.json({
              status: true,
              message: "View added successfully",
            });
          }
        }
      );
    }
  );
};

/*
 * This is the function which used to list user who recently view the item
 */
exports.recentlyViewed = function (req, res) {
  console.log(getErrLine().str, "apistart");
  var page = req.query.page ? req.query.page : "1";
  var query = views.find();
  var offset = page == "1" ? 0 : parseInt(page - 1) * 10;
  query = query.where("item_id", req.query.item_id);
  query = query.where("user_id", req.query.user_id);
  query = query.sort("-created_date");
  var options = {
    page: page,
    offset: offset,
    limit: 15,
  };
  views.paginate(query, options).then(function (result) {
    res.json({
      status: true,
      message: "Views retrieved successfully",
      data: result,
    });
  });
};

/*
 * This is the function which used to list item offer and profile offer
 */
function handleOrderItems(sender, receiver, _items, from) {
  console.log(getErrLine().str, "apistart");
  _items.map(async (d) => {
    let item = await items
      .findById(d.item_id)
      .populate({ path: "collection_id", model: collections })
      .populate({ path: "category_id", model: category })
      .populate({ path: "catlevel2_id", model: category })
      .populate({ path: "catlevel3_id", model: category })
      .populate({
        path: "current_owner",
        model: users,
        select:
          "_id username first_name last_name profile_image metamask_info is_idverified",
      })
      .populate({
        path: "author_id",
        model: users,
        select:
          "_id username first_name last_name profile_image metamask_info is_idverified",
      });
    // if(item.category_id?.type == 'Ditigal') {
    handleItem(
      sender,
      receiver,
      d.item_id,
      d.edition,
      d.option,
      d.amount,
      d.price,
      from
    );
    // }
  });
}

exports.get_stock = async function (req, res) {
  console.log(getErrLine().str, "apistart");
  var item_id = req.body.item_id;
  var edition = req.body.edition;
  var option = req.body.option;

  try {
    var item = await items.findById(item_id);
    if (item) {
      // get stock
      var label;
      switch (edition) {
        case "standard":
          label = "es_";
          break;
        case "collective":
          label = "ec_";
          break;
        case "limited":
          label = "el_";
          break;
        default:
          label = "ec_";
          break;
      }
      if (option) {
        let inventory = item[`${label}inventories`].find(
          (d) => JSON.stringify(d.option) == JSON.stringify(option)
        );
        if (inventory) {
          if (inventory.limited) {
            // complex
            let total = inventory.count;
            // var n_norder
            let n_purchased = 0;
            (await transactionModel.find({ item_id, edition })).map((d) => {
              if (JSON.stringify(d) == JSON.stringify(option)) {
                n_purchased += d.amount;
              }
            });

            res.json({
              status: true,
              message: "avaible count",
              result: {
                amount: total - n_purchased,
              },
            });
          } else {
            res.json({
              status: true,
              message: "unlimted",
              result: {
                limited: false,
              },
            });
          }
        } else {
          res.json({
            status: false,
            message: "something went wrong",
          });
        }
      } else {
        if (item[`${label}b_limited`]) {
          // complex
          let total = item[`${label}n_sell`];
          // var n_norder
          let n_purchased = 0;
          (await transactionModel.find({ item_id, edition })).map((d) => {
            n_purchased += d.amount;
          });
          res.json({
            status: true,
            message: "avaible count",
            result: {
              amount: total - n_purchased,
            },
          });
        } else {
          res.json({
            status: true,
            message: "retrived successfully",
            result: {
              limited: false,
            },
          });
        }
      }
      // stock  = total - n_order(sold count by order) - n_offer(sold count by offer) - n_bid(sold count by bid)
    } else {
      res.json({
        status: false,
        message: "Item not found",
      });
    }
  } catch (error) {
    console.log(error);
    res.json({
      status: false,
      message: "Something went wrong",
    });
  }
};

exports.addOffers = async function (req, res) {
  console.log(getErrLine().str, "apistart");
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    res.json({
      status: false,
      message: "Request failed",
      errors: errors.array(),
    });
    return;
  }
  if (req.body.type == "order") {
    try {
      var offer = new offers();
      offer.sender = req.decoded.user_id;
      offer.receiver = req.body.seller_id;
      offer.type = req.body.type;
      offer.items = req.body.items;
      offer.from = req.body.from;
      offer.paied = true;
      //!!20240107am2 coderC To save shipping price, added the below code. "(B) Fix Shipping Section on New Marketplace Item"
      offer.shipping_price = Number(req.body.shippingPrice);
      handleOrderItems(req.decoded.user_id, req.body.seller_id, req.body.items, req.body.from);
      offer.orderId = "e" + String(global.nOrderId).padStart(6, "0");
      global.nOrderId++;
      offer.addr_fullname = req.body.addr_fullname;
      offer.addr_street = req.body.addr_street;
      offer.addr_city = req.body.addr_city;
      offer.addr_state = req.body.addr_state;
      offer.addr_zipcode = req.body.addr_zipcode;
      offer.addr_country = req.body.addr_country;

      let notif_users = [];

      // NEW_NOTIFICATION DECIDE SELLER NOTIFICATION SETTING IS ENABLED
      let user = await users.findOne({
        _id: req.body.seller_id,
        "notif_selling.is_buy_now_sales": true,
      });
      console.log("&_^user", user);
      if (user) {
        let count = 0;
        let price = 0;
        req.body.items?.map((d) => {
          count += d.amount;
          price += d.amount * d.price;
        });
        let new_notification = new notificationModel({
          type: NOTIFICATION_TYPES.SELL_BUYNOW,
          filter: null,
          from_id: req.decoded.user_id,
          to_id: req.body.seller_id,
          items: req.body.items,
          message: `Bought ${count} item${count > 1 ? "s" : ""} for $${Number(
            price || 0
          ).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`,
        });
        await new_notification.save();
        notif_users.push(req.body.seller_id);
      }

      await offer.save();
      res.json({
        status: true,
        message: "offer added successfully",
        data: offer,
        result: {
          notif_users,
        },
      });
    } catch (error) {
      console.log(error);
      res.json({
        status: false,
        message: error.message,
      });
    }
    return;
  } else {
    // items
    //   .findOne({ _id: req.body.item_id, status: "active" })
    //   .populate("collection_id")
    //   .exec(function (err, item) {
    //     if (err || !item) {
    //       res.json({
    //         status: false,
    //         message: "Item not found",
    //         errors: err,
    //       });
    //       return;
    //     }
    //     userController.getUserInfoByID(
    //       req.decoded.user_id,
    //       function (err, sender) {
    //         item.has_offer = true;
    //         item.save(function (err, itemObj) {
    //           offers
    //             .findOne({
    //               sender: req.decoded.user_id,
    //               item_id: req.body.item_id,
    //             })
    //             .exec(function (err, offerObj) {
    //               if (!offerObj) {
    //                 var offer = new offers();
    //                 offer.sender = req.decoded.user_id;
    //                 offer.item_id = req.body.item_id;
    //                 offer.receiver = item.current_owner;
    //                 offer.price = req.body.price;
    //                 offer.edition = req.body.edition ? req.body.edition : "";
    //                 offer.type = req.body.type ? req.body.type : "offer";
    //                 offer.offers.push({
    //                   created_date: Date.now(),
    //                   amount: req.body.amount ? req.body.amount : 1,
    //                   price: req.body.price,
    //                   sender: "Buyer", // or 'Seller'
    //                   status: "Pending",
    //                 });
    //                 offer.status = "Pending";
    //                 offer.save(function (err, offerOb) {
    //                   var history = new histories();
    //                   history.item_id = item._id;
    //                   history.collection_id = item.collection_id._id;
    //                   history.from_id = req.decoded.user_id;
    //                   history.to_id = item.current_owner;
    //                   history.transaction_hash = "";
    //                   history.history_type = "bids";
    //                   history.price = req.body.price;
    //                   history.save(function (err, historyObj) {
    //                     res.json({
    //                       status: true,
    //                       message: "offer added successfully",
    //                       data: offerOb,
    //                     });
    //                   });
    //                 });
    //               } else {
    //                 res.json({
    //                   status: false,
    //                   message: "offer added already",
    //                 });
    //               }
    //             });
    //         });
    //       }
    //     );
    //   });
  }
};

/*
 * This is the function which used to update offer
 */
exports.actionOffers = function (req, res) {
  console.log(getErrLine().str, "apistart");
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    res.json({
      status: false,
      message: "Request failed..",
      errors: errors.array(),
    });
    return;
  }

  if (req.body.type == "addTrackId") {
    offers.findOne({ _id: req.body.offer_id }, function (err, offer) {
      if (err || !offer) {
        res.json({
          status: false,
          message: "Offer not found",
          errors: err,
        });
        return;
      }
      offer.status = "Shipped";
      offer.trackId = req.body.trackId;
      offer.ship_date = req.body.ship_date;
      offer.ship_carrier = req.body.ship_carrier;
      offer.save(function (err, offerOb) {
        res.json({
          status: true,
          error: err,
          offer: offerOb,
          message: "TrackingID added successfully",
        });
      });
    });
    return;
  }

  items
    .findOne({
      _id: req.body.item_id,
      /*current_owner: req.body.user_id,*/ status: "active",
    })
    .populate("collection_id")
    .exec(function (err, item) {
      if (err || !item) {
        res.json({
          status: false,
          message: "Item not found",
          errors: err,
        });
        return;
      }
      offers.findOne({ _id: req.body.offer_id }, function (err, offer) {
        if (err || !offer) {
          res.json({
            status: false,
            message: "Offer not found",
            errors: err,
          });
          return;
        }
        if (req.body.type == "offer_reply") {
          offer.offers.push({
            created_date: Date.now(),
            amount: req.body.amount ? req.body.amount : 1,
            price: req.body.price,
            sender: req.body.sender, // 'Buyer',// or 'Seller'
            status: req.body.status, // Accept, Decline, Counter
          });
          offer.save(function (err, offerOb) {
            res.json({
              status: true,
              error: err,
              offer: offerOb,
              message: req.body.sender + " replied:" + req.body.status,
            });
          });
        } else if (req.body.type == "cancel") {
          offers.deleteOne({ _id: req.body.offer_id }, function (err) {
            offers.count(
              { item_id: req.body.item_id },
              function (err, OfferItemCount) {
                if (OfferItemCount > 0) {
                  res.json({
                    status: true,
                    message: "Offer cancelled successfully",
                  });
                } else {
                  item.has_offer = false;
                  item.save(function (err, result) {
                    res.json({
                      status: true,
                      message: "Offer cancelled successfully",
                    });
                  });
                }
              }
            );
          });
        } else if (req.body.type == "updatebid") {
          offer.price = req.body.price;
          offer.created_date = Date.now();
          offer.save(function (err, offerOb) {
            res.json({
              status: true,
              error: err,
              offer: offerOb,
              message: "Bid updated successfully",
            });
          });
        } else {
          offer.status = "Accepted";
          offer.save(function (err, offerOb) {
            res.json({
              status: true,
              message: "Offer accepted successfully",
            });
          });
        }
      });
    });
};

/*
 * This is the function which used to remove offer
 */
exports.removeOffers = function (req, res) {
  console.log(getErrLine().str, "apistart");
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    res.json({
      status: false,
      message: "Request failed",
      errors: errors.array(),
    });
    return;
  }
  offers
    .findOne({ sender: req.decoded.user_id, _id: req.body.offer_id })
    .exec(function (err, offerObj) {
      if (err || !offerObj) {
        res.json({
          status: false,
          message: "Offer not found",
          errors: err,
        });
        return;
      }
      offers.deleteOne({ _id: req.body.offer_id }, function (err) {
        offers.count(
          { item_id: req.body.item_id },
          function (err, OfferItemCount) {
            if (OfferItemCount > 0) {
              res.json({
                status: true,
                message: "Item deleted successfully",
              });
            } else {
              items
                .findOne({ _id: req.body.item_id, status: "active" })
                .exec(function (err, item) {
                  item.has_offer = false;
                  item.save(function (err, result) {
                    res.json({
                      status: true,
                      message: "Item deleted successfully",
                    });
                  });
                });
            }
          }
        );
      });
    });
};

/*
 * This is the function which used to list item offer and profile offer
 */
exports.listOffers = function (req, res) {
  console.log(getErrLine().str, "apistart");
  var page = req.query.page ? req.query.page : "1";
  var limit = req.query.limit ? req.query.limit : "100";
  var keyword = req.query.keyword || "";
  var show = req.query.show || "all";
  var sort = req.query.sort || "new";
  var query;
  var is_admin = false;
  if (req.decoded.user_id != null && req.query.user) {
    if (req.decoded.role == 1 && req.query.user == "admin") {
      is_admin = true;
    }
  }
  if (is_admin) {
    query = offers.find();
  } else {
    if (req.query.type == "item") {
      query = offers.find({ item_id: req.query.item_id });
    } else if (req.query.type == "Accepted") {
      query = offers.find({ sender: req.query.user_id, status: "Accepted" });
    } else if (req.query.type == "buy_offers") {
      if (req.decoded.user_id) {
        query = offers.find({ sender: req.decoded.user_id, type: "offer" });
      } else {
        query = offers.find({ sender: req.query.user_id, type: "offer" });
      }
    } else if (req.query.type == "sell_offers") {
      if (req.decoded.user_id) {
        query = offers.find({ receiver: req.decoded.user_id, type: "offer" });
      } else {
        query = offers.find({ receiver: req.query.user_id, type: "offer" });
      }
    } else if (req.query.type == "buy_bids") {
      if (req.decoded.user_id) {
        query = offers.find({ sender: req.decoded.user_id, type: "bid" });
      } else {
        query = offers.find({ sender: req.query.user_id, type: "bid" });
      }
    } else if (req.query.type == "buy_orders") {
      if (req.decoded.user_id) {
        query = offers.find({ sender: req.decoded.user_id, type: "order" });
      } else {
        query = offers.find({ sender: req.query.user_id, type: "order" });
      }
    } else if (req.query.type == "sell_orders") {
      if (req.decoded.user_id) {
        query = offers.find({ receiver: req.decoded.user_id, type: "order" });
      } else {
        query = offers.find({ receiver: req.query.user_id, type: "order" });
      }
    } else {
      query = offers.find({ receiver: req.query.user_id });
    }
  }

  query = query.sort("-created_date");
  switch (show) {
    case "all":
      break;
    default:
      query = query.find({ items: { $elemMatch: { status: show } } });
      break;
  }

  if (sort == 'old') {
    query = query.sort("created_date");
  }


  var offset = page == "1" ? 0 : parseInt(page - 1) * 10;
  query = query.populate({
    path: "sender",
    model: users,
    select: "_id username first_name last_name profile_image",
  });
  query = query.populate({
    path: "receiver",
    model: users,
    select: "_id username first_name last_name profile_image",
  });
  //!!20240118pm4 coderC To get item object id, updated the below code. "(B)buying > items > orders - links to items aren’t working"
  /* !!20240112pm4 coderd added below code {(B) selling  > items - sold - missing image} */ 
  // !!20240122pm4 coderd "(B)buying > items > orders - links to items aren’t working"
  if(req.query.type == "buy_orders" || "sell_orders"){
    query = query.populate({
      path: "items",
      populate:{
        path:"item_id",
        model:items
      },
    });
  }
  query = query.populate({
    path: "item_id",
    model: items,
    populate: [
      {
        path: "category_id",
        model: "category",
        select: "title level",
      },
      {
        path: "catlevel2_id",
        model: "category",
        select: "title level",
      },
      {
        path: "catlevel3_id",
        model: "category",
        select: "title level",
      },
    ],
  });
  var options = {
    page: page,
    offset: offset,
    limit: limit,
  };
  offers.paginate(query, options).then(function (result) {
    res.json({
      status: true,
      message: "offers retrieved successfully",
      data: result,
    });
  });
};

/*
 * This is the function which used to check balance of the user
 */
exports.checkUserBalance = function (req, res) {
  console.log(getErrLine().str, "apistart");
  userController.getUserInfoByID(req.decoded.user_id, function (err, user) {
    web3.eth.getBalance(user.public_key).then((balance) => {
      res.json({
        status: true,
        message: "balance details successfull",
        return_id: balance / 1000000000000000000,
      });
    });
  });
};

/*
 * This is the function which used to check balance of the user
 */
exports.sendETH = function (req, res) {
  console.log(getErrLine().str, "apistart");
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    res.json({
      status: false,
      message: "Request failed",
      errors: errors.array(),
    });
    return;
  }
  userController.getUserInfoByID(req.decoded.user_id, function (err, user) {
    web3.eth.getBalance(user.public_key).then((balance) => {
      var eth = balance / 1000000000000000000;
      if (eth > req.body.amount) {
        var command =
          "sh send.sh " +
          user.private_key +
          " " +
          req.body.eth_address +
          " " +
          req.body.amount;
        if (config.rpcurl == "Indiefire") {
          command =
            "sh send_indy.sh " +
            user.private_key +
            " " +
            req.body.eth_address +
            " " +
            req.body.amount;
        }
        if (config.rpcurl == "Rinkeby") {
          command =
            "sh send_rinkeby.sh " +
            user.private_key +
            " " +
            req.body.eth_address +
            " " +
            req.body.amount;
        }
        if (config.rpcurl == "Goerli") {
          command =
            "sh send_goerli.sh " +
            user.private_key +
            " " +
            req.body.eth_address +
            " " +
            req.body.amount;
        }
        cp.exec(command, function (err, stdout, stderr) {
          if (err) {
            res.json({
              status: false,
              message: "Trasnfer Error",
              errors: err,
            });
          } else {
            res.json({
              status: true,
              message: "Ethereum transferred successfully",
            });
          }
        });
      } else {
        res.json({
          status: false,
          message: "Not enough balance in your ethereum address",
          return_id: balance,
        });
      }
    });
  });
};

/**
 *  This is the function which used to report item
 */
exports.report = function (req, res) {
  console.log(getErrLine().str, "apistart");
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    res.json({
      status: false,
      message: "Request failed",
      errors: errors.array(),
    });
    return;
  }
  var query = items.findOne({ _id: req.body.item_id });
  query.exec(function (err, item) {
    if (err || !item) {
      res.json({
        status: false,
        message: "item not found",
        errors: err,
      });
      return;
    }
    userController.getUserInfoByID(
      req.decoded.user_id,
      function (err, receiver) {
        var mailUser = receiver.first_name + " " + receiver.last_name;
        var mailTitle = "Report Notification";
        var mailContent =
          mailUser +
          " reported Item. Item ID : " +
          item._id +
          "\n\n" +
          req.body.message;
        mailer.mail(
          {
            username: mailUser,
            content: mailContent,
          },
          config.site_email,
          mailTitle,
          receiver.mail,
          function (error, result) {
            if (error) {
            }
            res.json({
              status: false,
              message: "Report sent successfully",
              errors: err,
            });
          }
        );
      }
    );
  });
};

/**
 * This is the function which used to get balance for ethereum address
 */
checkbalance = function (eth_address, item, callback) {
  console.log(getErrLine().str, "apistart");
  web3.eth.getBalance(eth_address).then((balance) => {
    var eth = balance / 1000000000000000000;
    if (eth < item.price + 0.2) {
      callback(false);
    } else {
      callback(true);
    }
  });
};

/**
 * This is the function which used to get admin comission before transaction
 */

transferAdminComission = function (item, callback) {
  console.log(getErrLine().str, "apistart");
  options.findOne({ name: "admin_commission" }, function (err, option) {
    if (err || !option) {
      callback("error", 0);
      return;
    }
    var commission = item.price * (option.value / 100);
    userController.getUserInfoByID(item.current_owner, function (err, sender) {
      users.findOne({ role: 1 }).exec(function (err, receiver) {
        if (sender._id == receiver._id) {
          callback("error", 0);
          return;
        }
        var history = new histories();
        history.item_id = item._id;
        history.collection_id = item.collection_id._id;
        history.from_id = item.current_owner;
        history.to_id = receiver._id;
        history.transaction_hash = "";
        history.history_type = "admin_comission";
        history.price = commission;
        history.save(function (err, historyObj) {
          callback(null, commission);
        });
      });
    });
  });
};

/**
 * This is the function which used to transfer erc721 token
 */
transferBalance = function (sender, receiver, item, commission, callback) {
  console.log(getErrLine().str, "apistart");
  var sender_id = sender._id.toString();
  var receiver_id = receiver._id.toString();
  var author_id = item.author_id.toString();

  if (author_id == receiver_id) {
    callback(true);
  } else if (author_id == sender_id) {
    callback(true);
  } else {
    var royalty = item.price * (item.collection_id.royalties / 100);
    var history = new histories();
    history.item_id = item._id;
    history.collection_id = item.collection_id._id;
    history.from_id = sender._id;
    history.to_id = item.author_id;
    history.transaction_hash = "";
    history.history_type = "comission";
    history.price = royalty;
    history.save(function (err, historyObj) {
      callback(true);
    });
  }
};

exports.generateHash = function (req, res) {
  console.log(getErrLine().str, "apistart");
  var symbol = req.body.name.replace(" ", "_");
  var symbolsol = symbol + ".sol";
  var command =
    "sh generate.sh " + symbol + ' "' + req.body.name + '" ' + symbolsol;
  cp.exec(command, function (err, stdout, stderr) {
    if (err) {
      res.json({
        status: false,
        message: err.toString().split("ERROR: ").pop().replace(/\n|\r/g, ""),
      });
      return;
    }
    fs.readFile(
      "/usr/work/nft/cryptotrade/backend/" + symbol + ".bin",
      "utf8",
      (err, data) => {
        if (err) {
          res.json({
            status: false,
            message: err
              .toString()
              .split("ERROR: ")
              .pop()
              .replace(/\n|\r/g, ""),
          });
          console.error(err);
          return;
        }
        res.json({
          status: true,
          message: "generate abi successful",
          result: data,
        });
      }
    );
  });
};

exports.getABI = function (req, res) {
  console.log(getErrLine().str, "apistart");
  var symbol = req.query.name.replace(" ", "_");
  fs.readFile(
    "/usr/work/nft/cryptotrade/backend/" + symbol + ".bin",
    "utf8",
    (err, data) => {
      if (err) {
        res.json({
          status: false,
          message: err.toString().split("ERROR: ").pop().replace(/\n|\r/g, ""),
        });
        console.error(err);
        return;
      }
      res.json({
        status: true,
        message: "abi information successful",
        result: data,
      });
    }
  );
};

exports.view = function (req, res) {
  console.log(getErrLine().str, "apistart");
  res.json({
    description:
      "Friendly OpenSea Creature that enjoys long swims in the ocean.",
    external_url: "https://openseacreatures.io/3",
    image:
      "https://storage.googleapis.com/opensea-prod.appspot.com/puffs/3.png",
    name: "Dave Starbelly",
  });
  return;
};

async function trendingItems(req, res) {
  console.log(getErrLine().str, "apistart");
  try {
    var user_id = req.decoded.user_id;

    // get param
    var type = req.query.type,
      part = req.query.part,
      rootCat = req.query.rootCat,
      _filter = req.query.filter,
      cat1 = req.query.cat1,
      cat2 = req.query.cat2,
      cat3 = req.query.cat3,
      cat4 = req.query.cat4,
      keyword = req.query.keyword || "",
      page = req.query.page || 1,
      limit = req.query.limit || 15,
      itemKind = req.query.itemKind,
      itemType = req.query.itemType,
      filterShow = req.query.filterShow,
      filterFrom = req.query.filterFrom,
      filterTime = req.query.filterTime,
      filterTimeFrom = req.query.filterTimeFrom,
      filterTimeTo = req.query.filterTimeTo,
      tfilterFrom = req.query.tfilterFrom,
      tfilterTime = req.query.tfilterTime,
      tfilterTimeFrom = req.query.tfilterTimeFrom,
      tfilterTimeTo = req.query.tfilterTimeTo,
      TrendingOrderBy = req.query.TrendingOrderBy;
    var pipeline = [];
   
   
    // pipeline.push({
    //   $sort: { create_date: -1 },
    // });
    if (type == "Marketplace") {
      cat1 = cat2;
      cat2 = cat3;
      cat3 = null;
    }

    let matchClause = {}; // for search

    let andQuery = [];

    let blocked_accounts = [
      ...(await blockModel.find({ user_id }))?.map(d => d.block_user_id),
      ...(await blockModel.find({ block_user_id: user_id }))?.map(d => d.user_id),
    ];
    // block_accounts = [...blocked_accounts, ...(await blockModel.find({ block_user_id: user_id })?.map(d => d.user_id))];


    andQuery.push({
      author_id: { $nin: blocked_accounts }
    });

    if (_filter == "For you") {
      let followings = (await followers.find({ user_id })).map(
        (d) => d.star_id
      );
      console.log(followings);
      andQuery.push({
        author_id: { $in: followings },
      });
    }

    if (keyword != "") {
      // search by keyword
      if (cat4 == "Podcasters" || cat4 == "Artists" || cat4 == "Comedians") {
        // search by Podcasters/Artists/Comedians
        let _author_ids = (await users.find({
          $or: [
            { username: { $regex: new RegExp(keyword, "ig") } },
            { first_name: { $regex: new RegExp(keyword, "ig") } },
            { last_name: { $regex: new RegExp(keyword, "ig") } },
          ],
        }))?.map(d => d._id);
        andQuery.push({
          author_id: {
            $in: _author_ids,
          }
        })
        console.log("Search by user");
      } else {
        console.log("Search by keyword");
        andQuery.push({
          $or: [
            { name: { $regex: new RegExp(keyword, "ig") } },
            { description: { $regex: new RegExp(keyword, "ig") } },
          ]
        })
      }
    }

    andQuery.push({
      "$expr": {
        $eq: ["$author_id", "$current_owner"],
      }
    })
    //

    if (cat1 || cat2 || cat3 || cat4) {
      if (cat1) {
        andQuery.push({
          category_id: ObjectID(cat1)
        })
        // matchClause.category_id = ObjectID(cat1);
      }
      if (cat2) {
        andQuery.push({
          catlevel2_id: ObjectID(cat2)
        })
        // matchClause.catlevel2_id = ObjectID(cat2);
      }
      if (cat3) {
        andQuery.push({
          catlevel3_id: ObjectID(cat3)
        })
        // matchClause.catlevel3_id = ObjectID(cat3);
      }
      if (cat4 && cat4 != "" && cat4 != "Everything" && cat4 != "Podcasters" && cat4 != "Artists" && cat4 != "Comedians") {
        let format = cat4.slice(0, -1);
        if (format == "Gig") {
          format = "Comedy gig"
        }
        andQuery.push({
          $or: [{ format: format }, { format: null }],
        })
      }
    }

    switch (tfilterFrom) {
      case "Everybody":
        // Do nothing, get all posts
        break;
      case "following":
        let _followings = (await followers.find({ user_id })).map((d) =>
          ObjectID(d.star_id)
        );
        // pipeline.push({ $match: { author_id: { $in: _followings } } });
        andQuery.push({
          author_id: { $in: _followings }
        })
        break;
      default:
        break;
    }
    if (type == "Marketplace") {
      cat1 = cat2;
      cat2 = cat3;
      cat3 = null;
      if (!cat1) {
        let merchandiseCat = await category.find({
          level: 1,
          type: "Merchandise",
        });
        let mIds = merchandiseCat.map((d) => d._id);
        console.log(mIds);
        andQuery.push({
          category_id: { $in: mIds }
        })
      }
      let typeQuery;
      switch (itemType) {
        case "Buy now":
          typeQuery = {
            $or: [
              {
                $and: [{ es_is_auction: false }, { es_enabled: true }],
              },
              {
                $and: [{ ec_is_auction: false }, { ec_enabled: true }],
              },
              {
                $and: [{ el_is_auction: false }, { el_enabled: true }],
              },
            ],
          };
          break;
        case "Auctions":
          typeQuery = {
            $or: [
              {
                $and: [{ es_is_auction: true }, { es_enabled: true }],
              },
              {
                $and: [{ ec_is_auction: true }, { ec_enabled: true }],
              },
              {
                $and: [{ el_is_auction: true }, { el_enabled: true }],
              },
            ],
          };
          break;
        default:
          typeQuery = {};
          break;
      }
      andQuery.push(typeQuery)
    } else {
      let kindQuery;
      let typeQuery;
      switch (itemKind) {
        case "Free":
          kindQuery = { f_sell: false };
          break;
        case "For Sale":
          kindQuery = { f_sell: true };
          break;
        case "Rent":
          kindQuery = {
            $or: [{ es_enabled: true }, { ec_rent_price: { $ne: "" } }],
          };
          break;
        default:
          kindQuery = {};
          break;
      }
      if (itemKind != "Free" && itemKind != "Rent") {
        switch (itemType) {
          case "Buy now":
            typeQuery = {
              $or: [
                {
                  $and: [{ es_is_auction: false }, { es_enabled: true }],
                },
                {
                  $and: [{ ec_is_auction: false }, { ec_enabled: true }],
                },
                {
                  $and: [{ el_is_auction: false }, { el_enabled: true }],
                },
              ],
            };
            break;
          case "Auctions":
            typeQuery = {
              $or: [
                {
                  $and: [{ es_is_auction: true }, { es_enabled: true }],
                },
                {
                  $and: [{ ec_is_auction: true }, { ec_enabled: true }],
                },
                {
                  $and: [{ el_is_auction: true }, { el_enabled: true }],
                },
              ],
            };
            break;
          default:
            typeQuery = {};
            break;
        }
      } else {
        typeQuery = {};
      }
      andQuery.push(kindQuery)
      andQuery.push(typeQuery)
    }
// 20240115pm7 CoderB "(A)fix discover and trending filters in all sections"
    // if (part == 'main') {
      if (part) {
      let play_lists = (await item_plays.find({ user_id })).map(
        (d) => d.item_id
      );

      switch (filterShow) {
        case "Everything":
          break;
        case "seen":
          andQuery.push({
            _id: { $in: play_lists }
          })
          break;
        case "notseen":
          andQuery.push({
            _id: { $nin: play_lists }
          })
          break;
        default:
          break;
      }
      let user = await users.findById(user_id);
      switch (filterFrom) {
        case "Everybody":
          break;
        case "following":
          let _followings = (await followers.find({ user_id })).map(
            (d) => d.star_id
          );
          andQuery.push({
            author_id: { $in: _followings }
          })
          break;
        default:
          break;
      }

      switch (filterTime) {
        case "anytime":
          break;
        case "today":
          var date = new Date();
          var startOfToday = new Date(
            date.getFullYear(),
            date.getMonth(),
            date.getDate()
          );
          var endOfToday = new Date(
            startOfToday.getTime() + 24 * 60 * 60 * 1000 - 1
          ); // End of day is one millisecond before start of next day
          andQuery.push({
            create_date: {
              $gte: startOfToday, $lt: endOfToday
            }
          })
          break;
        case "thisweek":
          andQuery.push({
            create_date: {
              $gte: new Date(new Date() - 7 * 24 * 60 * 60 * 1000),
            }
          })
          break;
        case "thismonth":
          var date = new Date();
          var monthStart = new Date(date.getFullYear(), date.getMonth(), 1); // Get first day of current month
          var monthEnd = new Date(date.getFullYear(), date.getMonth() + 1, 0); // Get last day of current month
          andQuery.push({
            create_date: { $gte: monthStart, $lte: monthEnd },
          })
          break;
        case "range":
          var startDate = new Date(filterTimeFrom);
          var endDate = new Date(filterTimeTo);
          andQuery.push({
            create_date: { $gte: startDate, $lte: endDate }
          })
          break;
        default:
          break;
      }

    }



    console.log("andQuery");
    console.log(andQuery);

    pipeline.push({
      $match: {
        $and: andQuery
      },
    });



    var filter = "trending";

    if (TrendingOrderBy == "Popular") {
      filter = "trending";
    } else if (TrendingOrderBy == "Sales") {
      filter = "sale";
    } else {
      filter = "play";
    }

    switch (tfilterTime) {
      case "now":
        var date = new Date();
        var datestr = getDateStr(date);
        pipeline.push(
          {
            $addFields: {
              _nowFields: {
                $filter: {
                  input: `$daily_${filter}`,
                  as: "trend",
                  cond: {
                    //!!20240112am2 coderd {(A)fix discover and trending filters}
                    $lte: ["$$trend.date", datestr],
                    // $eq: ["$$trend.date", datestr],
                  },
                },
              },
            },
          },
          {
            $addFields: {
              nowSum: {
                $sum: {
                  $filter: {
                    input: "$_nowFields.count",
                    as:"item",
                    cond: {
                      $ne:["$$item",null]
                    },
                  },
                },
              },
            },
          },
          // {
          //   $sort: { nowSum: -1 },
          // }
        );
        break;
      case "yesterday":
        var date = new Date();
        date.setDate(date.getDate() - 1);
        var datestr = getDateStr(date);
        pipeline.push(
          {
            $addFields: {
              _yesterdayFields: {
                $filter: {
                  input: `$daily_${filter}`,
                  as: "trend",
                  cond: {
                    /* !!20240112am2 coderd {(A)fix discover and trending filters} */ 
                    $gte: ["$$trend.date", datestr],
                    // $eq: ["$$trend.date", datestr],
                  },
                },
              },
            },
          },
          {
            $addFields: {
              yesterdaySum: {
               
                $sum: {
                  $filter: {
                    input: "$_yesterdayFields.count",
                    as:"item",
                    cond: {
                      $ne:["$$item",null]
                    },
                  },
                },
              },
            },
          },
          // {
          //   $sort: { yesterdaySum: -1 },
          // }
        );
        break;
      case "thisweek":
        var date = new Date();
        var weekAgo = new Date(new Date(new Date() - 7 * 24 * 60 * 60 * 1000));
        var datestr = getDateStr(weekAgo);
        console.log(datestr);
        pipeline.push(
          {
            $addFields: {
              _thisweekFields: {
                $filter: {
                  input: `$daily_${filter}`,
                  as: "trend",
                  cond: {
                    $gte: ["$$trend.date", datestr],
                  },
                },
              },
            },
          },
          {
            $addFields: {
              weeklySum: {
                $sum: {
                  $filter: {
                    input: "$_thisweekFields.count",
                    as:"item",
                    cond: {
                      $ne:["$$item",null]
                    },
                  },
                },
              },
            },
          },
          // {
          //   $sort: { weeklySum: -1 },
          // }
        );
        break;
      case "thismonth":
        var date = new Date();
        var monthAgo = new Date(
          date.getFullYear(),
          date.getMonth() - 1,
          date.getDate()
        ); // Get date 1 month ago
        var datestr = getDateStr(monthAgo);
        pipeline.push(
          {
            $addFields: {
              _thismonthFields: {
                $filter: {
                  input: `$daily_${filter}`,
                  as: "trend",
                  cond: {
                    $gte: ["$$trend.date", datestr],
                  },
                },
              },
            },
          },
          {
            $addFields: {
              monthlySum: {
                $sum: {
                  $filter: {
                    input: "$_thismonthFields.count",
                    as:"item",
                    cond: {
                      $ne:["$$item",null]
                    },
                  },
                },
              },
            },
          },
          // {
          //   $sort: { monthlySum: -1 },
          // }
        );
        break;
      case "range":
        var startDate = new Date(tfilterTimeFrom);
        var endDate = new Date(tfilterTimeTo);
        // !!20240112am2 coderd {(A)fix discover and trending filters}
        var datestr1 = getDateStr(startDate);
        var datestr2 = getDateStr(endDate);

        pipeline.push(
          {
            $addFields: {
              _rangeFields: {
                $filter: {
                  input: `$daily_${filter}`,
                  as: "trend",
                  cond: {
                    $gte: ["$$trend.date", datestr1],
                    $lte: ["$$trend.date", datestr2],
                  },
                },
              },
            },
          },
          {
            $addFields: {
              rangeSum: {
                // 20240112pm2 CoderB
                $sum: {
                  $filter: {
                    input: "$_rangeFields.count",
                    as:"item",
                    cond: {
                      $ne:["$$item",null]
                    },
                  },
                },
              },
            },
          },
          // {
          //   $sort: { rangeSum: -1 },
          // }
        );
        break;
      default:
        break;
    }
 // 20240111pm8 CoderB "(B) discover - test “trending” and “for you” - I don’t think it’s working correctly"
 if(TrendingOrderBy =="Streams"){
  pipeline.push({
    $sort: {n_play:-1},
  });
}else if(TrendingOrderBy =="Sales"){
  pipeline.push({
    $sort: {n_sale:-1},
  });
}else{
  if(_filter == "Trending"&&tfilterTime=="now"){
    console.log('Trending')
    pipeline.push({
      $sort: {nowSum:-1,n_love:-1,n_like:-1,n_play:-1},
    });
  }else if(_filter == "Trending"&&tfilterTime=="yesterday"){
    console.log('Trending')
    pipeline.push({
      $sort: {yesterdaySum:-1,n_love:-1,n_like:-1,n_play:-1},
    });
  }else if(_filter == "Trending"&&tfilterTime=="thisweek"){
    console.log('Trending')
    pipeline.push({
      $sort: {weeklySum:-1,n_love:-1,n_like:-1,n_play:-1},
    });
  }else if(_filter == "Trending"&&tfilterTime=="thismonth"){
    console.log('Trending')
    pipeline.push({
      $sort: {monthlySum:-1,n_love:-1,n_like:-1,n_play:-1},
    });
  }else if(_filter == "Trending"&&tfilterTime=="range"){
    console.log('Trending')
    pipeline.push({
      $sort: {rangeSum:-1,n_love:-1,n_like:-1,n_play:-1},
    });
  }else{
    // pipeline.push({
    //   $sort: { create_date: -1 },
    // });
  }
}
    var offset = page == "1" ? 0 : parseInt(page - 1) * limit;
    const countPipeline = [...pipeline, { $count: "count" }];
    pipeline.push(
      {
        $skip: offset,
      },
      {
        $limit: Number(limit),
      }
    );
    console.log(pipeline);
    const [docs, countResult] = await Promise.all([
      items.aggregate(pipeline).exec(),
      items.aggregate(countPipeline).exec(),
    ]);
    const totalDocs = countResult[0] ? countResult[0].count : 0;
    const currentPage = parseInt(req.query.page) || 1;
    const _limit = parseInt(req.query.limit) || 10;
    const totalPages = Math.ceil(totalDocs / limit);
    const hasNextPage = currentPage < totalPages;
    const nextPage = hasNextPage ? currentPage + 1 : null;

    let reactions = await item_reactions.find();
    let playLists = await item_plays.find();
    let comments = await item_comments.find({ parent_id: null });
    let likes = await item_likes.find();
    let loves = await item_loves.find();
    let boosts = await fanpostShareModel.find({ type: 'item', user_id: req.decoded?.user_id });

    const updatedDocs = await Promise.all(
      docs.map(async (d) => {
        let current_owner = await users.findById(d.current_owner, {
          first_name: 1,
          last_name: 1,
          username: 1,
          is_idverified: 1,
          profile_image: 1,
        });
        let author_id = await users.findById(d.author_id, {
          first_name: 1,
          last_name: 1,
          username: 1,
          is_idverified: 1,
          profile_image: 1,
        });
        let collection_id = await collections.findById(d.collection_id).populate({
          path: 'author_id',
          model: 'users',
          select: '_id first_name last_name username profile_image is_idverified'
        });
        let category = await categoryModel.findById(d.category_id);
        const itemReactions = reactions.filter(
          (r) => r.item_id == d._id.toString() && r.user_id == user_id
        );
        const reactionNumber = itemReactions.length
          ? itemReactions[0].reaction_number
          : -1;

        var season;
        if (d.season_id) {
          season = await seasons.findById(d.season_id);
        }
        var date = new Date();
        // get restructure item to decide the buy now and auction is finished or not
        if (d.es_enabled) {
          if (!d.es_is_auction) {
            if (d.es_enventories?.length > 0) {
            } else {
              if (d.es_b_limited && d.es_n_sell == 0) {
                d.es_enabled = false;
              }
              if (d.es_b_endMode == "noend") {
                // console.log("itemController::trendingItems().Trending")
              } else {
                if (new Date(d.es_b_endDate).getTime() < date.getTime()) {
                  d.es_enabled = false;
                }
              }
            }
          } else {
            // check auction is finished or not
            if (new Date(d.es_a_endDate).getTime() < date.getTime()) {
              d.es_enabled = false;
            }
            // if not
            if (d.es_enabled) {
              // get the current bid
              let c_bid = await offers
                .findOne({
                  type: "bid",
                  item_id: d._id,
                  edition: "standard",
                })
                .sort({ price: -1 })
                .limit(1)
                .exec();
              var currentbid = c_bid?.price;
              if (currentbid) {
                d.es_a_starting_price = currentbid;
              }
            }
          }
        }

        if (d.ec_enabled) {
          if (!d.ec_is_auction) {
            if (d.ec_enventories?.length > 0) {
            } else {
              if (d.ec_b_limited && d.ec_n_sell == 0) {
                d.ec_enabled = false;
              }
              if (d.ec_b_endMode == "noend") {
              } else {
                if (new Date(d.ec_b_endDate).getTime() < date.getTime()) {
                  d.ec_enabled = false;
                }
              }
            }
          } else {
            // check auction is finished or not
            if (new Date(d.ec_a_endDate).getTime() < date.getTime()) {
              d.ec_enabled = false;
            }
            // if not
            if (d.ec_enabled) {
              // get the current bid
              let c_bid = await offers
                .findOne({
                  type: "bid",
                  item_id: d._id,
                  edition: "collective",
                })
                .sort({ price: -1 })
                .limit(1)
                .exec();
              var currentbid = c_bid?.price;
              if (currentbid) {
                d.ec_a_starting_price = currentbid;
              }
            }
          }
        }

        if (d.el_enabled) {
          if (!d.el_is_auction) {
            if (d.el_enventories?.length > 0) {
            } else {
              if (
                (d.el_b_limited && d.el_n_sell == 0) ||
                d.el_n_now_sell == 0
              ) {
                d.el_enabled = false;
              }
              if (d.el_endMode == "noend") {
              } else {
                if (new Date(d.el_b_endDate).getTime() < date.getTime()) {
                  d.el_enabled = false;
                }
              }
            }
          } else {
            // check auction is finished or not
            if (new Date(d.el_a_endDate).getTime() < date.getTime()) {
              d.el_enabled = false;
            }
            // if not
            if (d.el_enabled) {
              // get the current bid
              let c_bid = await offers
                .findOne({
                  type: "bid",
                  item_id: d._id,
                  edition: "limited",
                })
                .sort({ price: -1 })
                .limit(1)
                .exec();
              var currentbid = c_bid?.price;
              if (currentbid) {
                d.el_a_starting_price = currentbid;
              }
            }
          }
        }

        let artist = await artistModel.findById(d?._doc?.artist || d?.artist)

        return {
          ...d,
          current_owner: current_owner,
          author_id: author_id,
          category_id: category,
          reaction_number: reactionNumber,
          season_id: season,
          collection_id,
          artist,
          isPlayed: playLists.some(
            (pl) => pl.item_id == d._id.toString() && pl.user_id == user_id
          ),
          isCommented: comments.some(
            (pl) => pl.item_id == d._id.toString() && pl.user_id == user_id
          ),
          isLiked: likes.some(
            (pl) => pl.item_id == d._id.toString() && pl.user_id == user_id
          ),
          isLoved: loves.some(
            (pl) => pl.item_id == d._id.toString() && pl.user_id == user_id
          ),
          isBoosted: boosts.some(
            (pl) => pl.item_id == d._id.toString() && pl.user_id == user_id
          ),
        };
      })
    );

    res.json({
      status: true,
      message: "items retrieved successfully",
      data: {
        docs: updatedDocs,
        totalDocs,
        limit: _limit,
        totalPages,
        currentPage,
        hasNextPage,
        nextPage,
      },
    });
  } catch (e) {
    console.log(e);
    res.json({
      status: false,
      message: e?.message,
    });
  }
}

exports.items = async function (req, res) {
  console.log(getErrLine().str, "apistart");
  if (
    req.query.rootCat == "Trending" ||
    req.query.filter == "For you" ||
    req.query.filter == "Trending"
  ) {
    trendingItems(req, res);
  } else {
    try {
      var user_id = req.decoded.user_id;

      // get param
      var type = req.query.type,
        rootCat = req.query.rootCat,
        cat1 = req.query.cat1,
        cat2 = req.query.cat2,
        cat3 = req.query.cat3,
        cat4 = req.query.cat4,
        collection_id = req.query.collection_id,
        keyword = req.query.keyword || "",
        page = req.query.page || 1,
        limit = req.query.limit || 15,

        edition = req.query.edition,
        sortKey = req.query.sortKey,
        rel_date = req.query.rel_date,
        rel_date_from = req.query.rel_date_from,
        rel_date_to = req.query.rel_date_to;

      fFavorites = req.query.fFavorites,
        filterShow = req.query.filterShow,
        filterFrom = req.query.filterFrom,
        filterTime = req.query.filterTime,
        filterTimeFrom = req.query.filterTimeFrom,
        filterTimeTo = req.query.filterTimeTo,
        itemKind = req.query.itemKind,
        itemType = req.query.itemType,
        tfilterFrom = req.query.tfilterFrom,
        tfilterTime = req.query.tfilterTime,
        tfilterTimeFrom = req.query.tfilterTimeFrom,
        tfilterTimeTo = req.query.tfilterTimeTo,
        TrendingOrderBy = req.query.TrendingOrderBy;

      // new parameter will be added
      var query = items.find();

      var andQuery = [];

      if (collection_id) {
        andQuery.push({ collection_id })
      }

      // get blocked accounts
      var blocked_accounts = [
        ...(await blockModel.find({ user_id }))?.map(d => d.block_user_id),
        ...(await blockModel.find({ block_user_id: user_id }))?.map(d => d.user_id)
      ];
      andQuery.push({ author_id: { $nin: blocked_accounts } });

      query = query.sort({ create_date: -1 });
      if (type == "Marketplace") {
        cat1 = cat2;
        cat2 = cat3;
        cat3 = null;
        if (!cat1) {
          let merchandiseCat = await category.find({
            level: 1,
            type: "Merchandise",
          });
          let mIds = merchandiseCat.map((d) => d._id);
          andQuery.push({ category_id: { $in: mIds } });
        }
        switch (itemType) {
          case "Buy now":
            andQuery.push({
              $or: [
                {
                  $and: [{ es_is_auction: false }, { es_enabled: true }],
                },
                {
                  $and: [{ ec_is_auction: false }, { ec_enabled: true }],
                },
                {
                  $and: [{ el_is_auction: false }, { el_enabled: true }],
                },
              ],
            });
            break;
          case "Auctions":
            console.log("auction");
            andQuery.push({
              $or: [
                {
                  $and: [{ es_is_auction: true }, { es_enabled: true }],
                },
                {
                  $and: [{ ec_is_auction: true }, { ec_enabled: true }],
                },
                {
                  $and: [{ el_is_auction: true }, { el_enabled: true }],
                },
              ],
            });
            break;
          default:
            break;
        }
      } else {
        switch (itemKind) {
          case "Free":
            andQuery.push({ f_sell: false });
            break;
          case "For Sale":
            andQuery.push({ f_sell: true });
            break;
          case "Rent":
            andQuery.push({
              $or: [{ es_enabled: true }, { es_rent_price: { $ne: null } }],
            });
            break;
          default:
            break;
        }
        if (itemKind != "Free" && itemKind != "Rent") {
          switch (itemType) {
            case "Buy now":
              andQuery.push({
                $or: [
                  {
                    $and: [{ es_is_auction: false }, { es_enabled: true }],
                  },
                  {
                    $and: [{ ec_is_auction: false }, { ec_enabled: true }],
                  },
                  {
                    $and: [{ el_is_auction: false }, { el_enabled: true }],
                  },
                ],
              });
              break;
            case "Auctions":
              /* 20231230pm1 CoderX  */
              const cur_date = Date.now();
              let cond1 = {
                $or: [
                  {
                    $and: [
                      { es_enabled: true },
                      {
                        $or: [
                          { $and: [{ es_is_auction: true }, { cur_date: { $lt: es_a_endDate } }] },
                          { es_is_auction: { $ne: true } }
                        ]
                      }
                    ]
                  },
                  {
                    $and: [
                      { ec_enabled: true },
                      {
                        $or: [
                          { $and: [{ ec_is_auction: true }, { cur_date: { $lt: ec_a_endDate } }] },
                          { ec_is_auction: { $ne: true } }
                        ]
                      }
                    ]
                  },
                  {
                    $and: [
                      { el_enabled: true },
                      {
                        $or: [
                          { $and: [{ el_is_auction: true }, { cur_date: { $lt: el_a_endDate } }] },
                          { el_is_auction: { $ne: true } }
                        ]
                      }
                    ]
                  }
                ]
              };
              let cond2 = { author_id: req.decoded.user_id };
              let cond3 = { current_owner: req.decoded.user_id };
              let cond4 = { bidUsers: { $in: [myuser_id] } };


              andQuery.push({
                $or: [
                  { cond1 },
                  { cond2 },
                  { cond3 },
                  { cond4 }
                ]
              });
              break;
            default:
              break;
          }
        }

        switch (edition) {
          case "standard":
            andQuery.push({ es_enabled: true });
            break;
          case "collective":
            andQuery.push({ ec_enabled: true });
            break;
          case "limited":
            andQuery.push({ el_enabled: true });
            break;
          default:
            break;
        }
        // sort
        switch (sortKey) {
          case "new":
            query = query.sort("-created_date");
            break;
          case "old":
            query = query.sort("created_date");
            break;
          case "newrel":
            query = query.sort("-released_date");
            break;
          case "az":
            query = query.sort("-name");
            break;
          case "za":
            query = query.sort("name");
            break;
          default:
            break;
        }

        if (rel_date_from && rel_date_to) {
          var startDate = new Date(rel_date_from);
          var endDate = new Date(rel_date_to);
          andQuery.push({
            publish_date: { $gte: startDate, $lte: endDate },
          });
        } else if (rel_date) {
          var date = new Date(rel_date);
          var startOfToday = new Date(
            date.getFullYear(),
            date.getMonth(),
            date.getDate()
          );
          var endOfToday = new Date(
            startOfToday.getTime() + 24 * 60 * 60 * 1000 - 1
          ); // End of day is one millisecond before start of next day
          andQuery.push({
            publish_date: { $gte: startOfToday, $lt: endOfToday },
          });
        }

      }

      if (cat1) andQuery.push({ category_id: cat1 });
      if (cat2) andQuery.push({ catlevel2_id: cat2 });
      if (cat3) andQuery.push({ catlevel3_id: cat3 });

      // only parent item
      andQuery.push({
        $expr: { $eq: ["$author_id", "$current_owner"] },
      });

      // check this this is from favorites
      console.log(fFavorites);
      if (fFavorites) {
        // get arrays of item_id who made love this items
        let itemIds = (await item_loves.find({ user_id })).map(
          (d) => d.item_id
        );
        console.log(itemIds);
        andQuery.push({ _id: { $in: itemIds } });
      }

      if (cat4 && cat4 != "" && cat4 != "Everything" && cat4 != "Podcasters" && cat4 != "Artists" && cat4 != "Comedians") {
        // Clips & Trailers
        let type = cat4.slice(0, -1);
        if (type == "Gig") {
          type = "Comedy gig";
        }
        andQuery.push({
          $or: [{ format: type }, { format: null }],
        });
      }

      if (keyword != "") {
        if ((cat4 == "Podcasters" || cat4 == "Artists" || cat4 == "Comedians")) {
          // search by Podcasters/Artists/Comedians
          console.log("Called users")
          let _author_ids = (await users.find({
            $or: [
              { username: { $regex: new RegExp(keyword, "ig") } },
              { first_name: { $regex: new RegExp(keyword, "ig") } },
              { last_name: { $regex: new RegExp(keyword, "ig") } },
            ],
          }))?.map(d => d._id);
          andQuery.push({ author_id: { $in: _author_ids } })
        } else {
          console.log("Called here")
          andQuery.push({
            $or: [
              { name: { $regex: new RegExp(keyword, "ig") } },
              { description: { $regex: new RegExp(keyword, "ig") } },
            ],
          })
        }
      }


      query = query
        .populate({ path: "collection_id", model: collections })
        .populate({ path: "category_id", model: category })
        .populate({ path: "catlevel2_id", model: category })
        .populate({ path: "catlevel3_id", model: category })
        .populate({ path: "artist", model: artistModel })
        .populate({
          path: "author_id",
          model: users,
          select:
            "_id username first_name last_name profile_image metamask_info is_idverified",
        })
        .populate({
          path: "current_owner",
          model: users,
          select:
            "_id username first_name last_name profile_image metamask_info is_idverified",
        })
        .populate({ path: "season_id", model: "seasons" });



      let play_lists = (await item_plays.find({ user_id })).map(
        (d) => d.item_id
      );

      // set for digital

      switch (filterShow) {
        case "Everything":
          break;
        case "seen":
          andQuery.push({ _id: { $in: play_lists } });
          break;
        case "notseen":
          andQuery.push({ _id: { $nin: play_lists } });
          break;
        default:
          break;
      }
      let user = await users.findById(user_id);
      switch (filterFrom) {
        case "Everybody":
          break;
        case "following":
          let _followings = (await followers.find({ user_id })).map(
            (d) => d.star_id
          );
          andQuery.push({ author_id: { $in: _followings } });
          break;
        case "muted":
          andQuery.push({
            author_id: { $in: user?.muted_block?.muted_accounts },
          });
          break;
        default:
          break;
      }

      switch (filterTime) {
        case "anytime":
          break;
        case "today":
          var date = new Date();
          var startOfToday = new Date(
            date.getFullYear(),
            date.getMonth(),
            date.getDate()
          );
          var endOfToday = new Date(
            startOfToday.getTime() + 24 * 60 * 60 * 1000 - 1
          ); // End of day is one millisecond before start of next day
          andQuery.push({
            create_date: { $gte: startOfToday, $lt: endOfToday },
          });
          break;
        case "thisweek":
          andQuery.push({
            create_date: {
              $gte: new Date(new Date() - 7 * 24 * 60 * 60 * 1000),
            },
          });
          break;
        case "thismonth":
          var date = new Date();
          var monthStart = new Date(date.getFullYear(), date.getMonth(), 1); // Get first day of current month
          var monthEnd = new Date(date.getFullYear(), date.getMonth() + 1, 0); // Get last day of current month
          andQuery.push({
            create_date: { $gte: monthStart, $lte: monthEnd },
          });
          break;
        case "range":
          andQuery.push({
            create_date: { $gte: startDate, $lte: endDate },
          });
          break;
        default:
          break;
      }

      let reactions = await item_reactions.find();
      let playLists = await item_plays.find();
      let comments = await item_comments.find({ parent_id: null });
      let likes = await item_likes.find();
      let loves = await item_loves.find();
      let boosts = await fanpostShareModel.find({ type: 'item', user_id });

      var offset = page == "1" ? 0 : parseInt(page - 1) * limit;
      var options = {
        page: page,
        offset: offset,
        limit: limit,
      };

      query.find({
        $and: andQuery
      });

      console.log("(await query.exec())?[0]")
      console.log((await query.exec())[0]);

      items.paginate(query, options).then(async function (result) {
        const updatedDocs = await Promise.all(
          result.docs.map(async (d) => {
            // console.log(playLists.some(pl => pl.item_id == d._doc._id && pl.user_id == user_id))
            const itemReactions = reactions.filter(
              (r) => r.item_id == d._doc._id.toString() && r.user_id == user_id
            );
            const reactionNumber = itemReactions.length
              ? itemReactions[0].reaction_number
              : -1;

            // check whether this is exited in up to next
            const up_to_next = await playerModel.findOne({
              item_id: d?._doc?._id?.toString(),
              user_id,
            });

            // check is follower, mute, block
            var _db_follower = await followers.findOne({
              star_id: d._doc?.author_id?._id,
              user_id: user_id,
            });
            var _db_block = await blockModel.findOne({
              block_user_id: d._doc?.author_id?._id,
              user_id: user_id,
            });
            var _db_mute = await muteModel.findOne({
              mute_user_id: d._doc?.author_id?._id,
              user_id: user_id,
            });

            var date = new Date();
            // get restructure item to decide the buy now and auction is finished or not
            if (d._doc.es_enabled) {
              if (!d._doc.es_is_auction) {
                if (d._doc.es_enventories?.length > 0) {
                } else {

                  if (d._doc.es_b_limited && d._doc.es_n_sell == 0) {
                    d._doc.es_enabled = false;
                  }
                  if (d._doc.es_b_endMode == "noend") {
                  } else {
                    if (
                      new Date(d._doc.es_b_endDate).getTime() < date.getTime()
                    ) {
                      d._doc.es_enabled = false;
                    }
                  }
                }
              } else {
                // check auction is finished or not
                if (new Date(d._doc.es_a_endDate).getTime() < date.getTime()) {
                  d._doc.es_enabled = false;
                }
                // if not
                if (d._doc.es_enabled) {
                  // get the current bid
                  let c_bid = await offers
                    .findOne({
                      type: "bid",
                      item_id: d._doc._id,
                      edition: "standard",
                    })
                    .sort({ price: -1 })
                    .limit(1)
                    .exec();
                  var currentbid = c_bid?.price;
                  if (currentbid) {
                    d._doc.es_a_starting_price = currentbid;
                  }
                }
              }
            }

            if (d._doc.ec_enabled) {
              if (!d._doc.ec_is_auction) {
                if (d._doc.ec_enventories?.length > 0) {
                } else {
                  if (d._doc.ec_b_limited && d._doc.ec_n_sell == 0) {
                    d._doc.ec_enabled = false;
                  }
                  if (d._doc.ec_b_endMode == "noend") {
                  } else {
                    if (
                      new Date(d._doc.ec_b_endDate).getTime() < date.getTime()
                    ) {
                      d._doc.ec_enabled = false;
                    }
                  }
                }
              } else {
                // check auction is finished or not
                if (new Date(d._doc.ec_a_endDate).getTime() < date.getTime()) {
                  d._doc.ec_enabled = false;
                }
                // if not
                if (d._doc.ec_enabled) {
                  // get the current bid
                  let c_bid = await offers
                    .findOne({
                      type: "bid",
                      item_id: d._doc._id,
                      edition: "collective",
                    })
                    .sort({ price: -1 })
                    .limit(1)
                    .exec();
                  var currentbid = c_bid?.price;
                  if (currentbid) {
                    d._doc.ec_a_starting_price = currentbid;
                  }
                }
              }
            }

            if (d._doc.el_enabled) {
              if (!d._doc.el_is_auction) {
                if (d._doc.el_enventories?.length > 0) {
                } else {
                  if (
                    (d._doc.el_b_limited && d._doc.el_n_sell == 0) ||
                    d._doc.el_n_now_sell == 0
                  ) {
                    d._doc.el_enabled = false;
                  }
                  if (d._doc.el_b_endMode == "noend") {
                  } else {
                    if (
                      new Date(d._doc.el_b_endDate).getTime() < date.getTime()
                    ) {
                      d._doc.el_enabled = false;
                    }
                  }
                }
              } else {
                // check auction is finished or not
                if (new Date(d._doc.el_a_endDate).getTime() < date.getTime()) {
                  d._doc.el_enabled = false;
                }
                // if not
                if (d._doc.el_enabled) {
                  // get the current bid
                  let c_bid = await offers
                    .findOne({
                      type: "bid",
                      item_id: d._doc._id,
                      edition: "limited",
                    })
                    .sort({ price: -1 })
                    .limit(1)
                    .exec();
                  var currentbid = c_bid?.price;
                  if (currentbid) {
                    d._doc.el_a_starting_price = currentbid;
                  }
                }
              }
            }


            return {
              ...d._doc, // copy all the existing fields
              reaction_number: reactionNumber,
              isPlayed: playLists.some(
                (pl) =>
                  pl.item_id == d._doc._id.toString() && pl.user_id == user_id
              ),
              isCommented: comments.some(
                (pl) =>
                  pl.item_id == d._doc._id.toString() && pl.user_id == user_id
              ),
              isLiked: likes.some(
                (pl) =>
                  pl.item_id == d._doc._id.toString() && pl.user_id == user_id
              ),
              isLoved: loves.some(
                (pl) =>
                  pl.item_id == d._doc._id.toString() && pl.user_id == user_id
              ),
              isBoosted: boosts.some(
                (pl) =>
                  pl.item_id == d._doc._id.toString() && pl.user_id == user_id
              ),
              isUptoNext: up_to_next ? true : false,
              isFollow: _db_follower ? true : false,
              isBlock: _db_block ? true : false,
              isMute: _db_mute ? true : false,
            };
          })
        );

        const updatedResult = { ...result, docs: updatedDocs };

        res.json({
          status: true,
          message: "items retrieved successfully",
          data: updatedResult,
        });
      });
    } catch (err) {
      console.log(err);
      res.json({
        status: false,
        message: err?.message,
        errors: err,
      });
    }
  }
};

exports.read_my_items = function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded.user_id;
  var keyword = req.query.keyword || "";
  var query;
  if (keyword != "") {
    query = {
      author_id: user_id,
    };
  } else {
    query = {
      $and: [
        { author_id: user_id },
        {
          $or: [
            { name: { $regex: new RegExp(keyword, "ig") } },
            { description: { $regex: new RegExp(keyword, "ig") } },
          ],
        },
      ],
    };
  }
  items.find(query, function (err, result) {
    if (err) {
      res.json({
        status: false,
        message: "Db error",
      });
    } else {
      res.json({
        status: true,
        message: "retrived successfully",
        result: result,
      });
    }
  });
};

async function handleAutomaticBid(param) {
  console.log(param);
  var lists = await bids
    .find({
      item_id: param.item_id,
      edition: param.edition,
      bid_step: param.bid_step,
      max_bid: { $gt: param.price },
    })
    .sort({ max_bid: -1 });
  if (lists.length > 0) {
    console.log(param.sender);
    console.log(lists[0].user_id);
    if (param.sender.toString() == lists[0].user_id.toString()) return true;
    console.log(2);
    console.log(param);

    var item = await items.findById(param.item_id);
    var step = 0;
    switch (param.edition) {
      case "standard":
        step = item.es_a_default_bid_price;
        break;
      case "collective":
        step = item.ec_a_default_bid_price;
        break;
      case "limited":
        step = item.el_a_default_bid_price;
        break;
      default:
        return true;
    }

    if (lists.length == 1) {
      var price =
        Number(param.price) + Number(step) >= Number(lists[0].max_bid)
          ? Number(lists[0].max_bid)
          : Number(param.price) + Number(step);
    } else {
      var price =
        Number(lists[1].max_bid) + Number(step) >= Number(lists[0].max_bid)
          ? Number(lists[0].max_bid)
          : Number(lists[1].max_bid) + Number(step);
    }

    var newBid = new offers({
      type: "bid",
      item_id: param.item_id,
      edition: param.edition,
      sender: lists[0].user_id,
      recever: param.receiver,
      bid_step: param.bid_step,
      price: price,
    });
    await new Promise((resolve, reject) => {
      newBid.save(function (err) {
        if (err) {
          reject(err);
        } else {
          resolve();
        }
      });
    });
  } else {
    return true;
  }
}

// handle item
async function handleItem(
  sender,
  receiver,
  item_id,
  edition,
  option,
  amount,
  price,
  type = "order"
) {
  console.log("this is called");
  console.log(sender, receiver, item_id, edition, option, amount, price, type);
  try {
    var item = await items
      .findById(item_id)
      .populate({ path: "collection_id", model: collections })
      .populate({ path: "category_id", model: category })
      .populate({ path: "catlevel2_id", model: category })
      .populate({ path: "catlevel3_id", model: category })
      .populate({
        path: "current_owner",
        model: users,
        select:
          "_id username first_name last_name profile_image metamask_info is_idverified",
      })
      .populate({
        path: "author_id",
        model: users,
        select:
          "_id username first_name last_name profile_image metamask_info is_idverified",
      });
    if (!item) return;
    var original_id = item.original_id || item._id;
    // check that you have this item
    var trans = new transactionModel({
      seller: receiver,
      buyer: sender,
      item_id: item_id,
      edition,
      option,
      amount,
      price,
      type,
    });

    try {
      await trans.save();
    } catch (error) {
      console.log(error);
    }

    var existed_item = await items.findOne({
      original_id,
      current_owner: sender,
    });
    var label;
    switch (edition) {
      case "standard":
        label = "es_";
        break;
      case "collective":
        label = "ec_";
        break;
      case "limited":
        label = "el_";
        break;
      default:
        return;
    }
    if (existed_item) {
      existed_item[`${label}enabled`] = true;
      if (existed_item[`${label}is_auction`]) {
        existed_item[`${label}n_sell`] =
          (existed_item[`${label}n_sell`] || 0) + amount;
        item[`${label}a_n_sold`] = (item[`${label}a_n_sold`] || 0) + amount;
      } else {
        if (option) {
          let invIndex = existed_item[`${label}inventories`].findIndex(
            (d) => JSON.stringify(d.option) == JSON.stringify(option)
          );
          if (invIndex >= 0) {
            existed_item[`${label}inventories`][invIndex].count =
              (existed_item[`${label}inventories`][invIndex].count || 0) +
              amount;
          } else {
            var inventory = item[`${label}inventories`].find(
              (d) => JSON.stringify(d.option) == JSON.stringify(option)
            );
            if (inventory) {
              var newInv = {
                ...inv._docentory.toObject(),
                ...{ count: amount },
              };
              existed_item[`${label}inventories`].push(newInv);
            } else {
              return;
            }
          }
        } else {
          console.log(existed_item[`${label}n_sell`]);
          existed_item[`${label}n_sell`] =
            (existed_item[`${label}n_sell`] || 0) + amount;
        }
      }
      await existed_item.save();
    } else {
      var new_item = new items();
      new_item.original_id = item.original_id || item._id;
      new_item.name = item.name;
      new_item.description = item.description;
      new_item.blockchain = item.blockchain;
      new_item.blockchain = config.blockchain;
      new_item.royalties = item.royalties;
      new_item.lyrics = item.lyrics;
      new_item.media = item.media;
      new_item.thumb = item.thumb;
      new_item.external_link = item.external_link;
      new_item.unlock_content_url = item.unlock_content_url;
      new_item.attributes = item.attributes;
      new_item.levels = item.levels;
      new_item.stats = item.stats;
      new_item.category_id = item.category_id;
      new_item.catlevel2_id = item.catlevel2_id;
      new_item.catlevel3_id = item.catlevel3_id;
      new_item.released_date = item.released_date;

      new_item.season_id = item.season_id;
      new_item.episode = item.episode;
      new_item.current_owner = sender;
      new_item.author_id = item.author_id;
      new_item.format = item.format;
      new_item.status = item.status;
      new_item.minted_date = item.minted_date;

      new_item.lyrics = item.lyrics;
      new_item.f_sell = item.f_sell;
      new_item.clips = item.clips;
      new_item.trailers = item.trailers;
      new_item.author_name = item.author_name;
      new_item.publish_date = item.publish_date;
      new_item.f_movie_watch_free = item.f_movie_watch_free;

      new_item[`${label}enabled`] = true;
      new_item[`${label}description`] = item[`${label}description`];
      new_item[`${label}rent_price`] = item[`${label}rent_price`];
      new_item[`${label}thumb`] = item[`${label}thumb`];
      new_item[`${label}audio`] = item[`${label}audio`];
      new_item[`${label}video`] = item[`${label}video`];
      new_item[`${label}pre_video`] = item[`${label}pre_video`];
      new_item[`${label}clips`] = item[`${label}clips`];
      new_item[`${label}trailers`] = item[`${label}trailers`];
      new_item[`${label}extras`] = item[`${label}extras`];
      new_item[`${label}options`] = item[`${label}options`];
      new_item[`${label}is_auction`] = new_item[`${label}is_auction`];
      if (new_item[`${label}is_auction`]) {
        new_item[`${label}n_sell`] = 1;
        new_item[`${label}a_starting_price`] = item[`${label}a_starting_price`];
        new_item[`${label}a_default_bid_price`] =
          item[`${label}a_default_bid_price`];
        new_item[`${label}a_reserve_price`] = item[`${label}a_reserve_price`];
      } else {
        if (option) {
          var inventory = item[`${label}inventories`].find(
            (d) => JSON.stringify(d.option) == JSON.stringify(option)
          );
          if (inventory) {
            console.log("===inventory");
            console.log(inventory);
            var newInv = {
              option: inventory.option,
              limit: inventory.limited,
              f_accept_offer: inventory.f_accept_offer,
              image: inventory.image,
              count: amount,
              price: price,
            };
            console.log("Inventory");
            console.log(newInv);
            new_item[`${label}inventories`] = [newInv];
            console.log(new_item[`${label}inventories`]);
          } else {
            return;
            // var newInv = { ...inv._docentory.toObject(), ...{ count: amount } };
            // item[`${label}inventories`].push(newInv);
          }
        } else {
          new_item[`${label}b_limited`] = item[`${label}b_limited`];
          new_item[`${label}b_f_accept_offer`] =
            item[`${label}b_f_accept_offer`];
          new_item[`${label}n_sell`] = amount;
          new_item[`${label}b_price`] = item[`${label}b_price`];
        }
      }
      await new_item.save();
    }
    item.save();
  } catch (error) {
    console.log(error);
  }
}

// set auto bid
exports.setAutoBid = async function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded.user_id;
  var bid_id = req.body.bid_id;
  var item_id = req.body.item_id;
  var edition = req.body.edition;
  var receiver = req.body.receiver;
  // var option = req.body.option;
  var max_bid = req.body.max_bid;
  var receiver = req.body.receiver;

  var serverDate = new Date();
  try {
    let item = await items.findById(item_id);
    // get the highest bid for this item edition
    let bid = await offers
      .findOne({
        type: "bid",
        item_id: item_id,
        edition: edition,
      })
      .sort({ price: -1 })
      .limit(1)
      .exec();
    let label = "es";
    switch (edition) {
      case "standard":
        label = "es";
        break;
      case "collective":
        label = "ec";
        break;
      case "limited":
        label = "el";
        break;
      default:
        res.json({
          status: false,
          message: "Something went wrong",
        });
        return;
    }
    // easily

    if (item[`${label}_enabled`] && item[`${label}_is_auction`]) {
      if (
        serverDate.getTime() >
        new Date(item[`${label}_a_startDate`]).getTime() &&
        serverDate.getTime() < new Date(item[`${label}_a_endDate`]).getTime()
      ) {
        // get the highest bid for this item edition

        // if its price is larger than your max_bid
        if (bid && bid.price > max_bid) {
          res.json({
            status: false,
            message: "Current highest bid price is bigger than your max bid",
          });
        } else {
          // already created or not
          let b;
          if (!bid_id) {
            b = await bids.findOne({ item_id, edition, user_id });
          }
          if (b) {
            res.json({
              status: false,
              message: "Auto Bid setting already created",
            });
          } else {
            if (bid_id) {
              await bids.findOneAndUpdate({ _id: bid_id }, req.body);
            } else {
              let autoBid = new bids(req.body);
              autoBid.user_id = user_id;
              await autoBid.save();
            }
            // after creating create bid
            let price;
            if (bid) {
              if (bid.sender == user_id) {
                res.json({
                  status: true,
                  message: "Saved successfully",
                });
                return;
              }
              if (
                Number(bid.price) +
                Number(item[`${label}_a_default_bid_price`]) >
                max_bid
              ) {
                price = Number(max_bid);
              } else {
                price =
                  Number(bid.price) +
                  Number(item[`${label}_a_default_bid_price`]);
              }
            } else {
              if (Number(item[`${label}_a_starting_price`]) > max_bid) {
                price = max_bid;
              } else {
                price = Number(item[`${label}_a_starting_price`]);
              }
            }
            let newBid = new offers({
              type: "bid",
              item_id: item_id,
              edition: edition,
              sender: user_id,
              price: price,
              receiver: receiver,
            });
            await newBid.save();
            await handleAutomaticBid(newBid);
            res.json({
              status: true,
              message: "Saved successfully",
            });
          }
        }
      } else {
        res.json({
          status: false,
          message: "bid might not start yet or finish already",
        });
      }
    } else {
      res.json({
        status: false,
        message: "error occurred",
      });
    }
  } catch (error) {
    console.log(error);
    res.json({
      status: false,
      message: "Error is occured",
    });
  }
};

exports.getBid = async function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded.user_id || req.query.user_id;
  var type = req.query.type; // to decide the buyer or seller
  var showOnly = req.query.showOnly || "all";
  var sortBy = req.query.sortBy || "new";
  var matchClause = {
    type: "bid",
  };
  if (type == "buy_bids") {
    matchClause.sender = ObjectID(user_id);
  } else {
    matchClause.receiver = ObjectID(user_id);
  }
  matchClause.is_winner_bid = { $ne: true };

  let sort = {};
  switch (sortBy) {
    case "new":
      sort = { created_date: -1 };
      break;
    case "old":
      sort = { created_date: 1 };
      break;
    default:
      sort = { created_date: -1 };
      break;
  }

  let pipe = [
    {
      $match: matchClause,
    },
    {
      // $sort: { price: -1 },
      $sort: { ...sort, ...{ price: -1 } },
    },
    {
      $group: {
        _id: {
          item_id: "$item_id",
          edition: "$edition",
          bid_step: "$bid_step"
        },
        data: {
          $push: {
            type: "$type",
            item_id: "$item_id",
            edition: "$edition",
            sender: "$sender",
            receiver: "$receiver",
            price: "$price",
            paid: "$paid",
            bid_step: "$bid_step",
            created_date: "$created_date",
          },
        },
      },
    },
    {
      $project: {
        maxData: {
          $arrayElemAt: ["$data", 0],
        },
      },
    },
    {
      $replaceRoot: { newRoot: "$maxData" },
    },
  ];
  try {
    let _bids = await offers.aggregate(pipe).exec();
    let updateBids = await Promise.all(
      _bids.map(async (d) => {
        let c_bid = await offers
          .findOne({
            type: d.type,
            item_id: d.item_id,
            edition: d.edition,
          })
          .sort({ price: -1 })
          .limit(1)
          .exec();
        var currentbid = c_bid;
        let c_item = await items
          .findById(d.item_id)
          .populate({ path: "category_id", model: category })
          .populate({ path: "catlevel2_id", model: category })
          .populate({ path: "catlevel3)id", model: category });

        if (c_item) {
          var label;
          switch (d.edition) {
            case "standard":
              label = "es";
              break;
            case "collective":
              label = "ec";
              break;
            case "limited":
              label = "el";
              break;
            default:
              res.json({
                status: false,
                message: "Something went wroing",
              });
              return;
          }
        } else {
          return null;
        }
        var bid = await offers.findOne({
          item_id: d.item_id,
          edition: d.edition,
          sender: user_id,
          created_date: {
            $gt: c_item[`${label}_a_startDate`],
            $lt: c_item[`${label}_a_endDate`],
          },
          bid_step: d.bid_step
        }).sort({ price: -1 });
        var maxbid = bid?.price;

        var endtime = c_item[`${label}_a_endDate`];
        var serverDate = new Date();
        var closed =
          new Date(c_item[`${label}_a_endDate`]).getTime() <
            new Date().getTime()
            ? true
            : false;

        // get winner = bid
        var winner_bid_query = {
          item_id: c_item._id,
          edition: d.edition,
          type: "bid",
          created_date: {
            $gt: c_item[`${label}_a_startDate`],
            $lt: c_item[`${label}_a_endDate`],
          },
          bid_step: d.bid_step
        };
        if (
          c_item[`${label}_a_reserve_price`] &&
          c_item[`${label}_a_reserve_price`] > 0
        ) {
          winner_bid_query.price = {
            $gt: c_item[`${label}_a_reserve_price`],
          };
        }

        var winner_bid = await offers
          .findOne(winner_bid_query)
          .sort({ price: -1 })
          .limit(1);


        return {
          ...d,
          closed,
          higher_bid: c_bid.sender == user_id ? true : false,
          has_winner: winner_bid ? true : false,
          currentbid: winner_bid ? winner_bid : currentbid,
          // currentbid: winner_bid ? { ...winner_bid._doc, user_id: winner_bid?.sender } : { ...currentbid._doc, user_id: currentbid?.sender },
          ...{ item: c_item },
          endtime,
          maxbid,
          serverDate,
        };
      })
    );
    updateBids = updateBids.filter((d) => d != null);
    switch (showOnly) {
      case "open":
        updateBids = updateBids.filter((d) => d.closed == false);
        break;
      case "closed":
        updateBids = updateBids.filter((d) => d.closed == true);
        break;
      default:
        break;
    }
    if (sortBy == 'new') {
      updateBids = updateBids.sort((a, b) => b.currentbid.created_date - a.currentbid.created_date)
    } else {
      updateBids = updateBids.sort((a, b) => a.currentbid.created_date - b.currentbid.created_date)
    }
    res.json({
      status: true,
      message: "retrived successfully",
      result: updateBids,
    });
  } catch (e) {
    console.log(e);
    res.json({
      status: false,
      message: "Something went wrong",
    });
  }
};

// set auto bid and bid
exports.setBid = async function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded.user_id;
  var item_id = req.body.item_id;
  var edition = req.body.edition;
  var receiver = req.body.receiver;
  var type = req.body.type;
  var serverDate = new Date();

  try {
    let item = await items.findById(item_id);
    if (item) {

      let label;
      switch (edition) {
        case "standard":
          label = "es";
          break;
        case "collective":
          label = "ec";
          break;
        case "limited":
          label = "el";
          break;
        default:
          res.json({
            status: false,
            message: "Something went wrong",
          });
          return;
      }

      let bid_step = item[`${label}_bid_step`]

      let bid = await offers
        .findOne({
          type: "bid",
          item_id,
          edition,
          bid_step
        })
        .sort({ price: -1 })
        .limit(1)
        .exec();

      if (item[`${label}_enabled`] && item[`${label}_is_auction`]) {
        if (
          serverDate.getTime() >
          new Date(item[`${label}_a_startDate`]).getTime() &&
          serverDate.getTime() < new Date(item[`${label}_a_endDate`]).getTime()
        ) {
          // get the highest bid for this item edition
          let newBid = new offers({
            type: "bid",
            item_id,
            edition,
            sender: user_id,
            receiver: receiver,
            bid_step
          });
          if (type == "autobid") {
            let autobid = await bids.find({
              item_id,
              edition,
              user_id,
              bid_step
            });
            if (autobid) {
              if (bid) {
                if (
                  Number(bid.price) +
                  Number(item[`${label}_a_default_bid_price`]) >
                  Number(autobid.max_bid)
                ) {
                  res.json({
                    status: false,
                    message: "max bid limitation",
                  });
                  return;
                }
              } else {
                if (
                  Number(item[`${label}_a_starting_price`]) +
                  Number(item[`${label}_a_default_bid_price`]) >
                  Number(autobid.max_bid)
                ) {
                  res.json({
                    status: false,
                    message: "max bid limitation",
                  });
                  return;
                }
              }
            } else {
              res.json({
                status: false,
                message: "Something went wrong",
              });
              return;
            }
          }
          console.log("this is called");
          if (bid) {
            console.log("add bid" + "this is called");
            newBid.price =
              Number(bid.price) + Number(item[`${label}_a_default_bid_price`]);
          } else {
            console.log(item[`${label}_a_starting_price`]);
            console.log(item[`${label}_a_default_bid_price`]);
            newBid.price = Number(item[`${label}_a_starting_price`]);
          }
          await newBid.save();
          await handleAutomaticBid(newBid); // handle for automatic bid

          //!!20231229am03 coderB To handle bidders data 
          await items.updateOne({ _id: item_id }, { $push: { bidder: user_id } })
          res.json({
            status: true,
            message: "Saved successfully",
          });
        } else {
          res.json({
            status: false,
            message: "bid might not start yet or finish already",
          });
        }
      } else {
        res.json({
          status: false,
          message: "error in standard",
        });
      }
    } else {
      res.json({
        status: false,
        message: "item not found",
      });
    }
  } catch (error) {
    console.log(error);
    res.json({
      status: false,
      message: "Error was occured",
    });
  }
};

// make offer
exports.setOffer = async function (req, res) {
  
  console.log(getErrLine().str, "apistart");
  console.log(req.body)
  var user_id = req.decoded.user_id;
  var offer_id = req.body.offer_id;
  var item_id = req.body.item_id;
  var edition = req.body.edition;
  var option = req.body.option;
  var receiver = req.body.receiver;
  var amount = req.body.amount;
  var price = req.body.price;

  var serverDate = new Date();

  try {
    let item = await items.findById(item_id);
    if (item) {
      let label;
      switch (edition) {
        case "standard":
          label = "es";
          break;
        case "collective":
          label = "ec";
          break;
        case "limited":
          label = "el";
          break;
        default:
          res.json({
            status: false,
            message: "Something went wrong",
          });
          return;
      }
      if (item[`${label}_enabled`]) {
        if (!item[`${label}_is_auction`]) {
          if (
            serverDate.getTime() >
            new Date(item[`${label}_b_startDate`]).getTime()
          ) {
            // skip next action to create offer
            // after validation needed here item sold is opened or closed
            if (option) {
              /* !!20240118am1 coderd changed below code {(B)make offer isn’t working} */ 
              let inventory = item[`${label}_inventories`].find((d) => {
              // let inventory = this.item[`$${label}_inventories`].find((d) => {
                return JSON.stringify(d.option) == JSON.stringify(option);
                // d.option.toString() == option.toString();
              });
              if (inventory) {
                if (inventory.f_accept_offer) {
                } else {
                  res.json({
                    status: false,
                    message: "This inventory is not enabled to accept offer",
                  });
                }
              } else {
                res.json({
                  status: false,
                  message: "Inventory not found",
                });
                return;
              }
            } else {
              if (item[`${label}_b_f_accept_offer`]) {
              } else {
                res.json({
                  status: false,
                  message: "This edition's accept offer is not enabled",
                });
                return;
              }
            }
          } else {
            res.json({
              status: false,
              message: "Sellign item is not opend yet",
            });
            return;
          }
        } else {
          if (
            serverDate.getTime() >
            new Date(item[`${label}_b_startDate`]).getTime() &&
            serverDate.getTime() <
            new Date(item[`${label}_a_endDate`]).getTime()
          ) {
            // skip next action to create offer
            // after validation needed here item sold is opened or closed
            if (item[`${label}_a_f_accept_offer`]) {
            } else {
              res.json({
                status: false,
                message: "This edition's accept offer is not enabled",
              });
              return;
            }
          } else {
            res.json({
              status: false,
              message: "Selling item is not opened yet or was closed already",
            });
            return;
          }
        }
      }

      if (offer_id) {
        let offer = await offers.findById(offer_id);
        let suboffer_id = req.body.suboffer_id;
        console.log(offer);
        console.log(suboffer_id);
        const parentIndex = offer.offers.findIndex((d) => d._id == suboffer_id);
        console.log(parentIndex);
        if (parentIndex < 0) {
          res.json({
            status: false,
            message: "Something went wrong. can't find offer",
          });
          return;
        }

        // CREATE NOTIFICATION
        let notif_users = [];
        switch (req.body.status) {
          case "Accepted":
            offer.offers[parentIndex].status = "Accepted";
            // handle accept action
            // get shipping address
            var _item = await items
              .findById(offer.item_id)
              .populate({ path: "category_id", model: category })
              .populate({ path: "catlevel2_id", model: category })
              .populate({ path: "catlevel3)id", model: category });
            if (_item) {
              var order = new offers({
                sender: offer.sender,
                receiver: offer.receiver,
                type: "order",
              });

              function getThumb() {
                var lvl;
                switch (offer.edition) {
                  case "standard":
                    lvl = "es_";
                    break;
                  case "collective":
                    lvl = "ec_";
                    break;
                  case "limited":
                    lvl = "el_";
                    break;
                  default:
                    return;
                }
                if (offer.option) {
                  return _item[`${label}enventories`].find(
                    (d) =>
                      JSON.stringify(d.option) == JSON.stringify(offer.option)
                  )?.image;
                } else {
                  return _item[`${label}thumb`];
                }
              }

              var order_item = {
                item_id: _item._id,
                name: _item.name,
                catlevel1: _item.category_id.title,
                catlevel2: _item.catlevel2_id.title,
                catlevel3: _item.catlevel3_id.title,
                price: Number(offer.offers[parentIndex]?.price),
                amount: offer.offers[parentIndex]?.amount,
                edition: offer.edition,
                option: offer.option,
                thumb: getThumb(),
                status: "Pending",
              };
              if (_item.category_id?.type == "Digital") {
                // might be added some action
                order_item.status == "Delivered";
                //
              } else {
                var shipping_addr = await shipaddrs
                  .findOne({ user_id: offer.sender })
                  .sort({ created_date: -1 })
                  .limit(1);
                if (shipping_addr) {
                  order.addr_fullname = shipping_addr.fullname;
                  order.addr_street = shipping_addr.street;
                  order.addr_city = shipping_addr.city;
                  order.addr_state = shipping_addr.state;
                  order.addr_zipcode = shipping_addr.zipcode;
                  order.addr_country = shipping_addr.country;
                }
              }
              // handleItem(
              //   order.sender,
              //   order.receiver,
              //   _item._id,
              //   offer.edition,
              //   offer.option,
              //   offer.offers[parentIndex]?.amount,
              //   Number(offer.offers[parentIndex]?.price),
              //   "offer"
              // );
              order.items = [order_item];
              await order.save();

              // ACCEPT OFFER NOTIFICATION
              if (user_id == offer.sender) {
                // SEND NOTIFICATION TO SELLER
                let _seller = await users.findOne({
                  _id: offer.receiver,
                  "notif_selling.is_offer_update": true,
                });
                if (_seller) {
                  let new_notification = new notificationModel({
                    type: NOTIFICATION_TYPES.SELL_OFFER,
                    from_id: user_id,
                    to_id: offer.receiver,
                    message: `Accepted your offer of $${Number(
                      offer.offers[parentIndex]?.price || 0
                    ).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`,
                    items: [
                      {
                        item_id: _item._id,
                        edition: offer.edition,
                        option: offer.option,
                        amount: offer.offers[parentIndex]?.amount,
                        price: Number(offer.offers[parentIndex]?.price),
                      },
                    ],
                  });
                  await new_notification.save();
                  notif_users.push(offer.receiver);
                }
              } else {
                // SEND NOTIFICATION TO BUYER
                let _buyer = await users.findOne({
                  _id: offer.sender,
                  "notif_buying.is_offer_update": true,
                });
                if (_buyer) {
                  let new_notification = new notificationModel({
                    type: NOTIFICATION_TYPES.BUYING_OFFER,
                    from_id: user_id,
                    to_id: offer.sender,
                    message: `Accepted your offer of $${Number(
                      offer.offers[parentIndex]?.price || 0
                    ).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`,
                    items: [
                      {
                        item_id: _item._id,
                        edition: offer.edition,
                        option: offer.option,
                        amount: offer.offers[parentIndex]?.amount,
                        price: Number(offer.offers[parentIndex]?.price),
                      },
                    ],
                  });
                  await new_notification.save();
                  notif_users.push(offer.sender);
                }
              }
            } else {
              res.json({
                status: false,
                message: "Item not found",
              });
              return;
            }
            break;
          case "Declined":
            offer.offers[parentIndex].status = "Declined";
            if (user_id == offer.sender) {
              let _seller = await users.findOne({
                _id: offer.receiver,
                "notif_selling.is_offer_update": true,
              });
              if (_seller) {
                let new_notification = new notificationModel({
                  type: NOTIFICATION_TYPES.SELL_OFFER,
                  from_id: user_id,
                  to_id: offer.receiver,
                  message: `Declined your offer of $${Number(
                    offer.offers[parentIndex].price || 0
                  ).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`,
                  items: [
                    {
                      item_id: offer.item_id,
                      edition: offer.edition,
                      option: offer.option,
                      amount: offer.offers[parentIndex].amount,
                      price: Number(offer.offers[parentIndex].price),
                    },
                  ],
                });
                await new_notification.save();
                notif_users.push(offer.receiver);
              }
            } else {
              let _buyer = await users.findOne({
                _id: offer.sender,
                "notif_buying.is_offer_update": true,
              });
              if (_buyer) {
                let new_notification = new notificationModel({
                  type: NOTIFICATION_TYPES.BUYING_OFFER,
                  from_id: user_id,
                  to_id: offer.sender,
                  message: `Declined your offer of $${Number(
                    offer.offers[parentIndex].price
                  ).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`,
                  items: [
                    {
                      item_id: offer.item_id,
                      edition: offer.edition,
                      option: offer.option,
                      amount: offer.offers[parentIndex].amount,
                      price: Number(offer.offers[parentIndex].price),
                    },
                  ],
                });
                await new_notification.save();
                notif_users.push(offer.sender);
              }
            }
            break;
          case "Counter":
            offer.offers[parentIndex].status = "Counter";
            let newReply = {
              amount: amount,
              price: price,
              sender: req.body.sender,
              status: "Pending",
            };

            offer.offers.splice(parentIndex + 1, 0, newReply);
            if (user_id == offer.sender) {
              let _seller = await users.findOne({
                _id: offer.receiver,
                // "notif_selling.is_offer_update": true, !!20240120pm4 coderd commented this line
              });
              if (_seller) {
                let new_notification = new notificationModel({
                  type: NOTIFICATION_TYPES.SELL_OFFER,
                  from_id: user_id,
                  to_id: offer.receiver,
                  message: `Made you a counter offer of $${Number(
                    price
                  ).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`,
                  items: [
                    {
                      item_id: offer.item_id,
                      edition: offer.edition,
                      option: offer.option,
                      amount: amount,
                      price: price,
                    },
                  ],
                });
                await new_notification.save();
                notif_users.push(offer.receiver);
              }
            } else {
              let _buyer = await users.findOne({
                _id: offer.sender,
                // "notif_buying.is_offer_update": true, !!20240120pm4 coderd commented this line
              });
              if (_buyer) {
                let new_notification = new notificationModel({
                  type: NOTIFICATION_TYPES.BUYING_OFFER,
                  from_id: user_id,
                  to_id: offer.sender,//!!20240120pm4 coderd changed this line {(B)make offer}
                  message: `Made you a counter offer of $${Number(
                    price
                  ).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`,
                  items: [
                    {
                      item_id: offer.item_id,
                      edition: offer.edition,
                      option: offer.option,
                      amount: amount,
                      price: price,
                    },
                  ],
                });
                await new_notification.save();
                notif_users.push(offer.sender);
              }
            }

            break;
          default:
            res.json({
              status: false,
              message: "Something went wrong",
            });
            return;
        }
        await offer.save();

        // CREATE NOTIFICATION FOR OFFER UPDATE

        res.json({
          status: true,
          message: "Saved successfully",
          result: {
            notif_users,
          },
        });
      } else {
        let of = await offers.findOne({
          type: "offer",
          item_id,
          edition,
          option,
          sender: user_id,
          receiver,
        });

        // if(of) {
        //     res.json({
        //         status: false,
        //         message: "You have already sent the offer"
        //     })
        // } else {
        let newOffer = new offers({
          type: "offer",
          item_id,
          edition,
          option,
          sender: user_id,
          receiver,
          // create new offer
          offers: [
            {
              amount,
              price,
            },
          ],
        });

        await newOffer.save();
        
        // CREATE NOTIFICATION
        let notif_users = [];
        let user = await users.findOne({
          _id: receiver,
          "notif_selling.is_offer_update": true,
        });
        if (user) {
          let new_notification = new notificationModel({
            type:NOTIFICATION_TYPES.SELL_OFFER,
            filter: null,
            // !!20240120pm4 coderd {(B)Make offer}
            from_id: user_id,
            // from_id: sender,
            to_id: user._id,
            message: `Made you an offer of $${Number(price || 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`,
            items: [
              {
                item_id,
                edition,
                option,
                amount,
                price,
              },
            ],
          });
          await new_notification.save();
          notif_users.push(user._id);
        }

        res.json({
          status: true,
          message: "Saved successfully",
          result: {
            notif_users,
          },
        });
        // }
      }
    } else {
      res.json({
        status: false,
        message: "Item not found",
      });
    }
  } catch (error) {
    console.log(error);
    res.json({
      status: false,
      message: "Error was occured",
    });
  }
};
// set rent
exports.setRent = async function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded.user_id,
    item_id = req.body.item_id,
    edition = req.body.edition;
  // ge the server date to decide the rent is expired or not
  var serverDate = new Date();
  try {
    let rentItem = await rents
      .findOne({ item_id, edition, sender: user_id })
      .sort({ created_date: -1 })
      .limit(1);
    var newRent = new rents(req.body);
    newRent.sender = user_id;
    if (rentItem) {
      var r_d = new Date(rentItem.created_date);
      // check rent is expired or not
      var distance = serverDate.getTime() - r_d.getTime();
      if (distance > 3 * 1000 * 60 * 60 * 24) {
        // pass for next step
      } else {
        res.json({
          status: false,
          message: "Rent already existed. You don't need to rent it now",
        });
        return;
      }
    }
    // saved here
    var item = await items.findById(item_id);
    var seller = item.current_owner._id;
    function getPrice() {
      switch (edition) {
        case "standard":
          return item.es_rent_price;
        case "collective":
          return item.ec_rent_price;
        case "limited":
          return item.el_rent_price;
        default:
          return item.es_rent_price;
      }
    }
    var trans = new transactionModel({
      seller,
      buyer: user_id,
      item_id,
      edition: edition,
      amount: 1,
      type: "rent",
      price: getPrice(),
    });
    await trans.save();
    await newRent.save();
    res.json({
      status: true,
      message: "Saved successfully",
    });
  } catch (e) {
    console.log(e);
    res.json({
      status: false,
      message: "Something went wrong",
    });
  }
};

// to get status to decide I have set the automatic bid or not
exports.getBidStatus = async function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded.user_id;
  var item_id = req.body.item_id;
  var edition = req.body.edition;

  bids.findOne(
    {
      item_id,
      edition,
      user_id,
    },
    function (err, result) {
      if (err) {
        res.json({
          status: false,
          message: "db error",
        });
      } else {
        if (!result) {
          res.json({
            status: false,
            message: "No data",
          });
        } else {
          res.json({
            status: true,
            message: "retrived successfully",
            result,
          });
        }
      }
    }
  );
};
// to get the updated bid
exports.getUpdatedBid = async function (req, res) {
  console.log(getErrLine().str, "apistart");
  // var user_id = req.decoded.user_id;
  var item_id = req.body.item_id;
  var edition = req.body.edition;
  try {
    let maxBid = await offers
      .findOne({
        type: "bid",
        item_id,
        edition,
      })
      .sort({ price: -1 })
      .limit(1)
      .exec();
    if (maxBid) {
      res.json({
        status: true,
        message: "retrived successfully",
        result: {
          maxBid,
          serverDate: new Date(),
        },
      });
    } else {
      res.json({
        status: false,
        message: "can't find bid",
      });
    }
  } catch (e) {
    console.log(e);
    res.json({
      status: false,
      message: "Something went wrong",
    });
  }
};
// get bid history
exports.getBidHistory = function (req, res) {
  console.log(getErrLine().str, "apistart");
  var item_id = req.body.item_id,
    edition = req.body.edition
  bid_step = req.body.bid_step || 1;
  (viewAll = req.body.viewAll), (page = req.body.page || 1);
  limit = req.body.limit || 15;

  let query;
  if (viewAll) {
    query = offers.find({ type: "bid", item_id, edition, bid_step }).sort({ price: -1 });
  } else {
    query = offers
      .find({ type: "bid", item_id, edition, bid_step })
      .sort({ price: -1 })
      .limit(10);
  }

  query
    .populate({
      path: "sender",
      model: "users",
      select: "_id first_name last_name username profile_image is_idverified",
    })
    .then(
      (result) => {
        res.json({
          status: true,
          message: "retrived successfully",
          result: result,
        });
      },
      (error) => {
        console.log(error);
        res.json({
          status: false,
          message: "error was occred",
        });
      }
    );
};

// get available from
exports.getAvailableFromList = function () {
  console.log(getErrLine().str, "apistart");
  var item_id = req.body.item_id,
    edition = req.body.edition,
    option = req.body.option;
  var query = {};
  var label;
  switch (edition) {
    case "standard":
      label = "es";
      break;
    case "collective":
      label = "ec";
      break;
    case "limited":
      label = "el";
      break;
    default:
      res.json({
        status: false,
        message: "No list",
      });
      return;
  }
  query[`orignial_id`] = item_id;
  query[`${label}_enabled`] = true;
  if (option) {
    Object.keys(option).map((key) => {
      query[`${label}_inventories.${key}`] = option[key];
    });
  }
  items.find(query, function (err, result) {
    if (err) {
      res.json({
        status: false,
        message: "Error was occured",
      });
    } else {
      if (result) {
        res.json({
          status: true,
          message: "Data retrived successfully",
          result,
        });
      } else {
        res.json({
          status: false,
          message: "No data",
        });
      }
    }
  });
};

exports.addShippedInfo = function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded.user_id;
  var updatedFields = {
    receive_type: req.body.receive_type,
    ship_date: req.body.ship_date,
    ship_carrier: req.body.ship_carrier,
    trackId: req.body.trackId,
    other_content: req.body.other_content,
    status: "Shipped",
  };
  let updateArray = [];
  req.body.items?.map((d, index) => {
    updateArray.push(d);
  });

  offers
    .findOne({ _id: req.body.offer_id }, function (err, offer) {
      if (err || !offer) {
        res.json({
          status: false,
          message: "Db error",
          errors: err,
        });
      } else {
        updateArray.map((d) => {
          offer.items?.map((item, index) => {
            if (d == item._id) {
              var newObj = {
                item_id: item.item_id,
                amount: item.amount,
                catlevel1: item.catlevel1,
                catlevel2: item.catlevel2,
                catlevel3: item.catlevel3,
                edition: item.edition,
                option: item.option,
                name: item.name,
                price: item.price,
                status: "Shipped",
                thumb: item.thumb,
                type: item.type,
                receive_type: updatedFields.receive_type,
                ship_date: updatedFields.ship_date,
                ship_carrier: updatedFields.ship_carrier,
                trackId: updatedFields.trackId,
                other_content: updatedFields.other_content,
              };
              console.log(newObj);
              offer.items[index] = newObj;
            }
          });
        });
        return offer.save();
      }
    })
    .then(async (savedOffer) => {
      // CREATE NOTIFICATION
      try {
        let notif_users = [];
        let _user = await users.findOne({
          _id: savedOffer.sender,
          "notif_buying.is_order_update": true,
        });
        if (_user) {
          let message;
          let count = 0;

          savedOffer.items.map((d) => {
            if (req.body.items.some((u) => u == d._id)) {
              count += d.amount;
            }
          });

          if (req.body.receive_type == "Shipping") {
            let ship_carrier = SHIPCARRIER.find(
              (d) => (d.code = req.body.ship_carrier)
            )?.name;
            message = `Shipped your ${count} item${count > 1 ? "s" : ""} ${ship_carrier ? "by " + ship_carrier : ""
              }`;
          } else {
            message = `Shipped your ${count} item${count > 1 ? "s" : ""}`;
          }
          let new_notification = new notificationModel({
            type: NOTIFICATION_TYPES.BUYING_ORDER,
            from_id: user_id,
            to_id: _user._id,
            message,
            items: savedOffer.items.filter((d) =>
              req.body.items.some((u) => u == d._id)
            ),
          });
          await new_notification.save();
          notif_users.push(_user._id);
        }
        res.json({
          status: true,
          message: "Saved successfully",
          result: {
            offer: savedOffer,
            notif_users,
          },
        });
      } catch (error) {
        res.json({
          status: false,
          message: "Something went wrong",
        });
      }
    })
    .catch((err) => {
      res.json({ status: false, message: "Something went wrong" });
    });
};

exports.create_item_reaction = function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded.user_id;
  var item_id = req.body.item_id;
  var reaction_number = req.body.reaction_number;
  item_reactions.findOne({ item_id, user_id }, function (err, result) {
    if (err) {
      res.json({
        status: false,
        message: "db error",
      });
    }
    if (result) {
      if (result.reaction_number == reaction_number) {
        items.findById(item_id, function (err, item) {
          if (err || !item) {
            res.json({
              status: false,
              message: "Item not found",
            });
            return;
          }
          const n_reaction = item.n_reaction - 1;
          item.n_reaction = n_reaction;
          const n_reaction_detail =
            item.n_reaction_detail[`r_${reaction_number}`] - 1;
          item.n_reaction_detail[`r_${reaction_number}`] = n_reaction_detail;

          var date = new Date();
          var datestr = getDateStr(date);

          let daily_trending = item.daily_trending.find(
            (d) => d.date == datestr
          );
          if (daily_trending) {
            let count = daily_trending.count - 1;
            daily_trending.count = count;
          } else {
            let newObj = {
              date: datestr,
              count: -1,
            };
            item.daily_trending.push(newObj);
          }

          item.save(function (err, itemSaved) {
            item_reactions.remove({ _id: result._id }, function (err, result) {
              if (err || !result) {
                res.json({
                  status: false,
                  message: "Something went wrong",
                });
              } else {
                res.json({
                  status: true,
                  message: "Removed successfully",
                });
              }
            });
          });
        });
      } else {
        items.findById(item_id, function (err, item) {
          if (err || !item) {
            res.json({
              status: false,
              message: "Item not found",
            });
            return;
          }
          const n_reaction_detail =
            item.n_reaction_detail[`r_${reaction_number}`] + 1;
          item.n_reaction_detail[`r_${reaction_number}`] = n_reaction_detail;
          const last_n_reaction_detail =
            item.n_reaction_detail[`r_${result.reaction_number}`] - 1;
          item.n_reaction_detail[`r_${result.reaction_number}`] =
            last_n_reaction_detail;

          item.save(function (err, itemSaved) {
            result.reaction_number = reaction_number;
            result.save(async function (err, result) {
              if (err || !result) {
                res.json({
                  status: false,
                  message: "Update error",
                });
                return;
              }

              let notif_users = [];

              let cat = await category.findById(item.category_id);
              // USERS WHO FOLLOWS ME AND THEIR NOTIFICATION SETTING IS ENABLED
              let query = {
                _id: item.current_owner,
              };
              let filter;
              if (cat.type == "Digital") {
                switch (cat.title) {
                  case "Music":
                    query = {
                      ...query,
                      "notif_music.is_reactions": true,
                    };
                    filter = NOTIFICATION_FILTERS.NEW_MUSIC;
                    break;
                  case "Podcasts":
                    query = {
                      ...query,
                      "notif_podcasts.is_reactions": true,
                    };
                    filter = NOTIFICATION_FILTERS.NEW_PODCAST;
                    break;
                  case "Comedy gigs":
                    query = {
                      ...query,
                      "notif_standUpComedy.is_reactions": true,
                    };
                    filter = NOTIFICATION_FILTERS.NEW_COMEDY_GIGS;
                    break;
                  case "Audiobooks":
                    query = {
                      ...query,
                      "notif_audioBooks.is_reactions": true,
                    };
                    filter = NOTIFICATION_FILTERS.NEW_AUDIOBOOKS;
                    break;
                  case "Movies":
                    query = {
                      ...query,
                      "notif_movies.is_reactions": true,
                    };
                    filter = NOTIFICATION_FILTERS.NEW_MOVIES;
                    break;
                  case "TV Series":
                    query = {
                      ...query,
                      "notif_tv_series.is_reactions": true,
                    };
                    filter = NOTIFICATION_FILTERS.NEW_TV_SERIES;
                    break;
                  default:
                    break;
                }
              } else {
              }

              let user = await users.findOne(query);

              if (user) {
                // CHECK WHETHER HE READ HIS NOTIFICATION OR NOT
                let notification = await notificationModel.findOne({
                  type: NOTIFICATION_TYPES.ITEM_REACTION,
                  filter: NOTIFICATION_FILTERS.NEW_REACTIONS,
                  item_id: item._id,
                  to_id: item.current_owner,
                  is_read: false,
                });
                if (notification) {
                  if (notification.from_id != user_id) {
                    const n_user = notification.n_user + 1;
                    notification.n_user = n_user;
                  } else {
                    notification.reaction_number = reaction_number;
                  }
                  notification.create_date = new Date();
                  await notificationModel.findByIdAndUpdate(
                    notification._id,
                    notification
                  );
                  notif_users.push(item.current_owner);
                } else {
                  let new_notification = new notificationModel({
                    type: NOTIFICATION_TYPES.ITEM_REACTION,
                    filter: NOTIFICATION_FILTERS.NEW_REACTIONS,
                    message: `Reacted to your`,
                    from_id: user_id,
                    to_id: item.current_owner,
                    item_id: item._id,
                    reaction_number,
                  });
                  await new_notification.save();
                  notif_users.push(item.current_owner);
                }
              }

              res.json({
                status: true,
                message: "updated successfully",
                result: {
                  notif_users,
                },
              });
            });
          });
        });
      }
    } else {
      var newOne = item_reactions({ item_id, user_id, reaction_number });
      items.findById(item_id, async function (err, item) {
        if (err || !item) {
          res.json({
            status: false,
            message: "Item not found",
          });
          return;
        }
        const n_reaction = item.n_reaction + 1;
        item.n_reaction = n_reaction;
        const n_reaction_detail =
          item.n_reaction_detail[`r_${reaction_number}`] + 1;
        item.n_reaction_detail[`r_${reaction_number}`] = n_reaction_detail;

        var date = new Date();
        var datestr = getDateStr(date);

        let daily_trending = item.daily_trending.find((d) => d.date == datestr);
        if (daily_trending) {
          let count = daily_trending.count + 1;
          daily_trending.count = count;
        } else {
          let newObj = {
            date: datestr,
            count: 1,
          };
          console.log("item_daily_trending", item.daily_trending);
          item.daily_trending.push(newObj);
        }

        try {
          await item.save();
          await newOne.save();

          let notif_users = [];

          let cat = await category.findById(item.category_id);
          // USERS WHO FOLLOWS ME AND THEIR NOTIFICATION SETTING IS ENABLED
          let query = {
            _id: item.current_owner,
          };
          let filter;
          if (cat.type == "Digital") {
            switch (cat.title) {
              case "Music":
                query = {
                  ...query,
                  "notif_music.is_reactions": true,
                };
                filter = NOTIFICATION_FILTERS.NEW_MUSIC;
                break;
              case "Podcasts":
                query = {
                  ...query,
                  "notif_podcasts.is_reactions": true,
                };
                filter = NOTIFICATION_FILTERS.NEW_PODCAST;
                break;
              case "Comedy gigs":
                query = {
                  ...query,
                  "notif_standUpComedy.is_reactions": true,
                };
                filter = NOTIFICATION_FILTERS.NEW_COMEDY_GIGS;
                break;
              case "Audiobooks":
                query = {
                  ...query,
                  "notif_audioBooks.is_reactions": true,
                };
                filter = NOTIFICATION_FILTERS.NEW_AUDIOBOOKS;
                break;
              case "Movies":
                query = {
                  ...query,
                  "notif_movies.is_reactions": true,
                };
                filter = NOTIFICATION_FILTERS.NEW_MOVIES;
                break;
              case "TV Series":
                query = {
                  ...query,
                  "notif_tv_series.is_reactions": true,
                };
                filter = NOTIFICATION_FILTERS.NEW_TV_SERIES;
                break;
              default:
                break;
            }
          } else {
          }

          let user = await users.findOne(query);

          if (user) {
            // CHECK WHETHER HE READ HIS NOTIFICATION OR NOT
            let notification = await notificationModel.findOne({
              type: NOTIFICATION_TYPES.ITEM_REACTION,
              filter: NOTIFICATION_FILTERS.NEW_REACTIONS,
              item_id: item._id,
              to_id: item.current_owner,
              is_read: false,
            });
            if (notification) {
              if (notification.from_id != user_id) {
                const n_user = notification.n_user + 1;
                notification.n_user = n_user;
              } else {
                notification.reaction_number = reaction_number;
              }
              notification.create_date = new Date();
              await notificationModel.findByIdAndUpdate(
                notification._id,
                notification
              );
              notif_users.push(item.current_owner);
            } else {
              let new_notification = new notificationModel({
                type: NOTIFICATION_TYPES.ITEM_REACTION,
                filter: NOTIFICATION_FILTERS.NEW_REACTIONS,
                message: `Reacted to your`,
                from_id: user_id,
                to_id: item.current_owner,
                item_id: item._id,
                reaction_number,
              });
              await new_notification.save();
              notif_users.push(item.current_owner);
            }
          }

          res.json({
            status: true,
            message: "updated successfully",
            result: {
              notif_users,
            },
          });
        } catch (e) {
          console.log(e);
          res.json({
            status: false,
            message: "Item save error",
          });
        }
      });
    }
  });
};

exports.read_item_reactions = function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded.user_id;
  var item_id = req.query.item_id;
  items.findById(item_id, function (err, result) {
    if (err) {
      res.json({
        status: false,
        message: "db error",
      });
      return;
    }
    item_reactions.findOne({ item_id, user_id }, function (err, reaction) {
      if (err) {
        res.json({
          status: false,
          message: "Db error",
        });
      } else {
        var resData = {
          data: result,
          reaction: reaction,
        };
        res.json({
          status: true,
          message: "retrieved successfully",
          result: resData,
        });
      }
    });
  });
};

exports.create_item_play = function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded.user_id;
  var item_id = req.body.item_id;

  items.findById(item_id, function (err, item) {
    if (err || !item) {
      res.json({
        status: false,
        message: "Db error or not found item",
      });
      return;
    }
    item_plays.findOne(
      { item_id: item_id, user_id: user_id },
      async function (err, result) {
        if (err || result) {
          res.json({ status: false, message: "Db error or already done" });
          return;
        } else {
          var newOne = new item_plays({
            item_id: item_id,
            user_id: user_id,
          });
          const n_play = item.n_play + 1;
          item.n_play = n_play;

          var date = new Date();
          var datestr = getDateStr(date);

          let daily_play = item.daily_play.find((d) => d.date == datestr);
          if (daily_play) {
            let count = daily_play.count + 1;
            daily_play.count = count;
          } else {
            let newObj = {
              date: datestr,
              count: 1,
            };
            item.daily_play.push(newObj);
          }

          try {
            await item.save();
            await newOne.save();
          } catch (error) {
            res.json({
              status: true,
              message: "Saved successfully",
            });
          }
        }
      }
    );
  });
};

exports.read_item_plays = function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded.user_id;
  item_plays.find({ user_id: user_id }, function (err, result) {
    if (err) {
      res.json({
        status: false,
        message: "db error",
      });
      return;
    }
    res.json({
      status: true,
      message: "retrieved successfully",
      result: result,
    });
  });
};

exports.create_item_comment_reaction = function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded.user_id;
  var item_comment_id = req.body.item_comment_id;
  var reaction_number = req.body.reaction_number;
  item_comment_reactions.findOne(
    { item_comment_id, user_id },
    function (err, result) {
      if (err) {
        res.json({
          status: false,
          message: "db error",
        });
      }
      if (result) {
        if (result.reaction_number == reaction_number) {
          item_comments.findById(item_comment_id, function (err, item_comment) {
            if (err || !item_comment) {
              res.json({
                status: false,
                message: "Item Comment not found",
              });
              return;
            }
            const n_reaction = item_comment.n_reaction - 1;
            item_comment.n_reaction = n_reaction;
            const n_reaction_detail =
              item_comment.n_reaction_detail[`r_${reaction_number}`] - 1;
            item_comment.n_reaction_detail[`r_${reaction_number}`] =
              n_reaction_detail;
            item_comment.save(function (err, itemSaved) {
              result.reaction_number = reaction_number;
              result.save(function (err, result) {
                if (err || !result) {
                  res.json({
                    status: false,
                    message: "Update error",
                  });
                  return;
                }
                item_comment_reactions.remove(
                  { item_comment_id, user_id },
                  function (err, result) {
                    if (err) {
                      res.json({
                        status: false,
                        message: "item comment reaction remove failed",
                      });
                    } else {
                      res.json({
                        status: true,
                        message: "updated successfully",
                      });
                    }
                  }
                );
              });
            });
          });
        } else {
          item_comments.findById(item_comment_id, function (err, item_comment) {
            if (err || !item_comment) {
              res.json({
                status: false,
                message: "Item Comment not found",
              });
              return;
            }
            const n_reaction_detail =
              item_comment.n_reaction_detail[`r_${reaction_number}`] + 1;
            item_comment.n_reaction_detail[`r_${reaction_number}`] =
              n_reaction_detail;
            const last_n_reaction_detail =
              item_comment.n_reaction_detail[`r_${result.reaction_number}`] - 1;
            item_comment.n_reaction_detail[`r_${result.reaction_number}`] =
              last_n_reaction_detail;
            item_comment.save(function (err, itemSaved) {
              result.reaction_number = reaction_number;
              result.save(function (err, result) {
                if (err || !result) {
                  res.json({
                    status: false,
                    message: "Update error",
                  });
                  return;
                }
                res.json({
                  status: true,
                  message: "updated successfully",
                });
              });
            });
          });
        }
      } else {
        var newOne = item_comment_reactions({
          item_comment_id,
          user_id,
          reaction_number,
        });
        item_comments.findById(item_comment_id, function (err, item_comment) {
          if (err || !item_comment) {
            res.json({
              status: false,
              message: "item_comment not found",
            });
            return;
          }
          const n_reaction = item_comment.n_reaction + 1;
          item_comment.n_reaction = n_reaction;
          const n_reaction_detail =
            item_comment.n_reaction_detail[`r_${reaction_number}`] + 1;
          item_comment.n_reaction_detail[`r_${reaction_number}`] =
            n_reaction_detail;
          item_comment.save(function (err, result) {
            newOne.save(function (err, result) {
              res.json({
                status: true,
                message: "Saved successfully",
              });
            });
          });
        });
      }
    }
  );
};

exports.read_item_comment_reaction = function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded.user_id;
  var item_comment_id = req.query.item_comment_id;
  item_comments.findById(item_comment_id, function (err, result) {
    if (err) {
      res.json({
        status: false,
        message: "db error",
      });
      return;
    }
    item_comment_reactions.findOne(
      { item_comment_id, user_id },
      function (err, reaction) {
        if (err) {
          res.json({
            status: false,
            message: "db error",
          });
        } else {
          var resData = {
            data: result,
            reaction: reaction,
          };
          res.json({
            status: true,
            message: "retrieved successfully",
            result: resData,
          });
        }
      }
    );
  });
};

exports.create_item_comment_love = function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded.user_id;
  var item_comment_id = req.body.item_comment_id;
  item_comment_loves.findOne(
    { item_comment_id, user_id },
    async function (err, result) {
      if (err) {
        res.json({
          status: false,
          message: "Db error or already done",
        });
        return;
      } else {
        if (result) {
          try {
            let item_comment = await item_comments.findById(item_comment_id);
            if (item_comment) {
              // decrease the love number
              const n_love = item_comment.n_love - 1;
              item_comment.n_love = n_love;
              item_comment.save();
              result.remove();
              res.json({
                status: true,
                message: "Removed successfully.",
              });
            } else {
              res.json({
                status: false,
                message: "Not found Item comment",
              });
            }
          } catch (error) {
            res.json({
              status: false,
              message: "Something weng wrong",
            });
          }
        } else {
          var newOne = item_comment_loves({
            item_comment_id,
            user_id,
          });
          item_comments.findById(item_comment_id, function (err, item_comment) {
            if (err || !item_comment) {
              res.json({
                status: false,
                message: "Db error or not found item comment",
              });
              return;
            } else {
              let n_love = item_comment.n_love + 1;
              item_comment.n_love = n_love;
              item_comment.save(function (err, result) {
                if (err) {
                  res.json({
                    status: false,
                    message: "Item comment update error",
                  });
                  return;
                }
                newOne.save(function (err, result) {
                  if (err) {
                    res.json({
                      status: false,
                      message: "New love is not save correctly",
                    });
                    return;
                  }
                  res.json({
                    status: true,
                    message: "Saved successfully",
                  });
                });
              });
            }
          });
        }
      }
    }
  );
};

exports.create_item_comment_like = function (req, res) {
  console.log(getErrLine().str, "apistart");
  var comment_id = req.body.comment_id;
  var user_id = req.decoded.user_id;
  item_comments.findOne(
    { _id: comment_id, user_id: user_id },
    function (err, result) {
      if (err || result) {
        res.json({
          status: false,
          message: "Db error or already done",
        });
        return;
      }
      const n_comment = item_comment.n_comment;
      item_comment.n_comment = n_comment;
      item_comment.save(function (err, result) {
        var newOne = new item_comment_likes({
          comment_id: comment_id,
          user_id: user_id,
        });
        newOne.save(function (err, result) {
          if (err) {
            res.json({
              status: false,
              message: "Db error",
            });
            return;
          }
          res.json({
            status: true,
            message: "Saved successfully.",
          });
        });
      });
    }
  );
};


exports.add_item_comment = function (user_id, item_id, description, parent_id = null, replyImages = [], replyVideo = null) {
  console.log(getErrLine().str, "apistart");
  return new Promise(async (resolve, reject) => {
    try {
      console.log("THIS PROMISE IS CALLED HERE.")
      var item = await items.findById(item_id);
      if (item) {
        var new_comment = new item_comments({
          item_id,
          parent_id,
          description,
          user_id,
          replyImages, replyVideo
        });

        if (parent_id) {
          var parent = await item_comments.findById(parent_id);
          if (parent) {
            const n_comment = parent.n_comment || 0 + 1;
            parent.n_comment = n_comment;
            await parent.save();
          }
        } else {
          const n_comment = (item.n_comment || 0) + 1;
          item.n_comment = n_comment;
          await item.save();
        }

        if (item.current_owner != user_id) {
          var date = new Date();
          var datestr = getDateStr(date);

          let daily_trending = item.daily_trending.find(
            (d) => d.date == datestr
          );
          if (daily_trending) {
            let count = daily_trending.count + 3;
            daily_trending.count = count;
          } else {
            let newObj = {
              date: datestr,
              count: 1,
            };
            item.daily_trending.push(newObj);
          }
        }
        // CREATE NOTIFICATION REPLY

        let notif_users = [];
        if (user_id != item?.current_owner) {
          let cat = await category.findById(item.category_id);
          // USERS WHO FOLLOWS ME AND THEIR NOTIFICATION SETTING IS ENABLED
          let query = {
            // _id: parent.user_id,
          };
          if (cat.type == "Digital") {
            switch (cat.title) {
              case "Music":
                query = {
                  ...query,
                  "notif_music.is_comments_replies": true,
                };
                break;
              case "Podcasts":
                query = {
                  ...query,
                  "notif_podcasts.is_comments_replies": true,
                };
                break;
              case "Comedy gigs":
                query = {
                  ...query,
                  "notif_standUpComedy.is_comments_replies": true,
                };
                break;
              case "Audiobooks":
                query = {
                  ...query,
                  "notif_audioBooks.is_comments_replies": true,
                };
                break;
              case "Movies":
                query = {
                  ...query,
                  "notif_movies.is_comments_replies": true,
                };
                break;
              case "TV Series":
                query = {
                  ...query,
                  "notif_tv_series.is_comments_replies": true,
                };
                break;
              default:
                break;
            }
          } else {
          }
          let user = await users.findOne(
            parent_id && parent ? {
              _id: parent?.user_id,
              ...query
            } :
              {
                _id: item?.current_owner,
                ...query
              }
          );
          if (user) {
            if (parent_id) {
              let notification = await notificationModel.findOne({
                type: NOTIFICATION_TYPES.ITEM_COMMENT_REPLY,
                filter: NOTIFICATION_FILTERS.NEW_COMMENTS_REPLIES,
                to_id: item.current_owner,
                item_id: item._id,
                is_read: false
              })
              if (notification) {
                if (notification.from_id != user_id) {
                  const n_user = notification.n_user + 1;
                  notification.n_user = n_user;
                }
                notification.create_date = new Date();
                await notification.save();
              } else {
                let new_notification = new notificationModel({
                  type: NOTIFICATION_TYPES.ITEM_COMMENT_REPLY,
                  filter: NOTIFICATION_FILTERS.NEW_COMMENTS_REPLIES,
                  message: "Replied to this comment",
                  from_id: user_id,
                  to_id: item.current_owner,
                  item_id: item._id,
                });
                await new_notification.save();
              }
              notif_users.push(item?.current_owner);
            } else {
              // CHECK THIS NOTIFICAITON IS READ OR NOT
              let notification = await notificationModel.findOne({
                type: NOTIFICATION_TYPES.ITEM_COMMENT_REPLY,
                filter: NOTIFICATION_FILTERS.NEW_COMMENTS_REPLIES,
                to_id: item.current_owner,
                item_id: item._id,
                is_read: false
              });

              if (notification) {
                if (notification.from_id != user_id) {
                  const n_user = notification.n_user + 1;
                  notification.n_user = n_user;
                }
                notification.create_date = new Date();
                await notification.save();
              } else {
                let new_notification = new notificationModel({
                  type: NOTIFICATION_TYPES.ITEM_COMMENT_REPLY,
                  filter: NOTIFICATION_FILTERS.NEW_COMMENTS_REPLIES,
                  from_id: user_id,
                  to_id: item?.current_owner,
                  item_id: item._id,
                });
                await new_notification.save();
              }

              notif_users.push(item?.current_owner);
            }
          }
        }
        await new_comment.save();
        resolve({
          new_comment,
          notif_users
        });

      } else {
        reject(false)
      }
    } catch (error) {
      console.log(error);
      reject(error);
    }
  })
}


exports.create_item_comment = function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded.user_id;
  items.findOne({ _id: req.body.item_id }, async function (err, item) {
    if (err || !item) {
      res.json({
        status: false,
        message: "Post not found",
        errors: err,
      });
      return;
    }
    var newcomment = new item_comments(req.body);

    if (req.body.parent_id) {
      // Define comment_count and increment it before updating the document
      const parent_id = req.body.parent_id;
      item_comments.findById(parent_id, async function (err, parent) {
        if (err) {
          console.log(err);
          res.json({
            status: false,
            message: "error",
            errors: error,
          });
        } else {
          // Increment comment_count by 1
          // if(parent.user_id != req.decoded.user_id) {
          // item.n_comment = item.n_comment + 1;
          const n_comment = parent.n_comment + 1;
          // increase trending number if item is not belong to u
          if (item.creator_id != user_id) {
            var date = new Date();
            var datestr = getDateStr(date);

            let daily_trending = item.daily_trending.find(
              (d) => d.date == datestr
            );
            if (daily_trending) {
              let count = daily_trending.count + 3;
              daily_trending.count = count;
            } else {
              let newObj = {
                date: datestr,
                count: 1,
              };
              item.daily_trending.push(newObj);
            }
          }
          try {
            await newcomment.save();
            await item_comments.findByIdAndUpdate(parent_id, {
              n_comment: n_comment,
            });
            await item.save();

            let notif_users = [];
            if (parent.user_id != user_id) {
              let cat = await category.findById(item.category_id);
              // USERS WHO FOLLOWS ME AND THEIR NOTIFICATION SETTING IS ENABLED
              let query = {
                _id: parent.user_id,
              };
              if (cat.type == "Digital") {
                switch (cat.title) {
                  case "Music":
                    query = {
                      ...query,
                      "notif_music.is_comments_replies": true,
                    };
                    break;
                  case "Podcasts":
                    query = {
                      ...query,
                      "notif_podcasts.is_comments_replies": true,
                    };
                    break;
                  case "Comedy gigs":
                    query = {
                      ...query,
                      "notif_standUpComedy.is_comments_replies": true,
                    };
                    break;
                  case "Audiobooks":
                    query = {
                      ...query,
                      "notif_audioBooks.is_comments_replies": true,
                    };
                    break;
                  case "Movies":
                    query = {
                      ...query,
                      "notif_movies.is_comments_replies": true,
                    };
                    break;
                  case "TV Series":
                    query = {
                      ...query,
                      "notif_tv_series.is_comments_replies": true,
                    };
                    break;
                  default:
                    break;
                }
              } else {
              }

              let user = await users.findOne(query);
              if (user) {
                let notification = await notificationModel.findOne({
                  type: NOTIFICATION_TYPES.ITEM_COMMENT_REPLY,
                  filter: NOTIFICATION_FILTERS.NEW_COMMENTS_REPLIES,
                  to_id: item.current_owner,
                  item_id: parent._id,
                  is_read: false,
                });
                if (notification) {
                  if (notification.from_id != user_id) {
                    notification.n_user = notification.n_user + 1;
                  }
                  notification.create_date = new Date();
                  await notification.save();
                } else {
                  let new_notification = new notificationModel({
                    type: NOTIFICATION_TYPES.ITEM_COMMENT_REPLY,
                    filter: NOTIFICATION_FILTERS.NEW_COMMENTS_REPLIES,
                    from_id: user_id,
                    to_id: item.current_owner,
                    item_id: parent._id,
                  });
                  await new_notification.save();
                }
                notif_users.push(parent.user_id);
              }
            }
            let new_comment = await item_comments.findById(newcomment._id)
              .populate({
                path: "user_id",
                model: "users",
                select: "_id first_name last_name username profile_image is_idverified",
              });

            res.json({
              status: true,
              message: "saved successfully",
              result: {
                new_comment,
                notif_users,
              },
            });
          } catch (error) {
            console.log(error);
            res.json({
              status: false,
              message: "error was occured",
            });
          }
          // } else {
          //     res.json({
          //         status: false,
          //         message: "That is yours, you can reply this "
          //     })
          // }
        }
      });
    } else {
      item.n_comment = item.n_comment + 1;
      // decide whether this item is belong to u and not increase the trending count
      if (item.creator_id != user_id) {
        var date = new Date();
        var datestr = getDateStr(date);

        let daily_trending = item.daily_trending.find((d) => d.date == datestr);
        if (daily_trending) {
          let count = daily_trending.count + 3;
          daily_trending.count = count;
        } else {
          let newObj = {
            date: datestr,
            count: 1,
          };
          item.daily_trending.push(newObj);
        }
      }

      try {
        await newcomment.save();
        await item.save();

        let notif_users = [];
        if (item.current_owner != user_id) {
          let cat = await category.findById(item.category_id);
          // USERS WHO FOLLOWS ME AND THEIR NOTIFICATION SETTING IS ENABLED
          let query = {
            _id: item.current_owner,
          };
          if (cat.type == "Digital") {
            switch (cat.title) {
              case "Music":
                query = {
                  ...query,
                  "notif_music.is_comments_replies": true,
                };
                break;
              case "Podcasts":
                query = {
                  ...query,
                  "notif_podcasts.is_comments_replies": true,
                };
                break;
              case "Comedy gigs":
                query = {
                  ...query,
                  "notif_standUpComedy.is_comments_replies": true,
                };
                break;
              case "Audiobooks":
                query = {
                  ...query,
                  "notif_audioBooks.is_comments_replies": true,
                };
                break;
              case "Movies":
                query = {
                  ...query,
                  "notif_movies.is_comments_replies": true,
                };
                break;
              case "TV Series":
                query = {
                  ...query,
                  "notif_tv_series.is_comments_replies": true,
                };
                break;
              default:
                break;
            }
          } else {
          }
          let user = await users.findOne(query);
          if (user) {
            let notification = await notificationModel.findOne({
              type: NOTIFICATION_TYPES.ITEM_COMMENT,
              filter: NOTIFICATION_FILTERS.NEW_COMMENTS_REPLIES,
              to_id: item.current_owner,
              item_id: item._id,
              is_read: false,
            });
            if (notification) {
              if (notification.from_id != user_id) {
                notification.n_user = notification.n_user + 1;
              }
              notification.create_date = new Date();
              await notification.save();
            } else {
              let new_notification = new notificationModel({
                type: NOTIFICATION_TYPES.ITEM_COMMENT,
                filter: NOTIFICATION_FILTERS.NEW_COMMENTS_REPLIES,
                from_id: user_id,
                to_id: item.current_owner,
                message: "Commented to this comment",
                item_id: item._id,
              });
              await new_notification.save();
            }
            notif_users.push(user._id);
          }
        }

        let new_comment = await item_comments.findById(newcomment._id)
          .populate({
            path: "user_id",
            model: "users",
            select: "_id first_name last_name username profile_image is_idverified",
          });


        res.json({
          status: true,
          message: "saved successfully",
          result: {
            new_comment,
            notif_users,
          },
        });
      } catch (e) {
        console.log(e);
        res.json({
          status: false,
          message: "Something went wrong",
        });
      }
    }
  });
};

exports.read_item_comments = async function (req, res) {
  console.log(getErrLine().str, "apistart");
  var keyword = req.query.keyword || ""; // added dreampanda 20230523 pm 9
  var page = req.query.page ? req.query.page : "1";
  var limit = req.query.limit ? req.query.limit : "15";
  var parent_id = req.query.parent_id || "";
  var user_id = req.decoded.user_id;
  var sortKey = req.query.sortKey;

  var query = item_comments.find();
  var offset = page == "1" ? 0 : parseInt(page - 1) * 10;
  if (parent_id != "") {
    query = query.find({ parent_id: parent_id });
  } else {
    query = query.where("item_id", req.query.item_id);
    query = query.find({ parent_id: null });
  }
  if (keyword != "") {
    query = query.find({ description: { $regex: new RegExp(keyword, "ig") } });
  }
  if (sortKey && sortKey == "newest") {
    query = query.sort("-created_date");
  } else {
    query = query.sort("created_date");
  }
  var options = {
    page: page,
    offset: offset,
    limit: limit,
  };

  let reactions = await item_comment_reactions.find();
  let comments = await item_comments.find({ parent_id: { $ne: null } });
  let loves = await item_comment_loves.find();
  let boosts = []; // temporary
  query = query.populate({
    path: "user_id",
    model: "users",
    select: "_id first_name last_name username profile_image is_idverified",
  });
  item_comments.paginate(query, options).then(function (result) {
    const updatedDocs = result.docs.map((d) => {
      // console.log(playLists.some(pl => pl.item_id == d._doc._id && pl.user_id == user_id))
      const itemReactions = reactions.filter(
        (r) =>
          r.item_comment_id == d._doc._id.toString() && r.user_id == user_id
      );
      const reactionNumber = itemReactions.length
        ? itemReactions[0].reaction_number
        : -1;
      const date = new Date();
      return {
        ...d._doc, // copy all the existing fields
        reaction_number: reactionNumber,
        isCommented: comments.some(
          (pl) => pl.parent_id == d._doc._id.toString() && pl.user_id == user_id
        ),
        isLoved: loves.some(
          (pl) =>
            pl.item_comment_id == d._doc._id.toString() && pl.user_id == user_id
        ),
        isBoosted: boosts.some(
          (pl) =>
            pl.item_comment_id == d._doc._id.toString() && pl.user_id == user_id
        ),
        serverDate: date,
      };
    });

    const updatedResult = { ...result, docs: updatedDocs };

    res.json({
      status: true,
      message: "item_comments retrieved successfully",
      data: updatedResult,
    });
  });
};

exports.create_item_like = async function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded.user_id;
  var item_id = req.body.item_id;

  try {
    let item = await items.findById(item_id);
    if (item) {
      let item_like = await item_likes.findOne({ item_id, user_id });
      if (item_like) {
        const n_like = item.n_like - 1;
        item.n_like = n_like;
        var date = new Date();
        var datestr = getDateStr(date);
        let daily_trending = item.daily_trending.find((d) => d.date == datestr);
        if (daily_trending) {
          let count = daily_trending.count - 3;
          daily_trending.count = count;
        } else {
          let newObj = {
            date: datestr,
            count: -3,
          };
          item.daily_trending.push(newObj);
        }

        item.save();
        item_like.remove();

        res.json({
          status: true,
          message: "Removed successfully.",
        });
      } else {
        // save new comment like
        var new_itemlike = new item_likes({ item_id, user_id });
        new_itemlike.save();
        // increase item like count
        const n_like = item.n_like + 1;
        // handle trending
        // handle daily trending
        var date = new Date();
        var datestr = getDateStr(date);
        let daily_trending = item.daily_trending.find((d) => d.date == datestr);
        if (daily_trending) {
          let count = daily_trending.count + 3;
          daily_trending.count = count;
        } else {
          let newObj = {
            date: datestr,
            count: 3,
          };
          item.daily_trending.push(newObj);
        }

        item.n_like = n_like;
        item.save();
        res.json({
          status: true,
          message: "Saved successfully",
        });
      }
    } else {
      res.json({
        status: false,
        message: "Not found Item",
      });
    }
  } catch (error) {
    res.json({
      status: true,
      message: "Something went wrong.",
    });
  }
};

exports.read_item_likes = function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded.user_id;
  item_likes.find({ user_id: user_id }, function (err, result) {
    if (err) {
      res.json({ status: false, message: "DB error" });
      return;
    }
    res.json({
      status: true,
      message: "Retrived successfully",
      result: result,
    });
  });
};

exports.create_item_love = function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded.user_id;
  var item_id = req.body.item_id;
  // decide whether use already make love or not
  item_loves.findOne(
    { item_id: item_id, user_id: user_id },
    async function (err, result) {
      if (err) {
        res.json({ status: false, message: "Db error" });
        return;
      } // handle exception
      if (result) {
        // if you did, then remove
        try {
          let item = await items.findById(item_id);
          if (item) {
            const n_love = item.n_love - 1; // decrease item love count
            item.n_love = n_love;
            // handle daily trending
            var date = new Date();
            var datestr = getDateStr(date);
            let daily_trending = item.daily_trending.find(
              (d) => d.date == datestr
            );
            if (daily_trending) {
              let count = daily_trending.count - 2;
              daily_trending.count = count;
            } else {
              let newObj = {
                date: datestr,
                count: -2,
              };
              item.daily_trending.push(newObj);
            }

            item.save();
            result.remove();
            res.json({
              status: true,
              message: "Removed successfully",
            });
          } else {
            res.json({
              status: false,
              message: "Item not found",
            });
          }
        } catch (e) {
          console.log(e);
          res.json({
            status: false,
            message: "Something went wrong.",
          });
        }
      } else {
        // else add new
        // found item which you made love
        items.findById(item_id, async function (err, item) {
          // handle exception
          if (err || !item) {
            res.json({
              status: false,
              message: "Db error or item not found",
            });
            return;
          }
          try {
            // increase item love count
            const n_love = item.n_love + 1;
            item.n_love = n_love;

            // handle trending
            var date = new Date();
            var datestr = getDateStr(date);

            let daily_trending = item.daily_trending.find(
              (d) => d.date == datestr
            );
            if (daily_trending) {
              let count = daily_trending.count + 2;
              daily_trending.count = count;
            } else {
              let newObj = {
                date: datestr,
                count: 2,
              };
              item.daily_trending.push(newObj);
            }

            await item.save();

            // create new love user agianst that item
            var newOne = new item_loves({
              item_id: item_id,
              user_id: user_id,
            });
            await newOne.save();

            let notif_users = [];
            if (item.current_owner != user_id) {
              let cat = await category.findById(item.category_id);
              // USERS WHO FOLLOWS ME AND THEIR NOTIFICATION SETTING IS ENABLED
              let query = {
                _id: item.current_owner,
              };
              if (cat.type == "Digital") {
                switch (cat.title) {
                  case "Music":
                    query = {
                      ...query,
                      "notif_music.is_added_favorites": true,
                    };
                    break;
                  case "Podcasts":
                    query = {
                      ...query,
                      "notif_podcasts.is_added_favorites": true,
                    };
                    break;
                  case "Comedy gigs":
                    query = {
                      ...query,
                      "notif_standUpComedy.is_added_favorites": true,
                    };
                    break;
                  case "Audiobooks":
                    query = {
                      ...query,
                      "notif_audioBooks.is_added_favorites": true,
                    };
                    break;
                  case "Movies":
                    query = {
                      ...query,
                      "notif_movies.is_added_favorites": true,
                    };
                    break;
                  case "TV Series":
                    query = {
                      ...query,
                      "notif_tv_series.is_added_favorites": true,
                    };
                    break;
                  default:
                    break;
                }
              } else {
              }

              let user = await users.findOne(query);
              if (user) {
                let notification = await notificationModel.findOne({
                  type: NOTIFICATION_TYPES.ITEM_FAVORITE,
                  filter: NOTIFICATION_FILTERS.NEW_FAVORITES,
                  to_id: user._id,
                  item_id: item._id,
                  is_read: false,
                });
                if (notification) {
                  if (notification.user_id != user_id) {
                    notification.n_user = notification.n_user + 1;
                  }
                  notification.create_date = new Date();
                  await notification.save();
                  console.log(notification);
                } else {
                  let new_notification = new notificationModel({
                    type: NOTIFICATION_TYPES.ITEM_FAVORITE,
                    filter: NOTIFICATION_FILTERS.NEW_FAVORITES,
                    from_id: user_id,
                    to_id: user._id,
                    message: "Commented to this comment",
                    item_id: item._id,
                  });
                  await new_notification.save();
                  console.log("created");
                }
                notif_users.push(user._id);
              }
            }

            res.json({
              status: true,
              message: "saved successfully",
              result: {
                notif_users,
              },
            });
          } catch (error) {
            console.log(error);
            res.json({
              status: false,
              message: "error was occured while saving data",
              error,
            });
          }
        });
      }
    }
  );
};

exports.read_item_loves = function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded.user_id;
  item_loves.find({ user_id: user_id }, function (err, result) {
    if (err) {
      res.json({ status: false, message: "DB error" });
      return;
    }
    res.json({
      status: true,
      message: "Retrived successfully",
      result: result,
    });
  });
};

exports.create_item_boost = function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded.user_id;
  var item_id = req.body.item_id;

  item_boosts.findOne(
    { item_id: item_id, user_id: user_id },
    function (err, result) {
      if (err || result) {
        res.json({ status: false, message: "Db error or already done action" });
        return;
      }
      items.findById(item_id, async function (err, item) {
        if (err || !item) {
          res.json({
            status: false,
            message: "Db error or item not found",
          });
          return;
        }
        const n_boost = item.n_boost + 1;
        item.n_boost = n_boost;

        // trending count increase by
        var date = new Date();
        var datestr = getDateStr(date);

        let daily_trending = item.daily_trending.find((d) => d.date == datestr);
        if (daily_trending) {
          let count = daily_trending.count + 3;
          daily_trending.count = count;
        } else {
          let newObj = {
            date: datestr,
            count: 1,
          };
          item.daily_trending.push(newObj);
        }
        var newOne = new item_boosts({
          item_id: item_id,
          user_id: user_id,
        });
        try {
          await item.save();
          await newOne.save();
          res.json({
            status: true,
            message: "created successfully",
          });
        } catch (error) {
          res.json({
            status: false,
            message: "error was occured",
          });
        }
      });
    }
  );
};

exports.read_item_boosts = function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded.user_id;
  item_boosts.find({ user_id: user_id }, function (err, result) {
    if (err) {
      res.json({
        status: false,
        message: "Db error",
      });
      return;
    }
    res.json({
      status: true,
      message: "Retrived successfully",
      result: result,
    });
  });
};

// create season
exports.create_season = function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded.user_id;
  var season = new seasons(req.body);
  season.creator_id = user_id;
  seasons.findOne(
    { number: season.number, creator_id: user_id },
    function (err, result) {
      if (err || result) {
        res.json({
          status: false,
          message: "Db error or already created season with that number.",
        });
      } else {
        season.save(function (err, saved) {
          if (err) {
            res.json({
              status: false,
              message: "Error was occured",
              errors: err,
            });
          } else {
            res.json({
              status: true,
              message: "Created successfully",
              result: saved,
            });
          }
        });
      }
    }
  );
};

// read seasons
exports.read_seasons = function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded?.user_id || req.query.user_id;
  seasons
    .find({ creator_id: user_id })
    .sort({ number: 1 })
    .exec(function (err, result) {
      if (err) {
        console.log(err);
        res.json({
          status: false,
          message: "Db error",
        });
      } else {
        res.json({
          status: true,
          message: "season retrived successfully",
          result: result,
        });
      }
    });
};

// added by dreampanda 20230702 am 3
exports.getItemDetail = function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded?.user_id;
  var item_id = req.query.item_id;
  items
    .findById(item_id)
    .populate({
      path: "collection_id",
      model: collections,
      populate: [
        {
          path: "author_id",
          model: users,
          select:
            "_id username first_name last_name profile_image metamask_info is_idverified",
        },
      ],
    })
    .populate({ path: "collection_id.author_id", model: users })
    .populate({ path: "category_id", model: category })
    .populate({ path: "catlevel2_id", model: category })
    .populate({ path: "catlevel3_id", model: category })
    .populate({ path: "artist", model: artistModel })
    .populate({
      path: "current_owner",
      model: users,
      select:
        "_id username first_name last_name profile_image metamask_info is_idverified",
    })
    .populate({
      path: "author_id",
      model: users,
      select:
        "_id username first_name last_name profile_image metamask_info is_idverified",
    })
    .exec(async function (err, result) {
      if (err) {
        console.log(err);
        res.json({
          status: false,
          message: "Db error",
        });
      } else {
        if (result) {
          try {
            let _reaction = await item_reactions.findOne({ user_id, item_id });
            let _playList = await item_plays.findOne({ user_id, item_id });
            let _comment = await item_comments.findOne({
              user_id,
              item_id,
              parent_id: null,
            });
            let _like = await item_likes.findOne({ user_id, item_id });
            let _love = await item_loves.findOne({ user_id, item_id });
            let _boost = await fanpostShareModel.findOne({ type: 'item', user_id, item_id });

            let _items = await items
              .find({
                author_id: result?.author_id?._id,
                current_owner: result?.author_id?._id,
              })
              .populate({
                path: "collection_id",
                model: collections,
                populate: [
                  {
                    path: "author_id",
                    model: users,
                    select:
                      "_id username first_name last_name profile_image metamask_info is_idverified",
                  },
                ],
              })
              .populate({ path: "collection_id.author_id", model: users })
              .populate({ path: "category_id", model: category })
              .populate({ path: "catlevel2_id", model: category })
              .populate({ path: "catlevel3_id", model: category })
              .populate({
                path: "current_owner",
                model: users,
                select:
                  "_id username first_name last_name profile_image metamask_info is_idverified",
              })
              .populate({
                path: "author_id",
                model: users,
                select:
                  "_id username first_name last_name profile_image metamask_info is_idverified",
              });

            let _from_items = await items
              .find({
                original_id: item_id,
              })
              .populate({
                path: "collection_id",
                model: collections,
                populate: [
                  {
                    path: "author_id",
                    model: users,
                    select:
                      "_id username first_name last_name profile_image metamask_info is_idverified",
                  },
                ],
              })
              .populate({ path: "collection_id.author_id", model: users })
              .populate({ path: "category_id", model: category })
              .populate({ path: "catlevel2_id", model: category })
              .populate({ path: "catlevel3_id", model: category })
              .populate({
                path: "current_owner",
                model: users,
                select:
                  "_id username first_name last_name profile_image metamask_info is_idverified",
              })
              .populate({
                path: "author_id",
                model: users,
                select:
                  "_id username first_name last_name profile_image metamask_info is_idverified",
              });

            let rule = await itemShippingRuleModel.findOne({
              items: item_id
            });

            let item_status = {
            }
            // check it's yours or not, purchased or not, it's in on player or not
            if ((result?._doc || result)?.category_id?.type == 'Digital') {
              let full = user_id == result?._doc?.author_id?._id ? true : false;
              item_status = {
                ...item_status,
                full
              }
              if (!full) {
                let date = new Date();
                date.setDate(date.getDate() - 3)
                let _purchased_standard = await items.findOne({ original_id: item_id, edition: 'standard', current_owner: user_id });
                let _purchased_collective = await items.findOne({ original_id: item_id, edition: 'collective', current_owner: user_id });
                let _purchased_limited = await items.findOne({ original_id: item_id, edition: 'limited', current_owner: user_id });

                let _rent = await rents.findOne({ sender: user_id, item_id, edition: 'standard', created_date: { $gte: date } }).sort({ created_date: -1 }).limit(1);

                item_status = {
                  ...item_status,
                  _purchased_standard: _purchased_standard ? true : false,
                  _purchased_collective: _purchased_collective ? true : false,
                  _purchased_limited: _purchased_limited ? true : false,
                  _rent,

                }

              }
              let _free = await playerModel.findOne({ item_id, edition: 'free', user_id: user_id });
              let _standard = await playerModel.findOne({ item_id, edition: 'standard', user_id: user_id });
              let _collective = await playerModel.findOne({ item_id, edition: 'collective', user_id: user_id });
              let _limited = await playerModel.findOne({ item_id, edition: 'limited', user_id: user_id });

              item_status = {
                ...item_status,
                up_free: _free ? true : false,
                up_standard: _standard ? true : false,
                up_collective: _collective ? true : false,
                up_limited: _limited ? true : false
              }

            }

            let new_result = {
              ...result._doc,
              item_status,
              ...{
                setverDate: new Date(),
                reaction_number: _reaction ? _reaction.reaction_number : -1,
                isPlayed: _playList ? true : false,
                isCommented: _comment ? true : false,
                isLiked: _like ? true : false,
                isLoved: _love ? true : false,
                isBoosted: _boost ? true : false,
              },
              ...rule?._doc,
              _id: result?._doc?._id
            };

            let resData = {
              item: new_result,
              // reaction_number:  _reaction ? _reaction.reaction_number : -1,
              // isPlayed: _playList ? true: false,
              // isCommented: _comment ? true: false,
              // isLiked: _like ? true: false,
              // isLoved: _love ? true: false,
              // isBoosted: _boost ? true: false,
              items: _items,
              from_items: _from_items,
            };

            res.json({
              status: true,
              message: "retrived successfully",
              result: resData,
            });
          } catch (e) {
            res.json({
              status: false,
              message: e?.message,
            });
          }
        } else {
          res.json({
            status: false,
            message: "Item not found"
          })
        }
      }
    });
};

exports.get_items_listings = function (req, res) {
  console.log(getErrLine().str, "apistart");
  let user_id = req.decoded.user_id || req.query.user_id;
  (keyword = req.query.keyword || ""),
    (page = req.query.page || 1),
    (limit = req.query.limit || 15),
    (showOnly = req.query.showOnly),
    (sortBy = req.query.sortBy);

  var onlySelling = req.query.onlySelling;
  // other property will be added here.

  var query = items.find();
  query = query.find({ current_owner: user_id });

  switch (showOnly) {
    case "auctions":
      query = query.find({
        $or: [
          {
            $and: [{ es_is_auction: true }, { es_enabled: true }],
          },
          {
            $and: [{ ec_is_auction: true }, { ec_enabled: true }],
          },
          {
            $and: [{ el_is_auction: true }, { el_enabled: true }],
          },
        ],
      });
      break;
    case "sales":
      query = query.find({
        $or: [
          {
            $and: [{ es_is_auction: false }, { es_enabled: true }],
          },
          {
            $and: [{ ec_is_auction: false }, { ec_enabled: true }],
          },
          {
            $and: [{ el_is_auction: false }, { el_enabled: true }],
          },
        ],
      });
      break;
    default:
      break;
  }

  switch (sortBy) {
    case "new":
      query = query.sort({ create_date: -1 });
      break;
    case "old":
      query = query.sort({ create_date: 1 });
    case "mostsold":
      break;
    case "leastsold":
      break;
    case "az":
      query = query.sort({ name: 1 });
      break;
    case "za":
      query = query.sort({ name: -1 });
      break;
    default:
      query = query.sort({ create_date: -1 });
  }

  if (onlySelling) {
    query = query.find({ f_sell: true });
  }
  if (keyword != "") {
    query = query.find({
      $or: [
        { name: { $regex: new RegExp(keyword, "ig") } },
        { description: { $regex: new RegExp(keyword, "ig") } },
      ],
    });
  }

  query
    .populate({
      path: "collection_id",
      model: collections,
      populate: [
        {
          path: "author_id",
          model: users,
          select:
            "_id username first_name last_name profile_image metamask_info is_idverified",
        },
      ],
    })
    .populate({ path: "collection_id.author_id", model: users })
    .populate({ path: "category_id", model: category })
    .populate({ path: "catlevel2_id", model: category })
    .populate({ path: "catlevel3_id", model: category })
    .populate({
      path: "current_owner",
      model: users,
      select:
        "_id username first_name last_name profile_image metamask_info is_idverified",
    })
    .populate({
      path: "author_id",
      model: users,
      select:
        "_id username first_name last_name profile_image metamask_info is_idverified",
    });
  var offset = page == "1" ? 0 : parseInt(page - 1) * limit;
  var options = {
    page: page,
    offset: offset,
    limit: limit,
  };
  items.paginate(query, options).then(async (result) => {
    const updatedDocs = await Promise.all(
      result.docs.map(async (d) => {
        // console.log(playLists.some(pl => pl.item_id == d._doc._id && pl.user_id == user_id))

        let total_earning = 0;

        let es_total_earning = 0;
        let es_n_order = 0;
        let es_earn_order = 0;
        let es_n_total_offer = 0;
        let es_n_accepted_offer = 0;
        let es_earn_offer = 0;
        let es_n_rental = 0;
        let es_earn_rental = 0;

        let es_a_n_auction = 0;
        let es_earn_auction = 0;

        let es_a_total_offer = 0;
        let es_a_accept_offer = 0;
        let es_a_earn_offer = 0;
        let es_a_is_closed = false;
        let es_a_total_count = 0;
        var date = new Date();
        if (d._doc.es_enabled) {
          // buy now
          if (!d._doc.es_is_auction) {
            // inventories
            if (d._doc.es_inventories && d._doc.es_inventories.length > 0) {
              const updatedInventories = await Promise.all(
                d._doc.es_inventories.map(async (inv) => {
                  // order count
                  let n_order = 0;
                  let earn_order = 0;
                  let _orders = await transactionModel.find({
                    item_id: d._doc._id,
                    edition: "standard",
                    type: "order",
                  });
                  _orders.map((t) => {
                    if (
                      JSON.stringify(t.option) == JSON.stringify(inv.option)
                    ) {
                      n_order += t.amount;
                      earn_order += t.amount * t.price;
                    }
                  });
                  // offer count
                  let n_total_offer = 0;
                  let n_accepted_offer = 0;
                  let earn_offer = 0;

                  let _offers_from_offer = await offers.find({
                    item_id: d._doc._id,
                    edition: "standard",
                    type: "offer",
                  });
                  _offers_from_offer.map((of) => {
                    if (
                      JSON.stringify(of.option) == JSON.stringify(inv.option)
                    ) {
                      n_total_offer += 1;
                    }
                  });

                  let _offers_from_ts = await transactionModel.find({
                    item_id: d._doc._id,
                    edition: "standard",
                    type: "offer",
                  });

                  _offers_from_ts.map((t) => {
                    if (
                      JSON.stringify(t.option) == JSON.stringify(inv.option)
                    ) {
                      n_accepted_offer += 1;
                      earn_offer += t.amount * t.price;
                    }
                  });

                  return {
                    ...inv._doc,
                    n_order,
                    earn_order,
                    n_total_offer,
                    n_accepted_offer,
                    earn_offer,
                  };
                })
              );

              console.log("updatedDocs standard", updatedInventories);

              d._doc.es_inventories = updatedInventories;
            } else {
              (
                await transactionModel.find({
                  item_id: d._doc._id,
                  edition: "standard",
                  type: "order",
                })
              ).map((t) => {
                es_n_order += 1;
                es_earn_order += t.amount * t.price;
              });

              es_n_total_offer = (
                await offers.find({
                  item_id: d._doc._id,
                  edition: "standard",
                  type: "offer",
                })
              ).length;

              (
                await transactionModel.find({
                  item_id: d._doc._id,
                  edition: "standard",
                  type: "offer",
                })
              ).map((t) => {
                es_n_accepted_offer += 1;
                es_earn_offer += t.amount * t.price;
              });
            }
          } else {
            (
              await transactionModel.find({
                item_id: d._doc._id,
                edition: "standard",
                type: "bid",
              })
            ).map((t) => {
              es_a_n_auction += t.amout;
              es_earn_auction += t.amount * t.price;
            });

            es_a_total_offer = (
              await offers.find({
                item_id: d._doc._id,
                edition: "standard",
                type: "offer",
              })
            ).length;
            (
              await transactionModel.find({
                item_id: d._doc._id,
                edition: "standard",
                type: "offer",
              })
            ).map((t) => {
              es_a_accept_offer += 1;
              es_a_earn_offer = t.amount * t.price;
            });

            // get current bid and bid count
            es_a_is_closed =
              date.getTime() > new Date(d._doc.es_a_endDate).getTime();

            let c_bid = await offers
              .findOne({
                type: "bid",
                item_id: d._doc._id,
                edition: "standard",
                created_date: {
                  $gt: d._doc.es_a_startDate,
                  $lt: d._doc.es_a_endDate,
                },
              })
              .sort({ price: -1 })
              .limit(1)
              .exec();
            var currentbid = c_bid?.price;
            if (currentbid) {
              d._doc.es_a_starting_price = currentbid;
            }

            es_a_total_count = await offers.count({
              type: "bid",
              item_id: d._doc._id,
              edition: "standard",
              created_date: {
                $gt: d._doc.es_a_startDate,
                $lt: d._doc.es_a_endDate,
              },
            });
          }

          // n_rental & rental_earning
          (
            await transactionModel.find({
              item_id: d._doc._id,
              edition: "standard",
              type: "rental",
            })
          ).map((t) => {
            es_n_rental += 1;
            es_earn_rental = t.price;
          });
          // auction
        }

        es_total_earning =
          es_earn_order +
          es_earn_offer +
          es_earn_rental +
          es_earn_auction +
          es_a_earn_offer;

        let ec_total_earning = 0;
        let ec_n_order = 0;
        let ec_earn_order = 0;
        let ec_n_total_offer = 0;
        let ec_n_accepted_offer = 0;
        let ec_earn_offer = 0;
        let ec_n_rental = 0;
        let ec_earn_rental = 0;

        let ec_a_n_auction = 0;
        let ec_earn_auction = 0;

        let ec_a_total_offer = 0;
        let ec_a_accept_offer = 0;
        let ec_a_earn_offer = 0;
        let ec_a_is_closed = false;
        let ec_a_total_count = 0;

        if (d._doc.ec_enabled) {
          // buy now
          if (!d._doc.ec_is_auction) {
            // inventories
            if (d._doc.ec_inventories && d._doc.ec_inventories.length > 0) {
              const updatedInventories = await Promise.all(
                d._doc.ec_inventories.map(async (inv) => {
                  // order count
                  let n_order = 0;
                  let earn_order = 0;
                  let _orders = await transactionModel.find({
                    item_id: d._doc._id,
                    edition: "collective",
                    type: "order",
                  });
                  _orders.map((t) => {
                    if (
                      JSON.stringify(t.option) == JSON.stringify(inv.option)
                    ) {
                      n_order += t.amount;
                      earn_order += t.amount * t.price;
                    }
                  });
                  // offer count
                  let n_total_offer = 0;
                  let n_accepted_offer = 0;
                  let earn_offer = 0;

                  let _offers_from_offer = await offers.find({
                    item_id: d._doc._id,
                    edition: "collective",
                    type: "offer",
                  });
                  _offers_from_offer.map((of) => {
                    if (
                      JSON.stringify(of.option) == JSON.stringify(inv.option)
                    ) {
                      n_total_offer += 1;
                    }
                  });

                  let _offers_from_ts = await transactionModel.find({
                    item_id: d._doc._id,
                    edition: "collective",
                    type: "offer",
                  });

                  _offers_from_ts.map((t) => {
                    if (
                      JSON.stringify(t.option) == JSON.stringify(inv.option)
                    ) {
                      n_accepted_offer += 1;
                      earn_offer += t.amount * t.price;
                    }
                  });

                  return {
                    ...inv._doc,
                    n_order,
                    earn_order,
                    n_total_offer,
                    n_accepted_offer,
                    earn_offer,
                  };
                })
              );

              console.log("updatedDocs collective", updatedInventories);

              d._doc.ec_inventories = updatedInventories;
            } else {
              (
                await transactionModel.find({
                  item_id: d._doc._id,
                  edition: "collective",
                  type: "order",
                })
              ).map((t) => {
                ec_n_order += 1;
                ec_earn_order += t.amount * t.price;
              });

              ec_n_total_offer = (
                await offers.find({
                  item_id: d._doc._id,
                  edition: "collective",
                  type: "offer",
                })
              ).length;

              (
                await transactionModel.find({
                  item_id: d._doc._id,
                  edition: "collective",
                  type: "offer",
                })
              ).map((t) => {
                ec_n_accepted_offer += 1;
                ec_earn_offer += t.amount * t.price;
              });
            }
          } else {
            (
              await transactionModel.find({
                item_id: d._doc._id,
                edition: "collective",
                type: "bid",
              })
            ).map((t) => {
              ec_a_n_auction += t.amout;
              ec_earn_auction += t.amount * t.price;
            });

            ec_a_total_offer = (
              await offers.find({
                item_id: d._doc._id,
                edition: "collective",
                type: "offer",
              })
            ).length;
            (
              await transactionModel.find({
                item_id: d._doc._id,
                edition: "collective",
                type: "offer",
              })
            ).map((t) => {
              ec_a_accept_offer += 1;
              ec_a_earn_offer = t.amount * t.price;
            });

            ec_a_is_closed =
              date.getTime() > new Date(d._doc.ec_a_endDate).getTime();

            let c_bid = await offers
              .findOne({
                type: "bid",
                item_id: d._doc._id,
                edition: "collective",
                created_date: {
                  $gt: d._doc.ec_a_startDate,
                  $lt: d._doc.ec_a_endDate,
                },
              })
              .sort({ price: -1 })
              .limit(1)
              .exec();
            var currentbid = c_bid?.price;
            if (currentbid) {
              d._doc.ec_a_starting_price = currentbid;
            }

            ec_a_total_count = await offers.count({
              type: "bid",
              item_id: d._doc._id,
              edition: "collective",
              created_date: {
                $gt: d._doc.ec_a_startDate,
                $lt: d._doc.ec_a_endDate,
              },
            });
          }

          // n_rental & rental_earning
          (
            await transactionModel.find({
              item_id: d._doc._id,
              edition: "collective",
              type: "rental",
            })
          ).map((t) => {
            ec_n_rental += 1;
            ec_earn_rental = t.price;
          });
          // auction
        }

        ec_total_earning =
          ec_earn_order +
          ec_earn_offer +
          ec_earn_rental +
          ec_earn_auction +
          ec_a_earn_offer;

        let el_total_earning = 0;
        let el_n_order = 0;
        let el_earn_order = 0;
        let el_n_total_offer = 0;
        let el_n_accepted_offer = 0;
        let el_earn_offer = 0;
        let el_n_rental = 0;
        let el_earn_rental = 0;

        let el_a_n_auction = 0;
        let el_earn_auction = 0;

        let el_a_total_offer = 0;
        let el_a_accept_offer = 0;
        let el_a_earn_offer = 0;
        let el_a_is_closed = false;
        let el_a_total_count = 0;

        if (d._doc.el_enabled) {
          // buy now
          if (!d._doc.el_is_auction) {
            // inventories
            if (d._doc.el_inventories && d._doc.el_inventories.length > 0) {
              const updatedInventories = await Promise.all(
                d._doc.el_inventories.map(async (inv) => {
                  // order count
                  let n_order = 0;
                  let earn_order = 0;
                  let _orders = await transactionModel.find({
                    item_id: d._doc._id,
                    edition: "limited",
                    type: "order",
                  });
                  _orders.map((t) => {
                    if (
                      JSON.stringify(t.option) == JSON.stringify(inv.option)
                    ) {
                      n_order += t.amount;
                      earn_order += t.amount * t.price;
                    }
                  });
                  // offer count
                  let n_total_offer = 0;
                  let n_accepted_offer = 0;
                  let earn_offer = 0;

                  let _offers_from_offer = await offers.find({
                    item_id: d._doc._id,
                    edition: "limited",
                    type: "offer",
                  });
                  _offers_from_offer.map((of) => {
                    if (
                      JSON.stringify(of.option) == JSON.stringify(inv.option)
                    ) {
                      n_total_offer += 1;
                    }
                  });

                  let _offers_from_ts = await transactionModel.find({
                    item_id: d._doc._id,
                    edition: "limited",
                    type: "offer",
                  });

                  _offers_from_ts.map((t) => {
                    if (
                      JSON.stringify(t.option) == JSON.stringify(inv.option)
                    ) {
                      n_accepted_offer += 1;
                      earn_offer += t.amount * t.price;
                    }
                  });

                  return {
                    ...inv._doc,
                    n_order,
                    earn_order,
                    n_total_offer,
                    n_accepted_offer,
                    earn_offer,
                  };
                })
              );

              console.log("updatedDocs limited", updatedInventories);

              d._doc.el_inventories = updatedInventories;
            } else {
              (
                await transactionModel.find({
                  item_id: d._doc._id,
                  edition: "limited",
                  type: "order",
                })
              ).map((t) => {
                el_n_order += 1;
                el_earn_order += t.amount * t.price;
              });

              el_n_total_offer = (
                await offers.find({
                  item_id: d._doc._id,
                  edition: "limited",
                  type: "offer",
                })
              ).length;

              (
                await transactionModel.find({
                  item_id: d._doc._id,
                  edition: "limited",
                  type: "offer",
                })
              ).map((t) => {
                el_n_accepted_offer += 1;
                el_earn_offer += t.amount * t.price;
              });
            }
          } else {
            (
              await transactionModel.find({
                item_id: d._doc._id,
                edition: "limited",
                type: "bid",
              })
            ).map((t) => {
              el_a_n_auction += t.amout;
              el_earn_auction += t.amount * t.price;
            });

            el_a_total_offer = (
              await offers.find({
                item_id: d._doc._id,
                edition: "limited",
                type: "offer",
              })
            ).length;
            (
              await transactionModel.find({
                item_id: d._doc._id,
                edition: "limited",
                type: "offer",
              })
            ).map((t) => {
              el_a_accept_offer += 1;
              el_a_earn_offer = t.amount * t.price;
            });

            el_a_is_closed =
              date.getTime() > new Date(d._doc.el_a_endDate).getTime();

            let c_bid = await offers
              .findOne({
                type: "bid",
                item_id: d._doc._id,
                edition: "limited",
                created_date: {
                  $gt: d._doc.el_a_startDate,
                  $lt: d._doc.el_a_endDate,
                },
              })
              .sort({ price: -1 })
              .limit(1)
              .exec();
            var currentbid = c_bid?.price;
            if (currentbid) {
              d._doc.el_a_starting_price = currentbid;
            }

            el_a_total_count = await offers.count({
              type: "bid",
              item_id: d._doc._id,
              edition: "limited",
              created_date: {
                $gt: d._doc.el_a_startDate,
                $lt: d._doc.el_a_endDate,
              },
            });
          }
          // auction

          // n_rental & rental_earning
          (
            await transactionModel.find({
              item_id: d._doc._id,
              edition: "limited",
              type: "rental",
            })
          ).map((t) => {
            el_n_rental += 1;
            el_earn_rental = t.price;
          });
        }

        el_total_earning =
          el_earn_order +
          el_earn_offer +
          el_earn_rental +
          el_earn_auction +
          el_a_earn_offer;

        total_earning = es_total_earning + ec_total_earning + el_total_earning;

        return {
          ...d._doc, // copy all the existing fields
          total_earning,
          es_total_earning,
          es_n_order,
          es_earn_order,
          es_n_total_offer,
          es_n_accepted_offer,
          es_earn_offer,

          es_n_rental,
          es_earn_rental,

          es_a_n_auction,
          es_earn_auction,
          es_a_is_closed,
          es_a_total_count,

          es_a_total_offer,
          es_a_accept_offer,
          es_a_earn_offer,

          ec_total_earning,
          ec_n_order,
          ec_earn_order,
          ec_n_total_offer,
          ec_n_accepted_offer,
          ec_earn_offer,
          ec_n_rental,
          ec_earn_rental,

          ec_a_n_auction,
          ec_earn_auction,
          ec_a_is_closed,
          ec_a_total_count,

          ec_a_total_offer,
          ec_a_accept_offer,
          ec_a_earn_offer,

          el_total_earning,
          el_n_order,
          el_earn_order,
          el_n_total_offer,
          el_n_accepted_offer,
          el_earn_offer,
          el_n_rental,
          el_earn_rental,

          el_a_n_auction,
          el_earn_auction,
          el_a_is_closed,
          el_a_total_count,

          el_a_total_offer,
          el_a_accept_offer,
          el_a_earn_offer,
        };
      })
    );

    const updatedResult = { ...result, docs: updatedDocs };

    res.json({
      status: true,
      message: "retrived successfully",
      // data: updatedResult,
      data: updatedResult,
    });
  });
};

// get library items
exports.get_library_items = function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded.user_id;
  var cat1 = req.query.cat1,
    cat2 = req.query.cat2,
    cat3 = req.query.cat3,
    keyword = req.query.keyword || "",
    page = req.query.page || 1,
    limit = req.query.limit || 15,
    edition = req.query.edition,
    sortKey = req.query.sortKey,
    rel_date = req.query.rel_date,
    rel_date_from = req.query.rel_date_from,
    rel_date_to = req.query.rel_date_to;

  var query = items.find({ current_owner: user_id });
  if (cat1) query = query.find({ category_id: cat1 });
  if (cat2) query = query.find({ catlevel2_id: cat2 });
  if (cat3) query = query.find({ catlevel3_id: cat3 });

  if (keyword != "")
    query.find({
      $or: [
        { name: { $regex: new RegExp(keyword, "ig") } },
        { description: { $regex: new RegExp(keyword, "ig") } },
      ],
    });
  // filter by edition
  switch (edition) {
    case "standard":
      query = query.find({ es_enabled: true });
      break;
    case "collective":
      query = query.find({ ec_enabled: true });
      break;
    case "limited":
      query = query.find({ el_enabled: true });
      break;
    default:
      break;
  }
  // sort
  switch (sortKey) {
    case "new":
      query = query.sort("-created_date");
      break;
    case "old":
      query = query.sort("created_date");
      break;
    case "newrel":
      query = query.sort("-released_date");
      break;
    case "az":
      query = query.sort("-name");
      break;
    case "za":
      query = query.sort("name");
      break;
    default:
      break;
  }

  query = query
    .populate({ path: "collection_id", model: collections })
    .populate({ path: "category_id", model: category })
    .populate({ path: "catlevel2_id", model: category })
    .populate({ path: "catlevel3_id", model: category })
    .populate({
      path: "current_owner",
      model: users,
      select:
        "_id username first_name last_name profile_image metamask_info is_idverified",
    })
    .populate({
      path: "author_id",
      model: users,
      select:
        "_id username first_name last_name profile_image metamask_info is_idverified",
    })
    .populate({ path: "season_id", model: "seasons" });

  var offset = page == "1" ? 0 : parseInt(page - 1) * limit;
  var options = {
    page: page,
    offset: offset,
    limit: limit,
  };

  items.paginate(query, options).then(function (result) {
    res.json({
      status: true,
      message: "items retrieved successfully",
      data: result,
    });
  });
};

// get contents for home

exports.get_home_content = async function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded.user_id;
  // 20240122am2 CoderB "(B)show all posts : Home,Discover,Fanpage"
  page = req.query.page || 1,
  limit = req.query.limit || 15;
  try {
    var keyword = req.query.keyword || "";
    var filterBy = req.query.filterBy;
    var type = req.query.type;
    let start_date = new Date(new Date().setMonth(new Date().getMonth() - 1));

    // let _reactions = await fanpostReactionModel.find();
    // let _comments = await fanpostCommentModel.find({ parent_id: null });
    // let _loves = await fanpostLoveModel.find();
    // let _boosts = await fanpostShareModel.find();

    // let reactions = await item_reactions.find();
    // let playLists = await item_plays.find();
    // let comments = await item_comments.find({ parent_id: null });
    // let likes = await item_likes.find();
    // let loves = await item_loves.find();
    // let boosts = await fanpostShareModel.find({ type: 'item', user_id });

    const [_reactions, _comments, _loves, _boosts,
      me_follow_users, my_following_users,
      my_subscribers,
      muted_accounts, blocked_accounts,
      _subscribers,
      _fandoms1,
      users_with_fans, users_with_superfans,
      reactions, playLists, comments, likes, loves, boosts
    ] = await Promise.all([
      await fanpostReactionModel.find(),
      await fanpostCommentModel.find({ parent_id: null }),
      await fanpostLoveModel.find(),
      await fanpostShareModel.find(),

      await followers.find({ star_id: user_id }),
      await followers.find({ user_id }),

      await subscriberModel
        .find({ user_id, start_date: { $gte: start_date }, unsubscribed: false })
        .populate({ path: "subscription_id" }),

      (await muteModel.find({ user_id }))?.map(d => d.mute_user_id),
      (await blockModel.find({ user_id }))?.map(d => d.block_user_id),

      (await subscriberModel.find({
        unsubscribed: false,
        start_date: { $gte: start_date },
        user_id
      }))?.map(d => d?.subscription_id),

      await fandomModel.find({ status: "published" }),
      (
        await subscriptionlevelModel.find({ level: "basic" })
      ).map((d) => d.user_id),
      (
        await subscriptionlevelModel.find({ level: "super" })
      ).map((d) => d.user_id),

      await item_reactions.find(),
      await item_plays.find(),
      await item_comments.find({ parent_id: null }),
      await item_likes.find(),
      await item_loves.find(),
      await fanpostShareModel.find({ type: 'item', user_id }),
    ]
    );
    // what I joined the subscription level
    // var my_subscribers = await subscriberModel
    //   .find({ user_id, start_date: { $gte: start_date }, unsubscribed: false })
    //   .populate({ path: "subscription_id" });
    // var me_follow_users = await followers.find({ star_id: user_id });
    // var my_following_users = await followers.find({ user_id });
    // var _subscribers = (await subscriberModel.find({
    //   unsubscribed: false,
    //   start_date: { $gte: start_date },
    //   user_id
    // }))?.map(d => d?.subscription_id);


    // let muted_accounts = (await muteModel.find({ user_id }))?.map(d => d.mute_user_id);
    // let blocked_accounts = (await blockModel.find({ user_id }))?.map(d => d.block_user_id);
    // block_accounts = [...blocked_accounts, ...(await blockModel.find({ block_user_id: user_id }))?.map(d => d.user_id)];

    var _fandoms = _fandoms1;//await fandomModel.find({ status: "published" });
    // let users_with_fans = (
    //   await subscriptionlevelModel.find({ level: "basic" })
    // ).map((d) => d.user_id);
    // let users_with_superfans = (
    //   await subscriptionlevelModel.find({ level: "super" })
    // ).map((d) => d.user_id);


    var from_users = [];



    switch (type) {
      case "For you":
        from_users = my_following_users.map((d) => d.star_id);
        break;
      case "Following you":
        from_users = me_follow_users.map((d) => d.user_id);
        break;
      case "Fans":
        from_users = my_subscribers
          .filter((d) => d.subscription_id?.level == "basic")
          .map((d) => d.subscription_id?.user_id?.toString());
        break;
      case "Superfans":
        from_users = my_subscribers
          .filter((d) => d.subscription_id?.level == "super")
          .map((d) => d.subscription_id?.user_id?.toString());
        break;
      case "Fandoms":
        var user_ids = (await subscriptionlevelModel.find({ _id: { $in: _subscribers } }))?.map(d => d.user_id);
        from_users = (await fandomModel.find({ user_id: { $in: user_ids }, status: 'published' }))?.map(d => d.user_id);
        break;
      default:
        break;
    }

    var lists = [];

    try {
      if (
        filterBy == "Everything" ||
        filterBy == "Only posts with pictures" ||
        filterBy == "Only posts with videos" ||
        filterBy == "Only posts"
      ) {
        let query = fanpostModel
          .find({
            author_id: {
              $in: from_users,
              $nin: [...blocked_accounts, ...muted_accounts],
            }
          })
          .sort({ create_date: -1, priority: -1 })
          .limit(100);
        if (keyword && keyword != "") {
          query = query.find({
            $or: [
              { description: { $regex: new RegExp(keyword, "ig") } },
              { fanpost_poll_question: { $regex: new RegExp(keyword, "ig") } },
            ],
          });
        }



        // don't display content when fandom is not published
        _fandoms = _fandoms.map((d) => {
          return d.user_id;
        });
        query = query.find({ creator_id: { $in: _fandoms } });

        // don't display content depend on subscription levels
        let filter_ids_by_super = (
          await fanpostModel.find({
            creator_id: {
              $nin: users_with_superfans,
            },
            $or: [{ is_view_only: "superfans" }, { is_relay_only: "superfans" }],
          })
        ).map((d) => d._id);

        let filter_ids_by_basic = (
          await fanpostModel.find({
            $and: [
              { creator_id: { $nin: users_with_fans } },
              { creator_id: { $nin: users_with_superfans } },
            ],
            $or: [{ is_view_only: "fans" }, { is_relay_only: "fans" }],
          })
        ).map((d) => d._id);


        if (filterBy == "Only posts with pictures") {

          query = query.find({
            $and: [
              {
                $or: [
                  { fanpost_image: { $exists: true, $ne: "" } },
                  { fanpost_images: { $exists: true, $not: { $size: 0 } } },
                ],
                $and: [
                  { _id: { $nin: filter_ids_by_basic } },
                  { _id: { $nin: filter_ids_by_super } },
                ]
              },

            ]
          });
        }
        if (filterBy == "Only posts with videos") {
          _query = [
            { fanpost_video: { $ne: "" } },
            { fanpost_video: { $ne: null } },
          ]
          query = query.find({
            $and: [
              { fanpost_video: { $ne: "" } },
              { fanpost_video: { $ne: null } },
              { _id: { $nin: filter_ids_by_basic } },
              { _id: { $nin: filter_ids_by_super } },
            ]
          });
        }


        query = query.populate({
          path: "author_id",
          model: "users",
          // 20240113pm5 CoderB "(c ) whole site > verified icon use this spacing "
          // select: "_id first_name last_name username profile_image",
          select: "_id first_name last_name username profile_image is_idverified",
        });

        let result = await query.exec();
        const updatedDocsPromises = result.map(async (d) => {
          let _members = await memberModel.find({ star_id: (d._doc?.creator_id || d.creator_id) });
          let _fans = await fanModel.find({ star_id: (d._doc?.creator_id || d.creator_id) });
          let _followers = await followerModel.find({ star_id: (d._doc?.creator_id || d.creator_id) });
          let _followings = await followerModel.find({ star_id: user_id });

          let isFan = _fans.some((f) => f.user_id == user_id);
          let membership;
          if (isFan) {
            let _memberships = await subscriptionlevelModel.find({
              user_id: d._doc?.creator_id,
            });
            _memberships.map((d) => {
              return d._id;
            });
            var _start_date = new Date();
            _start_date.setMonth(_start_date.getMonth() - 1);
            membership = await subscriberModel
              .findOne({
                user_id: user_id,
                subscription_id: { $in: _memberships },
                unsubscribed: false,
                start_date: { $gte: _start_date },
              })
              .populate("subscription_id");
          }
          let InfoForUser = {
            isMember: _members.some((m) => m.user_id == user_id),
            isFan: isFan,
            membership: membership,
            isFollower: _followers.some((f) => f.user_id == user_id),
            isFollowing: _followings.some(
              (f) => f.user_id?.toString() == d._doc?.creator_id?.toString()
            ),
          };

          const itemReactions = _reactions.filter(
            (r) => r.fanpost_id == d._id.toString() && r.user_id == user_id
          );
          const reactionNumber = itemReactions.length
            ? itemReactions[0].reaction_number
            : -1;

          var _db_follower = await followers.findOne({
            star_id: d._doc?.author_id?._id,
            user_id: user_id,
          });

          //!!20231231 CoderA SpeedUp
          // var _db_block = await blockModel.findOne({
          //   block_user_id: d._doc?.author_id?._id,
          //   user_id: user_id,
          // });
          // var _db_mute = await muteModel.findOne({
          //   mute_user_id: d._doc?.author_id?._id,
          //   user_id: user_id,
          // });
          return {
            __type: "post",
            ...d.toObject(), // copy all the existing fields
            reaction_number: reactionNumber,
            isCommented: _comments.some(
              (pl) => pl.fanpost_id == d._id.toString() && pl.user_id == user_id
            ),
            isLoved: _loves.some(
              (pl) => pl.fanpost_id == d._id.toString() && pl.user_id == user_id
            ),
            isBoosted: _boosts.some(
              (pl) => pl.item_id == d._id.toString() && pl.user_id == user_id // edited by coderD db collection field name fix
            ),
            InfoForUser: InfoForUser,
            serverDate: new Date(),
            isFollow: _db_follower ? true : false,
            isBlock: d._doc?.author_id?.block_list?.includes(user_id), //!!_db_block ? true : false,
            isMute: d._doc?.author_id?.mute_list?.includes(user_id),//!!_db_mute ? true : false,
            // isBlock: _db_block ? true : false,
            // isMute: _db_mute ? true : false,
          };
        });
        const updatedResult = await Promise.all(updatedDocsPromises);
        lists = [...updatedResult];
      }
      // for item
      if (true) {
        //!!20231231 CoderA SpeedUp
        // let reactions = await item_reactions.find();
        // let playLists = await item_plays.find();
        // let comments = await item_comments.find({ parent_id: null });
        // let likes = await item_likes.find();
        // let loves = await item_loves.find();
        // let boosts = await fanpostShareModel.find({ type: 'item', user_id });

        let query;
        if (filterBy == "Everything") {
          query = items.find({
            author_id: {
              $in: from_users,
              $nin: [...blocked_accounts, ...muted_accounts],
            },
            original_id: null,
          });
        } else {
          query = items.find({
            author_id: { $in: from_users },
            original_id: null,
          });
          let cat;
          switch (filterBy) {
            case "Only music":
              cat = (await category.findOne({ title: "Music", level: 1 }))?._id;
              console.log('Only music', await category.findOne({ title: "Music", level: 1 }));
              console.log('Only music', cat);
              query = query.find({ category_id: cat });
              break;
            case "Only podcasts":
              cat = (await category.findOne({ title: "Podcasts", level: 1 }))?._id;
              query = query.find({ category_id: cat });
              break;
            case "Only comedy gigs":
              cat = (await category.findOne({ title: "Comedy gigs", level: 1 }))?._id;
              query = query.find({ category_id: cat });
              break;
            case "Only audiobooks":
              cat = (await category.findOne({ title: "Audiobooks", level: 1 }))?._id;
              query = query.find({ category_id: cat });
              break;
            case "Only movies":
              cat = (await category.findOne({ title: "Movies", level: 1 }))?._id;
              query = query.find({ category_id: cat });
              break;
            case "Only tv series":
              cat = (await category.findOne({ title: "TV Series", level: 1 }))?._id;
              query = query.find({ category_id: cat });
              break;
            case "Only marketplace":
              let merchandiseCat = await category.find({
                level: 1,
                type: "Merchandise",
              });
              let mIds = merchandiseCat.map((d) => d._id);
              console.log("mIds");
              console.log(mIds);
              query = query.find({ category_id: { $in: mIds } });
              break;
            default:
              query = null;
              break;
          }
          if (cat) {
            query = query.find({ category_id: cat });
          }
        }

        if (query != null) {
          query = query.sort({ create_date: -1 });
          if (keyword && keyword != "")
            query = query.find({
              $or: [
                { name: { $regex: new RegExp(keyword, "ig") } },
                { description: { $regex: new RegExp(keyword, "ig") } },
              ],
            });
          query = query.limit(100);

          query = query
            .populate({ path: "collection_id", model: collections })
            .populate({ path: "category_id", model: category })
            .populate({ path: "catlevel2_id", model: category })
            .populate({ path: "catlevel3_id", model: category })
            .populate({ path: "artist", model: artistModel })
            .populate({
              path: "current_owner",
              model: users,
              select:
                "_id username first_name last_name profile_image metamask_info is_idverified",
            })
            .populate({
              path: "author_id",
              model: users,
              select:
                "_id username first_name last_name profile_image metamask_info is_idverified",
            })
            .populate({ path: "season_id", model: "seasons" });
            let result = await query.exec();
          const updatedDocsPromises = result.map(async (d) => {
            const itemReactions = reactions.filter(
              (r) => r.item_id == d._doc._id.toString() && r.user_id == user_id
            );
            const reactionNumber = itemReactions.length
              ? itemReactions[0].reaction_number
              : -1;

            // check whether this is exited in up to next
            const up_to_next = await playerModel.findOne({
              item_id: d?._doc?._id?.toString(),
              user_id,
            });

            // check is follower, mute, block
            var _db_follower = await followers.findOne({
              star_id: d._doc?.author_id?._id,
              user_id: user_id,
            });

            //!!20231231 CoderA SpeedUp
            // var _db_block = await blockModel.findOne({
            //   block_user_id: d._doc?.author_id?._id,
            //   user_id: user_id,
            // });
            // var _db_mute = await muteModel.findOne({
            //   mute_user_id: d._doc?.author_id?._id,
            //   user_id: user_id,
            // });

            var date = new Date();
            // get restructure item to decide the buy now and auction is finished or not
            if (d.es_enabled) {
              if (!d.es_is_auction) {
                if (d.es_enventories?.length > 0) {
                } else {
                  if (d.es_b_limited && d.es_n_sell == 0) {
                    d.es_enabled = false;
                  }
                  if (d.es_b_endMode == "noend") {
                  } else {
                    if (new Date(d.es_b_endDate).getTime() < date.getTime()) {
                      d.es_enabled = false;
                    }
                  }
                }
              } else {
                // check auction is finished or not
                if (new Date(d.es_a_endDate).getTime() < date.getTime()) {
                  d.es_enabled = false;
                }
                // if not
                if (d.es_enabled) {
                  // get the current bid
                  let c_bid = await offers
                    .findOne({
                      type: "bid",
                      item_id: d._id,
                      edition: "standard",
                    })
                    .sort({ price: -1 })
                    .limit(1)
                    .exec();
                  var currentbid = c_bid?.price;
                  if (currentbid) {
                    d.es_a_starting_price = currentbid;
                  }
                }
              }
            }

            if (d.ec_enabled) {
              if (!d.ec_is_auction) {
                if (d.ec_enventories?.length > 0) {
                } else {
                  if (d.ec_b_limited && d.ec_n_sell == 0) {
                    d.ec_enabled = false;
                  }
                  if (d.ec_b_endMode == "noend") {
                  } else {
                    if (new Date(d.ec_b_endDate).getTime() < date.getTime()) {
                      d.ec_enabled = false;
                    }
                  }
                }
              } else {
                // check auction is finished or not
                if (new Date(d.ec_a_endDate).getTime() < date.getTime()) {
                  d.ec_enabled = false;
                }
                // if not
                if (d.ec_enabled) {
                  // get the current bid
                  let c_bid = await offers
                    .findOne({
                      type: "bid",
                      item_id: d._id,
                      edition: "collective",
                    })
                    .sort({ price: -1 })
                    .limit(1)
                    .exec();
                  var currentbid = c_bid?.price;
                  if (currentbid) {
                    d.ec_a_starting_price = currentbid;
                  }
                }
              }
            }

            if (d.el_enabled) {
              if (!d.el_is_auction) {
                if (d.el_enventories?.length > 0) {
                } else {
                  if (
                    (d.el_b_limited && d.el_n_sell == 0) ||
                    d.el_n_now_sell == 0
                  ) {
                    d.el_enabled = false;
                  }
                  if (d.el_endMode == "noend") {
                  } else {
                    if (new Date(d.el_b_endDate).getTime() < date.getTime()) {
                      d.el_enabled = false;
                    }
                  }
                }
              } else {
                // check auction is finished or not
                if (new Date(d.el_a_endDate).getTime() < date.getTime()) {
                  d.el_enabled = false;
                }
                // if not
                if (d.el_enabled) {
                  // get the current bid
                  let c_bid = await offers
                    .findOne({
                      type: "bid",
                      item_id: d._id,
                      edition: "limited",
                    })
                    .sort({ price: -1 })
                    .limit(1)
                    .exec();
                  var currentbid = c_bid?.price;
                  if (currentbid) {
                    d.el_a_starting_price = currentbid;
                  }
                }
              }
            }

            return {
              ...d.toObject(), // copy all the existing fields
              __type: "item",
              reaction_number: reactionNumber,
              isPlayed: playLists.some(
                (pl) =>
                  pl.item_id == d._doc._id.toString() && pl.user_id == user_id
              ),
              isCommented: comments.some(
                (pl) =>
                  pl.item_id == d._doc._id.toString() && pl.user_id == user_id
              ),
              isLiked: likes.some(
                (pl) =>
                  pl.item_id == d._doc._id.toString() && pl.user_id == user_id
              ),
              isLoved: loves.some(
                (pl) =>
                  pl.item_id == d._doc._id.toString() && pl.user_id == user_id
              ),
              isBoosted: boosts.some(
                (pl) =>
                  pl.item_id == d._doc._id.toString() && pl.user_id == user_id
              ),
              isUptoNext: up_to_next ? true : false,
              isFollow: _db_follower ? true : false,
              isBlock: d._doc?.author_id?.block_list?.includes(user_id), //!!_db_block ? true : false,
              isMute: d._doc?.author_id?.mute_list?.includes(user_id),//!!_db_mute ? true : false,  
              // isBlock: _db_block ? true : false,//!!20231231 CoderA SpeedUp
              // isMute: _db_mute ? true : false,//!!20231231 CoderA SpeedUp
            };
          });
          const updatedResult = await Promise.all(updatedDocsPromises);
          lists = [...lists, ...updatedResult];
        
         
         
        }
      }

      // for short
      // if (filterBy == "Only shorts" || filterBy == "Everthing") {
      //   let reactions = await partyReactionModel.find();
      //   let playLists = await partyPlayModel.find();
      //   let comments = await partyCommentModel.find({ parent_id: null });
      //   let likes = await partyLikeModel.find();
      //   let loves = await partyLoveModel.find();
      //   let boosts = []; // this will be added later

      //   let query = partyModel.find({ creator_id: { $in: from_users } });
      //   query = query.sort({ create_date: -1 });
      //   if (keyword && keyword != "")
      //     query = query.find({
      //       $or: [
      //         { name: { $regex: new RegExp(keyword, "ig") } },
      //         { description: { $regex: new RegExp(keyword, "ig") } },
      //       ],
      //     });
      //   query = query.limit(100);
      //   query = query.populate({
      //     path: "creator_id",
      //     model: users,
      //     select: "_id username first_name last_name profile_image is_idverified",
      //   });

      //   let result = await query.exec();

      //   const updatedDocsPromises = result.map((d) => {
      //     // console.log(playLists.some(pl => pl.party_id == d._doc._id && pl.user_id == user_id))
      //     const partyReactions = reactions.filter(
      //       (r) => r.party_id == d._doc._id.toString() && r.user_id == user_id
      //     );
      //     const reactionNumber = partyReactions.length
      //       ? partyReactions[0].reaction_number
      //       : -1;
      //     return {
      //       ...d.toObject(), // copy all the existing fields
      //       __type: "short",
      //       reaction_number: reactionNumber,
      //       isPlayed: playLists.some(
      //         (pl) =>
      //           pl.party_id == d._doc._id.toString() && pl.user_id == user_id
      //       ),
      //       isCommented: comments.some(
      //         (pl) =>
      //           pl.party_id == d._doc._id.toString() && pl.user_id == user_id
      //       ),
      //       isLiked: likes.some(
      //         (pl) =>
      //           pl.party_id == d._doc._id.toString() && pl.user_id == user_id
      //       ),
      //       isLoved: loves.some(
      //         (pl) =>
      //           pl.party_id == d._doc._id.toString() && pl.user_id == user_id
      //       ),
      //       isBoosted: boosts.some(
      //         (pl) =>
      //           pl.party_id == d._doc._id.toString() && pl.user_id == user_id
      //       ),
      //     };
      //   });

      //   const updatedResult = await Promise.all(updatedDocsPromises);
      //   lists = [...lists, ...updatedResult];
      // }

      if (filterBy == "Only LIVE now" || filterBy == "Everthing") {
        let query = livenowModel.find({
          user_id: {
            $in: from_users,
            $nin: [...blocked_accounts, ...muted_accounts],
          }
        });
        query = query.sort({ create_date: -1 });
        query = query.find({ status: { $in: ["online", "away", "beback"] } });
        if (keyword && keyword != "") {
          query = query.find({
            description: { $regex: new RegExp(keyword, "ig") },
          });
        }
        query = query.sort({ created_date: -1 });

        query = query.limit(100);
        query = query.populate({
          path: "user_id",
          model: "users",
          select: "_id first_name last_name username profile_image is_idverified",
        });
        query = query.populate({
          path: "user_id",
          model: "users",
          select: "_id first_name last_name username profile_image is_idverified",
        });
        query = query.populate({
          path: "co_hosts",
          model: "users",
          select: "_id first_name last_name username profile_image is_idverified",
        });
        query = query.populate({
          path: "guests",
          model: "users",
          select: "_id first_name last_name username profile_image is_idverified",
        });
        query = query.populate({
          path: "onlines.user_id",
          model: "users",
          select: "_id first_name last_name username profile_image is_idverified",
        });

        let result = (await query.exec()).map((d) => ({
          ...d.toObject(),
          __type: "livenow",
        }));
        lists = [...lists, ...result];
      }
        // 20240122am2 CoderB
            var offset = page == "1" ? 0 : parseInt(page - 1) * limit;
           
      let totalPages = Math.ceil(lists.length / limit);
      lists = lists
        .sort(
          (a, b) =>
            (b.create_date || b.created_date) - (a.create_date || a.created_date)
        )
        // 20240121pm6 CoderB "(B) home - not all posts are showing "
        // .slice(0, 30); 

      res.json({
        status: true,
        message: "Retrived successfully",
        // 20240122am2 CoderB "(B)show all posts : Home,Discover,Fanpage"
        // result: lists,
          result:lists.slice(offset,Number(offset+limit)),
        totalPages
      });
    } catch (e) {
      console.log(e);
      res.json({
        status: false,
        message: e?.message,
      });
    }
  } catch (error) {
    console.log(e);
    res.json({
      status: false,
      message: error?.message,
    });
  }

};

exports.get_favorite_digital_item = async function (req, res) {
  console.log(getErrLine().str, "apistart");
  let user_id = req.decoded.user_id;
  let keyword = req.query.keyword;
  let show = req.query.show;
  let sort = req.query.sort;
  // get digital categories
  try {
    let blocked_accounts = [
      ...(await blockModel.find({ user_id }))?.map(d => d.block_user_id),
      ...(await blockModel.find({ block_user_id: user_id }))?.map(d => d.user_id),
    ]
    let categories = (await category.find({ type: "Digital", level: 1 })).map(
      (d) => d._id
    );
    let loves_id = (await item_loves.find({ user_id })).map((d) => d.item_id);
    let query = items
      .find({ category_id: { $in: categories }, _id: { $in: loves_id }, author_id: { $nin: blocked_accounts } })
      .sort({ create_date: -1 });
    if (keyword && keyword.trim() != "") {
      let search = {
        $or: [
          {
            name: {
              $regex: new RegExp(keyword, "ig"),
            },
          },
          {
            description: {
              $regex: new RegExp(keyword, "ig"),
            },
          },
        ],
      };
      query = query.or(search);
    }
    let _items = await query
      .populate({
        path: "author_id",
        model: "users",
        select: "_id first_name last_name username profile_image",
      })
      .exec();
    res.json({
      status: true,
      message: "data retrived successfully",
      result: _items,
    });
  } catch (error) {
    console.log(error);
    res.json({
      status: false,
      message: "Somethign went wrong",
    });
  }
};

// get all digital items, merchandise items,

exports.get_all = async function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded.user_id;
  var keyword = req.query.keyword;
  var page = req.query.page || 1;
  var limit = req.query.limit || 15;

  try {
    let lists = [];

    // get items
    let itemsQuery = items
      .find({ author_id: user_id })
      .sort({ create_date: -1 });
    itemsQuery = itemsQuery
      .populate({ path: "collection_id", model: collections })
      .populate({ path: "category_id", model: category })
      .populate({ path: "catlevel2_id", model: category })
      .populate({ path: "catlevel3_id", model: category })
      .populate({
        path: "current_owner",
        model: users,
        select:
          "_id username first_name last_name profile_image metamask_info is_idverified",
      })
      .populate({
        path: "author_id",
        model: users,
        select:
          "_id username first_name last_name profile_image metamask_info is_idverified",
      })
      .populate({ path: "season_id", model: "seasons" });

    if (keyword != "")
      itemsQuery.find({
        $or: [
          { name: { $regex: new RegExp(keyword, "ig") } },
          { description: { $regex: new RegExp(keyword, "ig") } },
        ],
      });

    itemsList = await itemsQuery.exec();
    itemsList = await Promise.all(
      itemsList.map(async (d) => {
        var date = new Date();
        if (d._doc.es_enabled) {
          if (!d._doc.es_is_auction) {
            if (d._doc.es_enventories?.length > 0) {
            } else {
              if (d._doc.es_b_limited && d._doc.es_n_sell == 0) {
                d._doc.es_enabled = false;
              }
              if (d._doc.es_b_endMode == "noend") {
              } else {
                if (new Date(d._doc.es_b_endDate).getTime() < date.getTime()) {
                  d._doc.es_enabled = false;
                }
              }
            }
          } else {
            // check auction is finished or not
            if (new Date(d._doc.es_a_endDate).getTime() < date.getTime()) {
              d._doc.es_enabled = false;
            }
            // if not
            if (d._doc.es_enabled) {
              // get the current bid
              let c_bid = await offers
                .findOne({
                  type: "bid",
                  item_id: d._doc._id,
                  edition: "standard",
                })
                .sort({ price: -1 })
                .limit(1)
                .exec();
              var currentbid = c_bid?.price;
              if (currentbid) {
                d._doc.es_a_starting_price = currentbid;
              }
            }
          }
        }

        if (d._doc.ec_enabled) {
          if (!d._doc.ec_is_auction) {
            if (d._doc.ec_enventories?.length > 0) {
            } else {
              if (d._doc.ec_b_limited && d._doc.ec_n_sell == 0) {
                d._doc.ec_enabled = false;
              }
              if (d._doc.ec_b_endMode == "noend") {
              } else {
                if (new Date(d._doc.ec_b_endDate).getTime() < date.getTime()) {
                  d._doc.ec_enabled = false;
                }
              }
            }
          } else {
            // check auction is finished or not
            if (new Date(d._doc.ec_a_endDate).getTime() < date.getTime()) {
              d._doc.ec_enabled = false;
            }
            // if not
            if (d._doc.ec_enabled) {
              // get the current bid
              let c_bid = await offers
                .findOne({
                  type: "bid",
                  item_id: d._doc._id,
                  edition: "collective",
                })
                .sort({ price: -1 })
                .limit(1)
                .exec();
              var currentbid = c_bid?.price;
              if (currentbid) {
                d._doc.ec_a_starting_price = currentbid;
              }
            }
          }
        }

        if (d._doc.el_enabled) {
          if (!d._doc.el_is_auction) {
            if (d._doc.el_enventories?.length > 0) {
            } else {
              if (
                (d._doc.el_b_limited && d._doc.el_n_sell == 0) ||
                d._doc.el_n_now_sell == 0
              ) {
                d._doc.el_enabled = false;
              }
              if (d._doc.el_endMode == "noend") {
              } else {
                if (new Date(d._doc.el_b_endDate).getTime() < date.getTime()) {
                  d._doc.el_enabled = false;
                }
              }
            }
          } else {
            // check auction is finished or not
            if (new Date(d._doc.el_a_endDate).getTime() < date.getTime()) {
              d._doc.el_enabled = false;
            }
            // if not
            if (d._doc.el_enabled) {
              // get the current bid
              let c_bid = await offers
                .findOne({
                  type: "bid",
                  item_id: d._doc._id,
                  edition: "limited",
                })
                .sort({ price: -1 })
                .limit(1)
                .exec();
              var currentbid = c_bid?.price;
              if (currentbid) {
                d._doc.el_a_starting_price = currentbid;
              }
            }
          }
        }
        return {
          ...d._doc,
          __type: "item",
        };
      })
    );
    lists = [...lists, ...itemsList];

    // collections
    let collectionQuery = collections
      .find({ user_id })
      .sort({ create_date: -1 });
    if (keyword != "")
      collectionQuery.find({
        $or: [
          { name: { $regex: new RegExp(keyword, "ig") } },
          { description: { $regex: new RegExp(keyword, "ig") } },
        ],
      });
    collectionQuery = collectionQuery.populate({
      path: "user_id",
      model: "users",
      select: "_id first_name last_name username profile_image is_idverified",
    });
    let collectionLists = await collectionQuery.exec();
    collectionLists = collectionLists.map((d) => {
      return {
        ...d._doc,
        __type: "collection",
      };
    });
    lists = [...lists, ...collectionLists];

    // get post
    let postsQuery = fanpostModel
      .find({ creator_id: user_id })
      .sort({ create_date: -1, priority: -1 });
    if (keyword != "") {
      postsQuery.find({
        $or: [
          { description: { $regex: new RegExp(keyword, "ig") } },
          { fanpost_poll_question: { $regex: new RegExp(keyword, "ig") } },
        ],
      });
    }
    postsQuery.populate({
      path: "author_id",
      model: "users",
      select: "_id username first_name last_name profile_image metamask_info",
    });

    postsList = await postsQuery.exec();
    postsList = postsList.map((d) => {
      return {
        ...d._doc,
        __type: "post",
      };
    });
    lists = [...lists, ...postsList];

    // fandom
    let fandomsQuery = fandomModel.find({ user_id }).sort({ created_date: -1 });
    if (keyword != "") {
      fandomsQuery = fandomsQuery.find({
        $or: [
          { name: { $regex: new RegExp(keyword, "ig") } },
          { description: { $regex: new RegExp(keyword, "ig") } },
        ],
      });
    }
    let fandomsList = await fandomsQuery.exec();
    const updatedfandomList = await Promise.all(
      fandomsList.map(async (d) => {
        let n_posts = await fanpostModel.count({ creator_id: d?.user_id?._id });
        // let n_fans = await fans.count({ star_id: d?.user_id?._id })

        var date = new Date(new Date().setMonth(new Date().getMonth() - 1));

        var my_subscribers = await subscriberModel
          .find({ user_id, start_date: { $gte: date }, unsubscribed: false })
          .populate({ path: "subscription_id" });
        var your_fans = my_subscribers
          .filter((d) => d.subscription_id?.level == "basic")
          .map((d) => {
            d.subscription_id?.user_id;
          });
        var your_superfans = my_subscribers
          .filter((d) => d.subscription_id?.level == "super")
          .map((d) => {
            d.subscription_id?.user_id;
          });

        let n_pictures = await fanpostModel.count({
          creator_id: d?.user_id?._id,
          $or: [
            { fanpost_image: { $exists: true, $ne: "" } },
            { fanpost_images: { $exists: true, $not: { $size: 0 } } },
          ],
        });

        let n_videos = await fanpostModel.count({
          creator_id: d?.user_id?._id,
          $and: [
            { fanpost_video: { $ne: "" } },
            { fanpost_video: { $ne: null } },
          ],
        });
        return {
          ...d, // copy all the existing fields
          __type: "fandom",
          n_posts: n_posts,
          n_pictures,
          n_videos,
          n_fans: (your_fans?.length || 0) + (your_superfans?.length || 0),
        };
      })
    );

    lists = [...lists, ...updatedfandomList];

    // playlist

    // let playlistsQuery = playlistModel.find({ author_id: user_id }).sort({ create_date: -1 });
    // if(keyword != '') {
    //     playlistsQuery = playlistsQuery.find({ $or: [
    //         { name:  { $regex: new RegExp(keyword, "ig") } },
    //         { description:  { $regex: new RegExp(keyword, "ig") } }
    //     ] })
    // }
    // playlistsQuery.populate({
    //     path: 'author_id',
    //     model: 'users',
    //     select: '_id first_name last_name username profile_image is_idverified'
    // });

    // let playlistsList = await playlistsQuery.exec();

    // playlistsList.map(d => {
    //     return {
    //         ...d,
    //         __type: 'playlist'
    //     }
    // });

    // lists = [ ...lists, playlistsList ];

    // event

    // short
    let partyQuery = partyModel
      .find({ creator_id: user_id })
      .sort({ create_date: -1 });
    if (keyword != "") {
      partyQuery = partyQuery.find({
        $or: [{ description: { $regex: new RegExp(keyword, "ig") } }],
      });
    }
    partyQuery.populate({
      path: "creator_id",
      model: "users",
      select: "_id first_name last_name username profile_image is_idverified",
    });
    let partysList = await partyQuery.exec();
    partysList = partysList.map((d) => {
      return {
        ...d._doc,
        __type: "short",
      };
    });
    lists = [...lists, ...partysList];

    // livenow
    let livenowQuery = livenowModel
      .find({ user_id })
      .sort({ created_date: -1 });
    if (keyword != "") {
      livenowQuery = livenowQuery.find({
        $or: [{ description: { $regex: new RegExp(keyword, "ig") } }],
      });
    }
    livenowQuery = livenowQuery.find({
      status: { $in: ["online", "away", "beback"] },
    });
    livenowQuery.populate({
      path: "user_id",
      model: "users",
      select: "_id first_name last_name username profile_image is_idverified",
    });

    let livenowsList = await livenowQuery.exec();
    livenowsList = livenowsList.map((d) => {
      return {
        ...d._doc,
        __type: "livenow",
      };
    });
    lists = [...lists, ...livenowsList];
    lists = lists
      .sort(
        (a, b) =>
          (b.create_date || b.created_date) - (a.create_date || a.created_date)
      )
      .slice(0, 100);

    let totalPages = Math.ceil(lists.length / limit);
    const startIndex = (page - 1) * limit;
    const endIndex = startIndex + limit;
    const pageList = lists.slice(startIndex, endIndex);
    res.json({
      status: true,
      message: "Retrived successfully",
      result: {
        data: pageList,
        totalPages,
      },
    });
  } catch (error) {
    console.log(error);
    res.json({
      status: false,
      message: "Something went wrong",
    });
  }
};

exports.get_info_for_item = async function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded.user_id;
  try {
    var item_id = req.query.item_id;
    var edition = req.query.edition;
    var item = await items.findById(item_id);
    if (item) {
      var up_next = await playerModel.findOne({ item_id, edition });
      var love = await item_loves.findOne({ item_id, user_id });
      var data = {
        isUptoNext: up_next ? true : false,
        isLoved: love ? true : false,
      };
      if (item.author_id == user_id) {
      } else {
        var _follower = await followers.findOne({
          star_id: item.author_id,
          user_id,
        });
        var _block = await blockModel.findOne({
          block_user_id: item.author_id,
          user_id,
        });
        var _mute = await muteModel.findOne({
          mute_user_id: item.author_id,
          user_id,
        });
        data.isFollow = _follower ? true : false;
        data.isBlock = _block ? true : false;
        data.isMute = _mute ? true : false;
      }
      res.json({
        status: true,
        message: "retrived successfuly",
        result: data,
      });
    } else {
      res.json({
        status: false,
        message: "No found item",
      });
    }
  } catch (error) {
    console.log(error);
    res.json({
      status: error,
      message: "Something went wrong",
      error,
    });
  }
};


exports.get_my_merchandise_item = async function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded.user_id;
  var keyword = req.body.keyword;
  var cats = (await category.find({ type: 'Merchandise', level: 1 })).map(d => d._id);
  try {
    var _items = await items.find({
      category_id: { $in: cats },
      current_owner: user_id,
      $or: [
        { name: { $regex: new RegExp(keyword, "ig") } },
        { description: { $regex: new RegExp(keyword, "ig") } },
      ],
    }).sort({ create_date: -1 });

    res.json({
      status: true,
      message: "Retrived successfully",
      result: _items
    })
  } catch (error) {
    console.log(error);
    res.json({
      status: false,
      message: "Something went wrong"
    })
  }

}

exports.get_reactions_data = async function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.query.user_id || req.decoded.user_id;
  try {
    // get items that I made reaction 
    var blocked_accounts = [
      ...(await blockModel.find({ user_id }))?.map(d => d.block_user_id),
      ...(await blockModel.find({ block_user_id: user_id }))?.map(d => d.user_id)
    ];

    var raacted_item_ids = (await item_reactions.find({ user_id })).map(d => d.item_id)
    var reacted_items = await items
      .find({ _id: { $in: raacted_item_ids }, author_id: { $nin: blocked_accounts } })
      .populate({ path: "collection_id", model: collections })
      .populate({ path: "category_id", model: category })
      .populate({ path: "catlevel2_id", model: category })
      .populate({ path: "artist", model: artistModel })
      .populate({ path: "catlevel3_id", model: category })
      .populate({
        path: "current_owner",
        model: users,
        select:
          "_id username first_name last_name profile_image metamask_info is_idverified",
      })
      .populate({
        path: "author_id",
        model: users,
        select:
          "_id username first_name last_name profile_image metamask_info is_idverified",
      })
      .populate({ path: "season_id", model: "seasons" })
      .sort({ create_date: -1 });

    let reactions = await item_reactions.find();
    let playLists = await item_plays.find();
    let comments = await item_comments.find({ parent_id: null });
    let likes = await item_likes.find();
    let loves = await item_loves.find();
    let boosts = await fanpostShareModel.find({ type: 'item', user_id });


    const updatedReactedItems = await Promise.all(
      reacted_items.map(async d => {
        const itemReactions = reactions.filter(
          (r) => r.item_id == d._doc._id.toString() && r.user_id == user_id
        );
        const reactionNumber = itemReactions.length
          ? itemReactions[0].reaction_number
          : -1;

        // check whether this is exited in up to next
        const up_to_next = await playerModel.findOne({
          item_id: d?._doc?._id?.toString(),
          user_id,
        });

        // check is follower, mute, block
        var _db_follower = await followers.findOne({
          star_id: d._doc?.author_id?._id,
          user_id: user_id,
        });
        var _db_block = await blockModel.findOne({
          block_user_id: d._doc?.author_id?._id,
          user_id: user_id,
        });
        var _db_mute = await muteModel.findOne({
          mute_user_id: d._doc?.author_id?._id,
          user_id: user_id,
        });

        var date = new Date();
        // get restructure item to decide the buy now and auction is finished or not
        if (d._doc.es_enabled) {
          if (!d._doc.es_is_auction) {
            if (d._doc.es_enventories?.length > 0) {
            } else {

              if (d._doc.es_b_limited && d._doc.es_n_sell == 0) {
                d._doc.es_enabled = false;
              }
              if (d._doc.es_b_endMode == "noend") {
              } else {
                if (
                  new Date(d._doc.es_b_endDate).getTime() < date.getTime()
                ) {
                  d._doc.es_enabled = false;
                }
              }
            }
            console.log(d._doc.es_b_endDate)
            console.log(d._doc.es_b_endMode)
            console.log(date)
            console.log(d._doc._id);
            console.log(d._doc.es_enabled);
          } else {
            // check auction is finished or not
            if (new Date(d._doc.es_a_endDate).getTime() < date.getTime()) {
              d._doc.es_enabled = false;
            }
            // if not
            if (d._doc.es_enabled) {
              // get the current bid
              let c_bid = await offers
                .findOne({
                  type: "bid",
                  item_id: d._doc._id,
                  edition: "standard",
                })
                .sort({ price: -1 })
                .limit(1)
                .exec();
              var currentbid = c_bid?.price;
              if (currentbid) {
                d._doc.es_a_starting_price = currentbid;
              }
            }
          }
        }

        if (d._doc.ec_enabled) {
          if (!d._doc.ec_is_auction) {
            if (d._doc.ec_enventories?.length > 0) {
            } else {
              if (d._doc.ec_b_limited && d._doc.ec_n_sell == 0) {
                d._doc.ec_enabled = false;
              }
              if (d._doc.ec_b_endMode == "noend") {
              } else {
                if (
                  new Date(d._doc.ec_b_endDate).getTime() < date.getTime()
                ) {
                  d._doc.ec_enabled = false;
                }
              }
            }
          } else {
            // check auction is finished or not
            if (new Date(d._doc.ec_a_endDate).getTime() < date.getTime()) {
              d._doc.ec_enabled = false;
            }
            // if not
            if (d._doc.ec_enabled) {
              // get the current bid
              let c_bid = await offers
                .findOne({
                  type: "bid",
                  item_id: d._doc._id,
                  edition: "collective",
                })
                .sort({ price: -1 })
                .limit(1)
                .exec();
              var currentbid = c_bid?.price;
              if (currentbid) {
                d._doc.ec_a_starting_price = currentbid;
              }
            }
          }
        }

        if (d._doc.el_enabled) {
          if (!d._doc.el_is_auction) {
            if (d._doc.el_enventories?.length > 0) {
            } else {
              if (
                (d._doc.el_b_limited && d._doc.el_n_sell == 0) ||
                d._doc.el_n_now_sell == 0
              ) {
                d._doc.el_enabled = false;
              }
              if (d._doc.el_b_endMode == "noend") {
              } else {
                if (
                  new Date(d._doc.el_b_endDate).getTime() < date.getTime()
                ) {
                  d._doc.el_enabled = false;
                }
              }
            }
          } else {
            // check auction is finished or not
            if (new Date(d._doc.el_a_endDate).getTime() < date.getTime()) {
              d._doc.el_enabled = false;
            }
            // if not
            if (d._doc.el_enabled) {
              // get the current bid
              let c_bid = await offers
                .findOne({
                  type: "bid",
                  item_id: d._doc._id,
                  edition: "limited",
                })
                .sort({ price: -1 })
                .limit(1)
                .exec();
              var currentbid = c_bid?.price;
              if (currentbid) {
                d._doc.el_a_starting_price = currentbid;
              }
            }
          }
        }

        return {
          ...d._doc, // copy all the existing fields
          __type: "item",
          reaction_number: reactionNumber,
          isPlayed: playLists.some(
            (pl) =>
              pl.item_id == d._doc._id.toString() && pl.user_id == user_id
          ),
          isCommented: comments.some(
            (pl) =>
              pl.item_id == d._doc._id.toString() && pl.user_id == user_id
          ),
          isLiked: likes.some(
            (pl) =>
              pl.item_id == d._doc._id.toString() && pl.user_id == user_id
          ),
          isLoved: loves.some(
            (pl) =>
              pl.item_id == d._doc._id.toString() && pl.user_id == user_id
          ),
          isBoosted: boosts.some(
            (pl) =>
              pl.item_id == d._doc._id.toString() && pl.user_id == user_id
          ),
          isUptoNext: up_to_next ? true : false,
          isFollow: _db_follower ? true : false,
          isBlock: _db_block ? true : false,
          isMute: _db_mute ? true : false,
        };
      })
    )



    // get posts that I made reaction 
    var reacted_post_ids = (await fanpostReactionModel.find({ user_id })).map(d => d.fanpost_id)
    // don't display content when fandom is not published
    var query = fanpostModel.find();
    var _fandoms = await fandomModel.find({ status: "published" });
    _fandoms = _fandoms.map((d) => {
      return d.user_id;
    });
    query = query.find({ creator_id: { $in: _fandoms } });


    // don't display content depend on subscription levels
    let users_with_fans = (await subscriptionlevelModel.find({ level: 'basic' })).map(d => d.user_id);
    let users_with_superfans = (await subscriptionlevelModel.find({ level: 'super' })).map(d => d.user_id);

    let filter_ids_by_super = (await fanpostModel.find({
      creator_id: {
        $nin: users_with_superfans
      },
      $or: [
        { is_view_only: 'superfans' },
        { is_relay_only: 'superfans' }
      ]
    })).map(d => d._id);

    let filter_ids_by_basic = (await fanpostModel.find({
      $and: [
        { creator_id: { $nin: users_with_fans } },
        { creator_id: { $nin: users_with_superfans } }
      ],
      $or: [
        { is_view_only: 'fans' },
        { is_relay_only: 'fans' }
      ]
    })).map(d => d._id);


    query = query.find({
      $and: [
        { _id: { $in: reacted_post_ids } },
        { _id: { $nin: filter_ids_by_basic } },
        { _id: { $nin: filter_ids_by_super } },
      ]
    });

    reacted_posts = await query.populate({
      path: "author_id",
      model: "users",
      select: "_id first_name last_name username profile_image",
    }).sort({ create_date: -1 }).exec();

    let _reactions = await fanpostReactionModel.find();
    let _comments = await fanpostCommentModel.find({ parent_id: null });
    let _loves = await fanpostLoveModel.find();
    let _boosts = await fanpostShareModel.find();


    const updatedReactedPosts = await Promise.all(
      reacted_posts.map(async d => {
        let _members = await memberModel.find({ star_id: d._doc.creator_id });
        let _fans = await fanModel.find({ star_id: d._doc.creator_id });
        let _followers = await followers.find({ star_id: d._doc.creator_id });
        let _followings = await followers.find({ star_id: user_id });


        var _db_follower = await followers.findOne({
          star_id: d._doc?.author_id?._id,
          user_id: user_id,
        });
        var _db_block = await blockModel.findOne({
          block_user_id: d._doc?.author_id?._id,
          user_id: user_id,
        });
        var _db_mute = await muteModel.findOne({
          mute_user_id: d._doc?.author_id?._id,
          user_id: user_id,
        });


        let isFan = _fans.some((f) => f.user_id == user_id);
        let membership;
        if (isFan) {
          let _memberships = await subscriptionlevelModel.find({
            user_id: d._doc?.creator_id,
          });
          _memberships.map((d) => {
            return d._id;
          });
          var _start_date = new Date();
          _start_date.setMonth(_start_date.getMonth() - 1);
          membership = await subscribers
            .findOne({
              user_id: user_id,
              subscription_id: { $in: _memberships },
              unsubscribed: false,
              start_date: { $gte: _start_date },
            })
            .populate("subscription_id");
        }

        let InfoForUser = {
          isMember: _members.some((m) => m.user_id == user_id),
          isFan: isFan,
          membership: membership,
          isFollower: _followers.some((f) => f.user_id == user_id),
          isFollowing: _followings.some((f) => f.user_id == d._doc?.creator_id),
        };

        // check edited
        let histories = await fanpostHistoryModel.find({ fanpost_id: d._id });

        const itemReactions = _reactions.filter(
          (r) => r.fanpost_id == d._id.toString() && r.user_id == user_id
        );
        const reactionNumber = itemReactions.length
          ? itemReactions[0].reaction_number
          : -1;
        return {
          ...d.toObject(), // copy all the existing fields
          __type: "post",
          reaction_number: reactionNumber,
          isCommented: _comments.some(
            (pl) => pl.fanpost_id == d._id.toString() && pl.user_id == user_id
          ),
          isLoved: _loves.some(
            (pl) => pl.fanpost_id == d._id.toString() && pl.user_id == user_id
          ),
          isBoosted: _boosts.some(
            (pl) => pl.fanpost_id == d._id.toString() && pl.user_id == user_id
          ),
          InfoForUser: InfoForUser,
          serverDate: new Date(),
          isEdited: histories?.length > 0 ? true : false,
          isFollow: _db_follower ? true : false,
          isBlock: _db_block ? true : false,
          isMute: _db_mute ? true : false,

        };
      })
    )

    let result = [...updatedReactedItems, ...updatedReactedPosts];
    result = result.sort((a, b) => (b.create_date || b.created_date) - (a.create_date || a.created_date));

    res.json({
      status: true,
      message: "Retrived successfully",
      result: result
    })

  } catch (error) {
    console.log(error);
    res.json({
      status: false,
      message: "something went wrong"
    })
  }
}

exports.get_my_items = async function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded.user_id;
  var cat1 = req.query.cat1;
  var keyword = req.query.keyword
  try {
    let query = items.find({ author_id: user_id, original_id: { $eq: null }, category_id: cat1 }).sort({ create_date: -1 });
    if (keyword && keyword != "") {
      query.find({
        $or: [
          { name: { $regex: new RegExp(keyword, "ig") } },
          { description: { $regex: new RegExp(keyword, "ig") } },
        ],
      });
    }
    var result = await query.exec();
    res.json({
      status: true,
      message: "Retrived successfully",
      result
    })
  } catch (error) {
    console.log(error);
    res.json({
      status: false,
      message: "Something went wrong"
    });
  }
}

exports.add_clip_or_trailer_to_item = async function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded.user_id;
  var item_id = req.body.item_id;
  var edition = req.body.edition;
  var format = req.body.format;
  var data = req.body.data;

  try {
    var item = await items.findById(item_id);
    if (item) {
      switch (edition) {
        case 'standard':
          if (item.es_enabled) {
            if (format == 'Clip') {
              item.es_clips.push(data);
            } else {
              item.es_trailers.push(data);
            }
          } else {
            res.json({
              status: false,
              message: "Something went wrong"
            });
            return;
          }
          break;
        case 'collective':
          if (item.ec_enabled) {
            if (format == 'Clip') {
              item.ec_clips.push(data);
            } else {
              item.ec_trailers.push(data);
            }
          } else {
            res.json({
              status: false,
              message: "Something went wrong"
            });
            return;
          }
          break;
        case 'limited':
          if (item.el_enabled) {
            if (format == 'Clip') {
              item.el_clips.push(data);
            } else {
              item.el_trailers.push(data);
            }
          } else {
            res.json({
              status: false,
              message: "Something went wrong"
            });
            return;
          }
          break;
        default:
          if (format == 'Clip') {
            item.clips.push(data);
          } else {
            item.trailers.push(data);
          }
          break;
      }
      await item.save();
      res.json({
        status: true,
        message: "Added successfully",
        result: item

      })
    } else {
      res.json({
        status: false,
        message: "Not found item"
      })
    }
  } catch (error) {
    console.log(error);
    res.json({
      status: false,
      message: "Something went wrong"
    })
  }

}

// manage cart

exports.add_to_cart = async function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded.user_id;
  var item_id = req.body.item_id;
  var edition = req.body.edition;
  var option = req.body.option;
  var amount = req.body.amount;
  var offer_id = req.body.offer_id;
  var type = req.body.type;

  try {
    var query;
    if (type == 'buy') {
      query = {
        type: 'buy',
        user_id
      }
    } else if (type == 'offer' || type == 'bid') {
      query = {
        item_id,
        edition,
        option,
        user_id,
        offer_id
      }
    } else {
      query = {
        item_id,
        edition,
        option,
        user_id
      }
    }
    var cart = await cartModel.findOne(query);
    var total = amount;
    if (cart) {
      if (type == 'buy') {
        if (cart.item_id == item_id && cart.edition == edition && JSON.stringify(cart.option) == JSON.stringify(option)) {
          total += cart.amount;
        } else {
          cart.item_id = item_id;
          cart.edition = edition;
          cart.option = option;
        }
        cart.created_date = new Date();
      } else if (type == 'offer' || type == 'bid') {
        total = amount;
      } else {
        total += cart.amount;
        if (type == 'cart') {
          cart.type = 'cart'
        }
      }
    }
    // check stock
    var item = await items.findById(item_id);
    if (item) {
      let label;
      switch (edition) {
        case 'standard':
          label = 'es_';
          break;
        case 'collective':
          label = 'ec_';
          break;
        case 'limited':
          label = 'el_';
          break;
        default:
          res.json({
            status: false,
            message: "Edition error"
          });
          return;
      }

      if (!item[`${label}enabled`]) {
        if (cart) {
          await cart.remove();
        }
        res.json({
          status: false,
          message: "Item selling type was changed"
        });
        return;
      } else {
        // check is sell is possible by start time and end time;
        var date = new Date();

        if (item[`${label}is_auction`]) {
          total = 1;
        } else {

          var start_date = new Date(item[`${label}b_startDate`] || new Date());
          var end_mode = item[`${label}b_endMode`];
          var end_date = new Date(item[`${label}b_endDate`] || new Date());

          if (start_date.getTime() > date.getTime()) {
            res.json({
              status: false,
              message: "Sell is not open yet"
            });
            return;
          }

          if (end_mode != 'noend' && end_date.getTime() < date.getTime()) {
            res.json({
              status: false,
              message: "Sell was finished."
            });
            return;
          }


          if (item[`${label}inventories`]?.length > 0) {
            let inventory = item[`${label}inventories`].find(d => JSON.stringify(d.option) == JSON.stringify(option))
            if (inventory) {
              if (inventory.limited) {
                let stock = inventory.count;
                if (total >= stock) {
                  total = stock;
                }
              }
            } else {
              res.json({
                status: false,
                message: "Can't find inventory"
              });
              return;
            }
          } else {
            let stock = 0;
            if (edition == 'limited') {
              stock = item[`${label}n_sell`]
            } else {
              stock = item[`${label}n_now_sell`]
            };

            if (item[`${label}b_limited`]) {
              if (total > stock) {
                total = stock
              }
            }

          }
        }

      }
      console.log("total");
      console.log(total);
      if (cart) {
        if (total <= 0) {
          await cart.remove();
        } else {
          cart.amount = total;
          await cart.save();
          console.log(cart);
        }
      } else {
        var new_cart = new cartModel({
          item_id, edition, option, user_id, amount: total, type, offer_id
        });
        await new_cart.save();
        console.log(new_cart);
      }

      res.json({
        status: true,
        message: "Saved successfully",
      });

    } else {
      res.json({
        status: false,
        message: "Can't find item"
      });
    }

  } catch (error) {
    console.log(error);
    res.json({
      status: false,
      message: error.message,
    })
  }
  // operation 

}

exports.get_cart = async function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded.user_id;
  try {
    var carts = await cartModel.find({
      user_id
    }).populate({
      path: "item_id",
      model: 'item',
      populate: [
        {
          path: "category_id",
          model: 'category'
        },
        {
          path: "catlevel2_id",
          model: 'category'
        },
        {
          path: "catlevel3_id",
          model: 'category'
        },
        {
          path: "author_id",
          model: "users",
          select:
            "_id username first_name last_name profile_image metamask_info is_idverified",
        },

        {
          path: "current_owner",
          model: "users",
          select:
            "_id username first_name last_name profile_image metamask_info is_idverified",
        }
        , { path: "artist", model: artistModel }

      ]
    })
      .populate({
        path: "offer_id",
        model: "offer",
      })
      .sort({
        created_date: -1
      });

    const updateCarts = await Promise.all(carts.map(async d => {
      let rule = await itemShippingRuleModel.findOne({
        items: d._doc.item_id?._id
      });
      let item_id = {
        ...d?._doc?.item_id?._doc,
        ...rule?._doc,
        _id: d?._doc?.item_id?._doc?._id,

      }

      return {
        ...d._doc,
        item_id
      }

    }));
    res.json({
      status: true,
      message: "Retrived successsfully",
      result: updateCarts
    })
  } catch (error) {
    console.log(error);
    res.json({
      status: false,
      message: "Something went wrong"
    })
  }
}

exports.manage_cart = async function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded.user_id;
  var cart_id = req.body._id;

  try {
    var cart = await cartModel.findById(cart_id);
    if (cart) {
      if (cart.type == 'buy') {
        var buy = await cartModel.findOne({
          item_id: cart.item_id,
          edition: cart.edition,
          option: cart.option,
          type: { $eq: 'buy' }
        })
        await buy.remove();
      }
      var type = cart.type !== 'later' ? 'later' : 'cart';
      cart.type = type;
      await cart.save();
      res.json({
        status: true,
        message: "Saved successfully",
      })
    } else {
      res.json({
        status: false,
        message: "Something went wrong"
      });
    }
  } catch (error) {
    console.log(error);
    res.json({
      status: false,
      message: "Something went wrong"
    });
  }

}

exports.delete_cart = async function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded.user_id;
  var cart_id = req.body._id;
  try {
    var cart = await cartModel.findById(cart_id);
    if (cart) {
      await cartModel.findByIdAndRemove(cart_id);
      res.json({
        status: true,
        message: "Deleted successfully"
      })
    } else {
      res.json({
        status: false,
        message: "Can't find cart item"
      })
    }
  } catch (error) {
    console.log(error);
    res.json({
      status: false,
      message: "Something went wrong"
    })
  }
}


exports.handle_offer = async function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded.user_id;
  var offer_id = req.body.offer_id;
  try {
    var offer = await offers.findById(offer_id);
    console.log(offer);
    await offers.findByIdAndUpdate(offer_id, { paid: true });
    offer = await offers.findById(offer_id);
    console.log(offer);
    res.json({
      status: true,
      message: "Updated successfully"
    })
  } catch (error) {
    console.log(error);
    res.json({
      status: false,
      message: error.message
    })
  }
}


exports.handle_cart = async function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded.user_id;
  var method = req.body.method;
  try {
    switch (method) {
      case 'buy':
      case 'bid':
      case 'offer':
      case 'cart':
        await cartModel.deleteMany({ user_id, type: method });
        res.json({
          status: true,
          message: user_id + ' `s Cart deleted' + " " + method,
        })
        return;
      default:
        await cartModel.deleteMany({ user_id });
        res.json({
          status: true,
          message: user_id + ' `s Cart deleted' + " " + method,
        })
        return;
    }
  } catch (error) {
    console.log(error);
    res.json({
      status: false,
      message: error.message
    })
  }
}

/* !!20240106pm8 coderd {(B)(New) hide categories in discover that have no ite} */
exports.category_filter = function (req, res) {
  console.log(getErrLine().str, "apistart");
  let query;
  if(req.body.cat1 && req.body.cat1 == "Marketplace"){
    query = items.find({ category_id: { $in: req.body.cats } }).distinct("category_id");
  } else {
    console.log(req.body.cats,"++++++++++++++")
    query = mediaModel.find({ category_id: { $in: req.body.cats }}).distinct("category_id");
  }
  query.exec(function(err,result){
    if(err){
      console.log(err);
      return res.json({
        status: false,
        message: err.message
      });
    } else {
      return res.json({
        status: true,
        result: result,
        message: "Retrived succssfullyQ"
      });
    }
  });
  
};