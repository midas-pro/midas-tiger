var offers = require('../model/offerModel');
var itemModel = require('../model/itemModel');
var collections = require('./../../collection/model/collectionModel');
var category = require('./../../category/model/categoryModel');
var users = require('./../../user/model/userModel');

var shipaddrs = require('../../user/model/addressModel'); 
const autoBidTrackModel = require('../model/autoBidTrackModel');
const transactionModel = require('../model/transactionModel');
const bidModel = require('../model/bidModel');
const notificationModel = require('../../notification/model/notificationModel');
const { NOTIFICATION_TYPES } = require('../../helper/notification_config');
//20231212am11 CoderD pric print format "toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })" use to "toFixed(2)"
exports.handleBid = function() {
    async function handleEdition(edition) {
        try {
            console.log("Hnalde AUTO BID")
            // get last check date
            var last_check_date = await autoBidTrackModel.findOne().sort({ created_date: -1 }).limit(1)
            var now = new Date();
            var before = last_check_date ? new Date(last_check_date.created_date) : new Date((now.getTime() - 60000));
            var query = { };
            query[`${edition}enabled`] = true;
            query[`${edition}is_auction`] = true;
            query = {
                ...query,
                $and: [
                    {
                        [`${edition}a_endDate`]: { $gte: before }
                    }, {
                        [`${edition}a_endDate`]: { $lt: now }
                    }
                ]
            }
            var items = await itemModel.find(query)
                .populate({ path: 'collection_id', model: collections })
                .populate({ path: 'category_id', model: category })
                .populate({ path: 'catlevel2_id', model: category })
                .populate({ path: 'catlevel3_id', model: category })
                .populate({ path: 'current_owner', model: users, select: '_id username first_name last_name profile_image metamask_info is_idverified' })
                .populate({ path: 'author_id', model: users, select: '_id username first_name last_name profile_image metamask_info is_idverified' })
            ; // find the item the auction was finihsed from last checked time to current.
            // auto auction handle system.
            items.map(async item => {
                try {
                    // find the winnder bid
                    var editionText;
                    switch(edition) {
                        case 'es_':
                            editionText = 'standard'; break;
                        case 'ec_':
                            editionText = 'collective'; break;
                        case 'el_':
                            editionText = 'limited'; break;
                        default:
                            return;
                    }
                    // find bid auction between duration for item.
                    let query = {
                        item_id: item._id,
                        edition: editionText,
                        created_date: {
                            $gte: item[`${edition}a_startDate`],
                            $lt: item[`${edition}a_endDate`]
                        }
                    }
                    if(item[`${edition}a_reserve_price`]) {
                        query = { ...query, ...{
                        price: { $gte: item[`${edition}a_reserve_price`] }
                        } }                    
                    }
                    var winner = await offers.findOne(query).sort({ price: -1 }).limit(1);
                    console.log("winner: ", winner);
                    const s_date = item[`${edition}a_endDate`]
                    await offers.updateMany({
                        // _id: { $not: winner._id },
                        item_id: item._id,
                        edition: editionText,
                        created_date: {
                            $lt: s_date
                        }
                    }, { expired: true });
                    // clear auto bid setting history
                    await bidModel.updateMany({
                        item_id: item._id,
                        edition: editionText,
                        created_date: {
                            $lt: s_date
                        }
                    }, { expired: true });
                    if(winner) {
                        let bid_step = item[`${edition}bid_step`];
                        if((edition == 'el_' && item[`${edition}n_now_sell`] > bid_step) || (edition != 'el_' && item[`${edition}n_sell`] > 0)) {
                            // const s_date = item[`${edition}a_endDate`]
                            const e_date = new Date(new Date(item[`${edition}a_endDate`]).setTime(
                                new Date(item[`${edition}a_endDate`]).getTime() + (
                                    new Date(item[`${edition}a_endDate`]).getTime() - 
                                    new Date(item[`${edition}a_startDate`]).getTime()
                                ) 
                            ));
                            bid_step += 1;
                            item[`${edition}a_startDate`] = s_date;
                            item[`${edition}a_endDate`] = e_date;
                            item[`${edition}bid_step`] = bid_step;
                        }
                        
                        var updated_winner_bid = { ...winner, ... { is_winner_bid: true } };
                        await offers.findByIdAndUpdate(winner._id, updated_winner_bid);
                        // SEND NOTIFICATION TO WINNER IF HIS SETTING IS ENABLED
                        let _winner_user = await users.findOne({ _id: winner.sender, "notif_buying.is_auctions": true })
                        if(_winner_user) {
                            let new_notification = new notificationModel({
                                type: NOTIFICATION_TYPES.BUYING_AUCTIONS,
                                from_id: winner.receiver,
                                to_id: winner.sender,
                                message: `You won this auction with a bid of $${winner.price?.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`,
                              //  message: `You won this auction with a bid of $${winner.price.toFixed(2)}`,  //!!??crashed here
                                items: [
                                    {
                                        item_id: winner.item_id,
                                        edition: winner.edition,
                                        amount: 1,
                                        price: winner.price
                                    }
                                ]
                            });
                            await new_notification.save();
                        }
    
                         //  CREATE NOTIFICATION FOR SELLER
                         let _seller_user = await users.findOne({ _id: winner.receiver, "notif_selling.is_auctions":  true });
                         if(_seller_user) {
                             let new_notification = new notificationModel({
                                 type: NOTIFICATION_TYPES.SELL_AUCTIONS,
                                 from_id: winner.sender,
                                 to_id: winner.receiver,
                                 message: `Won your auction`,
                                 items: [
                                     {
                                         item_id: winner.item_id,
                                         edition: winner.edition,
                                         amount: 1,
                                         price: winner.price
                                     }
                                 ]
                             });
                             await new_notification.save();
                         }
    
                        // SENT NOTIFICATION TO LOSER IF HIS SETTING IS ENABLED
                        let _bid_users = (await offers.find({ 
                            _id: { $ne: winner._id },
                            item_id: item._id, 
                            edition: editionText, 
                            created_date: {
                                $gte: item[`${edition}a_startDate`],
                                $lt: item[`${edition}a_endDate`]
                            },
                            expired: true 
                        })).map(d => d.sender);
                        
                        let _loser_users = (await users.find({ _id: { $in: _bid_users }, "notif_buying.is_auctions": true })).map(d => d._id);
                        if(_loser_users.length > 0) {
                            await Promise.all(_loser_users.map( async d => {
                                let new_notification = new notificationModel({
                                    type: NOTIFICATION_TYPES.BUYING_AUCTIONS,
                                    from_id: item.current_owner?._id || item.current_owner,
                                    to_id: d,
                                    message: "You didn't win this auction",
                                    items: [
                                        {
                                            item_id: item._id,
                                            edition: editionText,
                                            amount: 1,
                                            price: winner.price
                                        }
                                    ]
                                });
                                await new_notification.save();
                            }))
                        }
                        
                    } else {
                        // SENT NOTIFICATION TO LOSER IF HIS SETTING IS ENABLED
                        let _bid_users = (await offers.find({ 
                            item_id: item._id, 
                            edition: editionText, 
                            created_date: {
                                $gte: item[`${edition}a_startDate`],
                                $lt: item[`${edition}a_endDate`]
                            },
                            expired: true
                        })).map(d => d.sender);
                        
                        let _loser_users = (await users.find({ _id: { $in: _bid_users }, "notif_buying.is_auctions": true })).map(d => d._id);
                        if(_loser_users.length > 0) {
                            await Promise.all(_loser_users.map( async d => {
                                let new_notification = new notificationModel({
                                    type: NOTIFICATION_TYPES.BUYING_AUCTIONS,
                                    from_id: item.current_owner?._id || item.current_owner,
                                    to_id: d,
                                    message: "You didn't win this auction",
                                    items: [
                                        {
                                            item_id: item._id,
                                            edition: editionText,
                                            amount: 1,
                                            price: winner?.price
                                        }
                                    ]
                                });
                                await new_notification.save();
                            }))
                        }
                        // CREATE NOTIFICATION FOR SELLER
                        let _seller_user = await users.findOne({ _id: item.current_owner, "notif_selling.is_auctions": true });
                        if(_seller_user) {
                            let new_notification = new notificationModel({
                                type: NOTIFICATION_TYPES.SELL_AUCTIONS,
                                to_id: _seller_user._id,
                                message: 'Nobody won your auction',
                                items: [
                                    {
                                        item_id: item._id,
                                        edition: editionText,
                                        amount: 1,
                                    }
                                ]
                            });
                            await new_notification.save();
                        }
                    }
                } catch (error) {
                    console.log(error);
                }
            });
            await autoBidTrackModel.deleteMany({});
            var newtrack = new autoBidTrackModel();
            newtrack.save();

        } catch (error) {
            console.log(error);
        }
    }

    async function handleBid() {
        try {
            handleEdition('es_'); // handle update standard edition auction day by day
            handleEdition('ec_'); // handle update standard edition auction day by day
            handleEdition('el_'); // handle update standard edition auction day by day
        } catch (error) {
            console.log(error);            
        }

    }

    handleBid();
    setInterval(() => {
        handleBid();
    }, 60000)
}