var https = require('https')
var offers = require('../model/offerModel');
var userModel = require('../../user/model/userModel');
var notificationModel = require('../../notification/model/notificationModel');
const { NOTIFICATION_TYPES } = require('../../helper/notification_config');
const SHIPCARRIER = require('../../helper/shipCarriers');


const apiKey = 'c3h9v8ry-vs53-t3os-98qa-8utl7m6rc8c0';
exports.getTrackingStatus = function() {
  function trakingInfoManager() {
    console.log('This is called automatically in backend unless server is offline. I am working well.')
    offers.find({
        'items.status': 'Shipped' 
    }, function(err, lists) {
        lists.map(async (offer, index) => {
            let _status;
            let _tracId;
            let _shipcarrier;
            offer.items?.map((item, index ) => {
                if(item.status == 'Shipped') {
                    let trackingNumber = item.trackId;
                    let carrierCode = item.ship_carrier;
                    // sent api request
                    const options = {
                        hostname: 'api.trackingmore.com',
                        path: `/v2/trackings/get?tracking_number=${trackingNumber}&carrier_code=${carrierCode}`,
                        method: 'GET',
                        headers: {
                          'Trackingmore-Api-Key': apiKey,
                          'Content-Type': 'application/json'
                        }
                    };
                    const req = https.request(options, res => {
                        let responseBody = '';
                        res.on('data', data => {
                          responseBody += data;
                        });
                        res.on('end', async () => {
                          const responseJson = JSON.parse(responseBody);
                          if(responseJson['meta']?.['code'] == 200) {
                            console.log('success response');
                            if(responseJson['data']) {
                                let item = responseJson['data']['items'][0];
                                console.log(item);
                                if(item.status) {
                                    _status = item.status;
                                    console.log('Status:' + _status);
                                    // if(status == 'delivered') {
                                    //     offer.items[index].status = status;
                                    //     return offer.save();
                                    // }
                                    switch(_status) {
                                      case 'pending':
                                        offer.items[index].status = 'Pending';
                                        break;
                                      case 'notfound':
                                        offer.items[index].status = 'Notfound';
                                        break;
                                      case 'transit':
                                        offer.items[index].status = 'Transit';
                                        break;
                                      case 'pickup':
                                        offer.items[index].status = 'Pickup';
                                        break;
                                      case 'delivered':
                                        // CREATE NOTIFICATION
                                        offer.items[index].status = 'Delivered';
                                        _trackId = trackingNumber;
                                        _shipcarrier = carrierCode;
                                        break;
                                      case 'expired':
                                        offer.items[index].status = 'Expired';
                                        break;
                                      case 'undelivered':
                                        offer.items[index].status = 'Undelivered';
                                        break;
                                      case 'exception':
                                        offer.items[index].status = 'Exception';
                                        break;
                                      case 'InfoReceived':
                                        offer.items[index].status = 'InfoReceived';
                                        break;
                                      default:
                                        
                                    }
                                    
                                    return offer.save();
                                }
                            }
                          }
                        });
                      });
                      
                      req.on('error', error => {
                        console.error(`An error occurred while making the request: ${error}`);
                      });
                      
                      req.end();
                }
            });

            if(_status == 'delivered' && _trackId) {
              // SEND NOTIFICATION TO SELLER
              var _seller_user = await userModel.findOne({
                _id: offer.receiver,
                "notif_selling.is_order_update": true
              });
              let shippingCarrer = SHIPCARRIER.find(d => d.code == __shipcarrier)?.name;
              if(_seller_user) {
                let new_notification = new notificationModel({
                  type: NOTIFICATION_TYPES.SELL_ORDER,
                  from_id: offer.sender,
                  to_id: _seller_user._id,
                  message: `Their order was delivered ${shippingCarrer ? ('by' + shippingCarrer) : ''}`,
                  items: offer.items.filter(d => d.trackId ==  _trackId)
                });
                await new_notification.save();
              }
            }

        })
    })
  }
  setInterval(() => {
      trakingInfoManager()
  }, 14400000)
}




exports.getTrackingInfo = function(req, res) {
  let trackingNumber = req.query.trackingNumber;
  let carrierCode = req.query.ship_carrier;
  // sent api request
  const options = {
      hostname: 'api.trackingmore.com',
      path: `/v2/trackings/get?tracking_number=${trackingNumber}&carrier_code=${carrierCode}`,
      method: 'GET',
      headers: {
        'Trackingmore-Api-Key': apiKey,
        'Content-Type': 'application/json'
      }
  };
  const request = https.request(options, response => {
      let responseBody = '';
      response.on('data', data => {
        responseBody += data;
      });
      response.on('end', () => {
        const responseJson = JSON.parse(responseBody);
        // Extract the status from the response
      //   console.log(responseBody)
      //   console.log(responseJson)
        if(responseJson['meta']?.['code'] == 200) {
          console.log('success response');
          res.json({
            status: true,
            result: responseJson
          })
        } else {
          res.json({
            status: false,
            result: responseJson
          })
        }
      //   const status = responseJson['data'][0]['status'];
      //   console.log(`The current status of the package is ${status}.`);
      });
    });
    
    request.on('error', error => {
      console.error(`An error occurred while making the request: ${error}`);
    });
    
    request.end();
}