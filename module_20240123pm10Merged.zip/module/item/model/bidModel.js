/*
Project : Cryptotrades
FileName :  priceModel.js
Author : Indiefire
File Created : 21/07/2021
CopyRights : Indiefire
Purpose : This is the file which used to define view schema that will store and reterive item price information.
*/

var mongoose = require('mongoose');
var mongoosePaginate = require('mongoose-paginate-v2');
var uniqueValidator = require('mongoose-unique-validator');
var config = require('./../../../helper/config')
const Schema = mongoose.Schema;

var bidSchema = mongoose.Schema({
    item_id: { type: Schema.Types.ObjectId, ref: 'item' },
    edition: { type: String, default: 'standard' },
    // option: { type: Object, default: null },
    max_bid: { type: Number, default: 0 },
    user_id: {
        type: Schema.Types.ObjectId, ref: 'users'
    },
    auto_bid: {
        type: Boolean,
        default: true,
    },
    bid_step: {
        type: Number,
        default: 1
    },
    created_date: {
        type: Date,
        default: Date.now
    },
});

bidSchema.plugin(uniqueValidator);
bidSchema.plugin(mongoosePaginate);

module.exports = mongoose.model('bids', bidSchema,config.db.prefix+'bids');