/*
Project : Cryptotrades
FileName : itemModel.js
Author : Indiefire
File Created : 21/07/2021
CopyRights : Indiefire
Purpose : This is the file which used to define collection schema that will communicate and process collection information with mongodb through mongoose ODM.
*/

var mongoose = require('mongoose');
var mongoosePaginate = require('mongoose-paginate-v2');
var uniqueValidator = require('mongoose-unique-validator');
var config = require('./../../../helper/config')
const Schema = mongoose.Schema;
// Setup schema

const attributeSchema = new Schema({ name: String, type:String });
const rangeSchema = new Schema({ name: String, value:Number, valueof: Number });
const buyersSchema = new Schema({ 
    buyer: { type: Schema.Types.ObjectId, ref: 'users' }, 
    amount:{
        type: Number,
        default:1,
    }, 
    price: Number,
});

const other_shipping_rule_schema = new Schema({
    shipping_country: {
        type: String,
    },
    shipping_method: {
        type: String
    },
    shipping_description: {
        type: String,
    },
    shipping_carrier: {
        type: String
    },
    shipping_duration: {
        type: Number
    },
    shipping_item_price: {
        type: Number
    },
    shipping_items_price: {
        type: Number
    }
})

const optionSchema = new Schema({
    option: {
        type: String
    },
    values: []
})

const inventorySchema = new Schema({
    option: { 
        type: Object,
        default: null
    },
    limited: {
        type: Boolean,
        default: false
    },
    total: {
        type: Number,
        default: 0
    },
    count: {
        type: Number,
        default: 0
    },
    price: {
        type: Number,
        default: 0
    },
    f_accept_offer: {
        type: Boolean,
        default: false
    },
    image: {
        type: String,
        default: ''
    },
    n_sold: {
        type: Number,
        default: 0
    }
});

var itemSchema = mongoose.Schema({
    original_id: {
        type: Schema.Types.ObjectId,
        default: null
    },
    name: {
        type: String,
        // minlength: [3, 'Name must be 3 characters or more'],
        maxlength: [255, "Name can't exceed 255 characters"],
        // unique: [ true , 'Name already exists. Please try a different name'], //!!2022.10.22
        required: [ true , 'Name is required'], 
    },   
    description: {
        type: String,
        maxlength: [1000, "Description can't exceed 1000 characters"]
    },   
    blockchain:{
        type: String,
    },
    
    external_link: {
        type: String,
    }, 
    
    media: {
        type: String,
        default: ''
    },

    thumb: {
        type: String,
        default: ''
    },

    video: {
        type: String,
        default: '',
    },

    has_offer: {
        type: Boolean,
        default: false
    },
    attributes: {
        type: [attributeSchema],
    },
    levels: {
        type: [rangeSchema],
    },
    stats: {
        type: [rangeSchema],
    },
    buyers: {
        type: [buyersSchema],
    },
    unlock_content_url: {
        type: String,
        default:""
    },
    view_count: {
        type: Number,
        default:0
    },
    like_count: {
        type: Number,
        default:0
    },
    royalties:{
        type: Number,
        default:0
    },
    price: {
        type: Number,
        default:0
    },
    amount: {
        type: Number,
        default:1
    },
    balance: { // available amount , residue amount for publisher(creator)
        type: Number,
        default:1
    },
    is_auction: {
        type: Boolean,
        default: false
    },
    is_ended: { // auction ended?
        type: Boolean,
        default: false
    },
    start_date: { // auction started date/time
        type: Date,
        default: Date.now
    },
    end_date: { // auction ended date/time
        type: Date,
        default: Date.now
    },

    //!!20231228pm09 coderB
    bidder: {
        type: Array,
        default: []
    },

    token_id:{
        type: String,
        default:""
    },
    released_date: {
        type: Date
    },
    category_id: { type: Schema.Types.ObjectId, ref: 'category' },
    catlevel2_id: { type: Schema.Types.ObjectId, ref: 'category' },
    catlevel3_id: { type: Schema.Types.ObjectId, ref: 'category' },
    collection_id: { type: Schema.Types.ObjectId, ref: 'collection' },
    season_id: { type: Schema.Types.ObjectId, ref: 'seasons' },
    episode: { type: Number, default: -1 },
    current_owner: { type: Schema.Types.ObjectId, ref: 'users' },
    author_id: { type: Schema.Types.ObjectId, ref: 'users' },
    artist: { type: Schema.Types.ObjectId, ref: 'artists' },
    format: {
        type: String,
        default: ''
    },
    status:{
        type: String,
        enum : ['active','inactive'],
        default: 'inactive'
    },
    minted_date: {
        type: Date,
    },
    create_date: {
        type: Date,
        default: Date.now
    },

    lyrics: {
        type: String,
        default:""
    },

    f_sell: {
        type: Boolean,
        default: false
    },
    clips: {
        type: Array,
        default: []
    },
    trailers: {
        type: Array,
        default: []
    },

    // for audio book
    author_name: {
        type: String,
        default: ''
    },
    publish_date: {
        type: Date,
        default: null
    },

    // for movie
    f_movie_watch_free: {
        type: Boolean,
        default: false
    },
//!! -- Standard Edition --
    es_enabled: { 
        type: Boolean,
        default: false
    },

    es_title: {
        type: String,
    },

    es_description: {
        type: String,
    },

    es_rent_price: {
        type: Number,
    },

    es_thumb: {
        type: String,
        default: ''
    },
    es_audio: {
        type: String,
        default: ''
    },
    es_video: {
        type: String,
        default: ''
    },
    es_pre_video: {
        type: String,
    },
    es_clips: {
        type: Array,
        default: []
    },
    es_trailers: {
        type: Array,
        default: []
    },
    es_extras: {
        type: Array,
        default: []
    },
    
    es_options: {
        type: Array,
        default: []
    },
    es_inventories: [
        inventorySchema
    ],
    
    // for standard buy now
    es_b_limited: {
        type: Boolean,
        default: false
    },
    es_b_f_accept_offer: {
        type: Boolean,
        default: false
    },

    es_b_total: {
        type: Number,
        default: 0
    },

    es_n_sell: {
        type: Number,
        default: 0
    },

    es_b_n_sold: {
        type: Number,
        default: 0
    },

    es_b_price: {
        type: String,
        default: ''
    },
    es_b_startDate: {
        type: Date,
        default: Date.now
    },
    es_b_endMode: {
        type: String,
        default: 'noend'
    },
    es_b_endDate: {
        type: Date,
    },
    // for auction
    es_is_auction: {
        type: Boolean,
        default: false
    },

    es_a_total: {
        type: Number,
        default: 0
    },

    es_a_n_sold: {
        type: Number,
        default: 0
    },

    es_a_starting_price: {
        type: Number,
    },
    es_a_f_accept_offer: {
        type: Boolean,
        default: false
    },
    es_a_default_bid_price: {
        type: Number,
    },
    es_a_reserve_price: {
        type: Number,
    },
    es_a_bid_step: {
        type: Number,
        default: 1
    },
    es_a_startDate: {
        type: Date,
        default: Date.now
    },
    es_a_endDate: {
        type: Date,
    },

    // //!! -- Collectible Edition --
    ec_enabled: { // Collectible Edition Enabled
        type: Boolean,
        default: false
    },
    ec_description: {
        type: String,
    },

    ec_rent_price: {
        type: Number,
    },

    ec_thumb: {
        type: String,
        default: ''
    },
    ec_audio: {
        type: String,
        default: ''
    },
    ec_video: {
        type: String,
        default: ''
    },
    ec_pre_video: {
        type: String,
    },
    ec_clips: {
        type: Array,
        default: []
    },
    ec_trailers: {
        type: Array,
        default: []
    },
    ec_extras: {
        type: Array,
        default: []
    },

    ec_options: {
        type: Array,
        default: []
    },
    ec_inventories: [inventorySchema],
    
    // for standard buy now
    ec_b_limited: {
        type: Boolean,
        default: false
    },
    ec_b_f_accept_offer: {
        type: Boolean,
        default: false
    },
    ec_n_sell: {
        type: Number,
        default: 0
    },

    ec_b_total: {
        type: Number,
        default: 0
    },

    ec_b_n_sold: {
        type: Number,
        default: 0
    },
    ec_b_price: {
        type: Number,
    },
    ec_b_startDate: {
        type: Date,
        default: Date.now
    },
    ec_b_endMode: {
        type: String,
        default: 'noend'
    },
    ec_b_endDate: {
        type: Date,
    },
    // for auction
    ec_is_auction: {
        type: Boolean,
        default: false
    },

    ec_a_total: {
        type: Number,
        default: 0
    },

    ec_a_n_sold: {
        type: Number,
        default: 0
    },
    ec_a_starting_price: {
        type: Number,
    },
    ec_a_f_accept_offer: {
        type: Boolean,
        default: false
    },
    ec_a_default_bid_price: {
        type: Number,
    },
    ec_a_reserve_price: {
        type: Number,
    },
    ec_a_bid_step: {
        type: Number,
        default: 1
    },
    ec_a_startDate: {
        type: Date,
        default: Date.now
    },
    ec_a_endDate: {
        type: Date,
    },

    //!! -- Limited Edition --
    el_enabled: { // Limited Edition Enabled
        type: Boolean,
        default: false
    },
 
    el_description: {
        type: String,
    },
    el_rent_price: {
        type: Number,
    },

    el_thumb: {
        type: String,
        default: ''
    },
    el_audio: {
        type: String,
        default: ''
    },
    el_video: {
        type: String,
        default: ''
    },
    el_pre_video: {
        type: String,
    },
    el_clips: {
        type: Array,
        default: []
    },
    el_trailers: {
        type: Array,
        default: []
    },
    el_extras: {
        type: Array,
        default: []
    },
    
    el_options: {
        type: Array,
        default: []
    },
    el_inventories: [ inventorySchema ],
    
    // for standard buy now
    el_b_limited: {
        type: Boolean,
        default: false
    },
    el_b_f_accept_offer: {
        type: Boolean,
        default: false
    },
    el_n_sell: {
        type: Number,
        default: 0
    },
    el_b_price: {
        type: Number,
    },
    el_b_startDate: {
        type: Date,
        default: Date.now
    },
    el_b_endMode: {
        type: String,
        default: 'noend'
    },
    el_b_endDate: {
        type: Date,
    },
    // for auction
    el_is_auction: {
        type: Boolean,
        default: false
    },
    
    el_n_now_sell: {
        type: Number,
        default: 0
    },
    el_a_starting_price: {
        type: Number,
    },
    el_a_f_accept_offer: {
        type: Boolean,
        default: false
    },
    el_a_default_bid_price: {
        type: Number,
    },
    el_a_reserve_price: {
        type: Number,
    },
    el_a_bid_step: {
        type: Number,
        default: 1
    },
    el_a_startDate: {
        type: Date,
        default: Date.now
    },
    el_a_endDate: {
        type: Date,
        default: Date.now
    },

    // us shipping rule
    // shipping_method: {
    //     type: String, 
    // },
    // shipping_carrier: {
    //     type: String
    // },
    // shipping_description: {
    //     type: String,
    // },
    // shipping_duration: {
    //     type: Number
    // },
    // shipping_item_price: {
    //     type: Number
    // },
    // shipping_items_price: {
    //     type: Number
    // },

    // other shipping rule
    // other_shipping_rules: [
    //     other_shipping_rule_schema
    // ],

    // return
    f_accept_return: {
        type: Boolean,
    },

    f_buyer_pay: {
        type: Boolean
    },


    // added by dreampanda 
    n_reaction: {
        type: Number,
        default: 0
    },
    n_reaction_detail: {
        r_1: { type: Number, default: 0 },
        r_2: { type: Number, default: 0 },
        r_3: { type: Number, default: 0 },
        r_4: { type: Number, default: 0 },
        r_5: { type: Number, default: 0 },
        r_6: { type: Number, default: 0 },
        r_7: { type: Number, default: 0 },
        r_8: { type: Number, default: 0 },
        r_9: { type: Number, default: 0 },
        r_10: { type: Number, default: 0 },
        r_11: { type: Number, default: 0 },
        r_12: { type: Number, default: 0 },
        r_13: { type: Number, default: 0 },
        r_14: { type: Number, default: 0 },
        r_15: { type: Number, default: 0 },
        r_16: { type: Number, default: 0 },
        r_17: { type: Number, default: 0 },
        r_18: { type: Number, default: 0 },
        r_19: { type: Number, default: 0 },
        r_20: { type: Number, default: 0 },
        r_21: { type: Number, default: 0 },
        r_22: { type: Number, default: 0 },
    },

    n_play: {
        type: Number,
        default: 0
    },

    daily_play: [
        {
            date: { type: String, default: '' },
            count: { type: Number, default: 0 }
        }
    ],
    
    n_comment: {
        type: Number,
        default: 0
    },
    
    n_love: {
        type: Number,
        default: 0
    },

    n_like: {
        type: Number,
        default: 0
    },

    daily_trending: [
        {
            date: {
                type: String,
                default: ""
            },
            count: {
                type: Number,
                default: 0
            }
        }
    ],

    n_sale: {
        type: Number,
        default: 0
    },
    daily_sale: [
        {
            date: {
                type: String, default: ''
            },
            count: {
                type: Number, default: 0
            }
        }
    ],

   
    n_boost: {
        type: Number,
        default: 0
    },


});

// itemSchema.plugin(uniqueValidator);//!!2022.10.22
itemSchema.plugin(mongoosePaginate);

module.exports = mongoose.model('item', itemSchema,config.db.prefix+'item');