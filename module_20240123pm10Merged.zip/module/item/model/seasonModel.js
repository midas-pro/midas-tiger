/*
Project : Cryptotrades
FileName : cartModel.js
Author : Indiefire
File Created : 21/07/2021
CopyRights : Indiefire
Purpose : This is the file which used to define cart schema that will store and reterive item cart information.
*/

var mongoose = require('mongoose');
var mongoosePaginate = require('mongoose-paginate-v2');
var uniqueValidator = require('mongoose-unique-validator');
var config = require('../../../helper/config')
const Schema = mongoose.Schema;

var seasonSchema = mongoose.Schema({
    number: {
        type: Number,
        required: [true, "Season Number should be input"]
    },
    description: {
        type: String,
        default: ''
    },
    imageUrl: {
        type: String,
        required: [true, "Season Image should be selected"]
    },
    creator_id: { type: Schema.Types.ObjectId, ref: 'users' },
    created_date: {
        type: Date,
        default: Date.now
    },
});

seasonSchema.plugin(uniqueValidator);
seasonSchema.plugin(mongoosePaginate);

module.exports = mongoose.model('seasons', seasonSchema,config.db.prefix+'seasons');