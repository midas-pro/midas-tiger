
var mongoose = require('mongoose');
var mongoosePaginate = require('mongoose-paginate-v2');
var uniqueValidator = require('mongoose-unique-validator');
var config = require('../../../helper/config')
const Schema = mongoose.Schema;

var transactionSchema = mongoose.Schema({
    seller: {
        type: Schema.Types.ObjectId, 
        ref: 'users'
    },
    buyer: {
        type: Schema.Types.ObjectId, 
        ref: 'users'
    },
    order_id: {
        type: Schema.Types.ObjectId,
        ref: 'offers'
    },
    item_id: { type: Schema.Types.ObjectId, ref: 'item' },
    edition: {  
        type: String,
    },
    option: {
        type: Object
    },
    type: {
        type: String,
        default: 'order'
    },
    amount: {
        type: Number,
        default: 1
    },
    price: {
        type: Number
    },
    created_date: {
        type: Date,
        default: Date.now
    },
});

transactionSchema.plugin(uniqueValidator);
transactionSchema.plugin(mongoosePaginate);

module.exports = mongoose.model('transactions', transactionSchema,config.db.prefix+'transactions');