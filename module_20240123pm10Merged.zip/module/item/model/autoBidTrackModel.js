
var mongoose = require('mongoose');
var mongoosePaginate = require('mongoose-paginate-v2');
var uniqueValidator = require('mongoose-unique-validator');
var config = require('./../../../helper/config')
const Schema = mongoose.Schema;

var autoBidTrackSchema = mongoose.Schema({
    created_date: {
        type: Date,
        default: Date.now
    },
});

autoBidTrackSchema.plugin(uniqueValidator);
autoBidTrackSchema.plugin(mongoosePaginate);

module.exports = mongoose.model('autobidtracks', autoBidTrackSchema,config.db.prefix+'autobidtracks');