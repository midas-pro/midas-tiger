/*
Project : Cryptotrades
FileName :  offerModel.js
Author : Indiefire
File Created : 21/07/2021
CopyRights : Indiefire
Purpose : This is the file which used to define offer schema that will store and reterive item offer information.
*/

var mongoose = require('mongoose');
var mongoosePaginate = require('mongoose-paginate-v2');
var uniqueValidator = require('mongoose-unique-validator');
var config = require('./../../../helper/config')
const Schema = mongoose.Schema;

var offerSchema = new Schema({
    created_date: {
        type: Date,
        default: Date.now
    },
    amount: {
        type: Number,
        default: 1
    },
    price: {
        type: Number,
        default: 0
    },
    sender: {
        type: String,
        default: 'Buyer'
    },
    status: {
        type: String,
        default: 'Pending'
    }
});

var orderItemSchema = new Schema({
    item_id: { type: Schema.Types.ObjectId, ref: 'item' }, // available only if type is 'bid' or 'offer'
    amount: { type: Number, default: 0 },
    catlevel1: { type: String, default: '' },
    catlevel2: { type: String, default: '' },
    catlevel3: { type: String, default: '' },
    edition: { type: String, default: '' },
    option: { type: Object, default: null },
    name: { type: String, default: '' },
    price: { type: Number, default: '' },
    status: { type: String, default: 'Pending' },
    thumb: { type: String, default: '' },
    type: { type: String, default: '' },
    receive_type: { type: String, default: '' },
    ship_date: { type: Date, default: Date.now },
    ship_carrier: { type: String, default: '' },
    trackId: { type: String, default: '' },
    other_content: { type: String, default: '' }
});

var offerSchema = mongoose.Schema({
    item_id: { type: Schema.Types.ObjectId, ref: 'item' }, // available only if type is 'bid' or 'offer'
    sender: { type: Schema.Types.ObjectId, ref: 'users' },
    receiver: { type: Schema.Types.ObjectId, ref: 'users' },
    price: {
        type: Number
    },
    amount: {
        type: Number,
        // default: 1
    },
    status: {
        type: String,
        enum: ['Pending', 'Accepted', 'You Replied', 'Buyer Replied', 'Seller Replied', 'Declined',
           /*'Pending',*/ 'Canceled', 'Shipped', 'Delivered'],
        // offer,bid status: 'Pending','Accepted','You Replied','Seller Replied','Declined',
        // order status : 'Pending', 'Canceled', 'Shipped', 'Delivered'
        // default: 'Pending'
    },
    type: {
        type: String,
        enum: ['offer', 'bid', 'order'],
        default: 'offer'
    },
    edition: {
        type: String,
    },
    option: {
        type: Object
    },
    created_date: {
        type: Date,
        default: Date.now
    },
    trackId: {
        type: String,
    },
    ship_carrier: {
        type: String
    },
    ship_date: {
        type: Date,
        // default: Date.now
    },
    orderId: {
        type: String,
    },
    addr_fullname: {
        type: String,
    },
    addr_street: {
        type: String,
    },
    addr_city: {
        type: String,
    },
    addr_state: {
        type: String,
    },
    addr_zipcode: {
        type: String,
    },
    addr_country: {
        type: String,
    },
    offers: [offerSchema],
    // items: { // available only if type is 'order'
    //     type: Array,
    //     default: []
    //     // [ { item_id, amount, price per item, edition, status }, ... ]
    // },

    items: [orderItemSchema],

    paid: {
        type: Boolean
    },
    from: {
        type: String,
        enum: ['order', 'offer', 'bid'],
        default: 'order'
    },

    is_winner_bid: {
        type: Boolean
    },
    bid_step: {
        type: Number,
        default: 1
    },
    expired: {
        type: Boolean,
    },
    //!!20240107am10 coderC To save shipping price, added the below variable.
    shipping_price: {
        type: Number,
        default: 0
    }
    
});

offerSchema.plugin(uniqueValidator);
offerSchema.plugin(mongoosePaginate);

module.exports = mongoose.model('offer', offerSchema, config.db.prefix + 'offer');