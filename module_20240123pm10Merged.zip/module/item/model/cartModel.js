/*
Project : Cryptotrades
FileName : cartModel.js
Author : Indiefire
File Created : 21/07/2021
CopyRights : Indiefire
Purpose : This is the file which used to define cart schema that will store and reterive item cart information.
*/

var mongoose = require('mongoose');
var mongoosePaginate = require('mongoose-paginate-v2');
var uniqueValidator = require('mongoose-unique-validator');
var config = require('../../../helper/config')
const Schema = mongoose.Schema;

var cartSchema = mongoose.Schema({
    item_id: { type: Schema.Types.ObjectId, ref: 'item' },
    edition: {
        type: String,
        default: "standard"
    },
    option: {
        type: Object,
        default: null
    },
    user_id: { type: Schema.Types.ObjectId, ref: 'users' },
    amount: {
        type: Number,
        default:1
    },
    offer_id: {
        type: Schema.Types.ObjectId, ref: 'offer'
    },
    type: {
        type: String,
        default: 'cart'
    },
    created_date: {
        type: Date,
        default: Date.now
    },
});

cartSchema.plugin(uniqueValidator);
cartSchema.plugin(mongoosePaginate);

module.exports = mongoose.model('carts', cartSchema,config.db.prefix+'carts');