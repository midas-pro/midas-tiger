/*
Project : Cryptotrades
FileName : item.js
Author : Indiefire
File Created : 21/07/2021
CopyRights : Indiefire
Purpose : This is the file which used to define all route releated to collecion api request.
*/

var express = require('express')
var router = express.Router();
var itemController = require("./../controller/itemController")
var trackingController = require("./../controller/trackingController") // added by dreampanda 20230526
var auth = require("./../../../middleware/auth");
var adminauth = require("./../../../middleware/adminauth");
var optionalauth = require("./../../../middleware/optionalauth");
const { check } = require('express-validator');

router.post('/add',[check('name').not().isEmpty(),check('price').not().isEmpty(),check('description').not().isEmpty(),check('category_id').not().isEmpty(),check('collection_id').not().isEmpty(),auth],itemController.add)
router.get('/get_editable_status', auth, itemController.get_editable_status);
router.get('/get_by_id', optionalauth, itemController.get_by_id);
// router.put('/update',[check('item_id').not().isEmpty(),auth],itemController.update)
router.put('/update', auth, itemController._update);
router.delete('/delete',[check('item_id').not().isEmpty(),auth],itemController.delete)
router.get('/list',optionalauth,itemController.list)
router.get('/items',optionalauth,itemController.items) // added by dreampanda 20230521 am 10
router.get('/item', optionalauth, itemController.item)
router.get('/detail', optionalauth, itemController.getItemDetail);
router.get('/read_my_items', auth, itemController.read_my_items);
/* !!20240106pm8 coderd {(B)(New) hide categories in discover that have no ite} */ 
router.post("/categoryfilter",auth,itemController.category_filter)

router.get('/listbycollection',itemController.listByCollection)
router.get('/morefromcollection',itemController.moreFromCollection)
router.post('/addviews',auth,itemController.addViews)
router.get('/viewslist',optionalauth,itemController.recentlyViewed)
router.post('/addfavourites',auth,itemController.actionFavourite)
router.get('/favouriteslist',itemController.listFavourite)
router.get('/favouriteself',optionalauth,itemController.isFavourite)
//router.post('/addcart',[check('item_id').not().isEmpty(),auth],itemController.actionCart)
//router.post('/removecart',[check('cart_id').not().isEmpty(),auth],itemController.removeCart)
//router.get('/cartslist',itemController.listCart)
router.post('/publish',[check('item_id').not().isEmpty(),auth],itemController.publish)
router.post('/purchase',[check('item_id').not().isEmpty(),auth],itemController.purchase)
router.post('/bulkpurchase',[check('item_id').not().isEmpty(),auth],itemController.bulkpurchase)
router.get('/history',itemController.history)
router.get('/prices',itemController.pricelist)

router.post('/get_stock', itemController.get_stock)
router.post('/addoffer',[auth],itemController.addOffers)
router.post('/removeoffer',[check('offer_id').not().isEmpty(),auth],itemController.removeOffers)
router.post('/actionoffer',[check('offer_id').not().isEmpty(),auth],itemController.actionOffers)
router.get('/offers',optionalauth,itemController.listOffers)
router.get('/checkbalance',auth,itemController.checkUserBalance)
router.post('/sendeth',[check('eth_address').not().isEmpty(),check('amount').not().isEmpty(),auth],itemController.sendETH)
router.post('/report',[check('message').not().isEmpty(), check('item_id').not().isEmpty(),auth],itemController.report)
router.post('/updateprice',[check('item_id').not().isEmpty(),auth],itemController.updatePrice)

router.get('/view/:id',itemController.view)
router.post('/generateabi',itemController.generateHash)
router.get('/getabi',itemController.getABI)

// added by dreampanda 20230525 am 5
router.get('/get_bid', optionalauth, itemController.getBid);
router.post('/set_bid', auth, itemController.setBid);
router.post('/set_auto_bid', auth, itemController.setAutoBid);
router.post('/set_offer', auth, itemController.setOffer);
router.post('/set_rent', auth, itemController.setRent);
router.post('/get_bid_status', auth, itemController.getBidStatus);
router.post('/get_updated_bid', itemController.getUpdatedBid);
router.post('/get_bid_history', itemController.getBidHistory);
router.post('/get_available_from', itemController.getAvailableFromList);
router.post('/add_shipped_info', auth, itemController.addShippedInfo);
router.get('/getTrackingInfo', trackingController.getTrackingInfo)


router.post('/create_item_comment_reaction', auth, itemController.create_item_comment_reaction);
router.get('/read_item_comment_reaction', auth, itemController.read_item_comment_reaction);

router.post('/create_item_comment_love', auth, itemController.create_item_comment_love);


router.post('/create_item_reaction', auth, itemController.create_item_reaction);
router.get('/read_item_reaction', auth, itemController.read_item_reactions);

router.post('/create_item_play', auth, itemController.create_item_play);
router.get('/read_item_play', auth, itemController.read_item_plays);

router.post('/create_item_comment', auth, itemController.create_item_comment);
router.get('/read_item_comment', auth, itemController.read_item_comments);

router.post('/create_item_love', auth, itemController.create_item_love);
router.get('/read_item_love', auth, itemController.read_item_loves);

router.post('/create_item_like', auth, itemController.create_item_like);
router.get('/read_item_like', auth, itemController.read_item_likes);

router.post('/create_item_boost', auth, itemController.create_item_boost);
router.get('/read_item_boost', auth, itemController.read_item_boosts);

// season
router.post('/create_season', auth, itemController.create_season);
router.get('/read_seasons', itemController.read_seasons);

router.get('/get_items_listings', optionalauth, itemController.get_items_listings)
router.get('/get_library_items', auth, itemController.get_library_items)

router.get('/get_home_content', optionalauth, itemController.get_home_content)
router.get('/get_favorite_digital_item', auth, itemController.get_favorite_digital_item)

router.get('/get_all', optionalauth, itemController.get_all);

router.get('/get_info_for_item', optionalauth, itemController.get_info_for_item);

router.post('/get_my_merchandise_item', auth, itemController.get_my_merchandise_item)

router.get('/get_reactions_data', optionalauth, itemController.get_reactions_data);

router.get('/get_my_items', auth, itemController.get_my_items)

router.post('/add_clip_or_trailer_to_item', auth, itemController.add_clip_or_trailer_to_item);

router.post('/add_to_cart', auth, itemController.add_to_cart);

router.get('/get_cart', auth, itemController.get_cart);

router.post('/manage_cart', auth, itemController.manage_cart);

router.post('/delete_cart', auth, itemController.delete_cart);

router.post('/handle_offer', auth, itemController.handle_offer)

router.post('/handle_cart', auth, itemController.handle_cart)

module.exports = router