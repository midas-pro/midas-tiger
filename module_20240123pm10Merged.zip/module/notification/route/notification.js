/*
Project : Cryptotrades
FileName : notification.js
Author : Indiefire
File Created : 21/07/2021
CopyRights : Indiefire
Purpose : This is the file which used to define all route releated to collecion api request.
*/

var express = require('express')
var router = express.Router();
var notificationController = require("../controller/notificationController")
var auth = require("../../../middleware/auth");
var adminauth = require("../../../middleware/adminauth");
var optionalauth = require("../../../middleware/optionalauth");
const { check } = require('express-validator');

router.post('/add',auth,notificationController.add)
router.put('/update',[check('notification_id').not().isEmpty(),auth],notificationController.update);
router.put('/read',[check('notification_id').not().isEmpty(),auth],notificationController.read);
router.get('/fulllist',adminauth,notificationController.getAdminList)
router.get('/list',optionalauth,notificationController.list)
router.get('/detail',notificationController.view)
router.delete('/delete',[check('notification_id').not().isEmpty(),auth],notificationController.delete)

// added by dreampanda 20230514 am 1 
router.post('/add_posting_notif',auth,notificationController.addPostingNotif)
router.post('/set_is_read',auth,notificationController.setIsRead)
router.get('/get_notifications', optionalauth, notificationController.get_notifications)
router.get('/get_unread_count', auth, notificationController.get_unread_count)
router.get('/deleteAll', notificationController.deleteAll)
//!!20240108pm11 coderC To save notification block user, added the below api. "(B) other’s Fanpage -> Notification for this user"
router.post('/add_notification_block_list', auth, notificationController.add_notification_block_list)
//!!20240109pm12 coderC To remvoe notification block user in notification block user list, added the below api. "(B) other’s Fanpage -> Notification for this user"
router.post('/remove_notification_block_list', auth, notificationController.remove_notification_block_list);
module.exports = router