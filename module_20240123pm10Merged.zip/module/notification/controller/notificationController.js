/*
Project : Cryptotrades
FileName : notificationController.js
Author : Indiefire
File Created : 21/07/2021
CopyRights : Indiefire
Purpose : This is the file which used to define all notification related api function.
*/

var notifications = require('../model/notificationModel');
var items = require('../../item/model/itemModel');
var userController = require('../../user/controller/userController');
var validator = require('validator');
const { validationResult } = require('express-validator');
var cp = require('child_process');
var Web3 = require('web3');
const config = require('../../../helper/config');
var fs = require('fs')

// added by dreampanda 20230514 am 1 
var users = require('../../user/model/userModel');
var followers = require('../../user/model/followerModel')
const mongoose = require('mongoose');
const { NOTIFICATION_TYPES } = require('../../helper/notification_config');
const playlistModel = require('../../playlist/model/playlistModel');
const { getErrLine } = require("../../helper/helpers");
exports.add = async function(req,res) {
    res.json({
        status: true,
        message: "Empty action"
    })

}
/*
* This is the function which used to update notification in database
*/
exports.update = function(req,res) {
    console.log(getErrLine().str, "apistart");
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        res.json({
            status: false,
            message: "Request failed",
            errors:errors.array()
        });
        return;
    }  
    notifications.findOne({_id:req.body.notification_id, to_id: req.body.to_id}, function (err, notification) {
        if (err || !notification) {
            res.json({
                status: false,
                message: "Notification not found",
                errors:err
            });
            return;
        } else {
            notification.msg = req.body.msg ?  req.body.msg : notification.msg;
            notification.items = req.body.items;
            notification.save(function (err , notification) {
                if (err) {
                    res.json({
                        status: false,
                        message: "Request failed",
                        errors:err
                    });
                    return;
                } else {
                    res.json({
                        status: true,
                        message: "Notification updated successfully",
                        result: notification 
                    });  
                }
            });
        }
    });
}

/*
* This is the function which used to read notification in database
*/
exports.read = function(req,res) {
    console.log(getErrLine().str, "apistart");
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        res.json({
            status: false,
            message: "Request failed",
            errors:errors.array()
        });
        return;
    }  
    notifications.findOne({_id:req.body.notification_id, to_id: req.body.to_id}, function (err, notification) {
        if (err || !notification) {
            res.json({
                status: false,
                message: "Notification not found",
                errors:err
            });
            return;
        } else {
            notification.is_unread = false;
            notification.save(function (err , notification) {
                if (err) {
                    res.json({
                        status: false,
                        message: "Request failed",
                        errors:err
                    });
                    return;
                } else {
                    res.json({
                        status: true,
                        message: "Notification updated successfully",
                        result: notification 
                    });  
                }
            });
        }
    });
}

/*
* This is the function which used to delete notification in database
*/
exports.delete = function(req,res) {
    console.log(getErrLine().str, "apistart");
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        res.json({
            status: false,
            message: "Request failed",
            errors:errors.array()
        });
        return;
    }  
    notifications.findOne({_id:req.body.notification_id, to_id:req.decoded.to_id}, function (err, notification) {
        if (err || !notification) {
            res.json({
                status: false,
                message: "Notification not found",
                errors:err
            });
            return;
        } 
        items.count({_id:req.body.notification_id},function(err,count) {
            if(count == 0) {
                notifications.deleteOne({_id:req.body.notification_id},function(err) {
                    res.json({
                        status: true,
                        message: "Notification deleted successfully"
                    }); 
                })
            } else {
                res.json({
                    status: true,
                    message: "Notification has items and you can't delete it"
                }); 
            }

        })
    });
}

/**
 *  This is the function which used to view notification
 */
exports.view = function(req,res) {
    console.log(getErrLine().str, "apistart");
    notifications.findOne({_id:req.query.notification_id}).exec( function (err, notification) {
        if (err) {
            res.json({
                status: false,
                message: "Request failed",
                errors:"Notification not found"
            });
            return;
        }
        if(!notification) {
            res.json({
                status: false,
                message: "Request failed",
                errors:"Notification not found"
            });
            return;
        } 
        res.json({
            status: true,
            message: "Notification info retrieved successfully",
            result: notification
        });
    })
}

/**
 * This is the function which used to list notification with filters
 */
exports.list = function(req,res) {
    console.log(getErrLine().str, "apistart");
    var keyword = req.query.keyword ? req.query.keyword : ''; 
    keyword = keyword.replace("+"," ");     
    var page = req.query.page ? req.query.page : '1';  
    var limit = req.query.limit ? req.query.limit : '10';  
    var query  = notifications.find();
    var offset = ( page == '1' ) ? 0 : ((parseInt(page-1))*10);
    if ( keyword != '' ) {
        search = { $or: [ { 
            msg :   {
                $regex: new RegExp(keyword, "ig")
        }  } ] }
       query = query.or(search)
    }    
    if(req.query.type == "my") {
        if(req.query.to_id != null) {
            query = query.where('to_id',req.query.to_id).sort('-create_date');
        }
    } else {
        query = query.sort('-create_date')
    }

    var options = {
    select:   'msg items is_unread from_id to_id create_date',
    populate: 'from_id to_id',
    page:page,
    offset:offset,
    limit:limit,    
    };  
    notifications.paginate(query, options).then(function (result) {
        res.json({
            status: true,
            message: "Notification retrieved successfully",
            data: result
        });
    }); 
}

/**
 * This is the function which used to list all items for admin
 */
exports.getAdminList = function(req,res) {
    console.log(getErrLine().str, "apistart");
    var keyword = req.query.keyword ? req.query.keyword : ''; 
    keyword = keyword.replace("+"," ");     
    var page = req.query.page ? req.query.page : '1';  
    var query  = notifications.find();
    var offset = ( page == '1' ) ? 0 : ((parseInt(page-1))*10);
    if ( keyword != '' ) {
        search = { $or: [ { 
            msg :   {
                $regex: new RegExp(keyword, "ig")
        }  } ] }
       query = query.or(search)
    }    
    query = query.sort('-create_date')
    var options = {
    select:   'msg items is_unread from_id to_id create_date',
    populate: 'from_id to_id',
    page:page,
    offset:offset,
    limit:10,    
    };  
    notifications.paginate(query, options).then(function (result) {
        res.json({
            status: true,
            message: "Notification retrieved successfully",
            data: result
        });
    });
}

// added by dreampanda 20230514 am 1
exports.addPostingNotif = function(req, res) {
    console.log(getErrLine().str, "apistart");
    var query = users.find();
    var search = {
        $or: [
            { 
                'notif_posts.is_new': true,
                'notif_posts.is_following': true,
                'notif_posts.is_following_accounts': { $in: [ mongoose.Types.ObjectId(req.body.from_id) ] }
            },
            {
                'notif_posts.is_new': true,
                'notif_posts.is_following': false,
                'notif_posts.is_selected_accounts': { $in: [ mongoose.Types.ObjectId(req.body.from_id) ] }
            }
        ]
    };
    query = query.or(search);
    query.exec(function(err, result) {
        if(err || !result) {
            res.json({
                status: false,
                message: 'No users for notification',
                errors: err
            })
        } else {
            var documents = [];
            result.forEach((d, index) => {
                var notification = Object.assign({}, req.body);
                notification.to_id = d._id;
                notification.is_unread = true;
                documents.push(notification);
            });
            console.log(documents);
            notifications.insertMany(documents, function(err, result2) {
                if(err) {
                    res.json({
                        status: false,
                        message: 'Insert error',
                        errors: err
                    }) 
                } else {
                    res.json({
                        status: true,
                        message: 'Saved successfully', 
                        data: result
                    })
                }
            })
        }
    })
}

// added by dreampanda 20230516 pm 11
exports.setIsRead = function(req, res) {
    console.log(getErrLine().str, "apistart");
    var user_id = req.decoded.user_id;
    // 20240120am5 CoderB "(B) notification - unread isn’t working "
    // notifications.updateMany({ to_id: user_id }, { is_read: true }, function(err, result) {
    //     if(err || !result) {
    //         res.json({
    //             status: false,
    //             message: 'no update'
    //         })
    //     } else {
    //         res.json({
    //             status: true,
    //             message: 'updated successfully'
    //         })
    //     }
    // })
    // !!20240121am9 coderd {(B)make offer}
    notifications.updateMany({to_id:user_id}
    // notifications.updateMany({$or:[
    //     {from_id:user_id},
    //     {to_id:user_id}
    // ]}
    , { is_read: true }, function(err, result) {
        if(err || !result) {
            console.log(result,"This is notification update result.")
            res.json({
                status: false,
                message: 'no update'
            })
        } else {
            res.json({
                status: true,
                message: 'updated successfully'
            })
        }
    })
}

exports.get_unread_count = async function(req, res) {
    console.log(getErrLine().str, "apistart");
    var user_id = req.decoded.user_id;
    try {
        var count = await notifications.count({
            to_id: user_id,
            is_read: false
        });
        res.json({
            status: true,
            message: "retrived successfully",
            result: count
        })
    } catch (err) {
        console.log(err);
        res.json({
            status: false,
            message: "Something went wrong"
        });
    }
}

exports.get_notifications = async function(req, res) {
    console.log(getErrLine().str, "apistart");
    var to_id = req.query.to_id || req.decoded.user_id;
	var page = req.query.page || 1;
	var limit = req.query.limit || 15;
    var keyword = req.query.keyword || '';
    var show = req.query.show || 'everything';
    var view = req.query.view || 'all';
    var sort = req.query.sort || 'new';

	try {
        // 20240109am2 CoderB "(B)notifications"
		var query = notifications.find({
            // !!20240121am5 coderd changed below code
            $and:[
                {from_id:{$ne:to_id}},
                {to_id:to_id}
                // !!20240121am5 coderd commentd below code
                // {from_id:to_id},!!self favorite notification
            ]
         });
        //  var query = notifications.find({to_id});
		if(keyword != '') {
			query = query.find({ message: { $regex: new RegExp(keyword, "ig") } });
		}
	
		if(show != 'everything') {
			query = query.find({ filter: show });
		}
	
		switch(view) {
			case 'read':
				query = query.find({ is_read: true });
				break;
			case 'unread':
				query = query.find({ is_read: false });
				break;
			default:
				break;
		}
	
		if(sort == 'new') {
			query = query.sort({ create_date: -1 })
		} else {
			query = query.sort({ create_date: 1 })
		}
	

		var offset = page == "1" ? 0 : parseInt(page - 1) * limit;
		var options = {
			page: page,
			offset: offset,
			limit: limit,
		};

		notifications.paginate(query, options).then(async function (result) {
			let updatedDocs = await Promise.all(result.docs.map(async d => {
				// operation for customize component this will make me crazy.
				let populatedResult;
                let query = notifications.findById(d._doc._id)
                .populate({ 
                    path: 'from_id',
                    model: 'users',
                    select: "_id username first_name last_name profile_image metamask_info is_idverified",
                })
                let date = new Date();
				switch(d.type) {
					case NOTIFICATION_TYPES.PLAYLIST_JOIN:
						populatedResult = await	query
						.populate({ path: 'item_id', model: 'playlist' })
						break;
                    case NOTIFICATION_TYPES.PLAYLIST_CHANGE:
                        populatedResult = await query.exec();
                        break;
                    case NOTIFICATION_TYPES.PLAYLIST_UPDATE:
                        populatedResult = await	query
						.populate({ path: 'item_id', model: 'playlist' })
                        break;
                    case NOTIFICATION_TYPES.NEW_FOLLOW:
                        populatedResult = await query.exec();
                        // check follow or not
                        let follower = await followers.findOne({ star_id: populatedResult.from_id?._id, user_id: populatedResult.to_id });
                        if(follower) {
                            populatedResult._doc.isFollow = true;
                        } else {
                            populatedResult._doc.isFollow = true;
                        }
                        break;
                        
                    case NOTIFICATION_TYPES.FAN_SUBSCRIBE:
                        populatedResult = await query.exec();
                        break;
                    case  NOTIFICATION_TYPES.FAN_UNSUBSCRIBE:
                        populatedResult = await query.exec();
                        break;
                    
                    

                    case NOTIFICATION_TYPES.POST_NEW:
                    case NOTIFICATION_TYPES.POST_REACTION:
                    case NOTIFICATION_TYPES.POST_COMMENT:
                    case NOTIFICATION_TYPES.POST_FAVORITE:
                        populatedResult = await query.populate({
                            path: 'item_id',
                            model: 'fanpost'
                        });
                        populatedResult._doc.serverDate = date;
                        break;
                    case NOTIFICATION_TYPES.POST_COMMENT_REACTION:
                    case NOTIFICATION_TYPES.POST_COMMENT_REPLY:
                    case NOTIFICATION_TYPES.POST_REPLY_REACTION:
                        populatedResult = await query.populate({
                            path: 'item_id',
                            model: 'fanpost_comments'
                        });
                        break;
                    case NOTIFICATION_TYPES.ITEM_NEW:
                    case NOTIFICATION_TYPES.ITEM_REACTION:
                    case NOTIFICATION_TYPES.ITEM_COMMENT:
                    case NOTIFICATION_TYPES.ITEM_FAVORITE:
                        populatedResult = await query.populate({
                            path: 'item_id',
                            model: 'item',
                            populate: [
                                {
                                    path: "category_id",
                                    model: "category"
                                },
                                {
                                    path: "author_id",
                                    model: "users",
                                    select: "_id username first_name last_name profile_image metamask_info is_idverified",
                                }
                            ]
                        });
                        break;
                    case NOTIFICATION_TYPES.ITEM_COMMENT_REACTION:
                    case NOTIFICATION_TYPES.ITEM_COMMENT_REPLY:
                        populatedResult = await query.populate({
                            path: 'item_id',
                            model: "item_comments"
                        });
                        break;
                        
                    case NOTIFICATION_TYPES.LIVENOW_NEW:
                        populatedResult = await query.populate({
                            path: "item_id",
                            model: "livenows"
                        });
                        break;

                    case NOTIFICATION_TYPES.BUYING_AUCTIONS:
                    case NOTIFICATION_TYPES.BUYING_OFFER:
                    case NOTIFICATION_TYPES.BUYING_ORDER:
                        populatedResult = await query.populate({
                            path: "items.item_id",
                            model: "item",
                            populate: [
                                {
                                    path: "category_id",
                                    model: "category"
                                },
                                {
                                    path: "author_id",
                                    model: "users",
                                    select: "_id username first_name last_name profile_image metamask_info is_idverified",
                                }
                            ]
                        });
                        break;
                    case NOTIFICATION_TYPES.SELL_AUCTIONS:
                    case NOTIFICATION_TYPES.SELL_BUYNOW:
                    case NOTIFICATION_TYPES.SELL_OFFER:
                    case NOTIFICATION_TYPES.SELL_ORDER:
                        populatedResult = await query.populate({
                            path: "items.item_id",
                            model: "item",
                            populate: [
                                {
                                    path: "category_id",
                                    model: "category"
                                },
                                {
                                    path: "author_id",
                                    model: "users",
                                    select: "_id username first_name last_name profile_image metamask_info is_idverified",
                                }
                            ]
                        });
                        break;
                    case NOTIFICATION_TYPES.SEND_COIN:
                        populatedResult = await query.exec()
                    default:
						break;
				}

				return {
					...populatedResult?._doc,
					serverDate: new Date()
				}
			}))

			const updatedResult = { ...result, docs: updatedDocs };

			res.json({
			  status: true,
			  message: "Retrived successfully",
			  data: updatedResult,
			});
		});

		
	} catch (error) {
		console.log(error);
		res.json({
			status: false,
			message: "Something went wrong"
		});
	}
}

// helper

exports.deleteAll = async function(req, res) {
    console.log(getErrLine().str, "apistart");
	try {
		await notifications.deleteMany({
			status: { $ne: true }
		});
		res.json({
			status: true,
			message: "removed successfully"
		})
	} catch (error) {
		console.log(error);
		res.json({
			status: false,
			message: "Delete successfully"
		})
	}
}

//!!20240108pm11 coderC To add notification block user, added the below function. "(B) other’s Fanpage -> Notification for this user"
exports.add_notification_block_list = async function(req, res) {
    console.log(getErrLine().str, "apistart");
    var user_id = req.decoded.user_id;
    var block_user = req.body.blockUser;
	try {
		let result = await users.update({"_id": user_id}, {$addToSet: {notification_block_list: {'id': block_user}}});
		res.json({
			status: true,
			message: "added successfully",
            result: result
		})
	} catch (error) {
		console.log(error);
		res.json({
			status: false,
			message: "Something went wrong!"
		})
	}
}

//!!20240109pm12 coderC To remove notification block user in notifcation block user list, added the below function. "(B) other’s Fanpage -> Notification for this user"
exports.remove_notification_block_list = async function(req, res) {
    console.log(getErrLine().str, "apistart");
    var user_id = req.decoded.user_id;
    var block_user = req.body.blockUser;
	try {
		let result = await users.update({"_id": user_id}, {$pull: {notification_block_list: {'id': block_user}}});
		res.json({
			status: true,
			message: "removed successfully",
            result: result
		})
	} catch (error) {
		console.log(error);
		res.json({
			status: false,
			message: "Something went wrong!"
		})
	}
}