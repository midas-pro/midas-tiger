/*
Project : Cryptotrades
FileName : notificationModel.js
Author : Indiefire
File Created : 21/07/2021
CopyRights : Indiefire
Purpose : This is the file which used to define notification schema that will communicate and process notification information with mongodb through mongoose ODM.
*/

var mongoose = require('mongoose');
var mongoosePaginate = require('mongoose-paginate-v2');
var uniqueValidator = require('mongoose-unique-validator');
var config = require('../../../helper/config')
const Schema = mongoose.Schema;

const item = new Schema({ 
    item_id: { type: Schema.Types.ObjectId, ref: 'items' },
    edition: {
        type: String,
    },
    option: {
        type: Object,
    },
    amount:{
        type: Number,
        default:1,
    }, 
    price: Number,
});
// Setup schema
var notificationSchema = mongoose.Schema({
    message: {
        type: String,
    },   
    from_id: { type: Schema.Types.ObjectId, ref: 'users' },
    to_id: { type: Schema.Types.ObjectId, ref: 'users' },
    is_read: {
        type: Boolean,
        default: false
    },

    // added by dreampanda
    type: {
        type: String,
    },

    filter: {
        type: String
    },

    item_id: {
        type: String,
    },
    
    n_user: {
        type: Number,
        default: 1
    },

    // for post
    reaction_number: {
        type: Number
    },

    // for follow
    isFollow: {
        type: Boolean,
        default: false
    },

    items: [
        item
    ],
    create_date: {
        type: Date,
        default: Date.now
    },
});

notificationSchema.plugin(uniqueValidator);
notificationSchema.plugin(mongoosePaginate);

module.exports = mongoose.model('notification', notificationSchema,config.db.prefix+'notification');