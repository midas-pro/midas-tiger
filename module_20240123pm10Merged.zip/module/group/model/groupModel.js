/*
Project : Cryptotrades
FileName : groupModel.js
Author : Indiefire
File Created : 21/07/2021
CopyRights : Indiefire
Purpose : This is the file which used to define group collection that will communicate and process group information with mongodb through mongoose ODM.
*/

var mongoose = require('mongoose');
var mongoosePaginate = require('mongoose-paginate-v2');
var uniqueValidator = require('mongoose-unique-validator');
var config = require('../../../helper/config')
const Schema = mongoose.Schema;

// Setup schema
var groupSchema = mongoose.Schema({
    name: {
        type: String,
        minlength: [3, 'Title must be 3 characters or more'],
        maxlength: [255, "Title can't exceed 255 characters"],
        required: [ true , 'Title is required'], 
    },
    members: {
        type: Array,
        default: []
    },
    author_id: { type: Schema.Types.ObjectId, ref: 'users' },
    create_date: {
        type: Date,
        default: Date.now
    },
});

groupSchema.plugin(uniqueValidator);
groupSchema.plugin(mongoosePaginate);

module.exports = mongoose.model('groups', groupSchema,config.db.prefix+'groups');