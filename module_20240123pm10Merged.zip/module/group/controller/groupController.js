/*
Project : Cryptotrades
FileName : groupController.js
Author : Indiefire
File Created : 21/07/2021
CopyRights : Indiefire
Purpose : This is the file which used to define all group related api function.
*/

var groups = require('../model/groupModel');
var userController = require('../../user/controller/userController');
var validator = require('validator');
const { validationResult } = require('express-validator');
var cp = require('child_process');
var Web3 = require('web3');
const config = require('../../../helper/config');
var fs = require('fs')
/*
* This is the function which used to add group in database
*/
exports.add = function(req,res) {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        res.json({
            status: false,
            message: "Request failed by validate param",
            errors:errors.array()
        });
        return;
    }  
    var symbol = req.body.name.replace(" ", "_")
    var group = new groups();
    group.name = req.body.name;
    group.members = req.body.members;
    group.author_id = req.decoded.user_id;
    group.save(function (err ,groupObj) {
        if (err) {
            res.json({
                status: false,
                message: "Request failed",
                errors:err
            });
            return;
        }
        res.json({
            status: true,
            message: "Group created successfully",
            result: groupObj
        });
    });

}

/*
* This is the function which used to update group in database
*/
exports.update = function(req,res) {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        res.json({
            status: false,
            message: "Request failed",
            errors:errors.array()
        });
        return;
    }  
    groups.findOne({_id:req.body.group_id, author_id: req.decoded.user_id}, function (err, group) {
        if (err || !group) {
            res.json({
                status: false,
                message: "Group not found",
                errors:err
            });
            return;
        } else {
            group.name = req.body.name ?  req.body.name : group.name;
            group.members = req.body.members;
            group.save(function (err , group) {
                if (err) {
                    res.json({
                        status: false,
                        message: "Request failed",
                        errors:err
                    });
                    return;
                } else {
                    res.json({
                        status: true,
                        message: "Group updated successfully",
                        result: group 
                    });  
                }
            });
        }
    });
}

/*
* This is the function which used to delete group in database
*/
exports.delete = function(req,res) {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        res.json({
            status: false,
            message: "Request failed",
            errors:errors.array()
        });
        return;
    }  
    groups.findOne({_id:req.body.group_id, author_id:req.decoded.user_id}, function (err, group) {
        if (err || !group) {
            res.json({
                status: false,
                message: "Group not found",
                errors:err
            });
            return;
        } 
        groups.deleteOne({_id:req.body.group_id},function(err) {
            res.json({
                status: true,
                message: "Group deleted successfully"
            }); 
        });
    });
}

/**
 *  This is the function which used to view group
 */
exports.view = function(req,res) {
    groups.findOne({_id:req.query.group_id}).exec( function (err, group) {
        if (err) {
            res.json({
                status: false,
                message: "Request failed",
                errors:"Group not found"
            });
            return;
        }
        if(!group) {
            res.json({
                status: false,
                message: "Request failed",
                errors:"Group not found"
            });
            return;
        } 
        res.json({
            status: true,
            message: "Group info retrieved successfully",
            result: group
        });
    })
}

/**
 * This is the function which used to list group with filters
 */
exports.list = function(req,res) {
    var keyword = req.query.keyword ? req.query.keyword : ''; 
    keyword = keyword.replace("+"," ");     
    var page = req.query.page ? req.query.page : '1';  
    var limit = req.query.limit ? req.query.limit : '10';  
    var query  = groups.find();
    var offset = ( page == '1' ) ? 0 : ((parseInt(page-1))*10);
    if ( keyword != '' ) {
        search = { $or: [ { 
            name :   {
                $regex: new RegExp(keyword, "ig")
        }  } , {
            description : {
                $regex : new RegExp ( keyword , "ig")
            }
        }] }
       query = query.or(search)
    }    
    if(req.query.type == "my") {
        if(req.query.user_id != null) {
            // query = query.where('author_id',req.query.user_id).sort('-create_date');
            query = query.where({
                "members": {
                  "$in": [ req.query.user_id ]
                }
              });
        }
    } else {
        query = query.sort('-create_date')
    }

    var options = {
    select:   'name members author_id create_date',
    populate: 'author_id',
    page:page,
    offset:offset,
    limit:limit,    
    };  
    groups.paginate(query, options).then(function (result) {
        res.json({
            status: true,
            message: "Group retrieved successfully",
            data: result
        });
    }); 
}

/**
 * This is the function which used to list all members for admin
 */
exports.getAdminList = function(req,res) {
    var keyword = req.query.keyword ? req.query.keyword : ''; 
    keyword = keyword.replace("+"," ");     
    var page = req.query.page ? req.query.page : '1';  
    var limit = req.query.limit ? req.query.limit : '10';  
    var query  = groups.find();
    var offset = ( page == '1' ) ? 0 : ((parseInt(page-1))*10);
    if ( keyword != '' ) {
        search = { $or: [ { 
            name :   {
                $regex: new RegExp(keyword, "ig")
        }  } , {
            description : {
                $regex : new RegExp ( keyword , "ig")
            }
        }] }
       query = query.or(search)
    }    
    query = query.sort('-create_date')
    var options = {
    select:   'name members author_id create_date',
    page:page,
    offset:offset,
    limit:limit,    
    };  
    groups.paginate(query, options).then(function (result) {
        res.json({
            status: true,
            message: "Group retrieved successfully",
            data: result
        });
    });
}

