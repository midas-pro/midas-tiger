/*
Project : Cryptotrades
FileName : group.js
Author : Indiefire
File Created : 21/07/2021
CopyRights : Indiefire
Purpose : This is the file which used to define all route releated to collecion api request.
*/

var express = require('express')
var router = express.Router();
var groupController = require("../controller/groupController")
var auth = require("../../../middleware/auth");
var adminauth = require("../../../middleware/adminauth");
var optionalauth = require("../../../middleware/optionalauth");
const { check } = require('express-validator');

router.post('/add',[check('name').not().isEmpty(),auth],groupController.add)
router.put('/update',[check('group_id').not().isEmpty(),auth],groupController.update);
router.get('/fulllist',adminauth,groupController.getAdminList)
router.get('/list',optionalauth,groupController.list)
router.get('/detail',groupController.view)
router.delete('/delete',[check('group_id').not().isEmpty(),auth],groupController.delete)

module.exports = router