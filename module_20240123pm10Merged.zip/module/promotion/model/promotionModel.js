/*
Project : Cryptotrades
FileName : loveModel.js
Author : Indiefire
File Created : 21/07/2021
CopyRights : Indiefire
Purpose : This is the file which used to define love schema that will store and reterive party love information.
*/

var mongoose = require('mongoose');
var mongoosePaginate = require('mongoose-paginate-v2');
var uniqueValidator = require('mongoose-unique-validator');
var config = require('../../../helper/config')
const Schema = mongoose.Schema;

var promotionSchema = mongoose.Schema({
    type: {
        type: String,
        required: true
    },
    item_id: {
        type: mongoose.Schema.Types.ObjectId,
        required: true
    },
    is_search: {
        type: Boolean,
        default: false,
    },
    keywords: {
        type: Array
    },
    is_view_category: {
        type: Boolean,
        default: false
    },
    cat1: {
        type: String
    },
    cat2: {
        type: Schema.Types.ObjectId, ref: 'category',
    },
    cat3: {
        type: Schema.Types.ObjectId, ref: 'category',
    },
    daily_budget: {
        type: Number,
        required: true
    },
    startDate: {
        type: Date,
        required: true
    },
    endDate: {
        type: Date,
        required: true
    },
    status: {
        type: Boolean,
        default: true
    },
    total_paid: {
        type: Number,
        default: 0
    },
    n_views: {
        type: Number,
        default: 0
    },
    created_date: {
        type: Date,
        default: Date.now
    },
    user_id: {
        type: Schema.Types.ObjectId, ref: 'users',
        required: true
    }
});

promotionSchema.plugin(uniqueValidator);
promotionSchema.plugin(mongoosePaginate);

module.exports = mongoose.model('promotions', promotionSchema,config.db.prefix+'promotions');