var express = require('express')
var router = express.Router();
var promotionController = require("../controller/promotionController")
var auth = require("../../../middleware/auth");
var adminauth = require("../../../middleware/adminauth");
var optionalauth = require("../../../middleware/optionalauth");
const { check } = require('express-validator');

router.post('/add_promotion', auth, promotionController.add_promotion )
router.get('/get_promotion', auth, promotionController.get_promotion )
router.post('/edit_promotion', auth, promotionController.get_promotion )

module.exports = router