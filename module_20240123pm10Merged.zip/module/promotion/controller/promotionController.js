

const { match } = require('assert');
var promotionModel = require('../model/promotionModel'),   
    itemModel = require('../../item/model/itemModel'),
    itemloveModel = require('../../item/model/itemloveModel'),
    categoryModel = require('../../category/model/categoryModel');
const fanpostModel = require('../../fanpost/model/fanpostModel');
const fandomModel = require('../../user/model/fandomModel');
const playlistModel = require('../../playlist/model/playlistModel');
const partyModel = require('../../party/model/partyModel');
const livenowModel = require('../../livenow/model/livenowModel');
const collectionModel = require('../../collection/model/collectionModel');
const { getErrLine } = require("../../helper/helpers");
const artistModel = require('../../user/model/artistModel');
exports.add_promotion = async function(req, res) {
    console.log(getErrLine().str, "apistart");
    var user_id = req.decoded.user_id;
    try {
        var newPromotion = new promotionModel(req.body);
        newPromotion.user_id = user_id;
        await newPromotion.save();
        res.json({
            status: true,
            message: "Saved successfully"
        })
    } catch (error) {
        console.log(error);
        res.json({
            status: false,
            message: error.message
        })
    }
}

exports.get_promotion = async function(req, res) {
    console.log(getErrLine().str, "apistart");
    var user_id = req.decoded.user_id;
    var page = req.query.page || 1;
    var limit = req.query.limit || 60;
    var keyword = req.query.keyword || '';
    var type = req.query.type || 'all';
    var cat = req.query.cat;
    var cat2 = req.query.cat2;
    var cat3 = req.query.cat3;
    var filterBy = req.query.filterBy || 'all';
    var sortBy = req.query.sortBy || 'new';
    var mine = req.query.mine;

    
    var query = {  }
    if(mine) {
        query = { ...query, user_id}
    } else {
        
    }

    if(keyword.trim() != "") {

    }

    if(type != 'all') {
        query = { ...query, ...{ type: type } }
    }

    if(type == 'item') {
       query = { ...query, ...{ cat1: cat } }
    }
    
    let date = new Date();
    if(filterBy == 'active' || !mine) {
        let active_query = {
            $and: [
                {startDate: { $lt: date }},
                {endDate: { $gt: date }}
            ]
        }
        query = {  ...query, ...active_query }
        
    } else if(filterBy == 'closed') {
        let closed_query = {
            $or: [
                {startDate: { $gt: date }},
                {endDate: { $lt: date }}

            ]
        }
        query = {  ...query, ...closed_query }
    }

    if(cat2 || cat3) {
        query = { 
            ...query,
            ...{
                is_view_category: true,
                cat2: cat2,
                cat3: cat3
            }
        }
    }

    if(!mine) {
        quey = {
            ...query,
            ...{
                f_search: true,
                keywords: { 
                    $in: [new RegExp(keyword, 'i')]
                }
            }
        }
    }

    
    try {
        console.log(query);
        let promotions = await promotionModel.find(query)
        .sort({ created_date: sortBy == 'new' ? -1 : 1 });
        promotions.map(d => {
            let status
            if(d.startDate > date || d.endDate < date) {
                status = false;
            } else {
                status = true;
            }
            return {
                ...(d._doc || d),
                status
            }
        });
        console.log("promotions");
        console.log(promotions);
        const updatedResults = await Promise.all(promotions.map(async result => {
            let populatedResult;
            if(result.type == 'item') {
                let match = {  }
                if(keyword != '') {
                    match = {
                        $or : [ 
                            { name: { $regex : new RegExp (keyword , "ig") }}, 
                            { description: { $regex : new RegExp (keyword , "ig") }},
                        ]
                    }
                }
                populatedResult = await promotionModel.findById(result._id).populate({ 
                    path: "item_id",
                    model: itemModel,
                    populate: [
                        {
                            path: 'category_id',
                            model: 'category'
                        },
                        {
                            path: 'author_id',
                            model: 'users',
                            select: 'username email first_name last_name profile_image profile_cover metamask_info password status is_idverified create_date'
                        },
                        {
                            path: 'current_owner',
                            model: 'users',
                            select: 'username email first_name last_name profile_image profile_cover metamask_info password status is_idverified create_date'
                        },
                        {
                            path: 'artist',
                            model: artistModel
                        }
                    ],
                    match: match,
                });
            }

            if(result.type == 'collection') {
                let match = {  }
                if(keyword != '') {
                    match = {
                        $or : [ 
                            { name: { $regex : new RegExp (keyword , "ig") }}, 
                            { description: { $regex : new RegExp (keyword , "ig") }},
                        ]
                    }
                }
                populatedResult = await promotionModel.findById(result._id).populate({ 
                    path: "item_id",
                    model: collectionModel,
                    populate: [
                        {
                            path: 'author_id',
                            model: 'users',
                            select: 'username email first_name last_name profile_image profile_cover metamask_info password status is_idverified create_date'
                        }
                    ],
                    match: match,
                });
            }

            if(result.type == 'post') {
                let match = {  }
                if(keyword != '') {
                    match = {
                        $or : [ 
                            { preview: { $regex : new RegExp (keyword , "ig") }},
                            { description: { $regex : new RegExp (keyword , "ig") }},
                        ]
                    }
                }
                populatedResult = await promotionModel.findById(result._id).populate({ 
                    path: "item_id",
                    model: fanpostModel,
                    populate: [
                        {
                            path: 'author_id',
                            model: 'users',
                            select: 'username email first_name last_name profile_image profile_cover metamask_info password status is_idverified create_date'
                        }
                    ],
                    match: match,

                });
            }

            if(result.type == 'fandom') {
                let match = {}
                if(keyword != '') {
                    match = {
                        $or : [ 
                            { name: { $regex : new RegExp (keyword , "ig") }},
                            { description: { $regex : new RegExp (keyword , "ig") }},
                        ]
                    }
                }
                populatedResult = await promotionModel.findById(result._id).populate({ 
                    path: "item_id",
                    model: fandomModel,
                    populate: [
                        {
                            path: 'user_id',
                            model: 'users',
                            select: 'username email first_name last_name profile_image profile_cover metamask_info password status is_idverified create_date'
                        }
                    ],
                    match: match,

                });
            }

            if(result.type == 'playlist') {
                let match = {}
                if(keyword != '') {
                    match = {
                        $or : [ 
                            { name: { $regex : new RegExp (keyword , "ig") }},
                            { description: { $regex : new RegExp (keyword , "ig") }},
                        ]
                    }
                }
                populatedResult = await promotionModel.findById(result._id).populate({ 
                    path: "item_id",
                    path:  'item_id',
                    model: playlistModel,
                    populate: [
                        {
                            path: 'author_id',
                            model: 'users',
                            select: 'username email first_name last_name profile_image profile_cover metamask_info password status is_idverified create_date'
                        }
                    ],
                    match: match,
                });
            }

            if(result.type == 'event') {

            }

            if(result.type == 'short') {
                let match = {}
                if(keyword != '') {
                    match = {
                        $or : [ 
                            { description: { $regex : new RegExp (keyword , "ig") }},
                        ]
                    }
                }
                populatedResult = await promotionModel.findById(result._id).populate({ 
                    path: "item_id",
                    model: partyModel,
                    populate: [
                        {
                            path: 'user_id',
                            model: 'users',
                            select: 'username email first_name last_name profile_image profile_cover metamask_info password status is_idverified create_date'
                        }
                    ],
                    match
                });
            }

            if(result.type == 'livenow') {
                let match = {}
                if(keyword != '') {
                    match = {
                        $or : [ 
                            { description: { $regex : new RegExp (keyword , "ig") }},
                        ]
                    }
                }
                if(!mine) {
                    match = {
                        ...match,
                        ...{
                            status: { $in: ['online', 'away', 'beback'] }
                        }
                    }
                }

                populatedResult = await promotionModel.findById(result._id).populate({ 
                    path: "item_id",
                    model: livenowModel,
                    populate: [
                        {
                            path: 'user_id',
                            model: 'users',
                            select: 'username email first_name last_name profile_image profile_cover metamask_info password status is_idverified create_date'
                        }
                    ],
                    match: match,
                });
            }
            return populatedResult
        }));
        res.json({
            status: true,
            message: "Retrived successfully",
            result: updatedResults
        });

    } catch (error) {
        console.log(error);
        res.json({
            status: false,
            message: "Something went wrong",
            error: error
        })
    }

}

exports.edit_promotion = async function(req,res) {
    console.log(getErrLine().str, "apistart");
    var user_id = req.decoded.user_id;
    try {
        await promotionModel.findByIdAndUpdate(req.body._id, req.body);
        res.json({
            status: true,
            message: "Saved successfully"
        })
    } catch (error) {
        console.log(error);
        res.json({
            status: false,
            message: error
        })
    }
}