
var userModel = require('../../user/model/userModel'),
    helpModel = require('../model/helpModel'),
    ticketModel = require('../model/ticketModel'),
    helpOrderModel = require('../model/helpOrderModel'),
    ticketCategoryModel = require('../model/ticketCategoryModel');
const { getErrLine } = require("../../helper/helpers");

//!!20231203 coderc To get information of user who is reported, added get_reprot_user_info function.
exports.get_report_user_info = async function(req, res) {
    try {
        let id = req.body.id;
        let userInfo = await userModel.findOne({_id: id});
        res.json({
            status: true,
            message: "Retrived successfully",
            result: userInfo
        });
    } catch(error) {
        console.log(error);
        res.json({
            status: false,
            message: "Something went wrong"
        })
    }
}

exports.get_ticket_cagetogries = async function (req, res) {
    console.log(getErrLine().str, "apistart");
    try {
        let categories = await ticketCategoryModel.find();
        res.json({
            status: true,
            message: "Retrived successfully",
            result: categories
        })
    } catch (error) {
        console.log(error);
        res.json({
            status: false,
            message: "Something went wrong"
        })
    }
}

exports.create_ticket = async function (req, res) {
    console.log(getErrLine().str, "apistart");
    var user_id = req.decoded.user_id;
    var ticket = new ticketModel(req.body);
    ticket.user_id = user_id;
    ticket.status = 'new'
    try {
        await ticket.save();
        res.json({
            status: true,
            message: "Created successfully",
            result: ticket
        });
    } catch (error) {
        console.log(error);
        res.json({
            status: false,
            message: "Something went wrong"
        })
    }
}


exports.get_tickets = async function (req, res) {
    console.log(getErrLine().str, "apistart");
    var user_id = req.decoded.user_id;
    var page = req.query.page || 1,
        limit = req.query.limit || 15,
        category = req.query.category,
        status = req.query.status,
        priority = req.query.priority,
        sort = req.query.sort,
        all = req.query.all;

    try {
        let query = ticketModel.find({ parent_id: { $eq: null } });
        if (all) {
            query = query.find();
        } else {
            query = query.find({ user_id });
        }
        if (category) {
            query = query.find({ category });
        }
        if (status) {
            query = query.find({ status })
        }
        if (priority) {
            query = query.find({ priority })
        }
        switch (sort) {
            default:
                query = query.sort({ created_date: -1 });
                break;
        }
        query = query.populate({
            path: 'category',
            model: 'ticket_categories'
        })
            .populate({
                path: 'user_id',
                model: 'users',
                select: "_id username first_name last_name profile_image",
            })
        var offset = page == "1" ? 0 : parseInt(page - 1) * limit;
        var options = {
            page: page,
            offset: offset,
            limit: 10,
        };
        ticketModel.paginate(query, options).then(function (result) {
            res.json({
                status: true,
                message: "Ticket retrieved successfully",
                data: result,
            });
        });

    } catch (error) {
        console.log(error);
        res.json({
            status: false,
            message: "Something went wrong"
        })
    }
}

exports.delete_ticket = async function (req, res) {
    console.log(getErrLine().str, "apistart");
    var user_id = req.decoded.user_id;
    try {
        await ticketModel.findByIdAndDelete(req.body._id);
        await ticketModel.deleteMany({ parent_id: req.body._id });
        res.json({
            status: true,
            message: "Removed successfully",
        })
    } catch (error) {
        console.log(error);
        res.json({
            status: false,
            message: "Something went wrong"
        })
    }
}

exports.get_reply_tickets = async function (req, res) {
    console.log(getErrLine().str, "apistart");
    var user_id = req.decoded.user_id;
    var parent_id = req.query.parent_id
    try {
        if (parent_id) {
            var parent = await ticketModel.findById(parent_id)
                .populate({
                    path: "category",
                    model: "ticket_categories"
                })
                .populate({
                    path: "user_id",
                    model: 'users',
                    select: "_id username first_name last_name profile_image",
                })
            var replies = await ticketModel.find({ parent_id })
                .populate({
                    path: "category",
                    model: "ticket_categories"
                })
                .populate({
                    path: "user_id",
                    model: 'users',
                    select: "_id username first_name last_name profile_image",
                }).sort({ created_date: 1 })
            let lists = [
                ...[parent],
                ...replies
            ]
            res.json({
                status: true,
                message: "Retrived successfully",
                result: lists
            })

        } else {
            res.json({
                status: false,
                message: "Something went wrong"
            })
        }
    } catch (error) {
        console.log(error);
        res.json({
            status: false,
            message: "Something went wrong"
        })
    }
}

exports.change_query_status = async function (req, res) {
    console.log(getErrLine().str, "apistart");
    let _id = req.body._id;
    ticketModel.updateOne({ _id: _id }, { status: 'closed' }).exec((err, result) => {
        if (err) console.log(err);
        res.json({
            status: true,
        })
    })
}

exports.add_category = async function (req, res) {
    console.log(getErrLine().str, "apistart");
    var category = new helpModel(req.body);
    try {
        category.save((err, resData) => {
            let parentTopic = req.body.parentCategory;
            let subTopic = req.body.title;
            try {
                helpOrderModel.findOne({ parentTopic: parentTopic }).exec((err, result) => {
                    if (err) { console.log(err); return; }
                    if (result) {
                        helpOrderModel.updateOne({ parentTopic: parentTopic }, { $push: { subTopics: subTopic } }).exec((err, data) => {
                            if (err) { console.log(err); return; }
                            res.json({
                                status: true,
                                message: "created successfully.",
                                result: resData,
                                order_status: data
                            });
                        })
                    } else {
                        let add_topic_order_data = {
                            parentTopic: parentTopic,
                            subTopics: [subTopic]
                        }
                        let topic_order = new helpOrderModel(add_topic_order_data);
                        topic_order.save((err, resData) => {
                            if (err) { console.log(err); return; }
                            res.json({
                                status: true,
                                message: "Created successfully.",
                                result: resData,
                                order_status: resData,
                            });
                        })
                    }
                });
            } catch (error) {
                res.json({
                    status: false,
                    message: "Something went wrong!"
                });
            }
        });
    } catch (error) {
        console.log(error);
        res.json({
            status: false,
            message: "Something went wrong"
        })
    }
}

exports.get_info = async function (req, res) {
    console.log(getErrLine().str, "apistart");
    try {
        helpModel.find({}).exec((err, result) => {
            if (err) console.log(err);
            else res.json({
                status: true,
                message: "Created successfully",
                result: result
            });
        })
    } catch (error) {
        console.log(error);
        res.json({
            status: false,
            message: "Something went wrong"
        })
    }
}

exports.saveUpdate = async function (req, res) {
    console.log(getErrLine().str, "apistart");
    try {
        helpModel.findOne({ title: req.body.title }).exec((err, result) => {
            if (err) console.log(err);
            else {
                if (result) {
                    try {
                        helpModel.updateOne({ title: req.body.title }, { description: req.body.description }).exec((err, resData) => {
                            if (err) { console.log(err); return; }
                            res.json({
                                status: true,
                                message: "Created successfully",
                                result: resData
                            });
                        })
                    } catch (error) {
                        res.json({
                            status: false,
                            message: "Something went wrong1"
                        });
                    }
                } else {
                    let topic = new helpModel(req.body);
                    try {
                        topic.save((err, resData) => {
                            if (err) { console.log(err); return; }
                            //add helpOrders model.
                            let parentTopic = req.body.parentCategory;
                            let subTopic = req.body.title;
                            try {
                                helpOrderModel.findOne({ parentTopic: parentTopic }).exec((err, result) => {
                                    if (err) { console.log(err); return; }
                                    if (result) {
                                        helpOrderModel.updateOne({ parentTopic: parentTopic }, { $push: { subTopics: subTopic } }).exec((err, data) => {
                                            if (err) { console.log(err); return; }
                                            res.json({
                                                status: true,
                                                message: "created successfully.",
                                                result: resData,
                                                order_status: data
                                            });
                                        })
                                    } else {
                                        let add_topic_order_data = {
                                            parentTopic: parentTopic,
                                            subTopics: [subTopic]
                                        }
                                        let topic_order = new helpOrderModel(add_topic_order_data);
                                        topic_order.save((err, resData) => {
                                            if (err) { console.log(err); return; }
                                            res.json({
                                                status: true,
                                                message: "Created successfully.",
                                                result: resData,
                                                order_status: resData,
                                            });
                                        })
                                    }
                                });
                            } catch (error) {
                                res.json({
                                    status: false,
                                    message: "Something went wrong!"
                                });
                            }
                        })
                    } catch (err) {
                        res.json({
                            status: false,
                            message: "Something went wrong2"
                        });
                    }
                }
            }
        })
    } catch (error) {
        res.json({
            status: false,
            message: "Something went wrong3"
        });
    }
}

exports.deleteTopic = async function (req, res) {
    console.log(getErrLine().str, "apistart");
    try {
        helpModel.deleteOne({ title: req.body.title, parentCategory: req.body.parentCategory }).exec((err, result) => {
            if (err) { console.log(err); return; }
            if (result) {
                helpOrderModel.updateOne({ parentTopic: req.body.parentCategory }, { $pull: { subTopics: req.body.title } }).exec((err, resData) => {
                    if (err) { console.log(err); return; }
                    else res.json({
                        status: true,
                        message: "deleted successfully",
                        result: result,
                        resData: resData
                    });
                })
            }
            else res.json({
                status: true,
                message: "no exist that data",
                result: result
            });
        })
    } catch (error) {
        console.log(error);
        res.json({
            status: false,
            message: "Something went wrong"
        })
    }
}

exports.getOrderInfo = async function (req, res) {
    console.log(getErrLine().str, "apistart");
    try {
        helpOrderModel.find({}).exec((err, result) => {
            if (err) console.log(err);
            else res.json({
                status: true,
                message: "Created successfully",
                result: result
            });
        })
    } catch (error) {
        console.log(error);
        res.json({
            status: false,
            message: "Something went wrong"
        })
    }
}

exports.updateOrder = async function (req, res) {
    console.log(getErrLine().str, "apistart");
    try {
        helpOrderModel.updateOne({parentTopic: req.body.parentTopic}, {subTopics: req.body.subTopics}).exec((err, resData) => {
            if(err){console.log(err); return;}
            res.json({
                status: true,
                message: "Created successfully",
                result: resData
            });
        })
    } catch (error) {
        console.log(error);
        res.json({
            status: false,
            message: "Something went wrong"
        })
    }
}

exports.get_help_data = async function (req, res) {
    console.log(getErrLine().str, "apistart");
    var data;
    try {
        helpOrderModel.find({}).exec((err, result1) => {
            if (err) {console.log(err); return;}
            helpModel.find({}).exec((err, result2) => {
                if(err) {console.log(err); return;}
                data = {
                    result1: result1,
                    result2: result2
                };
                res.json({
                    status: true,
                    message: "gained successfully",
                    result: data
                });
            })
        })
    } catch (error) {
        console.log(error);
        res.json({
            status: false,
            message: "Something went wrong"
        })
    }
}