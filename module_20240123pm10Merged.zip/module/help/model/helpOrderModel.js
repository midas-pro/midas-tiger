/*
Project : Cryptotrades
FileName : helpOrderModel.js
Author : Indiefire
File Created : 10/11/2023
CopyRights : Indiefire
Purpose : This is the file which used to define follower schema that will store and reterive item follower information.
*/

var mongoose = require('mongoose');
var mongoosePaginate = require('mongoose-paginate-v2');
var uniqueValidator = require('mongoose-unique-validator');
var config = require('../../../helper/config')
const Schema = mongoose.Schema;

var helpOrderSchema = mongoose.Schema({
    parentTopic: {
        type: String
    },
    subTopics: {
        type: Array
    },
    created_date: {
        type: Date,
        default: Date.now
    },
});

helpOrderSchema.plugin(uniqueValidator);
helpOrderSchema.plugin(mongoosePaginate);

module.exports = mongoose.model('help_orders', helpOrderSchema,config.db.prefix+'help_orders');