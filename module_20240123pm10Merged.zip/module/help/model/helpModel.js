/*
Project : Cryptotrades
FileName : helpModel.js
Author : Indiefire
File Created : 09/11/2023
CopyRights : Indiefire
Purpose : This is the file which used to define follower schema that will store and reterive item follower information.
*/

var mongoose = require('mongoose');
var mongoosePaginate = require('mongoose-paginate-v2');
var uniqueValidator = require('mongoose-unique-validator');
var config = require('../../../helper/config')
const Schema = mongoose.Schema;

var helpSchema = mongoose.Schema({
    parentCategory: {
        type: String
    },
    title: {
        type: String
    },
    description: {
        type: String
    },
    subCategories: {
        type: Array
    },
    created_date: {
        type: Date,
        default: Date.now
    },
});

helpSchema.plugin(uniqueValidator);
helpSchema.plugin(mongoosePaginate);

module.exports = mongoose.model('helps', helpSchema,config.db.prefix+'helps');