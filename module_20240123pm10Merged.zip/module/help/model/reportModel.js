
var mongoose = require('mongoose');
var mongoosePaginate = require('mongoose-paginate-v2');
var uniqueValidator = require('mongoose-unique-validator');
var config = require('../../../helper/config')
const Schema = mongoose.Schema;

var attachmentschema = new Schema({
    type: {
        type: String,
    },
    url: {
        type: String,
    }
})

var reportSchema = mongoose.Schema({
    reporter: {
        type: Schema.Types.ObjectId, 
        ref: 'users'
    },
    report_client: {
        type: Schema.Types.ObjectId, 
        ref: 'users'
    },
    description: {
        type: String,
        default: ""
    },
    attachments: [
        attachmentschema
    ],
    created_date: {
        type: Date,
        default: Date.now
    },
});

reportSchema.plugin(uniqueValidator);
reportSchema.plugin(mongoosePaginate);

module.exports = mongoose.model('reports', reportSchema,config.db.prefix+'reports');