
var mongoose = require('mongoose');
var mongoosePaginate = require('mongoose-paginate-v2');
var uniqueValidator = require('mongoose-unique-validator');
var config = require('../../../helper/config')
const Schema = mongoose.Schema;

var attachmentschema = new Schema({
    type: {
        type: String,
    },
    url: {
        type: String,
    }
})

var ticketSchema = mongoose.Schema({
    parent_id: {
        type: Schema.Types.ObjectId, 
        ref: 'tickets' 
    },
    ticket_id: {
        type: String,
    },
    title: {
        type: String,
    },
    category: {
        type: Schema.Types.ObjectId, 
        ref: 'ticket_categories'
    },
    status: {
        type: String,
        default: "new"
    },
    priority: {
        type: String,
        default: "Medium"
    },
    description: {
        type: String,
        default: ""
    },
    attachments: [
        attachmentschema
    ],
    user_id: { type: Schema.Types.ObjectId, ref: 'users' },
    created_date: {
        type: Date,
        default: Date.now
    },
});

ticketSchema.plugin(uniqueValidator);
ticketSchema.plugin(mongoosePaginate);

module.exports = mongoose.model('tickets', ticketSchema,config.db.prefix+'tickets');