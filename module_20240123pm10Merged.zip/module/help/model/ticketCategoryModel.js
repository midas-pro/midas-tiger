
var mongoose = require('mongoose');
var mongoosePaginate = require('mongoose-paginate-v2');
var uniqueValidator = require('mongoose-unique-validator');
var config = require('../../../helper/config')
const Schema = mongoose.Schema;

var ticketCategorySchema = mongoose.Schema({
    title: {
        type: String,
        required: true
    },
    created_date: {
        type: Date,
        default: Date.now
    },
});

ticketCategorySchema.plugin(uniqueValidator);
ticketCategorySchema.plugin(mongoosePaginate);

module.exports = mongoose.model('ticket_categories', ticketCategorySchema,config.db.prefix+'ticket_categories');