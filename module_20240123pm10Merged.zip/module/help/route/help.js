var express = require('express')
var router = express.Router();
var helpController = require("./../controller/helpController")
const { check } = require('express-validator');
var auth = require("./../../../middleware/auth");
var adminauth = require("./../../../middleware/adminauth");
var optionalauth = require("./../../../middleware/optionalauth");


router.get('/get_ticket_categories', helpController.get_ticket_cagetogries);
router.post('/create_ticket', auth, helpController.create_ticket);
router.get('/get_tickets', auth, helpController.get_tickets);
router.post('/delete_ticket', auth, helpController.delete_ticket);
router.get('/get_reply_tickets', auth, helpController.get_reply_tickets);
router.post('/change_query_status', auth, helpController.change_query_status);
//admin or supporter
router.post('/add', auth, helpController.add_category);
router.post('/getInfo', auth, helpController.get_info);
router.post('/save_update', auth, helpController.saveUpdate);
router.post('/delete_topic', auth, helpController.deleteTopic);
router.post('/get_order_info', auth, helpController.getOrderInfo);
router.post('/update_order', auth, helpController.updateOrder);
//all
//!!20240120am1 coderC To get help data before login, updated the below api. "(B)( New ) ID verify & Create Account"
router.get('/get_help_data', helpController.get_help_data);
// router.get('/get_help_data', auth, helpController.get_help_data);
//!!20231203 coderc To get information of user who is reported, added get_reprot_user_info api.
router.post('/get_report_user_info', auth, helpController.get_report_user_info);

module.exports = router
