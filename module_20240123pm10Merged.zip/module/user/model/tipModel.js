/*
Project : Cryptotrades
FileName : fanModel.js
Author : Indiefire
File Created : 21/07/2021
CopyRights : Indiefire
Purpose : This is the file which used to define fan schema that will store and reterive item fan information.
*/

var mongoose = require('mongoose');
var mongoosePaginate = require('mongoose-paginate-v2');
var uniqueValidator = require('mongoose-unique-validator');
var config = require('../../../helper/config')
const Schema = mongoose.Schema;

var tipSchema = mongoose.Schema({
    sender: { type: Schema.Types.ObjectId, ref: 'users' },
    receiver: { type: Schema.Types.ObjectId, ref: 'users' },
    coin: {
        type: Number,
    },
    status: {
        type: Boolean,
        default: false
    },
    created_date: {
        type: Date,
        default: Date.now
    },
});

tipSchema.plugin(uniqueValidator);
tipSchema.plugin(mongoosePaginate);

module.exports = mongoose.model('tips', tipSchema,config.db.prefix+'tips');