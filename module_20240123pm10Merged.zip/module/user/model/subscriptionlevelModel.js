/*
Project : Cryptotrades
FileName : memberModel.js
Author : Indiefire
File Created : 21/07/2021
CopyRights : Indiefire
Purpose : This is the file which used to define member schema that will store and reterive item member information.
*/

var mongoose = require('mongoose');
var mongoosePaginate = require('mongoose-paginate-v2');
var uniqueValidator = require('mongoose-unique-validator');
var config = require('../../../helper/config')
const Schema = mongoose.Schema;

var subscription_level_schema = mongoose.Schema({
    user_id: { type: Schema.Types.ObjectId, ref: 'users' },
    name: {
        type: String,
        default: ''
    },
    monthly_price: {
        type: String,
        default: 0
    },
    description: {
        type: String,
        default: ''
    },
    
    // default 
    f_behind_sc: {
        type: Boolean,
        default: false
    },
    f_chats: {
        type: Boolean,
        default: false
    },
    f_contests: {
        type: Boolean,
        default: false
    },
    f_digital_downloads: {
        type: Boolean,
        default: false
    },
    f_do_promo_codes: {
        type: Boolean,
        default: false
    },
    f_early_content_access: {
        type: Boolean,
        default: false
    },
    f_early_ticket_access: {
        type: Boolean,
        default: false
    },
    f_event_vip: {
        type: Boolean,
        default: false
    },
    f_exclusive_content: {
        type: Boolean,
        default: false
    },
    f_fan_requests: {
        type: Boolean,
        default: false
    },
    f_live_streams: {
        type: Boolean,
        default: false
    },
    f_merchandise: {
        type: Boolean,
        default: false
    },
    f_shout_outs: {
        type: Boolean,
        default: false
    },
    f_video_tutorial_lessons: {
        type: Boolean,
        default: false
    },
    f_voting_power: {
        type: Boolean,
        default: false
    },


    custom_perks: [
        {
            name: {
                type: String,
                default: ''
            },
            description: {
                type: String,
                default: ''
            },
            active: {
                type: Boolean,
                default: false
            }
        }
    ],

    level: {
        type: String,
        default: 'basic'
    },

    n_joined: {
        type: Number,
        default: 0
    },

    created_date: {
        type: Date,
        default: Date.now
    },
});

subscription_level_schema.plugin(uniqueValidator);
subscription_level_schema.plugin(mongoosePaginate);

module.exports = mongoose.model('subscription_levels', subscription_level_schema,config.db.prefix+'subscription_levels');