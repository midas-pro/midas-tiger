/*
Project : Cryptotrades
FileName : fanModel.js
Author : Indiefire
File Created : 21/07/2021
CopyRights : Indiefire
Purpose : This is the file which used to define fan schema that will store and reterive item fan information.
*/

var mongoose = require('mongoose');
var mongoosePaginate = require('mongoose-paginate-v2');
var uniqueValidator = require('mongoose-unique-validator');
var config = require('../../../helper/config')
const Schema = mongoose.Schema;

var findnanceSchema = mongoose.Schema({
    user_id: { type: Schema.Types.ObjectId, ref: 'users' },
    type: {
        type: String,
    },
    order_id: {
        type: Schema.Types.ObjectId, ref: 'orders'
    },
    price: {
        type: Number,
        required: true
    },
    transactionid: {
        type: String,
        required: true
    },
    created_date: {
        type: Date,
        default: Date.now
    },
});

findnanceSchema.plugin(uniqueValidator);
findnanceSchema.plugin(mongoosePaginate);

module.exports = mongoose.model('finances', findnanceSchema,config.db.prefix+'finances');