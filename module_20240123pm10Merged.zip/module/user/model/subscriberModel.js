/*
Project : Cryptotrades
FileName : memberModel.js
Author : Indiefire
File Created : 21/07/2021
CopyRights : Indiefire
Purpose : This is the file which used to define member schema that will store and reterive item member information.
*/

var mongoose = require('mongoose');
var mongoosePaginate = require('mongoose-paginate-v2');
var uniqueValidator = require('mongoose-unique-validator');
var config = require('../../../helper/config')
const Schema = mongoose.Schema;

var subscriber_schema = mongoose.Schema({
    user_id: { type: Schema.Types.ObjectId, ref: 'users' },
    subscription_id: { type: Schema.Types.ObjectId, ref: 'subscription_levels' },
    unsubscribed: {
        type: Boolean,
        default: false,
    },
    start_date: {
        type: Date,
        default: Date.now
    },
    end_date: {
        type: Date,
        default: Date.now
    },
    created_date: {
        type: Date,
        default: Date.now
    },
});

subscriber_schema.plugin(uniqueValidator);
subscriber_schema.plugin(mongoosePaginate);

module.exports = mongoose.model('subscribers', subscriber_schema,config.db.prefix+'subscribers');