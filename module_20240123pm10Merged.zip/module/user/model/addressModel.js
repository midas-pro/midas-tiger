/*
Project : Cryptotrades
FileName : shipaddrModel.js
Author : Indiefire
File Created : 30/04/2023
CopyRights : Indiefire
Purpose : This is the file which used to define shipaddr schema that will store and reterive item shipaddr information.
*/

var mongoose = require('mongoose');
var mongoosePaginate = require('mongoose-paginate-v2');
var uniqueValidator = require('mongoose-unique-validator');
var config = require('../../../helper/config')
const Schema = mongoose.Schema;

var shipaddrSchema = mongoose.Schema({
    user_id: { type: Schema.Types.ObjectId, ref: 'users' },
    fullname: {
        type: String,
    },
    street: {
        type: String,
    },
    city: {
        type: String,
    },
    state: {
        type: String,
    },
    zipcode: {
        type: String,
    },
    country: {
        type: String,
    },
    created_date: {
        type: Date,
        default: Date.now
    },
});

shipaddrSchema.plugin(uniqueValidator);
shipaddrSchema.plugin(mongoosePaginate);

module.exports = mongoose.model('shipaddrs', shipaddrSchema,config.db.prefix+'shipaddrs');