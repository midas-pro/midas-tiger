/*
Project : Cryptotrades
FileName : fanModel.js
Author : Indiefire
File Created : 21/07/2021
CopyRights : Indiefire
Purpose : This is the file which used to define fan schema that will store and reterive item fan information.
*/

var mongoose = require('mongoose');
var mongoosePaginate = require('mongoose-paginate-v2');
var uniqueValidator = require('mongoose-unique-validator');
var config = require('../../../helper/config')
const Schema = mongoose.Schema;

var blockSchema = mongoose.Schema({
    block_user_id: { type: Schema.Types.ObjectId, ref: 'users' },
    user_id: { type: Schema.Types.ObjectId, ref: 'users' },
    created_date: {
        type: Date,
        default: Date.now
    },
});

blockSchema.plugin(uniqueValidator);
blockSchema.plugin(mongoosePaginate);

module.exports = mongoose.model('blocks', blockSchema,config.db.prefix+'blocks');