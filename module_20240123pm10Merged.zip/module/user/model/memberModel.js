/*
Project : Cryptotrades
FileName : memberModel.js
Author : Indiefire
File Created : 21/07/2021
CopyRights : Indiefire
Purpose : This is the file which used to define member schema that will store and reterive item member information.
*/

var mongoose = require('mongoose');
var mongoosePaginate = require('mongoose-paginate-v2');
var uniqueValidator = require('mongoose-unique-validator');
var config = require('../../../helper/config')
const Schema = mongoose.Schema;

var memberSchema = mongoose.Schema({
    star_id: { type: Schema.Types.ObjectId, ref: 'users' },
    user_id: { type: Schema.Types.ObjectId, ref: 'users' },
    // added by dreampanda 20230513
    f_add_band: { type: Boolean, default: true },
    f_allow_post: { type: Boolean, default: true },
    created_date: {
        type: Date,
        default: Date.now
    },
});

memberSchema.plugin(uniqueValidator);
memberSchema.plugin(mongoosePaginate);

module.exports = mongoose.model('members', memberSchema,config.db.prefix+'members');