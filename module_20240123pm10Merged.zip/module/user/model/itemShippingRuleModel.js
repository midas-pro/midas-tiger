/*
Project : Cryptotrades
FileName : fanModel.js
Author : Indiefire
File Created : 21/07/2021
CopyRights : Indiefire
Purpose : This is the file which used to define fan schema that will store and reterive item fan information.
*/

var mongoose = require('mongoose');
var mongoosePaginate = require('mongoose-paginate-v2');
var uniqueValidator = require('mongoose-unique-validator');
var config = require('../../../helper/config')
const Schema = mongoose.Schema;

const other_shipping_rule_schema = new Schema({
    shipping_country: {
        type: String,
    },
    shipping_method: {
        type: String
    },
    shipping_description: {
        type: String,
    },
    shipping_carrier: {
        type: String
    },
    shipping_duration: {
        type: Number
    },
    shipping_item_price: {
        type: Number
    },
    shipping_items_price: {
        type: Number
    }
})

var itemShippingRule = mongoose.Schema({
    user_id: { type: Schema.Types.ObjectId, ref: 'users' },
    name: {
        type: String,
        default: ''
    },
    // us shipping rule
    shipping_method: {
        type: String, 
    },
    shipping_carrier: {
        type: String
    },
    shipping_description: {
        type: String,
    },
    shipping_duration: {
        type: Number
    },
    shipping_item_price: {
        type: Number
    },
    shipping_items_price: {
        type: Number
    },

    // other shipping rule
    other_shipping_rules: [
        other_shipping_rule_schema
    ],
    items: [
        {
            type: Schema.Types.ObjectId, ref: 'item'
        }
    ],
    created_date: {
        type: Date,
        default: Date.now
    },
});

itemShippingRule.plugin(uniqueValidator);
itemShippingRule.plugin(mongoosePaginate);

module.exports = mongoose.model('item_shipping_rule', itemShippingRule,config.db.prefix+'item_shipping_rule');