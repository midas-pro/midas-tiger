/*
Project : Cryptotrades
FileName : userModel.js
Author : Indiefire
File Created : 21/07/2021
CopyRights : Indiefire
Purpose : This is the file which used to define user collection that will communicate and process user information with mongodb through mongoose ODM.
*/

var mongoose = require('mongoose');
var mongoosePaginate = require('mongoose-paginate-v2');
var bcrypt = require('bcrypt');
var validator = require('validator');
var uniqueValidator = require('mongoose-unique-validator');
var config = require('./../../../helper/config');
const { TopologyDescriptionChangedEvent } = require('mongodb');//??


const alphanumericRegex = /^[a-zA-Z0-9]+$/;
// Setup schema
var userSchema = mongoose.Schema({
    verified_name: {
        type: String
    },
    username: {
        type: String,
        required: [true, 'Username is required'],
        unique: [true, 'Username should be unique'],
        trim: true,
        match: [/^[A-Za-z0-9]+$/, 'Username should only contain [A-Z], [a-z], [0~9]'],
        validate: {
            validator: function(v) {
                return `/^\S*$.text(v)`;
            },
            message: props => `${props.value} should not contain any spaces`
        }
        // minlength: [1, 'User Name must be 1 characters or more'],
        // maxlength: [32, "User Name can't exceed 32 characters"],
        // validate: [
        //     {
        //         validator: (value) => alphanumericRegex.test(value),
        //         message: 'Username must only contain alphanumeric characters'
        //     }
        // ]
    },

    main_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'users'
    },

    account_type: {
        type: String
    },

    email: {
        type: String,
        required: [true, 'Email is required']
    },
    password: {
        type: String,
    },
    first_name: {
        type: String,
        maxlength: [32, "First Name can't exceed 32 characters"],
        required: false, 
    },
    last_name: {
        type: String,
        maxlength: [32, "Last name can't exceed 32 characters"],
        required: false, 
    }, 
    dob:String,   
    phone_code: {
        type: String
    },
    phone: {
        type: String,
    },

    full_addr: {
        type: String
    }, 
    street: {
        type: String
    },
    city: {
        type: String
    },
    state: {
        type: String
    },
    zipcode: {
        type: String
    },
    country: {
        type: String
    },
    timezone:{
        type: String  //20231214am8coderd add
    },
    bio: {
        type: String
    },

    profile_image: {
        type: String,
        default: ''
    },    
    profile_cover: String,            
    metamask_info: {
        type: Map,
        of: String
    },
    role: {type:Number, default:2},
    is_notification: {type:Number, default:1},
    is_featured: {type:Number, default:0},
    // is_last_active: {type:Number, default:0},
    last_login_date: {
        type: Date,
        default: Date.now
    },
    is_idverified: {type:Number, default:0},

    //!!new fields for creator concept. 2022.7.19
    is_admin_approved: {type:Number, default:0},
    is_pros: {type:Number, default:0},// pros or personal
    is_type_author: {type:Number, default:0},
    is_type_artist: {type:Number, default:0},
    is_type_comedian: {type:Number, default:0},
    is_type_content_creator: {type:Number, default:0},
    is_type_filmmaker: {type:Number, default:0},
    is_type_musician: {type:Number, default:0},
    is_type_podcaster: {type:Number, default:0},
    is_type_singer: {type:Number, default:0},
    is_type_band: {type:Number, default:0},
    members_count: {
        type: Number,
        default:0
    },    

    // !!new fields for notification 2023.5.5

    // for notification posts
    notif_posts: {
        is_new: { type: Boolean, default: false },
        is_following: { type: Boolean, default: false },
        is_following_accounts: [
            {
                type: mongoose.Schema.Types.ObjectId,
                ref: 'users'
            }
        ],
        is_selected_accounts: [
            {
                type: mongoose.Schema.Types.ObjectId,
                ref: 'users'
            }
        ],
        is_reactions: { type: Boolean, default: false },
        is_comments_replies: { type: Boolean, default: false },
        is_comment_reply_reaction: { type: Boolean, default: false },
        is_added_favorites: { type: Boolean, default: false },
    },

    // for notification followers
    // followers
    notif_followers: {
        is_new: { type: Boolean, default: false },
        is_new_backs: { type: Boolean, default: false },
        is_unfollow: { type: Boolean, default: false },

        unfollow_safe_list: [
            {
                type: mongoose.Schema.Types.ObjectId,
                ref: 'users'
            }
        ],

        // fans
        is_fan_subcribed: { type: Boolean, default: false },
        is_fan_unsubcribed: { type: Boolean, default: false },
    },

 
    // for notification playlists
    notif_playlists: {
        is_updates: { type: Boolean, default: false },
        is_all_accounts: { type: Boolean, default: false },
        is_following: { type: Boolean, default: false },
        is_following_accounts: [
            {
                type: mongoose.Schema.Types.ObjectId,
                ref: 'users'
            }
        ],
        is_selected_accounts: [
            {
                type: mongoose.Schema.Types.ObjectId,
                ref: 'users'
            }
        ],
        is_changes: { type: Boolean, default: false },
    },
    
   
    // for notification live now
    notif_live_now: {
        is_new: { type: Boolean, default: false },
        is_following: { type: Boolean, default: false },
        is_following_accounts: [
            {
                type: mongoose.Schema.Types.ObjectId,
                ref: 'users'
            }
        ],
        is_selected_accounts: [
            {
                type: mongoose.Schema.Types.ObjectId,
                ref: 'users'
            }
        ],
    },

   
    // for notification vibes
    notif_vibes: {
        is_new: { type: Boolean, default: false },
        is_following: { type: Boolean, default: false },
        is_following_accounts: [
            {
                type: mongoose.Schema.Types.ObjectId,
                ref: 'users'
            }
        ],
        is_selected_accounts: [
            {
                type: mongoose.Schema.Types.ObjectId,
                ref: 'users'
            }
        ],
        is_comments_replies: { type: Boolean, default: false },
        is_reactions: { type: Boolean, default: false },
        is_added_favorites: { type: Boolean, default: false },
    },

    // for notification music
    notif_music: {
        is_new: { type: Boolean, default: false },
        is_following: { type: Boolean, default: false },
        is_following_accounts: [
            {
                type: mongoose.Schema.Types.ObjectId,
                ref: 'users'
            }
        ],
        is_selected_accounts: [
            {
                type: mongoose.Schema.Types.ObjectId,
                ref: 'users'
            }
        ],
        is_comments_replies: { type: Boolean, default: false },
        is_reactions: { type: Boolean, default: false },
        is_added_favorites: { type: Boolean, default: false },
        is_added_playlists: { type: Boolean, default: false },
        is_new_vibed: { type: Boolean, default: false },
    },

    
    // for notification podcasts
    notif_podcasts: {
        is_new: { type: Boolean, default: false },
        is_following: { type: Boolean, default: false },
        is_following_accounts: [
            {
                type: mongoose.Schema.Types.ObjectId,
                ref: 'users'
            }
        ],
        is_selected_accounts: [
            {
                type: mongoose.Schema.Types.ObjectId,
                ref: 'users'
            }
        ],
        is_comments_replies: { type: Boolean, default: false },
        is_reactions: { type: Boolean, default: false },
        is_added_favorites: { type: Boolean, default: false },
        is_added_playlists: { type: Boolean, default: false },
        is_new_vibed: { type: Boolean, default: false },
    },
   
    // for notification podcasts
    notif_standUpComedy: {
        is_new: { type: Boolean, default: false },
        is_following: { type: Boolean, default: false },
        is_following_accounts: [
            {
                type: mongoose.Schema.Types.ObjectId,
                ref: 'users'
            }
        ],
        is_selected_accounts: [
            {
                type: mongoose.Schema.Types.ObjectId,
                ref: 'users'
            }
        ],
        is_comments_replies: { type: Boolean, default: false },
        is_reactions: { type: Boolean, default: false },
        is_added_favorites: { type: Boolean, default: false },
        is_added_playlists: { type: Boolean, default: false },
        is_new_vibed: { type: Boolean, default: false },
    },
   
    // for notification audiobooks
    notif_audioBooks: {
        is_new: { type: Boolean, default: false },
        is_following: { type: Boolean, default: false },
        is_following_accounts: [
            {
                type: mongoose.Schema.Types.ObjectId,
                ref: 'users'
            }
        ],
        is_selected_accounts: [
            {
                type: mongoose.Schema.Types.ObjectId,
                ref: 'users'
            }
        ],
        is_comments_replies: { type: Boolean, default: false },
        is_reactions: { type: Boolean, default: false },
        is_added_favorites: { type: Boolean, default: false },
        is_added_playlists: { type: Boolean, default: false },
        is_new_vibed: { type: Boolean, default: false },
    },
 
    // for notification movies
    notif_movies: {
        is_new: { type: Boolean, default: false },
        is_following: { type: Boolean, default: false },
        is_following_accounts: [
            {
                type: mongoose.Schema.Types.ObjectId,
                ref: 'users'
            }
        ],
        is_selected_accounts: [
            {
                type: mongoose.Schema.Types.ObjectId,
                ref: 'users'
            }
        ],
        is_comments_replies: { type: Boolean, default: false },
        is_reactions: { type: Boolean, default: false },
        is_added_favorites: { type: Boolean, default: false },
        is_added_playlists: { type: Boolean, default: false },
        is_new_vibed: { type: Boolean, default: false },
    },

    
    // for notification tv_series
    notif_tv_series: {
        is_new: { type: Boolean, default: false },
        is_following: { type: Boolean, default: false },
        is_following_accounts: [
            {
                type: mongoose.Schema.Types.ObjectId,
                ref: 'users'
            }
        ],
        is_selected_accounts: [
            {
                type: mongoose.Schema.Types.ObjectId,
                ref: 'users'
            }
        ],
        is_comments_replies: { type: Boolean, default: false },
        is_reactions: { type: Boolean, default: false },
        is_added_favorites: { type: Boolean, default: false },
        is_added_playlists: { type: Boolean, default: false },
        is_new_vibed: { type: Boolean, default: false },
    },
    

    notif_selling: {
        is_auctions: { type: Boolean, default: false },
        is_buy_now_sales: { type: Boolean, default: false },
        is_offer_update: { type: Boolean, default: false },
        is_order_update: { type: Boolean, default: false },
    },


    notif_buying: {
        is_auctions: { type: Boolean, default: false },
        is_offer_update: { type: Boolean, default: false },
        is_order_update: { type: Boolean, default: false },
    },

    notif_users: [
        {
            type: mongoose.Schema.Types.ObjectId,
            ref: 'users'
        }
    ],
    // added by dreampanda 20230522
    privacy_safety: {
        audience: {
            type: String,
            default: 'everybody'
        },
        // added by coderB 20231217p10
        direct_message: { // for display of user
            type: String,
            default: "everybody" // other values --- "following", "safelist"
        }
    },

    //!!20231222pm02 coderB
    safe_list: {
            type: Array,
            default: []
        },

    //!!20231225am02 coderB
    following: {
        type: Array,
        default: []
    },

    //!!20231227pm06 coderB
    block_list: {
        type: Array,
        default: []
    },

    //!!20231230pm10 CoderX
    blocked_by_list: {
        type: Array,
        default: []
    },

    //!!20231227pm06 coderB
    mute_list: {
        type: Array,
        default: []
    },

    status:{
        type: String,
        enum : ['active','inactive','blocked','reset']
    },
    device_info:{
        type: Map,
        of: String
    },
    create_date: {
        type: Date,
        default: Date.now
    },
    fans_count: {
        type: Number,
        default:0
    },    
    followers_count: {
        type: Number,
        default:0
    },    
    followings_count: {
        type: Number,
        default: 0
    },
    posts_count: {
        type: Number,
        default: 0
    },
    reaction_count: {
        type: Number,
        default: 0
    },
    bio: {
        type: String,
    },
    coin: {
        type: Number,
        default: 0
    },

    balance: {
        type: Number,
        default: 0
    },
    
    default_address: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'shipaddrs'
    },

    //!!20231214am9 coderc To save payment method info(firstname, lastname, token), added the below param.
    payment_method_info: {
        type: Array
    },

    //!!20231215pm8 coderc To save payment gateway info(gateway_type, token), added the below param.
    gateway_info: {
        type: Array
    },

    //!!20231226pm5 coderc To set selected payment method token as default, added the below code. "(B) Spreedly Test : need Proof send tips"
    active_payment_method_token: {
        type: String,
    },

    //!!20231226pm5 coderc To set selected payment method token as default, added the below code. "(B) Spreedly Test : need Proof send tips"
    active_payment_gateway_token: {
        type: String
    },

    //!!20240108pm11 coderC To save notification block user list accoridng to user, added the below code. "(B) other’s Fanpage -> Notification for this user"
    notification_block_list: {
        type: Array
    }

});

userSchema.pre('save', function(next) {
    var user = this;
    if (!user.isModified('password')) return next();

    if (user.password.length==0) return next();
    if (user.password.length==60 || user.password.length==61) 
    { // on create creator, clone password data
        return next();
    } else 
    {
        // generate a salt
        bcrypt.genSalt(12, function(err, salt) {
            if (err) return next(err);
            // hash the password using our new salt
            bcrypt.hash(user.password, salt, function(err, hash) {
                if (err) return next(err);
                // override the cleartext password with the hashed one
                user.password = hash;
                next();
            });
        });
    }
    
});

userSchema.methods.comparePassword = function(candidatePassword, cb) {
bcrypt.compare(candidatePassword, this.password, function(err, isMatch) {
        if (err) return cb(err);
        cb(null, isMatch);
    });
};

userSchema.plugin(uniqueValidator);
userSchema.plugin(mongoosePaginate);

module.exports = mongoose.model('users', userSchema,config.db.prefix+'users');