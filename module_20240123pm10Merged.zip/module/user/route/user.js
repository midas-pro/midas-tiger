/*
Project : Cryptotrades
FileName : route.js
Author : Indiefire
File Created : 21/07/2021
CopyRights : Indiefire
Purpose : This is the file which used to define all route releated to user api request.
*/

var express = require('express')
var router = express.Router();
var userController = require("./../controller/userController")
const { check } = require('express-validator');
var auth = require("./../../../middleware/auth");
var adminauth = require("./../../../middleware/adminauth");
var optionalauth = require("./../../../middleware/optionalauth");

router.get('/allusers',userController.getListAllUsers4DupCheck)

router.post('/get_filtered_users', optionalauth, userController.get_filtered_users);

router.get('/',userController.getList)

router.post('/', userController.register)

router.post('/signup', userController.signup)

router.post('/login',[check('username').not().isEmpty(),check('password').not().isEmpty()],userController.login)

router.post('/reset_password_request', userController.reset_password_request);

router.put('/switch',[auth, check('username').not().isEmpty()], userController.switchuser)

router.put('/update/:userId',[auth], userController.update)

router.put('/profilesettings',auth,userController.updatesettings)

router.put('/updatebio',auth,userController.updatebio)

router.put('/updatewallet',auth,userController.updatewallet)

router.put('/setidverified',auth,userController.setidverified)

router.get('/profile/:userId',userController.details)

router.get('/get_status_count', userController.get_status_count)

router.get('/profileinfo/:userId',userController.publicdetails)

router.post('/chat',auth,userController.getListByIds)

router.get('/adminlist',adminauth,userController.getAdminList)

router.post('/updateuser',adminauth, userController.updateUser)

router.get('/listfans',userController.listFan)

router.post('/actionfan',auth,userController.actionFan)

router.get('/listfollowers',userController.listFollower)

router.get('/listfollowings',userController.listFollowing)

router.post('/actionfollower',auth,userController.actionFollower)

router.get('/listmembers',userController.listMember)

// added by dreampanda 20235013 pm 5
router.post('/addmember',auth,userController.addMember)

router.put('/editmember',auth,userController.editMember)

router.delete('/removemember',auth,userController.removeMember)

router.post('/actionmember',auth,userController.actionMember)

router.get('/listcreators',userController.listCreator)

router.post('/actioncreator',auth,userController.actionCreator)

router.post('/approvecreator',adminauth, userController.approveCreator)

router.get('/listshipaddrs',userController.listShipAddrs)

router.post('/actionshipaddrs',auth,userController.actionShipAddrs)

router.post('/set_default_ship_addr', auth, userController.set_default_ship_addr);

// added by dream panda in 2023 5.8
router.post('/getProfileData', auth, userController.getProfileData) // to get all info of profile

router.put('/profileUpdate', auth, userController.profileUpdate) // to update all info of profile at once

// added by dreampanda 20230516 am 3
router.get('/get_info_for_user',  optionalauth, userController.get_info_for_user)

router.get('/fandoms', userController.fandoms);

router.post('/fandom/create', auth, userController.create_fandom)
router.put('/fandom/update', auth, userController.update_fandom)
router.get('/fandom/readOne', auth, userController.read_fandom)
router.get('/fandom/read', auth, userController.read_fandoms)
router.post('/fandom/delete', auth, userController.delete_fandom)

router.post('/subscriptionlevel/create', auth, userController.create_subscription_level)
router.get('/subscriptionlevel/read', [auth], userController.read_subscription_level)
router.get('/subscriptions/read', [auth], userController.read_subscriptions)
router.get('/subscriptionlevel/read_for_join', auth, userController.read_subscription_level_for_join)
router.get('/read_fandom_payments', auth, userController.read_fandom_payments);
router.get('/get_subscription_earning', auth, userController.get_subscription_earning);
router.put('/subscriptionlevel/update', auth, userController.update_subscription_level)
router.post('/subscriptionlevel/delete', auth, userController.delete_subscription_level)
router.get('/fandom_payments', auth, userController.read_fandom_payments)

router.post('/subscriber/create', auth, userController.create_subscriber)
router.post('/subscriber/unsubscribe', auth, userController.unsubscribe)
router.get('/subscriber/read', auth, userController.read_subscribers)

router.get('/set_balance', userController.setBalance);
router.post('/buy_coin', auth, userController.buy_coin);
router.post('/send_coin', auth, userController.send_coin);
router.get('/get_coin_status', auth, userController.get_coin_status);
router.get('/get_tips', auth, userController.get_tips);
router.get('/get_tip_payouts', auth, userController.get_tip_payouts);

router.get('/get_blocked_accounts', optionalauth, userController.get_blocked_accounts);
router.post('/manage_block', auth, userController.manage_block);
router.get('/get_muted_accounts', optionalauth, userController.get_muted_accounts);
router.post('/manage_mute', auth, userController.manage_mute);

router.get('/get_count_fan', auth, userController.get_count_fan);
router.put('/update_profile', auth, userController.update_profile);
router.get('/reget_token', auth, userController.reget_token);
router.get('/get_users', optionalauth, userController.get_users);

router.post('/handle_pay', auth, userController.handle_pay);
router.get('/get_mute_words', auth, userController.get_mute_words);
router.post('/add_mute_word', auth, userController.add_mute_word);
router.put('/edit_mute_word', auth, userController.edit_mute_word);
router.post('/remove_mute_words', auth, userController.remove_mute_words);
router.post('/updatePassword', auth, userController.updatePassword)

router.get('/get_token_status', auth, userController.get_token_status)

router.post('/create_other_account', auth, userController.create_other_account)
router.get('/get_other_account', auth, userController.get_other_account)

router.post('/switch_account', auth, userController.switch_account);


router.post('/add_shipping_rule', auth, userController.add_shipping_rule)
router.get('/get_shipping_rule', auth, userController.get_shipping_rule)
router.put('/update_shipping_rule', auth, userController.update_shipping_rule)
router.post('/delete_shipping_rule', auth, userController.delete_shipping_rule)
router.post('/get_combined_shipping_rules', userController.get_combined_shipping_rules);

// manage item shipping rule
router.post('/add_item_shipping_rule', auth, userController.add_item_shipping_rule)
router.get('/get_item_shipping_rules', optionalauth, userController.get_item_shipping_rules)
router.put('/edit_item_shipping_rule', auth, userController.edit_item_shipping_rule)
router.post('/delete_item_shipping_rule', auth, userController.delete_item_shipping_rule)

router.get('/get_my_fandom_count', auth, userController.get_my_fandom_count);
router.get('/get_artists', optionalauth, userController.get_artists);
router.post('/create_artist', auth, userController.create_artist);

//!!20231218pm5 coderc To save payment method info(first and last name, token), updated the below api.
router.post('/add_payment_method_info', auth, userController.add_payment_method_info); 

//!!20231215pm8 coderc To save payment method info(first and last name, token), added the below api.
router.post('/create_payment_gateway', auth, userController.create_payment_gateway);

//!!20231216pm10 coderc To get payment gateway info, added the below api.
router.post('/get_payment_gateway', auth, userController.get_payment_gateway);

//!!20231218am4 coderc To delete payment method item, added the below api.
router.post('/delete_payment_gateway', auth, userController.delete_payment_gateway);

//!!20231218pm7 coderc To get user payment method info, added the below api.
router.post('/get_payment_method_info', auth, userController.get_payment_method_info);

//!!20231218pm8 coderc To remove user payment method info, added the below api.
router.post('/remove_payment_method_info', auth, userController.remove_payment_method_info);

//!!20231218pm11 coderB this is for update direct message properties in privacy & safety
router.put("/update_privacy", auth, userController.update_privacy);

//!!20231219pm7 coderc To get user card token info, added the below api.
router.get('/get_user_card_info', auth, userController.get_user_card_info);

//!!20231219pm7 coderc To get receiver card token, added the below api.get_receiver_card_token
router.post('/get_receiver_card_token', auth, userController.get_receiver_card_token);

// //!!20231219pm11 coderB To set the safelist data in direct message section
// router.put('/add_safelist', auth, userController.add_safelist)


//!!20221220am03 coderB To get the data of the safelist
router.get('/get_safelist', auth, userController.get_safelist);

//!!20221220am03 coderB To manage data of safelist
router.post('/manage_safelist', auth, userController.manage_safelist);

//!!20231221pm6 coderc To get paied result, added the below api.
router.post('/pay_now', auth, userController.pay_now);

//!!20231222am11 coderc To generate payment gateway, added the below api.
router.post('/generate_payment_gateway', auth, userController.generate_payment_gateway);

//!!20231222pm1 coderc To generate payment method token, added the below api.
router.post('/generate_payment_method_token', auth, userController.generate_payment_method_token);

//!!20231223pm8 coderc To save notify that is sent to live now creator, added the below api.
router.post('/sent_coin_notify', auth, userController.sent_coin_notify);

//!!20231226pm5 coderc To set selected payment gateway token as default, added the belwo api. "(B) Spreedly Test : need Proof send tips"
router.post('/set_gateway_token_as_default', auth, userController.set_gateway_token_as_default);

//!!20240119pm2 coderC To process age checker status, added the below api. "(B)(New) Account Verification: +agecheck.net integration"
router.post('/age_checker', auth, userController.age_checker);

//!!20240119pm6 coderC To get current user id verified status, added the below api. "(B)(New) Account Verification: +agecheck.net integration"
router.post('/get_current_user_id_verified_status', auth, userController.get_current_user_id_verified_status);

//!!20240119pm6 coderC To get current user token again, added the below api. "(B)(New) Account Verification: +agecheck.net integration"
router.post('/get_current_user_token', auth, userController.get_current_user_token);

//!!20231227pm3 coderc To set selected payment method token as default, added the below api. "(B) Spreedly Test : need Proof send tips"
router.post('/set_selected_payment_method_as_defult', auth, userController.set_selected_payment_method_as_defult);

//!!20240121pm5 coderC To pop up edit modal when click edit button, added the below code. "(B) comments - edit and delete not working"
router.post('/edit_comment', auth, userController.edit_comment);

//!!20240121pm5 coderC To remove comment, added the below code. "(B) comments - edit and delete not working"
router.post('/delete_comment', auth, userController.delete_comment);

//!!20231224pm coderB To get data of contact list to manipulate the message section
router.put('/get_contact_list', auth, userController.getContactList);

module.exports = router