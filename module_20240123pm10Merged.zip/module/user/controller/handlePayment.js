
const https = require('https');
const querystring = require('querystring');

class DirectPost {
  constructor(security_key) {
    this.security_key = security_key;
  }

  setBilling(billingInformation) {
    // Validate that passed in information contains valid keys
    const validBillingKeys = ['first_name', 'last_name', 'company', 'address1',
        'address2', 'city', 'state', 'zip', 'country', 'phone', 'fax', 'email'];

    for (let key in billingInformation) {
      if (!validBillingKeys.includes(key)) {
        throw new Error(`Invalid key provided in billingInformation. '${key}'
            is not a valid billing parameter.`)
      }
    };

    this.billing = billingInformation;
  }

  setShipping(shippingInformation) {
    // Validate that passed in information contains valid keys
    const validShippingKeys = [
      'shipping_first_name', 'shipping_last_name', 'shipping_company',
      'shipping_address1', 'address2', 'shipping_city', 'shipping_state',
      'shipping_zip', 'shipping_country', 'shipping_email'
    ];

    for (let key in shippingInformation) {
      if (!validShippingKeys.includes(key)) {
        throw new Error(`Invalid key provided in shippingInformation. '${key}'
            is not a valid shipping parameter.`)
      }
    };

    this.shipping = shippingInformation;
  }

  doSale(amount, ccNum, ccExp, cvv) {
    let requestOptions = {
      'type': 'sale',
      'amount': amount,
      'ccnumber': ccNum,
      'ccexp': ccExp,
      'cvv': cvv
    };

    // Merge together all request options into one object
    Object.assign(requestOptions, this.billing, this.shipping);

    // Make request
    this._doRequest(requestOptions);
  }

  doTokenSale(amount, token) {
    let requestOptions = {
      'type': 'sale',
      'amount': amount,
      'payment_token': token,
    };

    // Merge together all request options into one object
    Object.assign(requestOptions, this.billing, this.shipping);

    // Make request
    return this._doRequest(requestOptions);
  }


  _doRequest(postData) {
    return new Promise((resolve, reject) => {
      const hostName = 'secure.nmi.com';
      const path = '/api/transact.php';
  
      postData.security_key = this.security_key;
      postData = querystring.stringify(postData);
  
      const options = {
        hostname: hostName,
        path: path,
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
          'Content-Length': Buffer.byteLength(postData)
        }
      };
  
      // Make request to Payment API
      const req = https.request(options, (response) => {
        console.log(`STATUS: ${response.statusCode}`);
        console.log(`HEADERS: ${JSON.stringify(response.headers)}`);
        let responseData = '';
        response.on('data', (chunk) => {
          console.log(`BODY: ${chunk}`);
          responseData += chunk;
        });
        response.on('end', () => {
          console.log('No more data in response.');
          const result = querystring.parse(responseData);
          resolve(result)
        });
      });
  
      req.on('error', (e) => {
        console.error(`Problem with request: ${e.message}`);
        reject(e)
      });
  
      // Write post data to request body
      req.write(postData);
      req.end();

    })
  }
}



exports.handle_pay = function(data) {
    const dp = new DirectPost('6457Thfj624V5r7WUwc5v6a68Zsd6YEm');
    const billingInfo = data.billingInfo
    const shippingInfo = data.shippingInfo

    console.log("&-! payment start")

    dp.setBilling(billingInfo);
    dp.setShipping(shippingInfo);
    // Set dummy data for sale
    return dp.doTokenSale(data.price, data.token);
   
}