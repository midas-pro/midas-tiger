const request = require('request');

const domain = 'https://sandbox-paynote.seamlesschex.com';
const versionApi = 'v1';
const apiKey = 'pk_test_01HBR26CS68SMXFBPCWFA9X6P7';
const secretKey = 'sk_test_01HBR26CS68SMXFBPCWFA9X6P6';

exports.handlePayWithPaynote = function(requestData) {
    return new Promise((resolve, reject) => {
        const options = {
            method: 'POST',
            uri: `${domain}/${versionApi}/check/send`,
            headers: {
                Authorization: secretKey,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(requestData)
        };
        request(options, function(error, response) {
            if (error) {
                reject(error);
            } else {
                resolve(response.body);
            }
        });
    });
};
