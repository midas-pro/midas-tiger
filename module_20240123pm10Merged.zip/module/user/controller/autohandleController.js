const tipModel = require("../model/tipModel");
const userModel = require("../model/userModel");
const { handlePayWithPaynote } = require("./paynoteController");

let interval_for_coin;

exports.handleCoinStatus = function() {
    console.log("HANDLE COIN")
    async function handleCoin() {
        console.log("Automatic control");
        try {
            let tips = await tipModel.aggregate([
                {
                    $match: {
                        status: false
                    },
                },{
                    $group: {
                        _id: "$receiver",
                        sum: {
                            $sum: "$coin"
                        },
                        created_date: {
                            $min: "$created_date"
                        }
                    }
                }
            ]).exec();
    
            console.log(tips);

            let date = new Date();

            tips.map(async t => {
                let created = new Date(t.created_date);
                let distance = date.getTime() - created.getTime();
                // filter the sum is larger than 30 and created date is larger 10
                if(distance >= 60000 && t.sum >= 30) {
                    try {
                        let user = await userModel.findById(t._id);
                        if(user) {
                            let reqData = {
                              recipient: user.email,
                              name: user.first_name + user.last_name,
                              amount: t.sum,
                              description: 'Transaction in indiefire',
                              account: '',
                              number: '10038',
                              identifier: 'Transaction to indiefire.io',
                              attachment: '',
                              recurring: {
                                billing_cycle: 'day',
                                start_cycle: new Date(),
                                num_of_payments: 15
                              }
                            };
                            let paynoteResponse = await handlePayWithPaynote(reqData);
                            console.log("paynoteResponse");
                            console.log(paynoteResponse);

                            await tipModel.updateMany({ receiver: t._id }, { status: true })

                        }
                      } catch (error) {
                        console.log("4350: error")
                        console.log(error)
                      }

                // filter the sum is less than 30 but created date is larger than 30
                } else if(distance >= 180000) {
                    try {
                        let user = await userModel.findById(t._id);
                        if(user) {
                            let reqData = {
                            recipient: user.email,
                            name: user.first_name + user.last_name,
                            amount: t.sum,
                            description: 'Transaction in indiefire',
                            account: '',
                            number: '10038',
                            identifier: 'Transaction to indiefire.io',
                            attachment: '',
                            recurring: {
                                billing_cycle: 'day',
                                start_cycle: new Date(),
                                num_of_payments: 15
                            }
                            };
                            let paynoteResponse = await handlePayWithPaynote(reqData);
                            console.log("paynoteResponse");
                            console.log(paynoteResponse);

                            await tipModel.updateMany({ receiver: t._id }, { status: true })

                        }
                    } catch (error) {
                        console.log("4350: error")
                        console.log(error)
                    }
                }


            });

        } catch (error) {
            console.log(error);            
        }




    }

    if(interval_for_coin) {
        clearInterval(interval_for_coin);
    }

    interval_for_coin = setInterval(() => {
        handleCoin();
    }, 60000)
}

