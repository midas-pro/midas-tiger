/*
Project : Cryptotrades
FileName : userController.js
Author : Indiefire
File Created : 21/07/2021
CopyRights : Indiefire
Purpose : This is the file which used to define all user related api function.
*/

var users = require("./../model/userModel");
var fans = require("./../model/fanModel");
var followers = require("./../model/followerModel");
var members = require("./../model/memberModel");
var shipaddrs = require("./../model/addressModel");
var jwt = require("jsonwebtoken");
const { validationResult } = require("express-validator");
var randomstring = require("randomstring");
var bcrypt = require("bcrypt");
var validator = require("validator");
var config = require("./../../../helper/config");
var moment = require("moment");
var mailer = require("./../../common/controller/mailController");
var media = require("./../../media/controller/mediaController");
var cp = require("child_process");
const fandoms = require("../model/fandomModel");
const subscriptionlevels = require("../model/subscriptionlevelModel");
const subscribers = require("../model/subscriberModel");
const fanposts = require("../../fanpost/model/fanpostModel");

var tipModel = require("../model/tipModel");
const tipbuyModel = require("../model/tipbuyModel");

const blockModel = require("../model/blockModel");
const muteModel = require("../model/muteModel");
const fandomPaymentModel = require("../model/fandomPaymentModel");
const financeModel = require("../model/financeModel");
const muteWordModel = require("../model/muteWordModel");
const notificationModel = require("../../notification/model/notificationModel");
const { NOTIFICATION_TYPES, NOTIFICATION_FILTERS } = require("../../helper/notification_config");
const { reset_password } = require("../../helper/sentEmail");

const payController = require('../controller/handlePayment');
const paynoteController = require('../controller/paynoteController');
const shippingRuleModel = require("../model/shippingRuleModel");
const reactionModel = require("../../fanpost/model/reactionModel");
const itemreactionModel = require('../../item/model/itemreactionModel');
const itemShippingRuleModel = require("../model/itemShippingRuleModel");
const { getErrLine } = require("../../helper/helpers");
const artistModel = require("../model/artistModel");

//!!20231221pm4 coderc To send the Axios request, imported the following module
var request = require('superagent');
//added by coderB 20231220am05
const safelistModel = require("../model/safelistModel");
const commentModel = require("../../fanpost/model/commentModel");
/*
 *  This is the function which used to retreive all users ( username, email) in order to check duplicated username/email for signup
 */
//20231212am11 CoderD pric print format "toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })" use to "toFixed(2)"
exports.getListAllUsers4DupCheck = async function (req, res) {
  console.log(getErrLine().str, "apistart");
  var query = users.find();
  query.select("username email");
  query.exec(function (err, data) {
    res.json({
      status: true,
      message: "Users retrieved successfully",
      data: data,
    });
  });
};

/*
 *  This is the function which used to retreive user list
 */
exports.getList = async function (req, res) {
  console.log(getErrLine().str, "apistart");
  var logged_id = "";
  if (req.query.user_id) {
    logged_id = req.query.user_id;
  }
  var keyword = req.query.keyword ? req.query.keyword : "";
  keyword = keyword.replace("+", " ");
  var page = req.query.page ? req.query.page : "1";
  var limit = req.query.limit ? req.query.limit : "15";
  var query;
  if (logged_id) {
    var blockerIDS = [];
    blockerIDS.push(logged_id);
    query = users.find({ _id: { $nin: blockerIDS } });
  } else {
    query = users.find();
  }
  var offset = page == "1" ? 0 : parseInt(page - 1) * 15;
  if (keyword != "") {
    search = {
      $or: [
        {
          first_name: {
            $regex: new RegExp(keyword, "ig"),
          },
        },
        {
          last_name: {
            $regex: new RegExp(keyword, "ig"),
          },
        },
        {
          email: {
            $regex: new RegExp(keyword, "ig"),
          },
        },
      ],
    };
    query = query.or(search);
  }
  query = query.where("status", "active").sort("-create_date");
  var options = {
    select:
      "username email profile_image first_name last_name profile_cover status create_date bio timezone is_idverified privacy_safety",
    page: page,
    offset: offset,
    limit: limit,
  };
  users.paginate(query, options).then(function (result) {
    res.json({
      status: true,
      message: "Users retrieved successfully",
      data: result,
    });
  });
};

exports.get_filtered_users = function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded.user_id;
  var filter_users = req.body.users || [];
  var keyword = req.body.keyword ? req.body.keyword : "";
  keyword = keyword.replace("+", " ");
  var page = req.body.page ? req.body.page : "1";
  var limit = req.body.limit ? req.body.limit : "15";
  var query = users.find();

  if (user_id) {
    filter_users = [...filter_users, user_id];
  }
  query = query.find({ _id: { $nin: filter_users } });

  var offset = page == "1" ? 0 : parseInt(page - 1) * 15;
  if (keyword != "") {
    search = {
      $or: [
        {
          first_name: {
            $regex: new RegExp(keyword, "ig"),
          },
        },
        {
          last_name: {
            $regex: new RegExp(keyword, "ig"),
          },
        },
        {
          email: {
            $regex: new RegExp(keyword, "ig"),
          },
        },
      ],
    };
    query = query.or(search);
  }
  query = query.where("status", "active").sort("-create_date");
  var options = {
    select:
      "username email profile_image first_name last_name profile_cover status create_date bio is_idverified",
    page: page,
    offset: offset,
    limit: limit,
  };
  users.paginate(query, options).then(function (result) {
    res.json({
      status: true,
      message: "Users retrieved successfully",
      data: result,
    });
  });
};

/*
 *   This is the function which used to retreive user list for admin
 */
exports.getAdminList = async function (req, res) {
  console.log(getErrLine().str, "apistart");
  var logged_id = "";
  if (req.query.user_id) {
    logged_id = req.query.user_id;
  }
  var keyword = req.query.keyword ? req.query.keyword : "";
  keyword = keyword.replace("+", " ");
  var page = req.query.page ? req.query.page : "1";
  var query;
  if (logged_id) {
    var blockerIDS = [];
    blockerIDS.push(logged_id);
    query = users.find({ _id: { $nin: blockerIDS } });
  } else {
    query = users.find();
  }
  var offset = page == "1" ? 0 : parseInt(page - 1) * 15;
  if (keyword != "") {
    search = {
      $or: [
        {
          first_name: {
            $regex: new RegExp(keyword, "ig"),
          },
        },
        {
          last_name: {
            $regex: new RegExp(keyword, "ig"),
          },
        },
        {
          email: {
            $regex: new RegExp(keyword, "ig"),
          },
        },
      ],
    };
    query = query.or(search);
  }
  query = query.sort("-create_date");
  var options = {
    select: "username email profile_image first_name last_name status",
    page: page,
    offset: offset,
    limit: 15,
  };
  users.paginate(query, options).then(function (result) {
    res.json({
      status: true,
      message: "Users retrieved successfully",
      data: result,
    });
  });
};

/*
 *  This is the function which used to retreive user list
 */
exports.getListByIds = async function (req, res) {
  console.log(getErrLine().str, "apistart");
  var query = users.find({ _id: { $in: req.body.users } });
  query.select("_id first_name last_name profile_image");
  query.exec(function (err, data) {
    res.json({
      status: true,
      message: "Users retrieved successfully",
      data: data,
    });
  });
};

exports.switchuser = function (req, res) {
  console.log(getErrLine().str, "apistart");
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    res.json({
      status: false,
      message: "Request failed",
      errors: errors.array(),
    });
    return;
  }

  params = { username: req.body.username, email: req.decoded.email };
  console.log("switchuser:param:", params);
  this.loginUserWithSocial(params, req, res);
};

exports.get_token_status = async function (req, res) {
  console.log(getErrLine().str, "apistart");//!!20231230 CoderA too many log// disable temporarely
  res.json({
    status: true,
    message: "token is valid"
  })
}

exports.updatePassword = async function (req, res) {
  console.log(getErrLine().str, "apistart");
  let user_id = req.decoded.user_id;
  let cpass = req.body.cpass;
  let npass = req.body.npass;

  try {
    let user = await users.findById(user_id);
    if (user) {
      if (cpass) {
        let match = user.comparePassword(cpass);
        if (match) {
          user.password = npass;
          await user.save();
          res.josn({
            status: true,
            message: "Updated successfully",
          });
        } else {
          res.json({
            status: false,
            message: "Password is not matched",
          });
        }
      } else {
        user.password = npass;
        await user.save();
        res.json({
          status: true,
          message: "Updated successfully"
        });
      }
    } else {
      res.json({
        status: false,
        message: "User does not exist",
      });
    }
  } catch (error) {
    console.log(error);
    res.json({
      status: false,
      message: "Something went wrong",
    });
  }


}


exports.login = function (req, res) {
  console.log(getErrLine().str, "apistart");
  // const errors = validationResult(req);
  // if (!errors.isEmpty()) {
  //     res.json({
  //         status: false,
  //         message: "Request failed143",
  //         errors:errors.array()
  //     });
  //     return;
  // }

  if (validator.isEmail(req.body.email)) {
    // find where email & order by last_login_date
    // var query  = users.find({email:req.body.email},{"sort":[['last_login_date', 'asc']]}).select('username').limit(5);
    var query = users.find({ email: req.body.email }).select("username");
    // query = query.sort('-create_date').limit(5)
    query.sort({ last_login_date: -1 });
    query.exec(function (err, retusers) {
      if (err || !retusers || retusers.length == 0) {
        res.json({
          status: false,
          message: "User email Not Found",
          errors: err,
        });
        return;
      }
      var retuser = retusers[0];
      console.log("login with email:retuser" + JSON.stringify(retusers));
      params = { username: retuser.username };
      this.loginUser(params, req, res);
    });
  } else {
    params = { username: req.body.username };
    this.loginUser(params, req, res);
  }
};

loginUser = function (params, req, res) {
  users.findOne(params, function (err, user) {
    if (err) {
      res.json({
        status: false,
        message: "Request failed162",
        errors: err,
      });
      return;
    }
    if (this.isEmptyObject(user)) {
      res.json({
        status: false,
        message: "User not found",
      });
      return;
    }
    user.comparePassword(req.body.password, (error, match) => {
      if (!match) {
        res.json({
          status: false,
          message: "Password is mismatch",
        });
        return;
      }
      if (user.status == "inactive") {
        res.json({
          status: false,
          message:
            "Your account has been inactive. contact admin to activate your account",
        });
        return;
      }
      if (user.status == "blocked") {
        res.json({
          status: false,
          message:
            "Your account has been blocked. contact admin to activate your account",
        });
        return;
      }
      console.log(req.body.device_info);
      user.last_login_date = Date.now();
      if (req.body.device_info) {
        var device_info = JSON.parse(req.body.device_info);
        user.device_info = device_info;
      }
      user.save(function (err) {
        if (err) {
          res.json({
            status: false,
            message: "Request failed162",
            errors: err,
          });
          return;
        }
        let token = jwt.sign(
          {
            user_id: user._id,
            username: user.username,
            email: user.email,
            first_name: user.first_name,
            last_name: user.last_name,
            profile_image: user.profile_image ? user.profile_image : "",
            status: user.status,
            dob: user.dob,
            phone: user.phone,
            role: user.role,
            is_idverified: user.is_idverified,
            timezone: user.timezone, //20231214pm4 coderd timezone token add
            privacy_safety: user.privacy_safety, //20231219am03 coderB
            safe_list: user.safe_list //20231219am03 coderB
          },
          config.secret_key,
          {
            expiresIn: "24h", // expires in 24 hours
          }
        );
        res.json({
          status: true,
          token: token,
          message: "Login successful",
          username: params,
        });
      });
    });
  });
};


exports.reset_password_request = async function (req, res) {
  console.log(getErrLine().str, "apistart");
  let email = req.body.email;
  try {
    let user = await users.findOne({ email });
    if (user) {
      let token = jwt.sign(
        {
          user_id: user._id,
          username: user.username,
          email: user.email,
          first_name: user.first_name,
          last_name: user.last_name,
          profile_image: user.profile_image ? user.profile_image : "",
          status: user.status,
          dob: user.dob,
          phone: user.phone,
          role: user.role,
          is_idverified: user.is_idverified,
        },
        config.secret_key,
        {
          expiresIn: "1h", // expires in 24 hours
        }
      );

      const link = `indiefire.io/password-reset/${token}`;

      try {
        let result = await reset_password(user.email, "Password reset", link);
        console.log(result);
        if (result?.success) {
          res.json({
            status: true,
            message: "Please check your email"
          });
        } else {
          res.json({
            status: false,
            message: "Failed Request"
          })
        }
      } catch (error) {
        console.log(error)
        res.json({
          status: false,
          message: "Something went wrong"
        });
      }
    } else {
      res.json({
        status: false,
        message: "Unregistered email address"
      });
    }
  } catch (error) {
    console.log(error);
    res.json({
      status: false,
      message: "Something went wrong"
    });
  }
}

/*
 *  This is the function which used to retreive user detail by user id
 */
exports.details = function (req, res) {
  console.log(getErrLine().str, "apistart");
  users
    .findOne({ _id: req.params.userId })
    .select(
      "username role email first_name last_name profile_image profile_cover metamask_info password status is_idverified create_date"
    )
    .exec(function (err, user) {
      if (err) {
        res.json({
          status: false,
          message: "Request failed238",
          errors: "User not found",
        });
        return;
      }
      if (this.isEmptyObject(user)) {
        res.json({
          status: false,
          message: "Request failed246",
          errors: "User not found",
        });
        return;
      }
      res.json({
        status: true,
        message: "Profile info retrieved successfully",
        result: user,
      });
    });
};


exports.create_other_account = async function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded.user_id;

  try {
    var user = new users(req.body);
    user.main_id = user_id;

    let user_with_username = await users.findOne({ username: req.body.username });

    if (user_with_username) {
      res.json({
        status: false,
        message: "Username already exist"
      });
      return;
    }

    let user_with_email = await users.findOne({ email: req.body.email });
    if (user_with_email) {
      res.json({
        status: false,
        message: "Email is using in another account"
      });
      return;
    }

    await user.save();
    res.json({
      status: true,
      message: "Saved successfully"
    });
  } catch (error) {
    console.log(error);
    res.json({
      status: false,
      message: error.message
    })
  }

}

exports.get_other_account = async function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded.user_id;
  try {
    let user = await users.findById(user_id);
    let other_users;
    if (user.main_id) {
      other_users = await users.find({
        $or: [
          { _id: user.main_id },
          { main_id: user.main_id }
        ]
      }).select("username first_name last_name profile_image profile_cover status create_date bio is_idverified");
    } else {
      other_users = await users.find({
        $or: [
          { _id: user_id },
          { main_id: user._id }
        ]
      }).select("username first_name last_name profile_image profile_cover status create_date bio is_idverified");;
    }
    res.json({
      status: true,
      message: "Retrived successfully",
      result: other_users
    });
  } catch (error) {
    console.log(error);
    res.json({
      status: false,
      message: "Something went wrong"
    })
  }
}

exports.switch_account = async function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded.user_id;
  var _id = req.body._id;

  try {
    var user = await users.findById(_id);
    if (user) {
      let token = jwt.sign(
        {
          user_id: user._id,
          username: user.username,
          email: user.email,
          first_name: user.first_name,
          last_name: user.last_name,
          profile_image: user.profile_image ? user.profile_image : "",
          status: user.status,
          dob: user.dob,
          phone: user.phone,
          role: user.role,
          is_idverified: user.is_idverified,
        },
        config.secret_key,
        {
          expiresIn: "24h", // expires in 24 hours
        }
      );

      res.json({
        status: true,
        message: "Account switched successfully",
        result: token
      })
    } else {
      res.json({
        status: false,
        message: "Can't find user"
      })
    }

  } catch (error) {
    console.log(error);
    res.json({
      status: false,
      message: "Something went wrong"
    })
  }



}


/*
 *  This is the function which used to retreive user detail by user id
 */
exports.publicdetails = function (req, res) {
  console.log(getErrLine().str, "apistart");
  users
    .findOne({ _id: req.params.userId })
    .select(
      // 20240122pm12 CoderB "(C)fanpage - if no fans don’t show this "
      // "username first_name last_name profile_image profile_cover status create_date bio is_idverified privacy_safety"
      "username first_name last_name profile_image profile_cover status create_date bio is_idverified privacy_safety fans_count"

    )
    .exec(function (err, user) {
      if (err) {
        res.json({
          status: false,
          message: "Request failed",
          errors: "User not found",
        });
        return;
      }
      if (this.isEmptyObject(user)) {
        res.json({
          status: false,
          message: "Request failed",
          errors: "User not found",
        });
        return;
      }
      res.json({
        status: true,
        message: "Profile info retrieved successfully",
        result: user,
      });
    });
};

/*
 *  This is the function which used to create new user in Cryptotrades
 */
exports.register = function (req, res) {
  console.log(getErrLine().str, "apistart");
  if (req.body.social_info) {
    this.checkSocialUserExist(req, res, function (result) {
      if (result) {
        var social_info = JSON.parse(req.body.social_info);
        var params;
        if (social_info.type == "metamask") {
          params = { "metamask_info.id": social_info.id };
        }
        this.loginUserWithSocial(params, req, res);
      } else {
        var social_info = JSON.parse(req.body.social_info);
        this.registerUser(req, res);
      }
    });
  } else {
    res.json({
      status: false,
      message: "Request failed. register not accepted without connect wallet",
    });
  }
};

exports.signup = function (req, res) {
  console.log(getErrLine().str, "apistart");
  if (
    req.body.email &&
    req.body.username &&
    req.body.password &&
    req.body.first_name/* &&
    req.body.timezone */
  ) {
    this.registerUser(req, res);
  } else {
    res.json({
      status: false,
      message:
        "Request failed. Email or username or password or Display Name TimeZone is omitted.",
    });
  }
};

/**
 *   This is the function handle user registration
 */
registerUser = function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user = new users();
  user.username = req.body.username ? req.body.username : "";
  user.timezone = req.body.timezone ? req.body.timezone : "-06:00"; //20231214a9 coderd add
  user.email = req.body.email ? req.body.email : "";
  user.password = req.body.password ? req.body.password : "";
  user.first_name = req.body.first_name ? req.body.first_name : "";
  user.last_name = req.body.last_name ? req.body.last_name : "";
  user.phone = req.body.phone ? req.body.phone : "";
  user.profile_image = req.body.profile_image ? req.body.profile_image : "";
  user.dob = req.body.dob ? req.body.dob : "";
  // user.is_last_active = 1;
  user.last_login_date = Date.now();

  if (req.body.device_info) {
    var device_info = JSON.parse(req.body.device_info);
    user.device_info = device_info;
  }

  if (req.body.social_info) {
    var social_info = JSON.parse(req.body.social_info);
    social_info = {
      id: social_info.id ? social_info.id : "",
      type: social_info.type ? social_info.type : "",
    };

    let username = randomstring.generate({
      length: 10,
      charset: "alphabetic",
    });
    user.username = username;
    user.metamask_info = social_info;
  }
  user.status = "active";

  user.save(function (err, user) {
    if (err) {
      console.log(err);
      res.json({
        status: false,
        message: err.message,
        errors: err,
      });
      return;
    }
    let token = jwt.sign(
      {
        user_id: user._id,
        username: user.username,
        email: user.email,
        first_name: user.first_name,
        last_name: user.last_name,
        profile_image: user.profile_image ? user.profile_image : "",
        status: user.status,
        dob: user.dob,
        phone: user.phone,
        role: user.role,
        is_idverified: user.is_idverified,
        timezone: user.timezone,
      },
      config.secret_key,
      {
        expiresIn: "24h", // expires in 24 hours
      }
    );

    res.json({
      status: true,
      token: token,
      message: "Registration successful",
    });
  });
};

/*
 *  This function used to find whether user name exist or not
 */
checkUserNameExist = function (req, res, callback) {
  if (req.body.username) {
    users.find({ username: req.body.username }, function (err, data) {
      if (err) {
        res.json({
          status: false,
          message: "Request failed354",
          errors: err,
        });
        return;
      }
      if (data.length > 0) {
        res.json({
          status: false,
          message: "User Name already Exist",
          errors: "User Name already Exist",
        });
        return;
      }
      callback(true);
    });
  } else {
    res.json({
      status: false,
      message: "User Name is required",
      errors: "User Name is required",
    });
    return;
  }
};

/*
 *  This function used to find whether email exist or not
 */
checkEmailExist = function (req, res, callback) {
  if (req.body.email) {
    users.find({ email: req.body.email }, function (err, data) {
      if (err) {
        res.json({
          status: false,
          message: "Request failed388",
          errors: err,
        });
        return;
      }
      if (data.length > 0) {
        res.json({
          status: false,
          message: "Email already Exist",
          errors: "Email already Exist",
        });
        return;
      }
      callback(true);
    });
  } else {
    res.json({
      status: false,
      message: "Email is required",
      errors: "Email is required",
    });
    return;
  }
};

/**
 * This is the function which used to check if user social account have or not
 */
checkSocialUserExist = function (req, res, callback) {
  var social_info = JSON.parse(req.body.social_info);
  var params;
  if (social_info.type == "metamask") {
    params = { "metamask_info.id": social_info.id };
  }
  users.find(params, function (err, data) {
    if (err) {
      res.json({
        status: false,
        message: "Request failed426",
        errors: err,
      });
      return;
    }
    if (data.length > 0) {
      callback(true);
    } else {
      callback(false);
    }
  });
};

/**
 * This is the function which used to process login user with social login
 */
loginUserWithSocial = function (params, req, res) {
  users.findOne(params, function (err, user) {
    if (err) {
      res.json({
        status: false,
        message: "Request failed449",
        errors: err,
      });
      return;
    }
    if (this.isEmptyObject(user)) {
      res.json({
        status: false,
        message: "User not found",
      });
      return;
    }
    if (user.status == "inactive") {
      res.json({
        status: false,
        message:
          "Your account has been inactive. contact admin to activate your account",
      });
      return;
    }
    if (user.status == "blocked") {
      res.json({
        status: false,
        message:
          "Your account has been blocked. contact admin to activate your account",
      });
      return;
    }

    if (req.body.device_info) {
      var device_info = JSON.parse(req.body.device_info);
      user.device_info = device_info;
      console.log(req.body.device_info);
    }
    // user.is_last_active = 1;
    user.last_login_date = Date.now();
    user.save(function (err) {
      if (err) {
        res.json({
          status: false,
          message: "Update user status failed",
          errors: err,
        });
        return;
      }
      let token = jwt.sign(
        {
          user_id: user._id,
          username: user.username,
          email: user.email,
          first_name: user.first_name,
          last_name: user.last_name,
          profile_image: user.profile_image ? user.profile_image : "",
          status: user.status,
          dob: user.dob,
          phone: user.phone,
          role: user.role,
          is_idverified: user.is_idverified,
        },
        config.secret_key,
        {
          expiresIn: "24h", // expires in 24 hours
        }
      );
      res.json({
        status: true,
        token: token,
        message: "Login successful",
      });
    });
  });
};

/*
 *  This is the function which used to update user profile
 */
exports.update = function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded.user_id;
  var params = {};
  params["_id"] = { $ne: user_id };
  var query = users.find();
  if (req.body.email) {
    params["email"] = req.body.email;
  }
  if (req.body.username) {
    params["username"] = req.body.username;
  }
  query = users.find(params);
  query.exec(function (err, data) {
    if (req.body.email || req.body.username) {
      if (err) {
        res.json({
          status: false,
          message: "Request failed528",
          errors: err,
        });
        return;
      }
      if (data.length > 0) {
        res.json({
          status: false,
          message: "Email or Username already exist",
        });
        return;
      }
    }

    users.findOne({ _id: req.decoded.user_id }, function (err, user) {
      if (err) {
        res.json({
          status: false,
          message: "Request failed546",
          errors: err,
        });
        return;
      }
      if (this.isEmptyObject(user)) {
        res.json({
          status: false,
          message: "User not found",
        });
        return;
      }
      if (user.status == "inactive") {
        res.json({
          status: false,
          message:
            "Your account has been inactive. Contact admin to activate your account",
        });
        return;
      }
      if (user.status == "blocked") {
        res.json({
          status: false,
          message:
            "Your account has been blocked. Contact admin to activate your account",
        });
        return;
      }
      user.first_name = req.body.first_name
        ? req.body.first_name
        : user.first_name;
      user.last_name = req.body.last_name ? req.body.last_name : user.last_name;
      user.profile_image = req.body.profile_image
        ? req.body.profile_image
        : user.profile_image;
      user.profile_cover = req.body.profile_cover
        ? req.body.profile_cover
        : user.profile_cover;
      user.email = req.body.email ? req.body.email : user.email;
      user.username = req.body.username ? req.body.username : user.username;
      user.dob = req.body.dob ? req.body.dob : user.dob;
      user.phone = req.body.phone ? req.body.phone : user.phone;
      user.is_idverified = req.body.is_idverified
        ? req.body.is_idverified
        : user.is_idverified;
      if (req.body.password) {
        user.password = req.body.password;
      }
      if (req.body.social_info) {
        var social_info = JSON.parse(req.body.social_info);
        social_info = {
          id: social_info.id ? social_info.id : "",
          type: social_info.type ? social_info.type : "",
        };
        if (social_info.type == "metamask") {
          user.metamask_info = social_info;
        }
      }

      if (req.body.device_info) {
        var device_info = JSON.parse(req.body.device_info);
        user.device_info = device_info;
      }

      user.modified_date = moment().format();
      // save the user and check for errors
      user.save(function (err, user) {
        if (err) {
          res.json({
            status: false,
            message: "Request failed605",
            errors: err,
          });
          return;
        }

        let token = jwt.sign(
          {
            user_id: user._id,
            username: user.username,
            email: user.email,
            first_name: user.first_name,
            last_name: user.last_name,
            profile_image: user.profile_image ? user.profile_image : "",
            status: user.status,
            dob: user.dob,
            social_info: user.social_info,
            phone: user.phone,
            role: user.role,
            is_idverified: user.is_idverified,
          },
          config.secret_key,
          {
            expiresIn: "24h", // expires in 24 hours
          }
        );
        res.json({
          status: true,
          token: token,
          message: "profile updated successfully",
        });
      });
    });
  });
};

/*
 *  This is the function which used to update user profile
 */
exports.updatesettings = function (req, res) {
  console.log(getErrLine().str, "apistart");
  users.findOne({ _id: req.decoded.user_id }, function (err, user) {
    if (err) {
      res.json({
        status: false,
        message: "Request failed635",
        errors: err,
      });
      return;
    }
    if (this.isEmptyObject(user)) {
      res.json({
        status: false,
        message: "User not found",
      });
      return;
    }
    if (user.status == "inactive") {
      res.json({
        status: false,
        message:
          "Your account has been inactive. Contact admin to activate your account",
      });
      return;
    }
    if (user.status == "blocked") {
      res.json({
        status: false,
        message:
          "Your account has been blocked. Contact admin to activate your account",
      });
      return;
    }
    user.is_notification = req.body.is_notification;
    user.modified_date = moment().format();
    user.save(function (err, user) {
      if (err) {
        res.json({
          status: false,
          message: "Request failed667",
          errors: err,
        });
        return;
      }
      res.json({
        status: true,
        message: "profile settings updated successfully",
      });
    });
  });
};

/*
 *  This is the function which used to update user profile
 */
exports.updatebio = function (req, res) {
  console.log(getErrLine().str, "apistart");
  users.findOne({ _id: req.query.user_id }, function (err, user) {
    if (err) {
      res.json({
        status: false,
        message: "Request failed635",
        errors: err,
      });
      return;
    }
    if (this.isEmptyObject(user)) {
      res.json({
        status: false,
        message: "User not found",
      });
      return;
    }
    user.bio = req.body.bio;
    user.modified_date = moment().format();
    user.save(function (err, user) {
      if (err) {
        res.json({
          status: false,
          message: "Request failed on update bio",
          errors: err,
        });
        return;
      }
      res.json({
        status: true,
        message: "profile settings updated successfully",
      });
    });
  });
};

/*
 *  This is the function which used to update user profile
 */
exports.updatewallet = function (req, res) {
  console.log(getErrLine().str, "apistart");
  users.findOne({ _id: req.query.user_id }, function (err, user) {
    if (err) {
      res.json({
        status: false,
        message: "Request failed on updatewallet api",
        errors: err,
      });
      return;
    }
    if (this.isEmptyObject(user)) {
      res.json({
        status: false,
        message: "User not found",
      });
      return;
    }
    if (req.body.social_info) {
      var social_info = JSON.parse(req.body.social_info);
      social_info = {
        id: social_info.id ? social_info.id : "",
        type: social_info.type ? social_info.type : "",
        key: social_info.key ? social_info.key : "",
      };
      user.metamask_info = social_info;
    }
    user.modified_date = moment().format();
    user.save(function (err, user) {
      if (err) {
        res.json({
          status: false,
          message: "Request failed on update crypto wallet address",
          errors: err,
        });
        return;
      }
      res.json({
        status: true,
        message: "crypto wallet address settings updated successfully",
      });
    });
  });
};

/*
 *  This is the function which used to ID verified
 */
exports.setidverified = function (req, res) {
  console.log(getErrLine().str, "apistart");
  users.findOne({ _id: req.query.user_id }, function (err, user) {
    if (err) {
      res.json({
        status: false,
        message: "Request failed for set ID verified",
        errors: err,
      });
      return;
    }
    if (this.isEmptyObject(user)) {
      res.json({
        status: false,
        message: "User not found",
      });
      return;
    }
    user.is_idverified = req.body.is_idverified;
    user.save(function (err, user) {
      if (err) {
        res.json({
          status: false,
          message: "Request failed on set ID verified",
          errors: err,
        });
        return;
      }
      res.json({
        status: true,
        message: "set ID verified for the user",
      });
    });
  });
};
/**
 *   This is the function check object is empty or not
 */
exports.getUserInfoByID = function (userId, callback) {
  users
    .findOne({ _id: userId })
    .lean()
    .exec(function (err, user) {
      if (err) {
        callback(err, null);
        return;
      }
      if (this.isEmptyObject(user)) {
        callback(
          {
            status: false,
            message: "Request failed693",
            errors: "User not found",
          },
          null
        );
        return;
      }
      user.profile_image = user.profile_image ? user.profile_image : "";
      callback(null, user);
    });
};

/**
 *   This is the function check object is empty or not
 */
isEmptyObject = function (obj) {
  for (var key in obj) {
    if (Object.prototype.hasOwnProperty.call(obj, key)) {
      return false;
    }
  }
  return true;
};

/*
 *   This is the function which used to update user profile from admin
 */
exports.updateUser = function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.body.user_id;
  var params = {};
  params["_id"] = { $ne: user_id };
  var query = users.find();
  if (req.body.email) {
    params["email"] = req.body.email;
  }
  if (req.body.username) {
    params["username"] = req.body.username;
  }
  query = users.find(params);
  query.exec(function (err, data) {
    if (req.body.email || req.body.username) {
      if (err) {
        res.json({
          status: false,
          message: "Request failed738",
          errors: err,
        });
        return;
      }
      if (data.length > 0) {
        res.json({
          status: false,
          message: "Email or Username already exist",
        });
        return;
      }
    }

    users.findOne({ _id: req.body.user_id }, function (err, user) {
      if (err) {
        res.json({
          status: false,
          message: "Request failed756",
          errors: err,
        });
        return;
      }
      if (this.isEmptyObject(user)) {
        res.json({
          status: false,
          message: "User not found",
        });
        return;
      }
      user.first_name = req.body.first_name
        ? req.body.first_name
        : user.first_name;
      user.last_name = req.body.last_name ? req.body.last_name : user.last_name;
      user.profile_image = req.body.profile_image
        ? req.body.profile_image
        : user.profile_image;
      user.profile_cover = req.body.profile_cover
        ? req.body.profile_cover
        : user.profile_cover;
      user.email = req.body.email ? req.body.email : user.email;
      user.username = req.body.username ? req.body.username : user.username;
      user.dob = req.body.dob ? req.body.dob : user.dob;
      user.phone = req.body.phone ? req.body.phone : user.phone;
      if (req.body.password) {
        user.password = req.body.password;
      }
      let role;
      if (req.body.role == 'admin') { role = 1 }
      else if (req.body.role == 'supporter') { role = 3 }
      else { role = 2 }
      if (user.role != 1 || user.role) {
        user.role = role;
      }
      user.status = req.body.status ? req.body.status : "";
      user.modified_date = moment().format();
      user.save(function (err, user) {
        if (err) {
          res.json({
            status: false,
            message: "Request failed785",
            errors: err,
          });
          return;
        }
        res.json({
          status: true,
          message: "profile updated successfully",
        });
      });
    });
  });
};

/*
 * This is the function which used to list staruser in database
 */
exports.actionFan = function (req, res) {
  console.log(getErrLine().str, "apistart");
  users.findOne(
    { _id: req.body.star_id, status: "active" },
    function (err, staruser) {
      if (err || !staruser) {
        res.json({
          status: false,
          message: "Star User not found",
          errors: err,
        });
        return;
      }
      fans.findOne(
        { star_id: req.body.star_id, user_id: req.body.user_id },
        function (err, fan) {
          if (req.body.type == "increase") {
            if (!fan) {
              staruser.fans_count = staruser.fans_count + 1;
              var newfan = new fans();
              newfan.user_id = req.body.user_id;
              newfan.star_id = req.body.star_id;
              newfan.save(function (err, result) {
                staruser.save(function (err, result) {
                  res.json({
                    status: true,
                    message: "Fan added successfully",
                  });
                });
              });
            } else {
              res.json({
                status: true,
                message: "Fan added successfully",
              });
            }
          } else {
            if (!fan) {
              res.json({
                status: true,
                message: "Fan removed successfully.",
              });
            } else {
              staruser.fans_count = staruser.fans_count - 1;
              fans.deleteOne({ _id: fan._id }, function (err) {
                staruser.save(function (err, result) {
                  res.json({
                    status: true,
                    message: "Fan removed successfully!",
                  });
                });
              });
            }
          }
        }
      );
    }
  );
};

/*
 * This is the function which used to list user who add the staruser as fan staruser
 */
exports.listFan = async function (req, res) {
  console.log(getErrLine().str, "apistart");
  var type = req.query.type;
  var star_id = req.query.star_id;
  var page = req.query.page ? req.query.page : "1";
  var limit = req.query.limit ? req.query.limit : "15";
  var keyword = req.query.keyword ? req.query.keyword.trim() : ""; // added by dreampanda 20230512
  console.log(keyword);
  var query = fans.find();
  var offset = page == "1" ? 0 : parseInt(page - 1) * 10;
  try {
    query = query.where("star_id", req.query.star_id);
    // added by dreampandan 20230512 am 11.13 from
    var match = {};
    if (keyword != "") {
      match = {
        $or: [
          { first_name: { $regex: new RegExp(keyword, "ig") } },
          { last_name: { $regex: new RegExp(keyword, "ig") } },
          { username: { $regex: new RegExp(keyword, "ig") } },
          { email: { $regex: new RegExp(keyword, "ig") } },
        ],
      };
    }

    console.log("listfan");
    // get users who is fan
    let start_date = new Date(new Date().setMonth(new Date().getMonth() - 1));
    let f_subscription_level = await subscriptionlevels?.findOne({
      user_id: star_id,
      level: "basic",
    });
    let f_joined_users = [];
    if (f_subscription_level) {
      f_joined_users = (
        await subscribers.find({
          subscription_id: f_subscription_level._id,
          unsubscribed: false,
          start_date: { $gte: start_date },
        })
      ).map((d) => d.user_id);
    }
    console.log(f_joined_users);
    // get users who is super fan
    let s_subscription_level = await subscriptionlevels?.findOne({
      user_id: star_id,
      level: "super",
    });
    let s_joined_users = [];
    if (s_subscription_level) {
      s_joined_users = (
        await subscribers.find({
          subscription_id: s_subscription_level._id,
          unsubscribed: false,
          start_date: { $gte: start_date },
        })
      ).map((d) => d.user_id);
    }
    console.log(s_joined_users);
    query = query.find({
      $or: [
        { user_id: { $in: f_joined_users } },
        { user_id: { $in: s_joined_users } },
      ],
    });

    // added by dreampandan 20230512 am 11.13 to
    // if(type == 'fan') {
    //     let subscription_level = await subscriptionlevels.findOne({user_id: star_id, level: 'basic'});
    //     if(subscription_level) {
    //         var joined_subscribed = await subscribers.find({ subscription_id: subscription_level._id, unsubscribed: false });
    //         console.log(joined_subscribed);
    //         var joined_user_ids = joined_subscribed.map(d => d.user_id);
    //         console.log(joined_user_ids);
    //         query = query.find({ user_id: { $in: joined_user_ids } });
    //     } else {
    //         res.json({
    //             status: false,
    //             message: "Subscription level is not set yet."
    //         });
    //         return;
    //     }
    // } else {
    //     let subscription_level = await subscriptionlevels.findOne({user_id: star_id, level: 'super'});
    //     if(subscription_level) {
    //         var joined_subscribed = await subscribers.find({ subscription_id: subscription_level.id, unsubscribed: false });
    //         console.log(joined_subscribed);
    //         var joined_user_ids = joined_subscribed.map(d => d.user_id);
    //         console.log(joined_user_ids);
    //         query = query.find({ user_id: { $in: joined_user_ids } });
    //     } else {
    //         res.json({
    //             status: false,
    //             message: "Subscription super level is not set yet."
    //         });
    //         return;
    //     }
    // }
    query = query.sort("-created_date");
    var options = { page, offset, limit };
    query = query.populate({
      path: "user_id",
      match: match,
      model: users,
      select:
        "username email profile_image first_name last_name profile_cover status create_date bio is_idverified",
    });
    fans.paginate(query, options).then(async function (result) {
      const updatedDocsPromises = result.docs.map(async (d) => {
        let fanlvl = "fan";
        if (
          f_joined_users.some((fu) => fu == d._doc?.user_id?._id.toString())
        ) {
          fanlvl = "fan";
        } else if (
          s_joined_users.some((su) => su == d._doc?.user_id?._id.toString())
        ) {
          fanlvl = "super";
        }

        // check is follower or not
        var follower = await followers.findOne({
          star_id: d._doc?.user_id?._id,
          user_id: star_id,
        });

        return {
          ...d._doc,
          fanlvl,
          isFollower: follower ? true : false,
        };
      });

      const updatedDocs = await Promise.all(updatedDocsPromises);

      const updatedResult = { ...result, docs: updatedDocs };

      res.json({
        status: true,
        message: "Fans retrieved successfully",
        data: updatedResult,
      });
    });
  } catch (error) {
    console.log(error);
    res.json({
      status: false,
      message: "Something went wrong",
    });
  }
};

/*
 * This is the function which used to list staruser in database
 */
exports.actionFollower = async function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded.user_id,
    star_id = req.body.star_id;
  let me = await users.findById(user_id);
  users.findOne(
    { _id: req.body.star_id, status: "active" },
    function (err, staruser) {
      if (err || !staruser) {
        res.json({
          status: false,
          message: "Star User not found",
          errors: err,
        });
        return;
      }
      followers.findOne(
        { star_id: req.body.star_id, user_id: req.body.user_id },
        async function (err, follower) {
          if (req.body.type == "increase") {
            if (!follower) {
              staruser.followers_count = staruser.followers_count + 1;
              var newfollower = new followers();
              newfollower.user_id = req.body.user_id;
              newfollower.star_id = req.body.star_id;

              const followings_count = me.followings_count + 1;

              try {
                await newfollower.save();
                await staruser.save();
                await users.findByIdAndUpdate(user_id, { followings_count })

                // create noitification
                // check if star set up his notification setting
                let user = await users.findById(star_id);
                let notif_users = [];
                if (user?.notif_followers?.is_new) {
                  notif_users.push(star_id)
                  let notification = await notificationModel.findOne({
                    type: NOTIFICATION_TYPES.NEW_FOLLOW,
                    filter: NOTIFICATION_FILTERS.NEW_FOLLOW,
                    from_id: user_id,
                    to_id: star_id,
                  });
                  if (notification) {
                    notification.create_date = new Date();
                    await notification.save();
                  } else {
                    let new_notification = new notificationModel({
                      type: NOTIFICATION_TYPES.NEW_FOLLOW,
                      filter: NOTIFICATION_FILTERS.NEW_FOLLOW,
                      message: `Started following you`,
                      from_id: user_id,
                      to_id: star_id,
                    });
                    await new_notification.save();
                  }
                }

                // auto follow you
                if (user?.notif_followers?.is_new_backs) {
                  // check if you are follower or not
                  let follower = await followers.findOne({ star_id: user_id, user_id: star_id });
                  if (!follower) {
                    let new_follower = new followers({
                      star_id: user_id,
                      user_id: star_id
                    });
                    await new_follower.save();

                    //!!20231227pm06 coderB To add star_id into following list when automic unblocking
                    // /* Addtion of Inserting Start */
                    // await user.updateOne({ _id: user_id }, { $push: { following: star_id } })
                    // /* Addition of removing End */

                    let user = await users.findById(user_id);
                    if (user?.notif_followers?.is_new) {
                      let notification = await notificationModel.findOne({
                        type: NOTIFICATION_TYPES.NEW_FOLLOW,
                        filter: NOTIFICATION_FILTERS.NEW_FOLLOW,
                        from_id: star_id,
                        to_id: user_id,
                      });
                      if (notification) {
                        notification.create_date = new Date();
                        await notification.save();
                      } else {
                        let new_notification = new notificationModel({
                          type: NOTIFICATION_TYPES.NEW_FOLLOW,
                          filter: NOTIFICATION_FILTERS.NEW_FOLLOW,
                          message: `Started following you`,
                          from_id: star_id,
                          to_id: user_id,
                        });
                        await new_notification.save();
                      }
                    }
                    notif_users.push(user_id)
                  }
                }

                //!!20231225pm01 coderB Modify to handle the following data more easily
                /* Addition of Inserting start */
                await users.updateOne({ _id: user_id}, { $push: { following: star_id} })
                /*Addition of Inserting End */
                res.json({
                  status: true,
                  message: "Follow this user successfully",
                  result: {
                    notif_users
                  },
                })

              } catch (error) {
                console.log(error);
                res.json({
                  status: false,
                  message: "Something went wrong"
                })
              }

            } else {
              res.json({
                status: true,
                message: "Favoruite added successfully",
              });
            }
          } else {
            if (!follower) {
              res.json({
                status: true,
                message: "Favoruite removed successfully.",
              });
            } else {
              staruser.followers_count = staruser.followers_count - 1;
              const followings_count = me.followings_count - 1;

              try {
                await followers.findByIdAndDelete(follower._id);
                await staruser.save();
                await users.findByIdAndUpdate(user_id, { followings_count });

                // hande automatic unfollow
                let user = await users.findById(star_id);
                if (user && user.notif_followers?.is_unfollow && !user.notif_followers?.unfollow_safe_list.some(d => d == user_id)) {
                  // check if star follows user
                  let follower = await followers.findOne({ star_id: user_id, user_id: star_id });
                  if (follower) {
                    await followers.findOneAndDelete({ star_id: user_id, user_id: star_id });

                    //!!20231227pm05 coderB To remove user from following list if he has already followed when blocking
                    /* Addition of Removing Start */
                    await users.update({ _id: user_id }, { $pull: { following: star_id} })
                    /* Addition of Removing End */

                    // manage follower count , followings count
                    const star_user_followings_count = staruser.followings_count - 1
                    staruser.followings_count = star_user_followings_count;

                    const me_followers_count = me.followers_count - 1;

                    await staruser.save();
                    await users.findByIdAndUpdate(user_id, { followers_count: me_followers_count })
                  }
                }
                /* Addition of Removing Start */
                await users.updateOne({ _id: user_id }, { $pull: {following: star_id} } )
                /* Addition of Removing End */
                res.json({
                  status: true,
                  message: "Unfollow this user successfully",
                });
              } catch (error) {
                console.log(error);
                res.json({
                  status: false,
                  message: "Something went wrong"
                });
              }

            }
          }
        }
      );
    }
  );
};

/*
 * This is the function which used to list user who add the staruser as follower staruser
 */
exports.listFollower = function (req, res) {
  console.log(getErrLine().str, "apistart");
  var page = req.query.page ? req.query.page : "1";
  var limit = req.query.limit ? req.query.limit : "15";
  var keyword = req.query.keyword ? req.query.keyword.trim() : ""; // added by dreampanda 20230512
  var query = followers.find();
  var offset = page == "1" ? 0 : parseInt(page - 1) * 10;
  query = query.where("star_id", req.query.star_id);
  var match = {};
  if (keyword != "") {
    match = {
      $or: [
        { first_name: { $regex: new RegExp(keyword, "ig") } },
        { last_name: { $regex: new RegExp(keyword, "ig") } },
        { username: { $regex: new RegExp(keyword, "ig") } },
        { email: { $regex: new RegExp(keyword, "ig") } },
      ],
    };
  }
  query = query.populate({
    path: "user_id",
    match: match,
    model: users,
    select:
      "username email profile_image first_name last_name profile_cover status create_date bio is_idverified",
  });
  query = query.sort("-created_date");
  var options = { page, offset, limit };
  followers.paginate(query, options).then(async function (result) {
    const updatedDocsPromises = result.docs.map(async (d) => {
      // check is follower or not
      var follower = await followers.findOne({
        star_id: d._doc?.user_id?._id,
        user_id: req.query.star_id,
      });

      return {
        ...d._doc,
        isFollower: follower ? true : false,
      };
    });

    const updatedDocs = await Promise.all(updatedDocsPromises);

    const updatedResult = { ...result, docs: updatedDocs };

    res.json({
      status: true,
      message: "Followers retrieved successfully",
      data: updatedResult,
    });
  });
};

/*
 * This is the function which used to list user who add the staruser as follower staruser
 */
exports.listFollowing = function (req, res) {
  console.log(getErrLine().str, "apistart");
  var page = req.query.page ? req.query.page : "1";
  var limit = req.query.limit ? req.query.limit : "15";
  var keyword = req.query.keyword ? req.query.keyword.trim() : ""; // added by dreampanda 20230512
  var query = followers.find();
  var offset = page == "1" ? 0 : parseInt(page - 1) * 10;
  query = query.where("user_id", req.query.star_id);
  query = query.sort("-created_date");
  var match = {};
  if (keyword != "") {
    match = {
      $or: [
        { first_name: { $regex: new RegExp(keyword, "ig") } },
        { last_name: { $regex: new RegExp(keyword, "ig") } },
        { username: { $regex: new RegExp(keyword, "ig") } },
        { email: { $regex: new RegExp(keyword, "ig") } },
      ],
    };
  }
  query = query.populate({
    path: "star_id",
    match: match,
    model: users,
    select: "_id first_name last_name username profile_image ",
  });
  var options = { page, offset, limit };
  followers.paginate(query, options).then(async function (result) {
    const updatedDocsPromises = result.docs.map(async (d) => {
      // check is follower or not
      var follower = await followers.findOne({
        user_id: d._doc?.user_id?._id,
        star_id: req.query.star_id,
      });

      return {
        ...d._doc,
        isFollower: follower ? true : false,
      };
    });

    const updatedDocs = await Promise.all(updatedDocsPromises);

    const updatedResult = { ...result, docs: updatedDocs };

    res.json({
      status: true,
      message: "Following retrieved successfully",
      data: updatedResult,
    });
    // res.json({
    //     status: true,
    //     message: "Followers retrieved successfully",
    //     data: result
    // });
  });
};

/*
 * This is the function which used to list staruser in database
 */
exports.actionMember = function (req, res) {
  console.log(getErrLine().str, "apistart");
  users.findOne(
    { _id: req.body.star_id, status: "active" },
    function (err, staruser) {
      if (err || !staruser) {
        res.json({
          status: false,
          message: "User not found",
          errors: err,
        });
        return;
      }
      members.findOne(
        { star_id: req.body.star_id, user_id: req.body.user_id },
        function (err, member) {
          if (req.body.type == "add") {
            if (!member) {
              staruser.members_count = staruser.members_count + 1;
              var newmember = new members();
              newmember.user_id = req.body.user_id;
              newmember.star_id = req.body.star_id;
              newmember.save(function (err, result) {
                staruser.save(function (err, result) {
                  res.json({
                    status: true,
                    message: "Member added successfully",
                  });
                });
              });
            } else {
              res.json({
                status: true,
                message: "Member added successfully",
              });
            }
          } else {
            if (!member) {
              res.json({
                status: true,
                message: "Member removed successfully.",
              });
            } else {
              staruser.members_count = staruser.members_count - 1;
              members.deleteOne({ _id: member._id }, function (err) {
                staruser.save(function (err, result) {
                  res.json({
                    status: true,
                    message: "Member removed successfully!",
                  });
                });
              });
            }
          }
        }
      );
    }
  );
};

/*
 * This is the function which used to list user who add the staruser as member staruser
 */
exports.listMember = function (req, res) {
  console.log(getErrLine().str, "apistart");
  var page = req.query.page ? req.query.page : "1";
  var limit = req.query.limit ? req.query.limit : "15";
  var query = members.find();
  var offset = page == "1" ? 0 : parseInt(page - 1) * 10;
  query = query.where("star_id", req.query.star_id);
  query = query.populate({
    path: "user_id",
    model: users,
    select: "_id first_name last_name username profile_image ",
  });
  query = query.sort("-created_date");
  var options = {
    page: page,
    offset: offset,
    limit: limit,
  };
  members.paginate(query, options).then(function (result) {
    res.json({
      status: true,
      message: "Members retrieved successfully",
      data: result,
    });
  });
};

// added by dreampanda 20235013 pm 5 start
exports.addMember = function (req, res) {
  console.log(getErrLine().str, "apistart");
  var member = new members(req.body);
  member.star_id = req.decoded.user_id;
  users.findOne({ _id: req.decoded.user_id }, function (err, user) {
    if (err || !user) {
      res.json({
        status: false,
        message: "db error",
        error: err,
      });
    } else {
      if (user.status != "active") {
        res.json({
          status: false,
          message: "you are inactive",
        });
      } else {
        members.findOne(
          { star_id: req.decoded.user_id, user_id: req.body.user_id },
          function (err, result) {
            if (err) {
              res.json({
                status: false,
                message: "db error",
                error: err,
              });
            } else {
              if (result) {
                res.json({
                  status: false,
                  message: "already added",
                });
              } else {
                member.save(function (err, result) {
                  if (err) {
                    res.json({
                      status: false,
                      message: "db error",
                      error: err,
                    });
                  } else {
                    res.json({
                      status: true,
                      message: "added successfully",
                      data: result,
                    });
                  }
                });
              }
            }
          }
        );
      }
    }
  });
};

exports.editMember = function (req, res) {
  console.log(getErrLine().str, "apistart");
  members.findOneAndUpdate(
    { _id: req.body._id },
    req.body,
    function (err, result) {
      if (err) {
        res.json({
          status: false,
          message: "Error was occured",
          errors: err,
        });
      } else {
        res.json({
          status: true,
          message: "Updated successfully.",
          errors: err,
        });
      }
    }
  );
};

exports.removeMember = function (req, res) {
  console.log(getErrLine().str, "apistart");
  members.findOneAndDelete({ _id: req.body._id }, function (err, result) {
    if (err) {
      res.json({
        status: false,
        message: "Error was occured",
        errors: err,
      });
    } else {
      res.json({
        status: true,
        message: "Deleted successfully.",
        errors: err,
      });
    }
  });
};

// added by dreampanda 20235013 pm 5 end

/*
 * This is the function which used to list staruser in database
 */
exports.actionCreator = function (req, res) {
  console.log(getErrLine().str, "apistart");
  users.findOne(
    { _id: req.body.user_id, status: "active" },
    function (err, staruser) {
      if (err || !staruser) {
        res.json({
          status: false,
          message: "Account Holder not found",
          errors: err,
        });
        return;
      }
      users.findOne(
        { username: req.body.creator_name },
        function (err, creator) {
          if (req.body.type == "add") {
            if (!creator) {
              var newacc = new users();
              newacc.username = req.body.creator_name
                ? req.body.creator_name
                : "";
              newacc.first_name = req.body.first_name
                ? req.body.first_name
                : "";
              newacc.last_name = req.body.last_name ? req.body.last_name : "";

              // copy some info from account holder
              newacc.email = staruser.email;
              newacc.password = staruser.password;
              newacc.dob = staruser.dob;
              newacc.phone = staruser.phone;
              newacc.metamask_info = staruser.metamask_info;
              newacc.role = staruser.role;
              newacc.device_info = staruser.device_info;
              newacc.status = "active";

              newacc.profile_image = req.body.profile_image
                ? req.body.profile_image
                : "";
              newacc.profile_cover = req.body.profile_cover
                ? req.body.profile_cover
                : "";
              newacc.is_type_author = req.body.is_type_author
                ? req.body.is_type_author
                : 0;
              newacc.is_type_artist = req.body.is_type_artist
                ? req.body.is_type_artist
                : 0;
              newacc.is_type_comedian = req.body.is_type_comedian
                ? req.body.is_type_comedian
                : 0;
              newacc.is_type_content_creator = req.body.is_type_content_creator
                ? req.body.is_type_content_creator
                : 0;
              newacc.is_type_filmmaker = req.body.is_type_filmmaker
                ? req.body.is_type_filmmaker
                : 0;
              newacc.is_type_musician = req.body.is_type_musician
                ? req.body.is_type_musician
                : 0;
              newacc.is_type_podcaster = req.body.is_type_podcaster
                ? req.body.is_type_podcaster
                : 0;
              newacc.is_type_singer = req.body.is_type_singer
                ? req.body.is_type_singer
                : 0;
              newacc.is_type_band = req.body.is_type_band
                ? req.body.is_type_band
                : 0;
              newacc.is_pros = req.body.is_pros ? req.body.is_pros : 0;
              newacc.save(function (err, result) {
                if (err) {
                  res.json({
                    status: false,
                    message: "Adding Creator is failed.",
                    errors: err,
                  });
                  return;
                }
                staruser.save(function (err, result) {
                  res.json({
                    status: true,
                    message: "Creator added successfully",
                  });
                });
              });
            } else {
              res.json({
                status: true,
                message: "Creator is already existing",
              });
            }
          } else {
            if (!creator) {
              res.json({
                status: true,
                message: "Creator isn't existing.",
              });
            } else {
              users.deleteOne({ _id: creator._id }, function (err) {
                staruser.save(function (err, result) {
                  res.json({
                    status: true,
                    message: "Creator removed successfully!",
                  });
                });
              });
            }
          }
        }
      );
    }
  );
};

/*
 * This is the function which used to list user who add the staruser as creator staruser
 */
exports.listCreator = function (req, res) {
  console.log(getErrLine().str, "apistart");
  var page = req.query.page ? req.query.page : "1";
  var limit = req.query.limit ? req.query.limit : "15";
  var query = users.find();
  var offset = page == "1" ? 0 : parseInt(page - 1) * 10;
  query = query.where("email", req.query.email);
  query = query.populate({
    path: "user_id",
    model: users,
    select: "_id first_name last_name username profile_image ",
  });
  query = query.sort("-created_date");
  var options = {
    page: page,
    offset: offset,
    limit: limit,
  };
  users.paginate(query, options).then(function (result) {
    res.json({
      status: true,
      message: "Creator retrieved successfully",
      data: result,
    });
  });
};

/*
 *   This is the function which used to approve creator profile from admin
 */
exports.approveCreator = function (req, res) {
  console.log(getErrLine().str, "apistart");
  users.findOne(
    { _id: req.body.user_id, status: "active" },
    function (err, staruser) {
      if (err || !staruser) {
        res.json({
          status: false,
          message: "Account not found",
          errors: err,
        });
        return;
      }
      staruser.is_admin_approved = 1;
      staruser.save(function (err, result) {
        res.json({
          status: true,
          message: "Pros approved successfully",
        });
      });
    }
  );
};

/*
 * This is the function which used to add/update/remove Shipping Addresses in database
 */
exports.actionShipAddrs = function (req, res) {
  console.log(getErrLine().str, "apistart");
  if (req.body.type == "add") {
    var addr = new shipaddrs();
    addr.user_id = req.decoded.user_id;
    addr.fullname = req.body.fullname;
    addr.street = req.body.street;
    addr.city = req.body.city;
    addr.state = req.body.state;
    addr.zipcode = req.body.zipcode;
    addr.country = req.body.country;
    addr.save(function (err, obj) {
      if (err) {
        res.json({
          status: false,
          message: "Request failed",
          errors: err,
        });
        return;
      }
      res.json({
        status: true,
        message: "Ship address added successfully",
        result: obj,
      });
    });
  } else {
    shipaddrs.findOne({ _id: req.body.shipAddrId }, function (err, addr) {
      if (err || !addr) {
        res.json({
          status: false,
          message: "address not found",
          errors: err,
        });
        return;
      }
      if (req.body.type == "update") {
        addr.fullname = req.body.fullname;
        addr.street = req.body.street;
        addr.city = req.body.city;
        addr.state = req.body.state;
        addr.zipcode = req.body.zipcode;
        addr.country = req.body.country;
        addr.save(function (err, obj) {
          if (err) {
            res.json({
              status: false,
              message: "Request failed",
              errors: err,
            });
            return;
          }
          res.json({
            status: true,
            message: "Ship address updated successfully",
            result: obj,
          });
        });
      } else if (req.body.type == "delete") {
        shipaddrs.deleteOne({ _id: req.body.shipAddrId }, function (err) {
          if (err) {
            res.json({
              status: false,
              message: "Delete Address Request failed",
              errors: err,
            });
            return;
          }
          res.json({
            status: true,
            message: "Address removed successfully!",
            error: err,
          });
        });
      }
    });
  }
};

/*
 * This is the function which used to list ship address
 */
exports.listShipAddrs = async function (req, res) {
  console.log(getErrLine().str, "apistart");
  var page = req.query.page ? req.query.page : "1";
  var limit = req.query.limit ? req.query.limit : "200";
  var query = shipaddrs.find();
  var offset = page == "1" ? 0 : parseInt(page - 1) * 200;

  var user = await users.findById(req.query.user_id);
  if (user) {
    query = query.where("user_id", req.query.user_id);
    query = query.sort("-created_date");
    var options = {
      page: page,
      offset: offset,
      limit: limit,
    };
    console.log(user.default_address);
    shipaddrs.paginate(query, options).then(async function (result) {
      const updatedDocs = await Promise.all(
        result.docs.map((d) => {
          return {
            ...d._doc,
            active: d._id.toString() == user.default_address ? 1 : 0,
          };
        })
      );
      updatedDocs.sort((a, b) => b.active - a.active);
      const updatedResult = { ...result, docs: updatedDocs };
      res.json({
        status: true,
        message: "Ship Addresses retrieved successfully",
        data: updatedResult,
      });
    });
  } else {
    res.json({
      status: false,
      message: "unknown user",
    });
  }
};

exports.set_default_ship_addr = async function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded.user_id;
  try {
    var user = await users.findById(user_id);
    user.default_address = req.body._id;
    await user.save();
    res.json({
      status: true,
      message: "Set successfully",
    });
  } catch (error) {
    console.log(error);
    res.json({
      status: false,
      message: "Something went wrong",
    });
  }
};

// added by dream panda in 2023. 5. 8
// to get all info of profile
exports.getProfileData = function (req, res) {
  console.log(getErrLine().str, "apistart");
  var id = req.body.id;
  var select = {
    select: "",
  };
  var followingAccounts = {
    path: "is_following_accounts",
  };
  var selectedAccounts = {
    path: "is_selected_accounts",
  };
  if (id) {
    users
      .findOne({ _id: id })
      .populate({
        path: "notif_posts",
        populate: followingAccounts,
        select:
          "username email profile_image first_name last_name profile_cover status create_date bio is_idverified privacy_safety safe_list",
      })
      .populate({
        path: "notif_posts",
        populate: selectedAccounts,
        select:
          "username email profile_image first_name last_name profile_cover status create_date bio is_idverified privacy_safety safe_list",
      })
      .populate({
        path: "notif_playlists",
        populate: followingAccounts,
        select:
          "username email profile_image first_name last_name profile_cover status create_date bio is_idverified privacy_safety safe_list",
      })
      .populate({
        path: "notif_playlists",
        populate: selectedAccounts,
        select:
          "username email profile_image first_name last_name profile_cover status create_date bio is_idverified privacy_safety safe_list",
      })
      .populate({
        path: "notif_live_now",
        populate: followingAccounts,
        select:
          "username email profile_image first_name last_name profile_cover status create_date bio is_idverified privacy_safety safe_list",
      })
      .populate({
        path: "notif_live_now",
        populate: selectedAccounts,
        select:
          "username email profile_image first_name last_name profile_cover status create_date bio is_idverified privacy_safety safe_list",
      })
      .populate({
        path: "notif_vibes",
        populate: followingAccounts,
        select:
          "username email profile_image first_name last_name profile_cover status create_date bio is_idverified privacy_safety safe_list",
      })
      .populate({
        path: "notif_vibes",
        populate: selectedAccounts,
        select:
          "username email profile_image first_name last_name profile_cover status create_date bio is_idverified privacy_safety safe_list",
      })
      .populate({
        path: "notif_music",
        populate: followingAccounts,
        select:
          "username email profile_image first_name last_name profile_cover status create_date bio is_idverified privacy_safety safe_list",
      })
      .populate({
        path: "notif_music",
        populate: selectedAccounts,
        select:
          "username email profile_image first_name last_name profile_cover status create_date bio is_idverified privacy_safety safe_list",
      })
      .populate({
        path: "notif_podcasts",
        populate: followingAccounts,
        select:
          "username email profile_image first_name last_name profile_cover status create_date bio is_idverified privacy_safety safe_list",
      })
      .populate({
        path: "notif_podcasts",
        populate: selectedAccounts,
        select:
          "username email profile_image first_name last_name profile_cover status create_date bio is_idverified privacy_safety safe_list",
      })
      .populate({
        path: "notif_standUpComedy",
        populate: followingAccounts,
        select:
          "username email profile_image first_name last_name profile_cover status create_date bio is_idverified privacy_safety safe_list",
      })
      .populate({
        path: "notif_standUpComedy",
        populate: selectedAccounts,
        select:
          "username email profile_image first_name last_name profile_cover status create_date bio is_idverified privacy_safety safe_list",
      })
      .populate({
        path: "notif_audioBooks",
        populate: followingAccounts,
        select:
          "username email profile_image first_name last_name profile_cover status create_date bio is_idverified privacy_safety safe_list",
      })
      .populate({
        path: "notif_audioBooks",
        populate: selectedAccounts,
        select:
          "username email profile_image first_name last_name profile_cover status create_date bio is_idverified privacy_safety safe_list",
      })
      .populate({
        path: "notif_movies",
        populate: followingAccounts,
        select:
          "username email profile_image first_name last_name profile_cover status create_date bio is_idverified privacy_safety safe_list",
      })
      .populate({
        path: "notif_movies",
        populate: selectedAccounts,
        select:
          "username email profile_image first_name last_name profile_cover status create_date bio is_idverified privacy_safety safe_list",
      })
      .populate({
        path: "notif_tv_series",
        populate: followingAccounts,
        select:
          "username email profile_image first_name last_name profile_cover status create_date bio is_idverified privacy_safety safe_list",
      })
      .populate({
        path: "notif_tv_series",
        populate: selectedAccounts,
        select:
          "username email profile_image first_name last_name profile_cover status create_date bio is_idverified privacy_safety safe_list",
      })
      .populate({
        path: "notif_users",
        select:
          "username email profile_image first_name last_name profile_cover status create_date bio is_idverified privacy_safety safe_list",
      })
      .populate({
        path: "unfollow_safe_list",
        select:
          "username email profile_image first_name last_name profile_cover status create_date bio is_idverified privacy_safety safe_list",
      })
      .exec(function (err, result) {
        if (err) {
          res.json({
            status: false,
            message: "error was occured",
          });
        } else {
          res.json({
            status: true,
            message: "get user data successfully",
            result: result,
          });
        }
      });
  } else {
    res.json({
      status: false,
      message: "empty request data",
    });
  }
};
// to update all info
exports.profileUpdate = function (req, res) {
  console.log(getErrLine().str, "apistart");
  var updatedUser = req.body;
  if (updatedUser && req.decoded.user_id) {
    users.findOne({ _id: req.decoded.user_id }, function (err, result) {
      if (err) {
        res.json({
          status: false,
          message: "find error",
        });
      } else {
        if (result) {
          if (result.status == "inactive") {
            res.json({
              status: false,
              message: "It is inactive",
            });
          } else if (result.status == "blocked") {
            res.json({
              status: false,
              message: "It was blocked",
            });
          } else {
            result.update(updatedUser, function (err, result2) {
              if (err) {
                res.json({
                  status: false,
                  message: "not updated successfully.",
                });
              } else {
                res.json({
                  status: true,
                  message: "updated successfully.",
                });
              }
            });
          }
        } else {
          res.json({
            status: false,
            message: "unknown user",
          });
        }
      }
    });
  } else {
    res.json({
      status: false,
      message: "empty data",
    });
  }
};

// added by dreampanda 20230516 am 3
exports.get_info_for_user = async function (req, res) {
  var user_id = req.query.user_id || req.decoded?.user_id;
  var fan_id = req.query.fan_id;
  // console.log(getErrLine().str, "apistart",fan_id, user_id);//!!20231230 CoderA too many log// disable temporarely
  var query = { star_id: fan_id, user_id: user_id };
  if (user_id && fan_id) {
    try {
      var result = await fans.findOne(query);
      var result1 = await followers.findOne(query);
      var result12 = await followers.findOne({
        star_id: user_id,
        user_id: fan_id,
      });
      var result2 = await members.findOne(query);

      // get block status
      var _block = await blockModel.findOne({ user_id, block_user_id: fan_id });
      var _blocked = await blockModel.findOne({
        user_id: fan_id,
        block_user_id: user_id,
      });

      var _mute = await muteModel.findOne({ user_id, mute_user_id: fan_id });
      var _muted = await muteModel.findOne({
        user_id: fan_id,
        mute_user_id: user_id,
      });

      // get mute status

      let _subscribers;
      if (result) {
        var date = new Date(new Date().setMonth(new Date().getMonth() - 1));
        _subscribers = await subscribers
          .findOne({
            user_id: user_id,
            unsubscribed: false,
            start_date: { $gte: date },
          })
          .sort({ created_date: -1 })
          .limit(1)
          .populate({
            path: "subscription_id",
            match: {
              user_id: fan_id,
            },
          });
        // console.log(_subscribers);//!!20231231 CoderA Speed
      }
      var data = {};
      data.isFan = result && _subscribers ? true : false;
      data.subscribe = _subscribers || null;
      data.isFollower = result1 ? true : false;
      data.isFollowing = result12 ? true : false;
      data.isMember = result2 ? true : false;
      data.isBlock = _block ? true : false;
      data.isBlocked = _blocked ? true : false;
      data.isMute = _mute ? true : false;
      data.isMuted = _muted ? true : false;

      res.json({
        status: true,
        result: data,
      });
    } catch (error) {
      console.log(error);
      res.json({
        status: false,
        message: error?.message,
        result: false,
      });
    }

    // fans.findOne(query, function(err, result) {
    //     followers.findOne(query, function(err1, result1) {
    //         members.findOne(query, async function(err2, result2) {
    //             if(err || err1 || err2) {
    //                 res.json({
    //                     status: false,
    //                     message: "Error was occured"
    //                 });
    //                 return;
    //             }
    //             let _subscribers;
    //             if(result) {
    //                 var date = new Date(new Date().setMonth(new Date().getMonth() - 1))
    //                 _subscribers = await subscribers.findOne({
    //                     user_id: user_id,
    //                     unsubscribed: false,
    //                     start_date: { $gte: date }
    //                 })
    //                 .populate({
    //                     path: 'subscription_id',
    //                     match: {
    //                         user_id: fan_id
    //                     }
    //                 })
    //                 console.log(_subscribers)
    //             }
    //             var data = {  };
    //             data.isFan = (result && _subscribers) ? true : false;
    //             data.subscribe = _subscribers || null;
    //             data.isFollower = result1? true : false;
    //             data.isMember = result2? true : false;
    //             res.json({
    //                 status: true,
    //                 result: data
    //             })
    //         })
    //     })
    // })
  } else {
    res.json({
      status: false,
      message: "Request error",
      result: false,
    });
  }
};

exports.fandoms = function (req, res) {
  console.log(getErrLine().str, "apistart");
  fandoms.find({}, function (err, result) {
    if (err || !result) {
      res.json({
        status: false,
        message: "No found or db error",
      });
    } else {
      res.json({
        status: true,
        message: "retrived successfully",
        data: result,
      });
    }
  });
};

exports.create_fandom = function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded.user_id;
  var newOne = new fandoms(req.body);
  newOne.user_id = user_id;
  fandoms.findOne({ user_id }, function (err, fandom) {
    if (err) {
      res.json({
        status: false,
        message: "Db error",
      });
    } else {
      if (fandom) {
        res.json({
          status: false,
          message: "Already created",
        });
      } else {
        newOne.save(function (err, result) {
          if (err) {
            res.json({
              status: false,
              message: "Db error",
            });
          } else {
            res.json({
              status: true,
              message: "Saved successfully",
            });
          }
        });
      }
    }
  });
};

exports.update_fandom = function (req, res) {
  console.log(getErrLine().str, "apistart");
  fandoms.findByIdAndUpdate(req.body._id, req.body, function (err, result) {
    if (err) {
      res.json({
        status: false,
        message: "Db error",
      });
    } else {
      res.json({
        status: true,
        message: "Updated successfully",
      });
    }
  });
};

exports.delete_fandom = function (req, res) {
  console.log(getErrLine().str, "apistart");
  console.log(req.body);
  fandoms.findByIdAndDelete(req.body._id, function (err, result) {
    if (err) {
      res.json({
        status: false,
        message: "Db error",
      });
    } else {
      res.json({
        status: true,
        message: "Deleted successfully",
      });
    }
  });
};

exports.read_fandom = async function (req, res) {
  console.log(getErrLine().str, "apistart");
  var fandom_id = req.query.fandom_id;
  if (fandom_id) {
    //!!20240114pm11 coderC To get fandom user info, added the below code. "( b ) join fandom pay screen"
    let fandomInfo = await users.findOne({ _id: fandom_id});
    fandoms.findOne({ user_id: fandom_id }, function (err, result) {
      if (err || !result) {
        res.json({
          status: false,
          message: "Db error or not exist fandom",
        });
      } else {
        //!!20240114pm11 coderC To get fandom user info, added the below code. "( b ) join fandom pay screen"
        let fandomData = {
          result: result,
          fandomInfo: fandomInfo
        };
        res.json({
          status: true,
          message: "Retrived successfully",
          result: result,
          fandomInfo: fandomInfo
        });
        // res.json({
        //   status: true,
        //   message: "Retrived successfully",
        //   result: result,
        // });
      }
    });
  } else {
    res.json({
      status: false,
      message: "Something went wrong",
    });
  }
};

exports.read_fandoms = async function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded.user_id;
  try {
    var type = req.query.type,
      rootCat = req.query.rootCat,
      cat1 = req.query.cat1,
      cat2 = req.query.cat2,
      cat3 = req.query.cat3,
      cat4 = req.query.cat4,
      keyword = req.query.keyword || "",
      page = req.query.page || 1,
      limit = req.query.limit || 15,
      filterShow = req.query.filterShow,
      filterFrom = req.query.filterFrom,
      filterTime = req.query.filterTime,
      filterTimeFrom = req.query.filterTimeFrom,
      filterTimeTo = req.query.filterTimeTo;
    var sortkey = req.query.sortkey || "newest";
    var offset = page == "1" ? 0 : parseInt(page - 1) * 15;
    // get fandom who has fansubscription level
    var users_with_subscription = (await subscriptionlevels.find()).map(d => d.user_id)
    var query = fandoms.find({
      user_id: { $in: users_with_subscription },
      status: "published"
    });
    var match = {};
    if (keyword != "") {
      match = {
        $or: [
          { name: { $regex: new RegExp(keyword, "ig") } },
          { description: { $regex: new RegExp(keyword, "ig") } },
        ],
      };
    }
    query = query.find(match);
    if (sortkey == "newest") {
      query = query.sort("-created_date");
    } else {
      query = query.sort("created_date");
    }

    let user = await users.findById(user_id);
    switch (filterFrom) {
      case "Everybody":
        break;
      case "following":
        let _followings = (await followers.find({ user_id })).map(
          (d) => d.star_id
        );
        query = query.find({ user_id: { $in: _followings } });
        break;
      case "muted":
        query = query.find({
          user_id: { $in: user?.muted_block?.muted_accounts },
        });
        break;
      default:
        break;
    }
    switch (filterTime) {
      case "anytime":
        break;
      case "today":
        var date = new Date();
        var startOfToday = new Date(
          date.getFullYear(),
          date.getMonth(),
          date.getDate()
        );
        var endOfToday = new Date(
          startOfToday.getTime() + 24 * 60 * 60 * 1000 - 1
        ); // End of day is one millisecond before start of next day
        query = query.find({
          created_date: { $gte: startOfToday, $lt: endOfToday },
        });
        break;
      case "thisweek":
        query = query.find({
          created_date: {
            $gte: new Date(new Date() - 7 * 24 * 60 * 60 * 1000),
          },
        });
        break;
      case "thismonth":
        var date = new Date();
        var monthStart = new Date(date.getFullYear(), date.getMonth(), 1); // Get first day of current month
        var monthEnd = new Date(date.getFullYear(), date.getMonth() + 1, 0); // Get last day of current month
        query = query.find({
          created_date: { $gte: monthStart, $lte: monthEnd },
        });
        break;
      case "range":
        var startDate = new Date(filterTimeFrom);
        var endDate = new Date(filterTimeTo);
        query = query.find({
          created_date: { $gte: startDate, $lte: endDate },
        });
        break;
      default:
        break;
    }

    var options = {
      page: page,
      offset: offset,
      limit: limit,
    };
    query.populate({
      path: "user_id",
      model: "users",
      select:
        "username email first_name last_name profile_image profile_cover metamask_info password status is_idverified create_date",
    });
    fandoms.paginate(query, options).then(async function (result) {
      const updatedDocs = await Promise.all(
        result.docs.map(async (d) => {
          // console.log(playLists.some(pl => pl.item_id == d._doc._id && pl.user_id == user_id))
          let n_posts = await fanposts.count({
            creator_id: d._doc?.user_id?._id,
          });
          // let n_fans = await fans.count({ star_id: d._doc?.user_id?._id })

          var date = new Date(new Date().setMonth(new Date().getMonth() - 1));

          var my_subscribers = await subscribers
            .find({ user_id, start_date: { $gte: date }, unsubscribed: false })
            .populate({ path: "subscription_id" });
          console.log(my_subscribers);
          var your_fans = my_subscribers
            .filter((d) => d.subscription_id?.level == "basic")
            .map((d) => {
              d.subscription_id?.user_id;
            });
          var your_superfans = my_subscribers
            .filter((d) => d.subscription_id?.level == "super")
            .map((d) => {
              d.subscription_id?.user_id;
            });

          let n_pictures = await fanposts.count({
            creator_id: d._doc?.user_id?._id,
            $or: [
              { fanpost_image: { $exists: true, $ne: "" } },
              { fanpost_images: { $exists: true, $not: { $size: 0 } } },
            ],
          });

          let n_videos = await fanposts.count({
            creator_id: d._doc?.user_id?._id,
            $and: [
              { fanpost_video: { $ne: "" } },
              { fanpost_video: { $ne: null } },
            ],
          });

          //20231224pm10CoderD {count fans only posts}
          let n_fansonlyposts = await fanposts.count({
            creator_id: d._doc?.user_id?._id,
            $and: [
              {is_view_only: "fans"},
            ],
          });

          //20231224pm10CoderD {count superfans only posts}
          let n_superfansonlyposts = await fanposts.count({
            creator_id: d._doc?.user_id?._id,
            $and: [
              {is_view_only: "superfans"},
            ],
          });

          // check is follower, mute, block
          var _db_follower = await followers.findOne({
            star_id: d._doc?.user_id?._id,
            user_id: user_id,
          });
          var _db_block = await blockModel.findOne({
            block_user_id: d._doc?.user_id?._id,
            user_id: user_id,
          });
          var _db_mute = await muteModel.findOne({
            mute_user_id: d._doc?.user_id?._id,
            user_id: user_id,
          });

          return {
            ...d._doc, // copy all the existing fields
            n_posts: n_posts,
            n_pictures,
            n_videos,
            ///20231224pm10CoderD {count fans or superfans only posts} underline 2
            n_fansonlyposts, 
            n_superfansonlyposts,

            n_fans: (your_fans?.length || 0) + (your_superfans?.length || 0),
            isFollow: _db_follower ? true : false,
            isBlock: _db_block ? true : false,
            isMute: _db_mute ? true : false,
          };
        })
      );
      const updatedResult = { ...result, docs: updatedDocs };
      res.json({
        status: true,
        message: "subscribers retrieved successfully",
        data: updatedResult,
      });
    });
  } catch (e) {
    console.log(e);
    res.json({
      status: false,
      message: "something went wrong",
    });
  }
};

exports.create_subscription_level = function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded.user_id;
  var newOne = subscriptionlevels(req.body);
  newOne.user_id = user_id;
  subscriptionlevels.findOne(
    { name: newOne.name, level: newOne.level, user_id: user_id },
    function (err, result) {
      if (err) {
        res.json({
          status: false,
          message: "Db error",
        });
      } else {
        if (result) {
          res.json({
            status: false,
            message:
              "Another that has the equal name and monthly price is existed.",
          });
        } else {
          newOne.save(function (err, saved) {
            res.json({
              status: true,
              message: "Saved successfully",
            });
          });
        }
      }
    }
  );
};

exports.read_subscription_level = function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.query.user_id;
  if (user_id) {
    subscriptionlevels.find({ user_id }, function (err, result) {
      if (err) {
        res.json({
          status: false,
          message: "Db error",
        });
      } else {
        console.log(result)
        /* 20240112pm8 coderd added below code {selling > famdoms - total earned is not works} */ 
        let _ids = [];
        result?.map(item=>{
          _ids.push(item._id);
        });
        subscribers.find({subscription_id:{$in:_ids}},function(err,data){
          if(err){
            throw err;
          } else {
        res.json({
              status:true,
              message:"Retrived",
              result:result,
              payment_data:data
            });
          };
        }).populate({
          path: "subscription_id",
          model: "subscription_levels"
        });
        // res.json({
        //   status: true,
        //   message: "Retrived successfully",
        //   result: result,
        // });
      }
    });
  } else {
    res.json({
      status: false,
      message: "Something went wrong",
    });
  }
};

exports.read_subscriptions = async function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded.user_id;
  var page = req.query.page || 1;
  var keyword = req.query.keyword || "";
  var limit = req.query.limit || 15;
  var sortkey = req.query.sortkey || "newest";
  var offset = page == "1" ? 0 : parseInt(page - 1) * 15;

  var query = subscribers.find({ user_id });
  // var query = subscribers.find({ user_id });
  if (sortkey == "newest") {
    query = query.sort("-created_date");
  } else {
    query = query.sort("created_date");
  }


  let _subscriptions = [];
  if (keyword != "") {
    _subscriptions = await subscriptionlevels.find({
      user_id: user_id,
      $or: [
        { name: { $regex: new RegExp(keyword, "ig") } },
        { description: { $regex: new RegExp(keyword, "ig") } },
      ]
    });
    _subscriptions = _subscriptions.map((d) => d._id.toString());
  }

  var s_query = {};
  if (_subscriptions.length > 0) {
    s_query = {
      subscription_id: {
        $in: _subscriptions,
        $ne: null
      }
    };
  } else {
    s_query = {
      subscription_id: { $ne: null },
    };
  }

  query = query.find(s_query).populate({
    path: "subscription_id",
    model: "subscription_levels",
    populate: {
      path: "user_id",
      model: "users",
      select:
        "username email first_name last_name profile_image profile_cover metamask_info password status is_idverified create_date",
    },
  });

  var options = {
    page: page,
    offset: offset,
    limit: 1000,
  };

  subscribers.paginate(query, options).then(function (result) {
    res.json({
      status: true,
      message: "subscribers retrieved successfully",
      data: result,
    });
  });
};

exports.read_subscription_level_for_join = async function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded.user_id;
  var fandom_id = req.query.user_id;
  try {
    let _subscribers = await subscribers.find({
      user_id: user_id,
      unsubscribed: false,
    });
    if (fandom_id) {
      subscriptionlevels.find({ user_id: fandom_id }, function (err, result) {
        if (err) {
          res.json({
            status: false,
            message: "Db error",
          });
        } else {
          const updatedDocs = result.map((d) => {
            return {
              ...d.toObject(), // copy all the existing fields
              joined: _subscribers.some(
                (s) => s.subscription_id == d._id.toString()
              ),
            };
          });
          res.json({
            status: true,
            message: "Retrived successfully",
            result: updatedDocs,
          });
        }
      });
    } else {
      res.json({
        status: false,
        message: "Something went wrong",
      });
    }
  } catch (e) {
    console.log(e);
    res.json({
      status: false,
      message: "Something went wrong",
    });
  }
};

exports.update_subscription_level = function (req, res) {
  console.log(getErrLine().str, "apistart");
  subscriptionlevels.findByIdAndUpdate(
    req.body._id,
    req.body,
    function (err, saved) {
      if (err) {
        res.json({
          status: false,
          message: "Db error",
        });
      } else {
        res.json({
          status: true,
          message: "Updated successfully",
        });
      }
    }
  );
};

exports.delete_subscription_level = async function (req, res) {
  console.log(getErrLine().str, "apistart");
  try {
    let subscribes_with_level = await subscribers.find({
      subscription_id: req.body._id
    });
    if (subscribes_with_level.length > 0) {
      res.json({
        status: false,
        message: "You can't delete this subscription"
      });
    } else {
      subscriptionlevels.findOneAndRemove(req.body._id, function (err, result) {
        if (err) {
          res.json({
            status: false,
            message: "Db error",
          });
        } else {
          res.json({
            status: true,
            message: "Deleted successfully.",
          });
        }
      });
    }
  } catch (error) {
    console.log(error);
    res.json({
      status: false,
      message: "Something went wrong"
    });
  }
};

exports.create_subscriber = async function (req, res) {
  console.log(getErrLine().str, "apistart");
  let user_id = req.decoded.user_id;
  let newOne = new subscribers(req.body);
  let pay_price;
  newOne.user_id = user_id;
  try {
    subscribers.findOne(
      {
        subscription_id: req.body.subscription_id,
        user_id: user_id,
        unsubscribed: false,
      },
      function (err, result) {
        if (err || result) {
          res.json({
            status: false,
            message: "db error or already joined",
          });
        } else {
          subscriptionlevels.findById(
            req.body.subscription_id,
            async function (err, level) {
              if (err || !level) {
                res.json({
                  status: false,
                  message: "db error or not existe level",
                });
              } else {
                //

                let _subscriptions = await subscriptionlevels.find({
                  user_id: req.body.fandom_id,
                });
                _subscriptions = _subscriptions.map((d) => {
                  return d._id;
                });
                console.log(_subscriptions);
                /* !!20240112am1 coderd added below code {( b ) buying > fandoms > subscriptions} */
                // !!20240121am2 coderd changed below code {( b ) buying > fandoms > subscriptions}
                await subscribers.findOne(
                  {
                    $and: [
                      { user_id: user_id },
                      { subscription_id: { $ne: req.body.subscription_id } },
                      { subscription_id: { $in: _subscriptions } },
                      { unsubscribed: false },
                    ],
                  }, async function(err,data){
                    if(err){
                      throw err;
                    } else {
                      console.log(data,"this is unsubscribed datas")
                      if(data && data.length !=0){
                        var distance = new Date(data.end_date).getTime() - new Date(data.start_date).getTime();
                        var d = Math.floor(distance / ( 24 * 60 * 60 * 1000)) % 30;
                        pay_price = level.monthly_price - (data.subscription_id.monthly_price / 30) * ( 30 - d ) ;
                      } else {
                        pay_price = level.monthly_price;
                      };
                      console.log(pay_price,"console.log(pay_price)")
                    }
                  }
                ).populate({
                  path: "subscription_id",
                  model: "subscription_levels"
                });
                await subscribers.findOneAndUpdate(
                  {
                    $and: [
                      { user_id: user_id },
                      { subscription_id: { $ne: req.body.subscription_id } },
                      { subscription_id: { $in: _subscriptions } },
                      { unsubscribed: false },
                    ],
                  },
                  { end_date: new Date(), unsubscribed: true },
                  function (err, result) {
                    if (err) console.log(err);
                    else console.log(result);
                  }
                );
                await fans.findOne(
                  { star_id: req.body.fandom_id, user_id: user_id },
                  async function (err, fan) {
                    if (err) {
                      console.log(err);
                    } else {
                      if (fan) {
                        fan.created_date = new Date();
                        fan.save();
                      } else {
                        var newOne = new fans({
                          star_id: req.body.fandom_id,
                          user_id: user_id,
                        });
                        await users.findById(
                          req.body.fandom_id,
                          function (err, user) {
                            if (err || !user)
                              console.log(err + "or user not existed");
                            else {
                              const fans_count = user.fans_count + 1;
                              user.fans_count = fans_count;
                              user.save();
                            }
                          }
                        );
                        newOne.save();
                      }
                    }
                  }
                );

                //
                const n_joined = level.n_joined + 1;
                level.n_joined = n_joined;

                let fandom_payment = new fandomPaymentModel({
                  user_id,
                  seller_id: level.user_id,
                  level: level.level,
                  subscription_id: level._id,
                  /* !!20240112am2 coderd {( b ) buying > fandoms > subscriptions} */ 
                  price: pay_price?pay_price:level.monthly_price,
                  // price: level.monthly_price,
                });
                await fandom_payment.save();

                level.save(function (err, saved) {
                  if (err) {
                    res.json({
                      status: false,
                      message: "failed to create",
                    });
                  } else {
                    newOne.save(async function (err, saved) {
                      if (err) {
                        res.json({
                          status: false,
                          message: "failed to create",
                        });
                      } else {
                        // CREATE NOTIFICATION TO SUBSCRIBE
                        // CHECK USER NOTIFICATION SETTING IS ENABLED OR NOT
                        let notif_users = [];
                        let user = await users.findOne({ _id: level.user_id, "notif_followers.is_fan_subcribed": true });
                        if (user) {
                          let new_notification = new notificationModel({
                            type: NOTIFICATION_TYPES.FAN_SUBSCRIBE,
                            filter: null,
                            from_id: user_id,
                            to_id: user._id,
                            message: `Become a ${level?.level == 'basic' ? 'fan' : 'superfan'} for $${Number(level.monthly_price).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} a month`,
                          });
                          await new_notification.save();
                          notif_users.push(user._id);
                        }

                        res.json({
                          status: true,
                          message: "saved successfully",
                          result: {
                            notif_users
                          }
                        });
                      }
                    });
                  }
                });
              }
            }
          );
        }
      }
    );
  } catch (e) {
    res.json({
      status: false,
      message: "Something went wrong",
    });
  }
};

exports.unsubscribe = function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded.user_id;
  var subscription_id = req.body.subscription_id;
  subscribers.findOneAndUpdate(
    { subscription_id: subscription_id, user_id: user_id, unsubscribed: false },
    { unsubscribed: true, end_date: new Date() },
    function (err, updated) {
      if (err) {
        res.json({
          status: false,
          message: "db error",
        });
      } else {
        subscriptionlevels.findById(subscription_id, function (err, level) {
          if (err || !level) {
            res.json({
              status: false,
              message: "Db error or not found membership",
            });
          } else {
            const n_joind = level.n_joind - 1;
            level.n_joind = n_joind;
            level.save(function (err, result) {
              if (err) {
                res.json({
                  status: false,
                  message: "Db error or not found membership",
                });
              } else {
                fans.findOneAndDelete(
                  { star_id: req.body.fandom_id, user_id: user_id },
                  function (err, result) {
                    if (err) {
                      res.json({
                        status: false,
                        message: "db error",
                      });
                    } else {
                      users.findById(req.body.fandom_id, function (err, user) {
                        if (err || !user) {
                          console.log(err + "or not found user");
                          res.json({
                            status: false,
                            message: "db error",
                          });
                        } else {
                          const fans_count = user.fans_count - 1;
                          user.fans_count = fans_count;
                          user.save(async function (err, result) {
                            if (err) {
                              console.log(err + "or not found user");
                              res.json({
                                status: false,
                                message: "db error",
                              });
                            } else {
                              // CREATE NOTIFICATION TO SUBSCRIBE
                              // CHECK USER NOTIFICATION SETTING IS ENABLED OR NOT
                              let notif_users = [];
                              let user = await users.findOne({ _id: level.user_id, "notif_followers.is_fan_unsubcribed": true });
                              if (user) {
                                let new_notification = new notificationModel({
                                  type: NOTIFICATION_TYPES.FAN_UNSUBSCRIBE,
                                  filter: null,
                                  from_id: user_id,
                                  to_id: user._id,
                                  message: `Unsubscribed being a ${level?.level == 'basic' ? 'fan' : 'superfan'} for $${Number(level.monthly_price).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} a month`,
                                });
                                await new_notification.save();
                                notif_users.push(user._id);
                              }

                              res.json({
                                status: true,
                                message: "unsubscribed successfully",
                                result: {
                                  notif_users
                                }
                              });
                            }
                          });
                        }
                      });
                    }
                  }
                );
              }
            });
          }
        });
      }
    }
  );
};

exports.read_fandom_payments = async function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = (req.query.user_id || req.decoded.user_id);
  var subscription_id = req.query.subscription_id;
  console.log(user_id);
  console.log(subscription_id);
  try {
    var fandom_payments = await fandomPaymentModel
      .find(
        subscription_id ? {
          user_id, subscription_id
        } : {
          user_id
        }
      )
      .populate({
        path: "user_id",
        model: "users",
        select:
          "username email profile_image first_name last_name profile_cover status create_date bio is_idverified",
      })
      .populate({
        path: "seller_id",
        model: "users",
        select:
          "username email profile_image first_name last_name profile_cover status create_date bio is_idverified",
      })
      .populate({
        path: "subscription_id",
        model: "subscription_levels",
        populate: [
          {
            path: "user_id",
            model: "users",
          },
          // {
          //     path: 'author_id',
          //     model: 'users',
          //     select: 'username email first_name last_name profile_image profile_cover metamask_info password status is_idverified create_date'
          // }
        ],
      });
    res.json({
      status: true,
      message: "Retrived successfully",
      result: fandom_payments,
    });
  } catch (error) {
    console.log(error);
    res.json({
      status: false,
      message: "Something went wrong",
    });
  }
};

exports.get_subscription_earning = async function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded.user_id;
  try {
    var fandom_payments = await fandomPaymentModel
      .find({ seller_id: user_id })
      .populate({
        path: "seller_id",
        model: "users",
        select:
          "username email profile_image first_name last_name profile_cover status create_date bio is_idverified",
      })
      .populate({
        path: "user_id",
        model: "users",
        select:
          "username email profile_image first_name last_name profile_cover status create_date bio is_idverified",
      })
      .populate({
        path: "subscription_id",
        model: "subscription_levels",
        populate: [
          {
            path: "user_id",
            model: "users",
          },
          // {
          //     path: 'author_id',
          //     model: 'users',
          //     select: 'username email first_name last_name profile_image profile_cover metamask_info password status is_idverified create_date'
          // }
        ],
      });
    res.json({
      status: true,
      message: "Retrived successfully",
      result: fandom_payments,
    });
  } catch (error) {
    console.log(error);
    res.json({
      status: false,
      message: "Something went wrong",
    });
  }
}



exports.read_subscribers = async function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded.user_id;
  var page = req.query.page || 1;
  var keyword = req.query.keyword || "";
  var limit = req.query.limit || 15;
  var sortkey = req.query.sortkey || "newest";
  var offset = page == "1" ? 0 : parseInt(page - 1) * 15;

  let levels = await subscriptionlevels.find({ user_id });
  levels = levels.map((d) => {
    return d._id.toString();
  });
  var query = subscribers.find({ subscription_id: { $in: levels } });
  if (sortkey == "newest") {
    query = query.sort("-created_date");
  } else {
    query = query.sort("created_date");
  }
  query.populate({ path: "subscription_id", model: "subscription_levels" });
  query.populate({
    path: "user_id",
    model: "users",
    select:
      "username email first_name last_name profile_image profile_cover metamask_info password status is_idverified create_date",
  });
  if (keyword != "") {
    let _users = await users.find({
      $or: [
        { username: { $regex: new RegExp(keyword, "ig") } },
        { first_name: { $regex: new RegExp(keyword, "ig") } },
        { last_name: { $regex: new RegExp(keyword, "ig") } },
      ],
    });
    _users = _users.map((d) => {
      return d._id.toString();
    });
    let _subscriptions = await subscriptionlevels.find({
      $and: [
        { user_id: user_id },
        {
          $or: [
            { name: { $regex: new RegExp(keyword, "ig") } },
            { description: { $regex: new RegExp(keyword, "ig") } },
          ],
        },
      ],
    });
    _subscriptions = _subscriptions.map((d) => {
      return d._id.toString();
    });
    query = query.find({
      $or: [
        { user_id: { $in: _users } },
        { subscription_id: { $in: _subscriptions } },
      ],
    });
  }
  var options = {
    page: page,
    offset: offset,
    limit: limit,
  };
  subscribers.paginate(query, options).then(function (result) {
    res.json({
      status: true,
      message: "subscribers retrieved successfully",
      data: result,
    });
  });
};

exports.get_status_count = async function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.query.user_id;
  if (user_id) {
    try {
      // posts count, reaction count, fans count, followers_count, followings count
      var posts_count = await fanposts.count({ creator_id: user_id });

      // don't display content when fandom is not published
      var _fandoms = await fandoms.find({ status: "published" });
      _fandoms = _fandoms.map((d) => {
        return d.user_id;
      });

      // don't display content depend on subscription levels
      let users_with_fans = (await subscriptionlevels.find({ level: 'basic' })).map(d => d.user_id);
      let users_with_superfans = (await subscriptionlevels.find({ level: 'super' })).map(d => d.user_id);

      let filter_ids_by_super = (await fanposts.find({
        creator_id: {
          $nin: users_with_superfans
        },
        $or: [
          { is_view_only: 'superfans' },
          { is_relay_only: 'superfans' }
        ]
      })).map(d => d._id);

      let filter_ids_by_basic = (await fanposts.find({
        $and: [
          { creator_id: { $nin: users_with_fans } },
          { creator_id: { $nin: users_with_superfans } }
        ],
        $or: [
          { is_view_only: 'fans' },
          { is_relay_only: 'fans' }
        ]
      })).map(d => d._id);


      var fanpost_ids = (await fanposts.find({
        $and: [
          { creator_id: { $in: _fandoms } },
          {
            $and: [
              { _id: { $nin: filter_ids_by_basic } },
              { _id: { $nin: filter_ids_by_super } }
            ]
          }
        ]
      })).map(d => d._id);



      var reaction_count = await reactionModel.count({
        user_id,
        fanpost_id: { $in: fanpost_ids },
      }) + await itemreactionModel.count({ user_id }); // calc later

      let start_date = new Date(new Date().setMonth(new Date().getMonth() - 1));
      let f_subscription_level = await subscriptionlevels?.findOne({
        user_id,
        level: "basic",
      }).sort({ created_date: -1 }).limit(1);
      let f_joined_users = [];
      if (f_subscription_level) {
        f_joined_users = (
          await subscribers.find({
            subscription_id: f_subscription_level._id,
            unsubscribed: false,
            start_date: { $gte: start_date },
          })
        ).map((d) => d.user_id);
      }

      
      // get users who is super fan
      let s_subscription_level = await subscriptionlevels?.findOne({
        user_id,
        level: "super",
      }).sort({ created_date: -1 }).limit(1);
      let s_joined_users = [];
      if (s_subscription_level) {
        s_joined_users = (
          await subscribers.find({
            subscription_id: s_subscription_level._id,
            unsubscribed: false,
            start_date: { $gte: start_date },
          })
        ).map((d) => d.user_id);
      }

      
      var fans_count = f_joined_users.length + s_joined_users.length;
      var onyfans_count = f_joined_users.length;
      var superfans_count = s_joined_users;
      // var fans_count = await fans.count({ star_id: user_id });
      var followers_count = await followers.count({ star_id: user_id });
      var followings_count = await followers.count({ user_id });
      res.json({
        status: true,
        result: {
          onyfans_count,
          superfans_count,
          posts_count,
          reaction_count,
          fans_count,
          followers_count,
          followings_count,
        },
        message: "Retrived successfully",
      });
    } catch (error) {
      console.log(error);
      res.json({
        status: false,
        message: "Something went wroing.",
      });
    }
    // users.findById(user_id).select('posts_count reaction_count fans_count followers_count followings_count').exec(function(err, result) {
    //     if(err) {
    //         res.json({
    //             status: false,
    //             message: "Some thing went wrong"
    //         });
    //     } else {
    //         if(result) {
    //             res.json({
    //                 status: true,
    //                 message: "retrived successfully",
    //                 result
    //             });
    //         } else {
    //             res.json({
    //                 status: false,
    //                 message: "Some thing went wrong"
    //             });
    //         }
    //     }
    // })
  } else {
    res.json({
      status: false,
      message: "Some thing went wrong",
    });
  }
};

exports.buy_coin = async function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded?.user_id;
  var coin = req.body.coin;
  try {
    var user = await users.findById(user_id);
    // if (user.balance && user.balance > coin) {
    const u_coin = (user.coin || 0) + coin;
    user.coin = u_coin;
    var buyCoin = new tipbuyModel({
      user_id,
      coin: coin,
      price: coin,
    });
    await buyCoin.save();
    await user.save();
    res.json({
      status: true,
      message: "Bought successfully",
    });
    // } else {
    //   res.json({
    //     status: false,
    //     message: "Insufficient balance",
    //   });
    // }
  } catch (error) {
    console.log(error);
    res.json({
      status: false,
      message: "Something went wrong",
    });
  }
};

exports.send_coin = async function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded?.user_id;
  var receiver_id = req.body.receiver_id;
  var coin = req.body.coin;

  try {
    var user = await users.findById(user_id);
    var receiver = await users.findById(receiver_id);

    var u_coin = user.coin;
    if (u_coin >= coin) {
      user.coin = u_coin - coin;
      const r_coin = (receiver.coin || 0) + coin;
      receiver.coin = r_coin;
      await user.save();
      await receiver.save();

      // CREATE NOTIFICATION
      let notif_users = [receiver_id];
      let new_notification = new notificationModel({
        type: NOTIFICATION_TYPES.SEND_COIN,
        filter: null,
        from_id: user_id,
        to_id: receiver_id,
        message: `Sent you ${coin} ${coin > 1 ? "coins" : "coin"} • $${coin.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`
      })

      await new_notification.save();

      res.json({
        status: true,
        message: "Sent successfully",
        result: {
          notif_users
        }
      });
    } else {
      res.json({
        status: false,
        message: "Insufficient coin",
      });
    }
  } catch (error) {
    console.log(error);
    res.json({
      status: false,
      message: "Something went wrong",
    });
  }
};

exports.setBalance = function (req, res) {
  console.log(getErrLine().str, "apistart");
  users.updateMany(
    {},
    {
      balance: 100000000,
    },
    function (err, result) {
      if (err) {
        res.json({
          status: false,
          message: "error",
        });
      } else {
        res.json({
          status: true,
          message: "Saved",
        });
      }
    }
  );
};

exports.get_coin_status = async function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded.user_id;

  try {
    var user = await users.findById(user_id);
    if (user) {
      res.json({
        status: true,
        message: "Retrived successfully",
        result: user.coin || 0,
      });
    } else {
      res.json({
        status: false,
        message: "No user",
      });
    }
  } catch (error) {
    console.log(error);
    res.json({
      status: false,
      message: "something went wrong",
    });
  }
};

exports.get_tips = async function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded.user_id;
  var type = req.query.type;
  var keyword = req.query.keyword;
  var sortKey = req.query.sortKey;

  var sort = {};
  if (sortKey == "new") {
    sort.created_date = -1;
  } else {
    sort.created_date = 1;
  }
  var match = {};
  if (keyword != "") {
    match = {
      $or: [
        { first_name: { $regex: new RegExp(keyword, "ig") } },
        { last_name: { $regex: new RegExp(keyword, "ig") } },
        { username: { $regex: new RegExp(keyword, "ig") } },
        { email: { $regex: new RegExp(keyword, "ig") } },
      ],
    };
  }

  if (type == "send") {
    try {
      var query = tipModel.find();
      query = query.populate({
        path: "receiver",
        model: "users",
        select:
          "username email profile_image first_name last_name profile_cover status create_date bio is_idverified",
        match,
      });
      var tips = await query.find({ sender: user_id }).sort(sort);
      res.json({
        status: true,
        message: "Retrived successfully",
        result: tips,
      });
    } catch (error) {
      console.log(1);
      console.log(error);
      res.json({
        status: false,
        message: "Something went wrong",
        errors: error,
      });
    }
  } else {
    try {
      var query = tipModel.find();
      query = query.populate({
        path: "sender",
        match,
        model: "users",
        select:
          "username email profile_image first_name last_name profile_cover status create_date bio is_idverified",
        match,
      });
      var tips = await query.find({ receiver: user_id }).sort(sort);
      res.json({
        status: true,
        message: "Retrived successfully",
        result: tips,
      });
    } catch (error) {
      console.log(2);
      console.log(error);
      res.json({
        status: false,
        message: "Something went wrong",
        errors: error,
      });
    }
  }
};

exports.get_tip_payouts = async function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded.user_id;
  var keyword = req.query.keyword;
  var sortKey = req.query.sortKey;
  var match = {};
  var sort = {};
  if (sortKey == "new") {
    sort.created_date = -1;
  } else {
    sort.created_date = 1;
  }
  if (keyword != "") {
    match = {
      $or: [
        { first_name: { $regex: new RegExp(keyword, "ig") } },
        { last_name: { $regex: new RegExp(keyword, "ig") } },
        { username: { $regex: new RegExp(keyword, "ig") } },
        { email: { $regex: new RegExp(keyword, "ig") } },
      ],
    };
  }
  try {
    var payouts = await tipbuyModel.find({ user_id }).sort(sort);
    res.json({
      status: true,
      message: "Retrived successfully",
      result: payouts,
    });
  } catch (error) {
    res.json({
      status: false,
      message: "Something went wrong",
      errors: error,
    });
  }
};

exports.get_blocked_accounts = async function (req, res) {
  console.log(getErrLine().str, "apistart");
  try {
    const user_id = req.query.user_id || req.decoded?.user_id;
    const blocked_user_lists = await blockModel.find({ user_id });
    const blocked_user_ids = blocked_user_lists?.map(d => d.block_user_id);
    const blocked_users = await users.find({ _id: { $in: blocked_user_ids } }).select("username email profile_image first_name last_name profile_cover status create_date bio is_idverified");
    res.json({
      status: true,
      message: "Retrived successfully",
      result: blocked_users
    })
  } catch (error) {
    console.log(error);
    res.json({
      status: false,
      message: error?.message,
    });
  }
}

// manage block
exports.manage_block = async function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded.user_id;
  var type = req.body.type;
  var block_user_id = req.body.block_user_id;

  var db_block_user = await blockModel.findOne({ block_user_id, user_id });
  if (type == "block") {
    try {
      if (db_block_user) {
        res.json({
          status: true,
          message: "Already blocked",
        });
      } else {
        var new_block_user = new blockModel({ block_user_id, user_id });
        await new_block_user.save();
        //!!20231227pm06 coderB To add block_user_id into block_list field
        /* Addition of Inserting Start */
        await users.updateOne({ _id: user_id}, { $push: { block_list: block_user_id } });
        /* 20231230 CoderX "Add to user_id into blocked_by_list" */
        await users.updateOne({_id: block_user_id}, { $push: {blocked_by_list: user_id}}); 
        /* Addition of Removing End */
        res.json({
          status: true,
          message: "Added block list successfully",
        });
      }
    } catch (error) {
      console.log(error);
      res.json({
        status: false,
        message: "Error was occured",
      });
    }
  } else {
    if (db_block_user) {
      await blockModel.deleteMany({ block_user_id, user_id });
      //!!20231227pm06 coderB To remove block_user_id from block_list filed
      /* Addition of Inserting Start */
      await users.updateOne({ _id: user_id }, { $pull: { block_list: block_user_id }})
      /* Addition of Removing End */
      res.json({
        status: true,
        message: "Removed successfully",
      });
    } else {
      res.json({
        status: true,
        message: "He is already removed from block list before",
      });
    }
  }
};

exports.get_muted_accounts = async function (req, res) {
  console.log(getErrLine().str, "apistart");
  try {
    const user_id = req.query.user_id || req.decoded?.user_id;
    const muted_user_lists = await muteModel.find({ user_id });
    const muted_user_ids = muted_user_lists?.map(d => d.mute_user_id);
    const muted_users = await users.find({ _id: { $in: muted_user_ids } }).select("username email profile_image first_name last_name profile_cover status create_date bio is_idverified");
    res.json({
      status: true,
      message: "Retrived successfully",
      result: muted_users
    })
  } catch (error) {
    console.log(error);
    res.json({
      status: false,
      message: error?.message,
    });
  }
}

// manage mute
exports.manage_mute = async function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded.user_id;
  var type = req.body.type;
  var mute_user_id = req.body.mute_user_id;

  var db_mute_user = await muteModel.findOne({ mute_user_id, user_id });
  if (type == "mute") {
    try {
      if (db_mute_user) {
        res.json({
          status: true,
          message: "Already muteed",
        });
      } else {
        var new_mute_user = new muteModel({ mute_user_id, user_id });
        await new_mute_user.save();
        //!!20231227pm06 coderB To add mute_user_id into mute_list field
        /* Addition of Inserting Start */
        await users.updateOne({ _id: user_id }, { $push: { mute_list: mute_user_id }})
        /* Addition of Inserting End */
        res.json({
          status: true,
          message: "Added mute list successfully",
        });
      }
    } catch (error) {
      console.log(error);
      res.json({
        status: false,
        message: "Error was occured",
      });
    }
  } else {
    if (db_mute_user) {
      await muteModel.deleteMany({ mute_user_id, user_id });
      //!!20231227pm06 coderB To remove mute_user_id from mute_list field
      /* Addition of Removing Start */
      await users.updateOne({ _id: user_id}, { $pull: { mute_list: mute_user_id } })
      /* Addition of Removing End */
      res.json({
        status: true,
        message: "Removed successfully",
      });
    } else {
      res.json({
        status: true,
        message: "He is already removed from mute list before",
      });
    }
  }
};

exports.get_count_fan = async function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded.user_id;

  try {
    var date = new Date(new Date().setMonth(new Date().getMonth() - 1));


    let start_date = new Date(new Date().setMonth(new Date().getMonth() - 1));
    let f_subscription_level = await subscriptionlevels?.findOne({
      user_id,
      level: "basic",
    }).sort({ created_date: -1 }).limit(1);
    let f_joined_users = [];
    if (f_subscription_level) {
      f_joined_users = (
        await subscribers.find({
          subscription_id: f_subscription_level._id,
          unsubscribed: false,
          start_date: { $gte: start_date },
        })
      ).map((d) => d.user_id);
    }
    
    // get users who is super fan
    let s_subscription_level = await subscriptionlevels?.findOne({
      user_id,
      level: "super",
    }).sort({ created_date: -1 }).limit(1);
    let s_joined_users = [];
    if (s_subscription_level) {
      s_joined_users = (
        await subscribers.find({
          subscription_id: s_subscription_level._id,
          unsubscribed: false,
          start_date: { $gte: start_date },
        })
      ).map((d) => d.user_id);
    }

    var fans_count = f_joined_users.length + s_joined_users.length;

    res.json({
      status: true,
      message: "Data retrived successfully",
      result: {
        fan_count: f_joined_users.length,
        super_fan_count: s_joined_users.length,
      },
    });
  } catch (error) {
    console.log(error);
    res.json({
      status: false,
      message: "Sonething went wrong",
    });
  }
};

exports.update_profile = async function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded.user_id;
  try {
    await users.findByIdAndUpdate(req.body._id, req.body);
    res.json({
      status: true,
      message: "Updated successfully",
    });
  } catch (error) {
    console.log(error);
    res.json({
      status: false,
      message: "Something went wrong",
    });
  }
};

exports.reget_token = async function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded.user_id;
  try {
    let user = await users.findById(user_id);
    if (user) {
      let token = jwt.sign(
        {
          user_id: user._id,
          username: user.username,
          email: user.email,
          first_name: user.first_name,
          last_name: user.last_name,
          profile_image: user.profile_image ? user.profile_image : "",
          status: user.status,
          dob: user.dob,
          phone: user.phone,
          role: user.role,
          is_idverified: user.is_idverified,
        },
        config.secret_key,
        {
          expiresIn: "24h", // expires in 24 hours
        }
      );

      res.json({
        status: true,
        message: "Retrived successfully",
        result: token,
      });
    } else {
      res.json({
        status: false,
        message: "Something went wrong",
      });
    }
  } catch (error) {
    console.log(error);
    res.json({
      status: false,
      message: "Something went wrong",
    });
  }
};

// function for discover for you, new and trending
exports.get_users = async function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded.user_id;
  var type = req.query.type || "New";
  var filter = req.query.filter;
  var keyword = req.query.keyword;
  var page = req.query.page || 1;
  var limit = req.query.limit || 60;

  console.log(req.query,"======================")
  try {
    var query = users.find({ _id: { $ne: user_id } });
    if (keyword && keyword.trim() != "") {
      keyword = keyword.trim();
      query = query.find({
        $or: [
          {
            first_name: {
              $regex: new RegExp(keyword, "ig"),
            },
          },
          {
            last_name: {
              $regex: new RegExp(keyword, "ig"),
            },
          },
          {
            email: {
              $regex: new RegExp(keyword, "ig"),
            },
          },
          {
            username: {
              $regex: new RegExp(keyword, "ig"),
            },
          },
        ],
      });
    }
    switch (type) {
      case "Everybody":
        break;
      case "People":
        query = query.find({ account_type: "People" });
        break;
      case "Groups":
        query = query.find({ account_type: "Group" });
        break;
      case "Businesses":
        query = query.find({ account_type: "Business" });
        break;
      case "Organizations":
        query = query.find({ account_type: "Organization" });
        break;
      case "Goverment":
        query = query.find({ account_type: "Goverment" });
        break;
      default:
        break;
    }
    // var date = new Date(new Date().setDate(new Date().getDate() - 15));
    query = query.sort({ create_date: -1 })
    switch (filter) {
      case "New":
        query = query.find({ create_date: { $gt: new Date(new Date().setDate(new Date().getDate() - 90)) } });
        break;
      case "For you":
        // my followers
        var _followers = (await followers.find({ user_id })).map(
          (d) => d.star_id
        );
        // my follower's followers
        var _other_followers = (await followers.find({ user_id: { $in: _followers } })).map(d => d.star_id)
        query = query.find({
          $and: [
            {
              _id: {
                $not: { $in: _followers }
              }
            }
            //!!20240123pm4 coderd commented below code {(CoderD)(B)desktop • fanpage} 
            // }, {
            //   _id: {
            //     $in: _other_followers
            //   }
            // }
          ]
        });
        break;
      case "Trending":
        // might be complex
        let _users = await query.exec()
        _update_users = await Promise.all(_users.map(async d => {
          let n_follower = await followers.countDocuments({ star_id: d._id });
          // let n_fan = 
          var date = new Date(new Date().setMonth(new Date().getMonth() - 1));
          var my_subscribers = await subscribers
            .find({ user_id, start_date: { $gte: date }, unsubscribed: false })
            .populate({ path: "subscription_id" });
          var n_fan = my_subscribers.length;

          let follow = await followers.findOne({ star_id: d._id, user_id });
          let following = await followers.findOne({ star_id: user_id, user_id: d._id });

          return {
            ...d._doc,
            n_t: n_follower + n_fan,
            isFollow: follow ? true : false,
            isFollowing: following ? true : false
          }
        }));

        _update_users = _update_users.sort(function (a, b) { return b.n_t - a.n_t });
        let totalDocs = _update_users.length;
        let totalPages = Math.ceil(_update_users / limit);
        let currentPage = page;
        let docs = _update_users.slice((page - 1) * limit, limit);

        let resData = {
          docs,
          totalDocs,
          limit: limit,
          totalPages,
          currentPage,
          hasNextPage: totalPages > currentPage ? true : false,
          nextPage: totalPages > currentPage ? currentPage + 1 : null,
        }
        res.json({
          status: true,
          message: "Retrived successfully",
          data: resData
        })



        return;
      default:
        break;
    }

    var offset = page == "1" ? 0 : parseInt(page - 1) * 15;
    var options = {
      page: page,
      offset: offset,
      limit: limit,
    };

    users.paginate(query, options).then(async function (result) {
      const updatedDocs = await Promise.all(result.docs.map(async d => {
        let _follower = await followers.findOne({ star_id: d._doc?._id, user_id: user_id });
        let _following = await followers.findOne({ star_id: user_id, user_id: d._doc?._id })

        return {
          ...d._doc,  // copy all the existing fields
          isFollow: _follower ? true : false,
          isFollowing: _following ? true : false,
        }
      }))

      const updatedResult = { ...result, docs: updatedDocs };
      res.json({
        status: true,
        message: "Retrived successfully",
        data: updatedResult
      })
    })

  } catch (error) {
    console.log(error);
    res.json({
      status: false,
      message: "Something went wrong",
    });
  }
};


// handle_pay
exports.handle_pay = async function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded.user_id;
  var payTo = req.body.payTo;
  try {
    let user = await users.findById(user_id);
    if (user) {
      let billingInfo = {
        'first_name': user.first_name || "",
        'last_name': user.last_name || "",
        'address1': user.street || "",
        'city': user.state || "",
        'state': user.country || "",
        'zip': user.zipcode || "",
      }
      let shippingInfo = {
        'shipping_first_name': user.first_name || "",
        'shipping_last_name': user.last_name || "",
        'shipping_address1': user.street || "",
        'shipping_city': user.state || "",
        'shipping_state': user.country || "",
        'shipping_zip': user.zipcode || "",
      }
      let reqData = {
        price: req.body.price,
        token: req.body.token,
        billingInfo,
        shippingInfo: req.body.shippingInfo || shippingInfo
      }
      try {
        let response = await payController.handle_pay(reqData);
        console.log("nmi response");
        console.log(response);
        let finance = new financeModel({
          user_id,
          price: req.body.price,
          transactionid: response.transactionid
        })
        await finance.save();

        // direct pay with paynote
        if (payTo.length > 0) {
          let paynoteResults = await Promise.all(
            payTo.map(async d => {
              let user = await users.findById(d.user_id);
              if (user) {
                try {
                  let reqData = {
                    recipient: user.email,
                    name: user.first_name + user.last_name,
                    amount: d.price,
                    description: 'Transaction in indiefire',
                    account: '',
                    number: '10038',
                    identifier: 'Transaction to indiefire.io',
                    attachment: '',
                    recurring: {
                      billing_cycle: 'day',
                      start_cycle: new Date(),
                      num_of_payments: 15
                    }
                  };
                  let paynoteResponse = await paynoteController.handlePayWithPaynote(reqData);
                  console.log("paynoteResponse");
                  console.log(paynoteResponse);
                  return true;
                } catch (error) {
                  console.log("4350: error")
                  console.log(error)
                  return false;
                }
              } {
                return false;
              }
            })
          );
          console.log("paynoteResults");
          console.log(paynoteResults);
        }

        res.json({
          status: true,
          message: "paied successfully",
          result: response
        })
      } catch (error) {
        console.log(error);
        res.json({
          status: false,
          message: "Something went wrong",
          error: error
        })
      }
    } else {
      res.json({
        status: false,
        message: "No user"
      });
    }
  } catch (error) {
    console.log(error);
    res.json({
      status: false,
      message: "Something went wrong"
    })
  }
}


exports.add_mute_word = async function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded.user_id;
  try {
    var word = await muteModel.findOne({ word: req.body.word });
    if (word) {
      res.json({
        status: false,
        message: "this word already added"
      })
    } else {
      var new_word = new muteWordModel(req.body);
      new_word.user_id = user_id;
      var date = new Date();
      switch (req.body.expiredAt) {
        case '1D':
          new_word.expiredDate = new Date(date.setDate(date.getDate() + 1));
          break;
        case '1W':
          new_word.expiredDate = new Date(date.setDate(date.getDate() + 7));
          break;
        case '1M':
          new_word.expiredDate = new Date(date.setDate(date.getMonth() + 1));
          break;
        default:
          break;
      }
      await new_word.save();
      res.json({
        status: true,
        message: "Saved successfully"
      })
    }

  } catch (error) {
    console.log(error);
    res.json({
      status: true,
      message: 'Something went wrong'
    })
  }
}

exports.get_mute_words = async function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded.user_id;
  var keyword = req.query.keyword
  var filterBy = req.query.filterBy;
  var sortBy = req.query.sortBy;
  try {
    var query = muteWordModel.find({ user_id });
    // mute_word != "";
    if (keyword && keyword != '') {
      query = query.find({
        word: {
          $regex: new RegExp(keyword, "ig"),
        }
      })
    }
    var date = new Date()
    switch (filterBy) {
      case 'noend':
        query = query.find({ expiredAt: 'noend' });
        break;
      case 'endsoon':
        query = query.find({
          $and: [
            { expiredAt: { $ne: 'noend' } },
            { expiredDate: { $lte: new Date(date.setDate(date.getDate() + 1)) } },
            { expiredDate: { $gt: date } },
          ]
        })
        break;
      case 'ended':
        query = query.find({
          $and: [
            { expiredAt: { $ne: 'noend' } },
            { expiredDate: { $lt: date } }
          ]
        })
      default:
        break;
    }

    switch (sortBy) {
      case 'new':
        query = query.sort({ created_date: -1 }); break;
      case 'old':
        query = query.sort({ created_date: 1 }); break;
      case 'az':
        query = query.sort({ word: 1 }); break;
      case 'za':
        query = query.sort({ word: -1 }); break;
      default:
        break;
    }

    let result = await query.exec();
    result = result.map(d => {
      return {
        ...d._doc,
        serverDate: new Date()
      }
    })

    res.json({
      status: true,
      message: "retrived successfully",
      result: await query.exec()
    })
  } catch (error) {
    console.log(error);
    res.josn({
      status: false,
      message: "Sonething went wrong"
    })
  }
}

exports.edit_mute_word = async function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded.user_id;
  try {
    await muteWordModel.findByIdAndUpdate(req.body._id, req.body);
    res.json({
      status: true,
      message: "updated successfully"
    })
  } catch (error) {
    console.log(error);
    res.json({
      status: false,
      message: "Something went wrong"
    })
  }
}

exports.remove_mute_words = async function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded.user_id;
  try {
    var delete_ids = req.body.delete_ids;
    await muteWordModel.deleteMany({
      _id: { $in: delete_ids }
    });
    res.json({
      status: true,
      message: "Removed successfully"
    })
  } catch (error) {
    console.log(error);
    res.json({
      status: false,
      message: "Something went wrong"
    })
  }
}


exports.add_shipping_rule = async function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded.user_id;
  try {
    var rule = new shippingRuleModel(req.body);
    rule.user_id = user_id;
    await rule.save();
    res.json({
      status: true,
      message: "Saved successfully"
    })
  } catch (error) {
    console.log(error);
    res.json({
      status: false,
      message: "Something went wrong"
    })
  }
}

exports.get_shipping_rule = async function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.query.user_id || req.decoded?.user_id;
  try {
    var rules = await shippingRuleModel.find({
      user_id
    })
      .populate({
        path: "items",
        model: "item"
      })
      .sort({ created_date: -1 });

    res.json({
      status: true,
      message: "Retrived successfully",
      result: rules
    })

  } catch (error) {
    console.log(error);
    res.json({
      status: false,
      message: error.message
    })
  }

}

exports.update_shipping_rule = async function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded.user_id;
  try {
    await shippingRuleModel.findByIdAndUpdate(req.body._id, req.body);
    res.json({
      status: true,
      message: "Updated successfully"
    })
  } catch (error) {
    console.log(error);;
    res.json({
      status: false,
      message: "Something went wrong"
    })
  }
}


exports.delete_shipping_rule = async function (req, res) {
  console.log(getErrLine().str, "apistart");
  try {
    await shippingRuleModel.findByIdAndRemove(req.body._id);
    res.json({
      status: true,
      message: "Deleted successfully"
    })
  } catch (error) {
    console.log(error);;
    res.json({
      status: false,
      message: "Something went wrong"
    })
  }
}

//!!20240105pm4 coderC To get combined shipping rules price, updatd the below function. ""
exports.get_combined_shipping_rules = async function (req, res) {
  console.log(getErrLine().str, "apistart");
  try {
    var data = req.body.items_id;
    var owner = req.body.owner;
    var reduceShippingRule = [];
    var rules = await shippingRuleModel.find({"user_id": owner});
    rules.map(element => {
      let flag = true;
      element.items.map(item => {
        // console.log('========start==========', element, data);
        //set flag as false if element is not included in data
        if(!data.some((itemElement) => itemElement == item)) {flag = false; return;}
      });
      if(flag){
        //reduceShippingRule is arrary that can discount when buy things.
        reduceShippingRule.push(element);
      }
    })
    console.log('$$$$$$$$$$$$reduce shipping rule$$$$$$$$$$$$$', reduceShippingRule);
    res.json({
      status: true,
      message: "Retrived sucessfully",
      result: reduceShippingRule
    })
  } catch (error) {
    console.log(error);
    res.json({
      status: false,
      message: "Something went wrong"
    })
  }
}

// exports.get_combined_shipping_rules = async function (req, res) {
//   console.log(getErrLine().str, "apistart");
//   try {
//     var items = req.body.items;
//     var rules = await shippingRuleModel.find({
//       items: {
//         $elemMatch: {
//           $in: items
//         }
//       }
//     });
//     res.json({
//       status: true,
//       message: "Retrived sucessfully",
//       result: rules
//     })
//   } catch (error) {
//     console.log(error);
//     res.josn({
//       status: false,
//       message: "Something went wrong"
//     })
//   }
// }


exports.add_item_shipping_rule = async function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded.user_id;
  try {
    var item_shipping_rule = new itemShippingRuleModel(req.body);
    item_shipping_rule.user_id = user_id;
    await item_shipping_rule.save();
    res.json({
      status: true,
      message: "Saved successfully."
    });
  } catch (error) {
    console.log(error);
    res.json({
      status: false,
      message: error.message
    })

  }
}

exports.get_item_shipping_rules = async function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.query.user_id || req.decoded?.user_id;;
  var keyword = req.query.keyword;
  try {
    var query = itemShippingRuleModel.find({ user_id })
    if (keyword && keyword != "") {
      query = query.find(
        {
          name: {
            $regex: new RegExp(keyword, "ig"),
          },
        }
      )
    }
    query = query.populate({
      path: 'items',
      model: 'item'
    });
    let rules = await query.exec();
    res.json({
      status: true,
      result: rules,
      message: "Retrived successfully",
    })
  } catch (error) {
    console.log(error)
    res.json({
      status: false,
      message: error.message
    })
  }
}

exports.edit_item_shipping_rule = async function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded.user_id;
  var _id = req.body._id;
  try {
    await itemShippingRuleModel.findByIdAndUpdate(_id, req.body);
    res.json({
      status: true,
      message: "Saved successfully"
    })
  } catch (error) {
    console.log(error);
    res.json({
      status: false,
      message: error.message
    })
  }

}


exports.delete_item_shipping_rule = async function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded.user_id;
  try {
    await itemShippingRuleModel.findByIdAndRemove(req.body._id);
    res.json({
      status: true,
      message: "Deleted successfully"
    })
  } catch (error) {
    console.log(error)
    res.json({
      status: false,
      message: error.message
    })
  }
}

exports.get_my_fandom_count = async function (req, res) {
  console.log(getErrLine().str, "apistart");
  try {
    var user_id = req.decoded.user_id;
    let start_date = new Date(new Date().setMonth(new Date().getMonth() - 1));
    var _subscribers = (await subscribers.find({
      unsubscribed: false,
      start_date: { $gte: start_date },
      user_id
    }))?.map(d => d?.subscription_id);
    var user_ids = (await subscriptionlevels.find({ _id: { $in: _subscribers } }))?.map(d => d.user_id);
    var fandom_count = await fandoms.count({ user_id: { $in: user_ids }, status: 'published' });

    res.json({
      status: true,
      message: 'Retrived successfully',
      result: fandom_count
    })

  } catch (error) {
    res.josn({
      status: false,
      message: error?.message
    })
  }
}

exports.get_artists = async function (req, res) {
  console.log(getErrLine().str, "apistart");
  try {
    let user_id = req.decoded?.user_id;
    let artists = await artistModel.find({}).sort({ created_date: -1 });
    res.json({
      status: true,
      message: "Retrived successfully",
      result: artists
    })
  } catch (error) {
    console.log(error);
    res.josn({
      status: false,
      message: error?.message
    })
  }
}

exports.create_artist = async function (req, res) {
  console.log(getErrLine().str, "apistart");
  try {
    let user_id = req.decoded.user_id;
    const artist = new artistModel(req.body);
    artist.user_id = user_id;
    await artist.save();
    res.json({
      status: true,
      message: "Saved successfully",
      result: artist
    });
  } catch (error) {
    console.log(error);
    res.json({
      status: false,
      message: error?.message
    })
  }
}

// added by coderB 20231218a01
// function for update the properties of direct message in privacy & safety
exports.update_privacy = async function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.body.user_id;
  try {
    let user = await users.updateOne(
      { _id: user_id },
      { $set: { "privacy_safety.direct_message": req.body.direct_message } }
    )
    if (user) {
      res.json({
        status: true,
        message: "Updated successfully",
        data: req.body.direct_message
      });
    } else {
      res.json({
        status: false,
        message: "Something went wrong"
      });
    }
  } catch (error) {
    console.log(error);
    res.json({
      status: false,
      message: "Something went wrong",
    });
  }
}

//!!20231214am8 coderc To save payment method token, added the following function
exports.add_payment_method_info = async function (req, res) {
  try {
    let id, firstName, lastName, userToken, cardType, paymentMethodType, paymentMethodToken, transactionType, lastNumber, month, year;
    id = req.body.id;
    firstName = req.body.first_name;
    lastName = req.body.last_name;
    cardType = req.body.card_type;
    paymentMethodType = req.body.payment_method_type;
    paymentMethodToken = req.body.payment_method_token;
    userToken = req.body.token;
    lastNumber = req.body.last_number;
    transactionType = req.body.transaction_type;
    month = req.body.month;
    year = req.body.year;
    let pmInfo = await users.update({ '_id': id }, { $push: { payment_method_info: { 'first_name': firstName, 'last_name': lastName, 'card_type': cardType, 'payment_method_type': paymentMethodType, 'payment_method_token': paymentMethodToken, 'token': userToken, 'last_number': lastNumber, 'transaction_type': transactionType, 'month': month, 'year': year } } });
    res.json({
      status: true,
      message: "Saved successfully",
      result: pmInfo
    });
  } catch (error) {
    console.log(error);
    res.json({
      status: false,
      message: error?.message
    })
  }
}
//!!20231215pm8 coderc To add payment gateway token, added the following function
exports.create_payment_gateway = async function (req, res) {
  try {
    let id, gateway_type, userToken;
    id = req.body.id;
    gateway_type = req.body.gateway_type;
    userToken = req.body.token;
    if (gateway_type && userToken) {
      let gateway_info = await users.update({ '_id': id }, { $addToSet: { gateway_info: { 'gateway_type': gateway_type, 'token': userToken } } })
      res.json({
        status: true,
        message: "Saved successfully",
        result: gateway_info
      });
    }
  } catch (error) {
    console.log(error);
    res.json({
      status: false,
      message: error?.message
    })
  }
}

//!!20231216pm10 coderc To get payment gateway info, added the following function

exports.get_payment_gateway = async function (req, res) {
  try {
    let id;
    id = req.body.id;
    let userInfo = await users.findOne({ '_id': id })
    res.json({
      status: true,
      message: "gained payment gateway info successfully",
      result: userInfo.gateway_info,
      //!!20231226pm6 coderc To get active gateway token, added the below param. "(B) Spreedly Test : need Proof send tips"
      active_gateway_token: userInfo?.active_payment_gateway_token
    });
  } catch (error) {
    console.log(error);
    res.json({
      status: false,
      message: error?.message
    })
  }
}

//!!20231218am4 coderc, To delete payment  added the following function

exports.delete_payment_gateway = async function (req, res) {
  try {
    let id = req.body.id;
    let item = req.body.item;
    let userInfo = await users.updateOne({ '_id': id }, {
      $pullAll: {
        gateway_info: [
          { gateway_type: item.gateway_type, token: item.token }
        ]
      }
    });
    res.json({
      status: true,
      message: "deleted payment gateway info successfully",
      result: userInfo
    });
  } catch (error) {
    console.log(error);
    res.json({
      status: false,
      message: error?.message
    })
  }
}

//!!20231218pm7 coderc, To get user payment mehtod info, added the following function

exports.get_payment_method_info = async function (req, res) {
  try {
    let userPaymentMethodInfo = await users.findOne({ '_id': req.body.id });
    res.json({
      status: true,
      message: "deleted payment gateway info successfully",
      //!!20231227pm2 coderc To add active payment method info, updated the below code. "(B) Spreedly Test : need Proof send tips"
      // result: userPaymentMethodInfo.payment_method_info
      result: {
        paymentMethodInfo: userPaymentMethodInfo?.payment_method_info,
        activePaymentMethod: userPaymentMethodInfo?.active_payment_method_token
      }
    });
  } catch (error) {
    console.log(error);
    res.json({
      status: false,
      message: error?.message
    })
  }
}

//!!20231218pm8 coderc To remove payment method info, added the below function.
exports.remove_payment_method_info = async function (req, res) {
  try {
    let id = req.body.id;
    let data = req.body;
    let userInfo = await users.updateOne({ '_id': id }, {
      $pullAll: {
        payment_method_info: [
          {
            first_name: data.first_name,
            last_name: data.last_name,
            card_type: data.card_type,
            payment_method_type: data.payment_method_type,
            payment_method_token: data.payment_method_token,
            token: data.token,
            last_number: data.last_number,
            transaction_type: data.transaction_type,
            month: data.month,
            year: data.year
          }
        ]
      }
    });
    res.json({
      status: true,
      message: "deleted payment gateway info successfully",
      result: userInfo
    });
  } catch (error) {
    console.log(error);
    res.json({
      status: false,
      message: error?.message
    })
  }
}

//!!20231218pm8 coderc To remove payment method info, added the below function.
exports.get_user_card_info = async function (req, res) {
  try {
    let user_id = req.decoded.user_id;
    let userInfo = await users.findOne({ '_id': user_id });
    res.json({
      status: true,
      message: "sucessfully",
      result: userInfo.payment_method_info
    });
  } catch (error) {
    console.log(error);
    res.json({
      status: false,
      message: error?.message
    })
  }
}

//!!20231219pm7 coderc To get receiver card token, added the below function.
exports.get_receiver_card_token = async function (req, res) {
  try {
    let receiver_id = req.body.id;
    let receiverInfo = await users.findOne({ '_id': receiver_id });
    res.json({
      status: receiverInfo.gateway_info?.length ? true : false,
      message: "sucessfully",
      //!!20231228am1 coderc To add active gateway token, updated the below code. "(B) Spreedly Test : need Proof send tips"
      result: {
        'gatewayList': receiverInfo.gateway_info.length ? receiverInfo.gateway_info : null,
        'activeGatewayToken': receiverInfo?.active_payment_gateway_token,
        'receiverName': receiverInfo.username
      },
      // result: receiverInfo.gateway_info.length ? receiverInfo.gateway_info : null,
      // receiverName: receiverInfo.username
    });
  } catch (error) {
    console.log(error);
    res.json({
      status: false,
      message: error?.message
    })
  }
}

//!!20231219pm7 coderc To get paied result, added the below function.
exports.pay_now = async function (req, res) {
  try {

    //This is purchase test.
    // request
    //   .post('https://core.spreedly.com/v1/gateways/1dbF8MhQnBMVgHAxJogZnIWpLDE/purchase.json')
    //   .set('Authorization', 'Basic WmFsRThaYjNhUEQ2UzJ6dHVqdTZyc0s2MWd0Ok0xSUpZNHZHZ0ZjVHJodmI3aVY0ZmEydEJHNG0zYzl6WHdTZTVYVFM2ZVo5ZWU5Tk5WWTRHY2dBNTRDek9qNEo=')
    //   .set('Host', 'core.spreedly.com')
    //   .type('json')
    //   //  .send('\n{\n  "transaction": {\n    "payment_method_token": "Fn37EA7zIoVRLiTRTD984cFTiG7",\n    "amount": 10700,\n    "currency_code": "USD",\n    "retain_on_success": true\n  }\n}\n')
    //   .send({
    //     'transaction': {
    //       'payment_method_token': 'Fn37EA7zIoVRLiTRTD984cFTiG7',
    //       'amount': 10700,
    //       'currency_code': 'USD',
    //       'retain_on_success': true
    //     }
    //   })
    //   .then(result => {
    //     console.log(result.body);
    //     res.json({
    //       status: true,
    //       message: "successfully",
    //       result: result.body
    //     })
    //   });
    let payerToken = req.body.payerToken;
    let receiverToken = req.body.receiverToken
    let price;
    let user_id = req.decoded.user_id;
    let subscription_id = req.body.subscription_id;
    let level = req.body.level;
    let url = 'https://core.spreedly.com/v1/gateways/' + receiverToken + '/purchase.json';
    const key = 'VUj1RpEie6m0tYCdDkKckGDMkte';
    const access_secret = 'CTHX9l55oQ44WfV8GZEnxUn8mgxMZhxrofyFvaQ4enNupRv8gfI934YgJLvVop34';
    const authorization = 'Basic ' + btoa(key + ":" + access_secret);
    //!!20240113am11 coderd added below code {( b ) buying > fandoms > subscriptions} 
    // !!20240121am2 coderd changed below code {( b ) buying > fandoms > subscriptions}
    if(level == "super"){
      let _subscriptions = await subscriptionlevels.find({
        user_id: req.body.fandom_id,
      });
      _subscriptions = _subscriptions.map((d) => {
        return d._id;
      });
      console.log(_subscriptions);
      await subscribers.findOne(
        {
          $and: [
            { user_id: user_id },
            { subscription_id: { $ne: subscription_id } },
            { subscription_id: { $in: _subscriptions } },
            { unsubscribed: false },
          ],
        }, async function(err,data){
          if(err){
            throw err;
          } else {
            console.log(data,"this is unsubscribed datas")
            if(data && data.length !=0){
              var distance = new Date(data.end_date).getTime() - new Date(data.start_date).getTime();
              var d = Math.floor(distance / ( 24 * 60 * 60 * 1000)) % 30;
              price = req.body.price - (data.subscription_id.monthly_price / 30) * (30 - d);
            } else {
              price = req.body.price;
            };
            console.log(price,"console.log(pay_price)")
          }
        }
      ).populate({
        path: "subscription_id",
        model: "subscription_levels"
      });
    } else {
      price = req.body.price;
    };
    request
      .post(url)
      .set('Authorization', authorization)
      .set('Host', 'core.spreedly.com')
      .type('json')
      .send({
        'transaction': {
          'payment_method_token': payerToken,
          'amount': price,
          'currency_code': 'USD',
          'retain_on_success': true
        }
      })
      .then(result => {
        console.log(result.body);
        res.json({
          status: true,
          message: "successfully",
          result: result.body
        })
      })
      .catch(err => {
        console.log(err);
        res.json({
          status: false,
          message: err
        })
      })

  } catch (error) {
    console.log(error);
    res.json({
      status: false,
      message: error?.message
    })
  }
}

//!!20231222am11 coderc To gnerate payment gateway token, added the below function.

exports.generate_payment_gateway = async function (req, res) {
  try {
    let user_id = req.decoded.user_id;
    let data = req.body.data;
    const key = 'VUj1RpEie6m0tYCdDkKckGDMkte';
    const access_secret = 'CTHX9l55oQ44WfV8GZEnxUn8mgxMZhxrofyFvaQ4enNupRv8gfI934YgJLvVop34';
    const authorization = 'Basic ' + btoa(key + ":" + access_secret);
    // const authorization = 'Basic VlVqMVJwRWllNm0wdFlDZERrS2NrR0RNa3RlOkNUSFg5bDU1b1E0NFdmVjhHWkVueFVuOG1neE1aaHhyb2Z5RnZhUTRlbk51cFJ2OGdmSTkzNFlnSkx2Vm9wMzQ='
    let url = 'https://core.spreedly.com/v1/gateways.json';
    request
      .post(url)
      .set('Authorization', authorization)
      .set('Host', 'core.spreedly.com')
      .type('json')
      //  .send('\n{\n  "transaction": {\n    "payment_method_token": "Fn37EA7zIoVRLiTRTD984cFTiG7",\n    "amount": 10700,\n    "currency_code": "USD",\n    "retain_on_success": true\n  }\n}\n')
      .send(data)
      .then(result => {
        users.update({ '_id': user_id }, { $addToSet: { gateway_info: { 'gateway_type': result.body.gateway.gateway_type, 'token': result.body.gateway.token } } }).exec((err, res1) => {
          if (err) {
            console.log(err);
            res.json({
              status: false,
              message: 'gateway info update error',
              result: result.body
            });
          }
          res.json({
            status: true,
            message: "successfully",
            result: result.body,
            updatedStatus: res1
          })
        })

      })
      .catch(err => {
        console.log(err);
        res.json({
          status: false,
          message: err
        })
      })
  } catch (error) {
    console.log(error);
    res.json({
      status: false,
      message: error?.message
    })
  }
}

//!!20231222am11 coderc To gnerate payment gateway token, added the below function.

exports.generate_payment_method_token = async function (req, res) {
  try {
    let user_id = req.decoded.user_id;
    let data = req.body.data;
    const key = 'VUj1RpEie6m0tYCdDkKckGDMkte';
    const access_secret = 'CTHX9l55oQ44WfV8GZEnxUn8mgxMZhxrofyFvaQ4enNupRv8gfI934YgJLvVop34';
    const authorization = 'Basic ' + btoa(key + ":" + access_secret);
    // const authorization = 'Basic VlVqMVJwRWllNm0wdFlDZERrS2NrR0RNa3RlOkNUSFg5bDU1b1E0NFdmVjhHWkVueFVuOG1neE1aaHhyb2Z5RnZhUTRlbk51cFJ2OGdmSTkzNFlnSkx2Vm9wMzQ='
    let url = 'https://core.spreedly.com/v1/payment_methods.json';
    request
      .post(url)
      .set('Authorization', authorization)
      .set('Host', 'core.spreedly.com')
      .type('json')
      //  .send('\n{\n  "transaction": {\n    "payment_method_token": "Fn37EA7zIoVRLiTRTD984cFTiG7",\n    "amount": 10700,\n    "currency_code": "USD",\n    "retain_on_success": true\n  }\n}\n')
      .send(data)
      .then(result => {
        let transaction = result.body.transaction;
        let firstName = transaction.payment_method.first_name;
        let lastName = transaction.payment_method.last_name;
        let cardType = transaction.payment_method.card_type;
        let paymentMethodType = transaction.payment_method.payment_method_type;
        let paymentMethodToken = transaction.payment_method.token;
        let lastNumber = transaction.payment_method.last_four_digits;
        let month = transaction.payment_method.month;
        let year = transaction.payment_method.year;
        let userToken = transaction.token;
        let transactionType = transaction.transaction_type;
        users.update({ '_id': user_id }, { $push: { payment_method_info: { 'first_name': firstName, 'last_name': lastName, 'card_type': cardType, 'payment_method_type': paymentMethodType, 'payment_method_token': paymentMethodToken, 'token': userToken, 'last_number': lastNumber, 'transaction_type': transactionType, 'month': month, 'year': year } } }).exec((err, res1) => {
          if (err) {
            console.log(err);
            res.json({
              status: false,
              message: 'gateway info update error',
              result: result.body
            });
          }
          res.json({
            status: true,
            message: "successfully",
            result: result.body,
            updatedStatus: res1
          })
        })
      })
      .catch(err => {
        console.log(err);
        res.json({
          status: false,
          message: err
        })
      })
  } catch (error) {
    console.log(error);
    res.json({
      status: false,
      message: error?.message
    })
  }
}

//!!20231223pm8 coderc
exports.sent_coin_notify = async function (req, res) {
  var user_id = req.decoded?.user_id;
  var receiver_id = req.body.receiver_id;
  var coin = req.body.coin;

  try {
    // CREATE NOTIFICATION
    let notif_users = [receiver_id];
    let new_notification = new notificationModel({
      type: NOTIFICATION_TYPES.SEND_COIN,
      filter: null,
      from_id: user_id,
      to_id: receiver_id,
      //!!20231224pm5 coderc To change notification when someone sent tip to someone, changed the below code.
      message: `Sent you a $${coin.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} tip`
      // message: `Sent you ${coin} ${coin > 1 ? "coins" : "coin"} • $${coin.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`
    })

    await new_notification.save();

    res.json({
      status: true,
      message: "Sent successfully",
      result: {
        notif_users
      }
    });
  } catch (error) {
    console.log(error);
    res.json({
      status: false,
      message: "Something went wrong",
    });
  }
};

//!!20231226pm5 coderc To set selected payment gateway token as default, added the belwo api. "(B) Spreedly Test : need Proof send tips"
exports.set_gateway_token_as_default = async function (req, res) {
  var user_id = req.decoded?.user_id;
  let selected_gateway_token = req.body?.token;

  try {
    users.updateOne({'_id': user_id}, {'active_payment_gateway_token': selected_gateway_token}).exec((err, result) => {
      if(err){
        console.log(err);
        res.json({
          status: false,
          message: "Something went wrong",
        });
        return;
      }
      res.json({
        status: true,
        message: "updated successfully!",
        result: result
      });
    })
  } catch (error) {
    console.log(error);
    res.json({
      status: false,
      message: "Something went wrong",
    });
  }
};

//!!20231227pm3 coderc To set selected payment method token as default, added the below function. "(B) Spreedly Test : need Proof send tips"
exports.set_selected_payment_method_as_defult = async function (req, res) {
  var user_id = req.decoded?.user_id;
  let selected_payment_method_token = req.body?.token;

  try {
    users.updateOne({'_id': user_id}, {'active_payment_method_token': selected_payment_method_token}).exec((err, result) => {
      if(err){
        console.log(err);
        res.json({
          status: false,
          message: "Something went wrong",
        });
        return;
      }
      res.json({
        status: true,
        message: "updated successfully!",
        result: result
      });
    })
  } catch (error) {
    console.log(error);
    res.json({
      status: false,
      message: "Something went wrong",
    });
  }
};

//!!20240119pm2 coderC To process age check status, added the below function. "(B)(New) Account Verification: +agecheck.net integration"
exports.age_checker = async function (req, res) {
  var user_id = req.decoded?.user_id;
  try {
    let idVerificationStatus = req.body?.status;
    let idVerificationUuid = req.body?.uuid;
    if(idVerificationStatus == "accepted"){
      let changedIdVerificationStatus = await users.updateOne({"_id": user_id}, {"is_idverified": 1});
      res.json({
        status: true,
        message: "successfully!",
        result: changedIdVerificationStatus
      });
    } else {
      if(idVerificationUuid && idVerificationStatus == "denied"){
        res.json({
          status: false,
          message: "Photo and Id is not matched!",
          result: "P&IDenied"
        });
      } else {
        res.json({
          status: false,
          message: "Access denied",
          result: "AcessDenied"
        });
      }
    }
  } catch (error) {
    console.log(error);
    res.json({
      status: false,
      message: "Something went wrong",
    });
  }
};

//!!20240119pm6 coderC To get current user id verified status, added the below function. "(B)(New) Account Verification: +agecheck.net integration"
exports.get_current_user_id_verified_status = async function (req, res) {
  var user_id = req.decoded?.user_id;
  try {
    let currentUser = await users.findOne({"_id": user_id});
    res.json({
      status: true,
      message: "successfully!",
      result: currentUser?.is_idverified
    });
  } catch (error) {
    console.log(error);
    res.json({
      status: false,
      message: "Something went wrong",
    });
  }
};

//!!20240119pm6 coderC To get current user token again, added the below function. "(B)(New) Account Verification: +agecheck.net integration"
exports.get_current_user_token = async function (req, res) {
  var user_id = req.decoded?.user_id;
  try {
    let user = await users.findOne({"_id": user_id});
    let token = jwt.sign(
      {
        user_id: user._id,
        username: user.username,
        email: user.email,
        first_name: user.first_name,
        last_name: user.last_name,
        profile_image: user.profile_image ? user.profile_image : "",
        status: user.status,
        dob: user.dob,
        phone: user.phone,
        role: user.role,
        is_idverified: user.is_idverified,
        timezone: user.timezone, //20231214pm4 coderd timezone token add
        privacy_safety: user.privacy_safety, //20231219am03 coderB
        safe_list: user.safe_list //20231219am03 coderB
      },
      config.secret_key,
      {
        expiresIn: "24h", // expires in 24 hours
      }
    );
    res.json({
      status: true,
      token: token,
      message: "generated successfully",
    });
  } catch (error) {
    console.log(error);
    res.json({
      status: false,
      message: "Something went wrong",
    });
  }
};

//!!20240121pm5 coderC To pop up edit modal when click edit button, added the below code. "(B) comments - edit and delete not working"
exports.edit_comment = async function (req, res) {
  let id = req.body?.id;
  let description = req.body?.description;
  try {
    commentModel.updateOne({'_id': id}, {'description': description}).exec((err, result) => {
      if(err){
        console.log(err);
        res.json({
          status: false,
          message: "Something went wrong",
        });
        return;
      }
      res.json({
        status: true,
        message: "updated successfully!",
        result: result
      });
    })
  } catch (error) {
    console.log(error);
    res.json({
      status: false,
      message: "Something went wrong",
    });
  }
};

//!!20240121pm5 coderC To remove comment when click delete button, added the below code. "(B) comments - edit and delete not working"
exports.delete_comment = async function (req, res) {
  let id = req.body?.id;
  try {
    commentModel.deleteOne({'_id': id}).exec((err, result) => {
      if(err){
        console.log(err);
        res.json({
          status: false,
          message: "Something went wrong",
        });
        return;
      }
      res.json({
        status: true,
        message: "deleted successfully!",
        result: result
      });
    })
  } catch (error) {
    console.log(error);
    res.json({
      status: false,
      message: "Something went wrong",
    });
  }
};

// 20231219pm11 coderB To get the safelist data in direct message section
exports.get_safelist = async function (req, res) {
  console.log(getErrLine().str, "apistart");
  //!!20231222am02 coderB modify and add
  try {
    const user_id = req.query.user_id || req.decoded?.user_id;
    const safe_users = await users.findOne({ _id: user_id});
    const safe_list = await users.find({ _id: { $in: safe_users?.safe_list }}).select('username profile_image profile_cover first_name last_name email created_date bio privacy_safety safe_list is_idverified');
    res.json({
      status: true,
      message: "Safelist retrieved successfully",
      data: safe_list,
    })
  } catch (error) {
    console.log(error);
    res.json({
      status: false,
      message: error?.message,
    });
  }
}

//!!20231220am05 coderB To manage the data of safelist in direct message section
exports.manage_safelist = async function (req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded.user_id;
  var type = req.body.type;
  var safe_user_id = req.body.safe_user_id;
  var db_safe_list = await users.findOne({_id: user_id, safe_list : { $in: [safe_user_id]}});
  if (type == "add") {
    try {
      if (db_safe_list) {
        res.json({
          status: true,
          message: "Already added",
          param: type,
        });
      } else {
        await users.updateOne({ _id : user_id }, {$push: {safe_list: safe_user_id}});
        res.json({
          status: true,
          message: "Added into safelist successfully",
          param: type,
        });
      }
    } catch (error) {
      console.log(error);
      res.json({
        status: false,
        message: "Error was occured",
        param: type,
        error: error,
        check: checkExist
      });
    }
  } else {
    try {
      if (db_safe_list) {
        await users.updateOne({ _id: user_id }, { $pull : { safe_list: safe_user_id} });
        res.json({
          status: true,
          message: "Removed successfully",
          param: type,
        });
      } else {
        res.json({
          status: true,
          message: "He is already removed before",
          param: type,
        });
      }
    } catch (error) {
      console.log(error);
      res.json({
        status: false,
        message: error?.message,
      })
    }
  }
};


//!20221222am08 coderB To get the data of contact list
/* !!20240104pm5 coderd {( b ) messages - scrolling down stops - but there are still items to be scrolled } */ 
exports.getContactList =async function (req, res) {
// exports.getContactList = function (req, res) {
  console.log(getErrLine().str, "apistart");
  var logged_id = "";
  if (req.body.user_id) {
    logged_id = req.body.user_id;
  }
  var dms = req.body.dms_type ? req.body.dms_type : ""; //value of direct message in privacy & safety section
  var keyword = req.body.keyword ? req.body.keyword.trim() : "";
  var page = req.body.page ? req.body.page : "1";
  var limit = req.body.limit ? req.body.limit : "15";
  var query, basic_search, search;
  if (logged_id) {
    /* !!20240104pm5 coderd {( b ) messages - scrolling down stops - but there are still items to be scrolled } */ 
    var blockerIDS = [
      ...(await blockModel.find({ user_id:req.body.user_id }))?.map(d => d?.block_user_id),
      ...(await blockModel.find({ block_user_id: req.body.user_id }))?.map(d => d?.user_id),
    ];
    // var blockerIDS = [];
    blockerIDS.push(logged_id);
    query = users.find({ _id: { $nin: blockerIDS } });
  } else {
    query = users.find();
  }
  var offset = page == "1" ? 0 : parseInt(page - 1) * 15;
  basic_search = {
    $or: [
      { first_name: { $regex: new RegExp(keyword, "ig") } },
      { last_name: { $regex: new RegExp(keyword, "ig") } },
      { email: { $regex: new RegExp(keyword, "ig") } },
      { username: { $regex: new RegExp(keyword, "ig") } }
    ]
  };
  search = {
    $and: [
      {
        $or: [
          {
            $and: [
              { 'privacy_safety.direct_message': 'everybody'},
              keyword != "" ? basic_search : {}
            ]
          },// in case dms is "everybody"
          { 
            $and: [
              { following : { $in: [logged_id] }},
              { 'privacy_safety.direct_message': 'following' },
              keyword != "" ? basic_search : {}
            ]
          }, // in case dms is 'following'
          {
            $and: [
              { safe_list: { $in: [logged_id] } },
              { 'privacy_safety.direct_message': 'safelist' },
              keyword != "" ? basic_search: {}
            ]
          }, // in case dms is "safelist"
          
        ] 
      },
      {
        $and: [
          { block_list: { $nin: [logged_id] }},
          keyword != "" ? basic_search: {}
        ]
      }, // in case not exists in 'block_list' field
      {
        $and: [
          { mute_list: { $nin: [logged_id] }},
          keyword != "" ? basic_search : {}
        ]
      } // in case not exists in 'mute_list' field
    ]
  };
    
  query = query.or(search);
  query = query.where("status", "active").sort("-create_date");
  var options = {
    select:
      "username email profile_image first_name last_name profile_cover status create_date bio timezone is_idverified privacy_safety safe_list",
    page: page,
    offset: offset,
    limit: limit,
  };
  users.paginate(query, options).then(function (result) {
    res.json({
      status: true,
      message: "Contact list retrieved successfully",
      data: result,
      param: dms
    })
  })
}
