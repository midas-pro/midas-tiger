/*
Project : Cryptotrades
FileName : route.js
Author : Indiefire
File Created : 21/07/2021
CopyRights : Indiefire
Purpose : This is the file which used to define all route releated to media controller
*/

var express = require('express')
var router = express.Router();
var mediaController = require("../controller/mediaController")
var auth = require("../../../middleware/auth");
var multer  = require('multer')
var storage = multer.diskStorage({
    destination: function (req, file, cb) {
      cb(null, 'media/images/user')
    },
    filename: function (req, file, cb) {
      cb(null, file.originalname)
    }
})
var avatarupload = multer({ storage: storage })

var coverstorage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'media/images/cover')
  },
  filename: function (req, file, cb) {
    cb(null, file.originalname)
  }
})
var coverupload = multer({ storage: coverstorage })

var collectionlogostorage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'media/images/collection/logo')
  },
  filename: function (req, file, cb) {
    cb(null, file.originalname)
  }
})
var collectionlogoupload = multer({ storage: collectionlogostorage })

var collectionbannerstorage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'media/images/collection/banner')
  },
  filename: function (req, file, cb) {
    cb(null, file.originalname)
  }
})
var collectionbannerupload = multer({ storage: collectionbannerstorage })


var itemthumbstorage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'media/images/item/thumb')
  },
  filename: function (req, file, cb) {
    cb(null, file.originalname)
  }
})
var itemthumbupload = multer({ storage: itemthumbstorage })

var itemmediastorage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'media/images/item/media')
  },
  filename: function (req, file, cb) {
    cb(null, file.originalname)
  }
})
var itemmediaupload = multer({ storage: itemmediastorage })

var categorystorage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'media/images/categories')
  },
  filename: function (req, file, cb) {
    cb(null, file.originalname)
  }
})
var categoryupload = multer({ storage: categorystorage })

var fanpostimagestorage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'media/images/fanpostimage')
  },
  filename: function (req, file, cb) {
    cb(null, file.originalname)
  }
})
var fanpostimageupload = multer({ storage: fanpostimagestorage })

var fanpostvideostorage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'media/videos/fanpostvideo')
  },
  filename: function (req, file, cb) {
    cb(null, file.originalname)
  }
})
var fanpostvideoupload = multer({ storage: fanpostvideostorage })


var itemcommentimagestorage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'media/images/itemcommentimage')
  },
  filename: function (req, file, cb) {
    cb(null, file.originalname)
  }
})
var itemcommentimageupload = multer({ storage: itemcommentimagestorage })

var itemcommentvideostorage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'media/images/itemcommentvideo')
  },
  filename: function (req, file, cb) {
    cb(null, file.originalname)
  }
})
var itemcommentvideoupload = multer({ storage: itemcommentvideostorage })


var collectioncommentimagestorage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'media/images/collectioncommentimage')
  },
  filename: function (req, file, cb) {
    cb(null, file.originalname)
  }
})
var collectioncommentimageupload = multer({ storage: collectioncommentimagestorage })

var collectioncommentvideostorage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'media/images/collectioncommentvideo')
  },
  filename: function (req, file, cb) {
    cb(null, file.originalname)
  }
})
var collectioncommentvideoupload = multer({ storage: collectioncommentvideostorage })



var fanpostcommentimagestorage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'media/images/fanpostcommentimage')
  },
  filename: function (req, file, cb) {
    cb(null, file.originalname)
  }
})
var fanpostcommentimageupload = multer({ storage: fanpostcommentimagestorage })

var fanpostcommentvideostorage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'media/images/fanpostcommentvideo')
  },
  filename: function (req, file, cb) {
    cb(null, file.originalname)
  }
})
var fanpostcommentvideoupload = multer({ storage: fanpostcommentvideostorage })


var partycommentimagestorage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'media/images/partycommentimage')
  },
  filename: function (req, file, cb) {
    cb(null, file.originalname)
  }
})
var partycommentimageupload = multer({ storage: partycommentimagestorage })

var partycommentvideostorage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'media/images/partycommentvideo')
  },
  filename: function (req, file, cb) {
    cb(null, file.originalname)
  }
})
var partycommentvideoupload = multer({ storage: partycommentvideostorage })

var fandomimagestorage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'media/images/fandomimage')
  },
  filename: function (req, file, cb) {
    cb(null, file.originalname)
  }
})
var fandomimageupload = multer({ storage: fandomimagestorage })


// -- for Message 's img/video/audio Upload
var msgimagestorage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'media/images/msgimage')
  },
  filename: function (req, file, cb) {
    cb(null, file.originalname)
  }
})
var msgimageupload = multer({ storage: msgimagestorage })

var msgvideostorage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'media/videos/msgvideo')
  },
  filename: function (req, file, cb) {
    cb(null, file.originalname)
  }
})
var msgvideoupload = multer({ storage: msgvideostorage })

var msgaudiostorage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'media/audios/msgaudio')
  },
  filename: function (req, file, cb) {
    cb(null, file.originalname)
  }
})
var msgaudioupload = multer({ storage: msgaudiostorage })

router.post('/avatar',avatarupload.single('file'),mediaController.uploadImage)
router.post('/cover',coverupload.single('file'),mediaController.uploadImage)
router.post('/collectionlogo',collectionlogoupload.single('file'),mediaController.uploadImage)
router.post('/collectionbanner',collectionbannerupload.single('file'),mediaController.uploadImage)
router.post('/itemthumb',itemthumbupload.single('file'),mediaController.uploadImage)
router.post('/itemmedia',itemmediaupload.single('file'),mediaController.uploadImage)
router.post('/category',categoryupload.single('file'),mediaController.uploadImage)
router.post('/fanpostimage',fanpostimageupload.single('file'),mediaController.uploadImage)
router.post('/fanpostvideo',fanpostvideoupload.single('file'),mediaController.uploadFile)
router.post('/fanpostcommentimage',fanpostcommentimageupload.single('file'),mediaController.uploadImage)
router.post('/fanpostcommentvideo',fanpostcommentvideoupload.single('file'),mediaController.uploadFile)
router.post('/partycommentimage',partycommentimageupload.single('file'),mediaController.uploadImage)
router.post('/partycommentvideo',partycommentvideoupload.single('file'),mediaController.uploadFile)
router.post('/itemcommentimage',itemcommentimageupload.single('file'),mediaController.uploadImage)
router.post('/itemcommentvideo',itemcommentvideoupload.single('file'),mediaController.uploadFile)
router.post('/collectioncommentimage',collectioncommentimageupload.single('file'),mediaController.uploadImage)
router.post('/collectioncommentvideo',collectioncommentvideoupload.single('file'),mediaController.uploadFile)
router.post('/msgimage',msgimageupload.single('file'),mediaController.uploadImage)
router.post('/msgvideo',msgvideoupload.single('file'),mediaController.uploadFile)
router.post('/msgaudio',msgaudioupload.single('file'),mediaController.uploadFile)
router.post('/fandomimage', fandomimageupload.single('file'), mediaController.uploadImage)

router.post('/addMedia',mediaController.addMedia)
router.put('/update', auth, mediaController.update);
router.post('/listMedia',mediaController.listMedia)
router.get('/uploaded_list', auth, mediaController.uploaded_list)
module.exports = router