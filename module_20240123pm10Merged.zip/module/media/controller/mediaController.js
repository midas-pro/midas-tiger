var request = require("request");
var fs = require("fs");
var download = require('image-downloader');
var moment = require('moment');
var validator = require('validator');
const { validationResult } = require('express-validator');
var users = require('../../user/model/userModel');
var medias = require('../model/mediaModel');
const { getErrLine } = require("../../helper/helpers");

exports.saveFacebookImageUrl = function(url,imgname,callback) {
  console.log(getErrLine().str, "apistart");
    request(url, function(err, res, body) {
        var data = JSON.parse(body)
        options = {
            url: data.data.url,
            dest: __basedir +'/media/images/user/'+imgname+'.jpg'      // will be saved to /path/to/dest/photo.jpg
          }
          download.image(options)
          .then(({ filename }) => {
            callback("success")
          });
    });

}

exports.saveImageUrl = function(url,imgname,callback) {
  console.log(getErrLine().str, "apistart");
    var options = {
        url: url,
        dest: __basedir +'/media/images/user/'+imgname+'.jpg'      // will be saved to /path/to/dest/photo.jpg
      }
      download.image(options)
      .then(({ filename }) => {
        callback("success")
      });
}

exports.uploadImage = function (req,res) {
  console.log(getErrLine().str, "apistart");
  res.json({
    status: true,
    message: 'image upload successfully completed',
    // param: req,
  })
}

exports.uploadFile = function (req,res) {
  console.log(getErrLine().str, "apistart");
  res.json({
    status: true,
    message: 'File upload successfully completed',
    // param: req,
  })
}

exports.addMedia = function ( req, res ) {
  console.log(getErrLine().str, "apistart");
  var media = new medias();
  media.url = req.body.url;
  media.type = req.body.type;
  media.creator_id = req.body.creator_id;
  media.name = req.body.name;
  media.create_date = Date.now();
  media.save(function (err , mediaObj) {
      if (err) {
          res.json({
              status: false,
              message: "Request failed",
              errors:err,
              // param: req,
          });
          return;
      }
      res.json({
          status: true,
          message: "Media created successfully",
          result: mediaObj,
          // param: req,
      });
  });
}

exports.listMedia = function ( req, res ) {
  console.log(getErrLine().str, "apistart");
  var page = req.query.page ? req.query.page : '1';  
  var limit = req.query.limit ? req.query.limit : '300';  
  var query = medias.find({creator_id: req.body.creator_id});
  var offset = ( page == '1' ) ? 0 : ((parseInt(page-1))*limit); 
  // query = query.where('creator_id',req.query.user_id)
  query = query.sort('-create_date')
  var options = {
    select:   'url type name create_date',
    page:page,
    offset:offset,
    limit:limit,    
  };  
  medias.paginate(query, options).then(function (result) {
      res.json({
          status: true,
          message: "Party retrieved successfully",
          data: result
      });
  }); 
}

exports.uploaded_list = function(req, res) {
  console.log(getErrLine().str, "apistart");
  var page = req.query.page || 1;  
  var limit = req.query.limit || 300;  
  var sortKey = req.query.sortKey || 'newest';
  var keyword = req.query.keyword || '';
  var type = req.query.type;
  var filterBy = req.query.filterBy;

  var query = medias.find({creator_id: req.decoded.user_id});
  var offset = ( page == '1' ) ? 0 : ((parseInt(page-1))*limit); 
  // query = query.where('creator_id',req.query.user_id)

  if(sortKey == 'newest') {
    query = query.sort('-create_date')
  } else {
    query = query.sort('create_date')
  }


  switch(filterBy) {
    case 'audio':
      query = query.find({ type: 'audio' }); break;
    case '1280-720':
      query = query.find({ type: 'image' });
      query = query.find({ size: '1280-720' });
      break;
    case '1600-1600':
      query = query.find({ type: 'image' });
      query = query.find({ size: '1600-1600' });
      break;
    case 'video':
      query = query.find({ type: 'video' });
      break;
    default:
      break;
  }

  
  if(type) {
    switch(type) {
      case 'image':
      case 'video':
      case 'audio':
        query = query.find({ type });
        break;
      default:
        break;
    }
  }

  if(keyword != "") {
    query = query.find({ name:  { $regex: new RegExp(keyword, "ig") } })
  }

  var options = {
    select:   'url type name create_date',
    page:page,
    offset:offset,
    limit:limit,    
  };  
  medias.paginate(query, options).then(function (result) {
      res.json({
          status: true,
          message: "Party retrieved successfully",
          data: result
      });
  });
}

exports.update = function(req, res) {
  console.log(getErrLine().str, "apistart");
  var user_id = req.decoded.user_id;
  medias.findByIdAndUpdate(req.body._id, req.body, function(err, result) {
    if(err) {
      res.josn({
        status: false,
        message: "Db Error"
      })
    } else {
      res.json({
        status: true,
        message: "Updated successfully"
      });
    }
  })
}