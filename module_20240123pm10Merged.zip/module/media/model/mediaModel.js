/*
Project : Cryptotrades
FileName : mediaModel.js
Author : Indiefire
File Created : 15/04/2023
CopyRights : Indiefire
Purpose : This is the file which used to define media collection that will communicate and process media information with mongodb through mongoose ODM.
*/

var mongoose = require('mongoose');
var mongoosePaginate = require('mongoose-paginate-v2');
var uniqueValidator = require('mongoose-unique-validator');
var config = require('../../../helper/config')
const Schema = mongoose.Schema;

// Setup schema
var mediaSchema = mongoose.Schema({
    url: {
        type: String,
    },
    type: {
        type: String,
        default: 'image',//image,audio,file,item,video,
    },
    creator_id: { type: Schema.Types.ObjectId, ref: 'users' },
    name: {
        type: String,
    },    
    size: {
        type: String,
    },
    create_date: {
        type: Date,
        default: Date.now
    },
});

mediaSchema.plugin(uniqueValidator);
mediaSchema.plugin(mongoosePaginate);

module.exports = mongoose.model('media', mediaSchema,config.db.prefix+'media');