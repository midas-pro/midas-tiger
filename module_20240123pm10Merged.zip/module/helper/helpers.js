const moment = require('moment');
const log = console.log;
const path = require('path');

function getTime(time) { return moment().format('YYYY-MM-DD HH:mm:ss') };

function getErrLine(num = 2) {
    const e = new Error();
    const regex = /\((.*):(\d+):(\d+)\)$/
    const match = regex.exec(e.stack.split("\n")[num]);
    const filepath = match[1];
    const fileName = path.basename(filepath);
    const line = match[2];
    const column = match[3];
    return {
        filepath,
        fileName,
        line,
        column,
        str: `${getTime()} - ${fileName}:${line}:${column}`
    };
}

const getDateStr = (date) =>  {
  var datestr = `${date.getFullYear()}${("0" + (date.getMonth() + 1)).substr(
    -2
  )}${("0" + date.getDate()).substr(-2)}`;
  return datestr;
}

module.exports = {
    getDateStr,
    getErrLine
}