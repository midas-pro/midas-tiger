const request = require('request');
const he = require('he');

class ElasticMail {

	constructor(apiKey, apiURI, config) {
		this.defaultConfig = {
			apiKey: apiKey,
			isTransactional: true,
		};

		this.apiKey = apiKey;
		this.apiURI = apiURI || 'https://api.elasticemail.com/v2';
		this.setConfig(config);
	}

	post(path, options, attachments) {
		return new Promise((resolve, reject) => {
			const req = request.post(this.apiURI + path, (err, res, body) => {
				if (err) {
					reject(err);
				}
				resolve(body);
			});

			const form = req.form();

			for (let key in options) {
				form.append(key, String(options[key]));
			}


		});
	}

	setConfig(options) {
		this.config = Object.assign(this.defaultConfig, options);
	}

	send(params, attachments) {
		return this.post('/email/send', Object.assign(this.config, params));
	}
}

const API_KEY = "35D5D3BC687A71E81DB219A207234648E9A8213D226D7C8674D4876B895BEC946800B40E0F37CD4FAB5080CC166F5D20";

const reset_password = async (email, subject, link) => {
	return new Promise(async (resolve, reject) => {
		try {
			try {
				var mg = new ElasticMail(API_KEY);
				var logoLink = 'https://indiefire.io:3306/images/desktop-logo.png';
				var imgLink = 'https://indiefire.io:3306/images/lock.png'
				var reqData = {
					fromName: "IndieFire",
					from: "help@high5ivemail.io",
					subject,
					msgTo: [email],
					bodyHtml: `
                    <!DOCTYPE html>
                    <html>
                    <head>
                    <style type='text/css'>
						* {
							color: white;
						}
						div {
							display: none !important;
						}
						.d-block {
							display: block !important;
						}
						.link {
							display: inline-block;
							line-height: 1.5;
							text-align: center;
							text-decoration: none;
							vertical-align: middle;
							cursor: pointer;
							-webkit-user-select: none;
							-moz-user-select: none;
							user-select: none;
							background-color: transparent;
							padding: 0.75rem 2.5rem;
							border-radius: 0.25rem;
							transition: color .15s ease-in-out, background-color .15s ease-in-out, border-color .15s ease-in-out, box-shadow .15s ease-in-out;
							border-radius: 10px;
							background: #1B1F2D;
							white-space: nowrap;
							overflow: hidden;
							text-overflow: ellipsis;
							background: linear-gradient(
								180deg,
								rgba(229, 3, 87, 1) 0%,
								rgba(229, 3, 56, 1) 35%,
								rgba(219, 101, 17, 1) 100%
							);
							color: white !important;
                       }
                       .link:hover {
                            background: #DDD;
                       }
                       .link:active {
                            outline: 1px solid #ddd;
                       }
                       .text-center {
                            text-align: center
                       }
                       .bg-dark {
							background: #0C101B !important;
                       }
					   .bg-card {
							background: #20242e !important;
					   }
					   .radius-12 {
							border-radius: 12px !important;
						}
						.text-white {
							color: white !important;
						}
						a {
							color: white !important;
						}
						.description {
							max-width: 360px;
							margin: auto;
							margin-bottom: 36px !important;
						}
                    </style>
                    </head>
                        <body class="text-center bg-dark" style="padding: 2rem;">
							<img src=${logoLink} style="height: 70px; margin-bottom: 2rem"/>
                            <main style="max-width: 600px; margin: auto; padding: 2rem 0" class="bg-card radius-12">
								<img src=${imgLink} style="height: 70px; margig-bottom: 36px"/>
								<h1 style="text-align: center; font-size: 30px; margin-bottom: 36px">Forgot your password?</h1>
                                <div class="description d-block">
									That's okay, it happens. Click on the button below in the next 20 minutes to reset your password.
								</div>
								<div style="text-align: center; margin-bottom: 36px" class="d-block">
                                    <a href=${link} target="blank" class="link">Reset your password</a>
                                </div>
								<div class="text-center d-block">
									Problems or questions? Email us at
									<div class="text-center text-white d-block">
										hello@high5ivemail.io
									</div>
								</div>
                            </main>
							<footer class="text-center" style="margin-top: 2rem">@${new Date().getFullYear()} High5ive</footer>
                        </body>
                    </html>
                    `
				}
				console.log(reqData);
				var res = await mg.send(reqData);
				console.log(res)
				resolve(JSON.parse(res))
			} catch (error) {
				console.log(error);
				reject(error)
			}
		} catch (error) {
			console.log(error);
			reject(error);
		}
	})
}

module.exports = {
	reset_password
};


// const Mailgun = require("mailgun.js");
// const formData = require('form-data');

// const DOMAIN = "sandbox35f8a56aff9441a0b200f06aa6341c95.mailgun.org";
// const API_KEY = "6b07232bb49aa5a435f89c25e84260b5-db137ccd-3c592b5e";

// const mailgun = new Mailgun(formData);
// // const mg = mailgun({ apiKey: API_KEY, domain: DOMAIN });
// const mg = mailgun.client({ username: 'API', key: API_KEY });

// const reset_password = async (email, subject, link) => {
//     return new Promise(async (resolve, reject) => {
//         try {
//             let msg = {
//                 from: 'test1@sandbox35f8a56aff9441a0b200f06aa6341c95.mailgun.org',
//                 to: email,
//                 subject,
//                 html: `
                // <html>
                // <style>
                //     a:hover {
                //         color: black
                //     }
                // </style>
                // <h1>Reset your password</h1>
                // <a href="${link}" target="blank" style="text-decoration: underline; color: #fe23df; cursor: pointer">Reset your password</a>
                // </html>
//                 `
//             }
//             try {
//                 await mg.messages.create(DOMAIN, msg);
//                 resolve(true)
//             } catch (error) {
//                 reject(error);
//             }
//         } catch (error) {
//             console.log(error);
//             reject(error);
//             return;
//         }
//     })
// }


// module.exports = {
//     reset_password
// }
