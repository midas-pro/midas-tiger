module.exports = [
	{
		name:"Fedex",
		code:"fedex"
	}, {
		name:"DHL Express",
		code:"dhl"
	}, {
		name:"UPS",
		code:"ups"
	}, {
		name:"TNT",
		code:"tnt"
	}, {
		name:"China Post",
		code:"china-post"
	}, {
		name:"China EMS",
		code:"china-ems"
	}, {
		name:"Hong Kong Post",
		code:"hong-kong-post"
	}, {
		name:"Swiss Post",
		code:"swiss-post"
	}, {
		name:"USPS",
		code:"usps"
	}, {
		name:"UK Royal Mail",
		code:"royal-mail"
	}, {
		name:"PostNL International",
		code:"postnl-parcels"
	}, {
		name:"Canada Post",
		code:"canada-post"
	}, {
		name:"Australia Post",
		code:"australia-post"
	}, {
		name:"New Zealand Post",
		code:"new-zealand-post"
	}, {
		name:"Parcel Force",
		code:"parcel-force"
	}, {
		name:"Bpost",
		code:"belgium-post"
	}, {
		name:"Brazil Correios",
		code:"brazil-correios"
	}, {
		name:"Russian Post",
		code:"russian-post"
	}, {
		name:"PostNord",
		code:"sweden-posten"
	}, {
		name:"La Poste",
		code:"laposte"
	}, {
		name:"Poste Italiane",
		code:"poste-italiane"
	}, {
		name:"Aland Post",
		code:"aland-post"
	}, {
		name:"Afghan Post",
		code:"afghan-post"
	}, {
		name:"Albania Post",
		code:"posta-shqiptare"
	}, {
		name:"Andorra Post",
		code:"andorra-post"
	}, {
		name:"Antilles Post",
		code:"antilles-post"
	}, {
		name:"Argentina Post",
		code:"correo-argentino"
	}, {
		name:"Armenia Post",
		code:"armenia-post"
	}, {
		name:"Aruba Post",
		code:"aruba-post"
	}, {
		name:"Australia EMS",
		code:"australia-ems"
	}, {
		name:"Austrian Post",
		code:"austria-post"
	}, {
		name:"Azerbaijan Post",
		code:"azerbaijan-post"
	}, {
		name:"Bahrain Post",
		code:"bahrain-post"
	}, {
		name:"Bangladesh EMS",
		code:"bangladesh-ems"
	}, {
		name:"Barbados Post",
		code:"barbados-post"
	}, {
		name:"Belarus Post",
		code:"belpochta"
	}, {
		name:"Belize Post",
		code:"belize-post"
	}, {
		name:"Benin Post",
		code:"benin-post"
	}, {
		name:"Bermuda Post",
		code:"bermuda-post"
	}, {
		name:"Bhutan Post",
		code:"bhutan-post"
	}, {
		name:"Bolivia Post",
		code:"correos-bolivia"
	}, {
		name:"Bosnia And Herzegovina Post",
		code:"bosnia-and-herzegovina-post"
	}, {
		name:"Botswana Post",
		code:"botswana-post"
	}, {
		name:"Brunei Post",
		code:"brunei-post"
	}, {
		name:"Bulgaria Post",
		code:"bulgaria-post"
	}, {
		name:"Burkina Faso Post",
		code:"sonapost"
	}, {
		name:"Burundi Post",
		code:"burundi-post"
	}, {
		name:"Cambodia Post",
		code:"cambodia-post"
	}, {
		name:"Cameroon Post",
		code:"campost"
	}, {
		name:"Correios Cabo Verde",
		code:"correios-cabo-verde"
	}, {
		name:"Colombia Post",
		code:"colombia-post"
	}, {
		name:"Croatia Post",
		code:"hrvatska-posta"
	}, {
		name:"Cuba Post",
		code:"cuba-post"
	}, {
		name:"Cyprus Post",
		code:"cyprus-post"
	}, {
		name:"Czech Post",
		code:"czech-post"
	}, {
		name:"Denmark post",
		code:"denmark-post"
	}, {
		name:"Dominican Post",
		code:"inposdom"
	}, {
		name:"Ecuador Post",
		code:"correos-del-ecuador"
	}, {
		name:"El Salvador Post",
		code:"el-salvador-post"
	}, {
		name:"Eritrea Post",
		code:"eritrea-post"
	}, {
		name:"Estonia Post",
		code:"omniva"
	}, {
		name:"Ethiopia Post",
		code:"ethiopia-post"
	}, {
		name:"Faroe Islands Post",
		code:"faroe-islands-post"
	}, {
		name:"Fiji Post",
		code:"fiji-post"
	}, {
		name:"Finland Post - Posti",
		code:"finland-posti"
	}, {
		name:"Colissimo",
		code:"colissimo"
	}, {
		name:"Chronopost",
		code:"chronopost"
	}, {
		name:"Georgia Post",
		code:"georgian-post"
	}, {
		name:"Deutsche Post",
		code:"deutsche-post"
	}, {
		name:"Ghana Post",
		code:"ghana-post"
	}, {
		name:"Gibraltar  Post",
		code:"gibraltar-post"
	}, {
		name:"ELTA Hellenic Post",
		code:"greece-post"
	}, {
		name:"Greenland Post",
		code:"tele-post"
	}, {
		name:"Guatemala Post",
		code:"elcorreo"
	}, {
		name:"Guernsey Post",
		code:"guernsey-post"
	}, {
		name:"Magyar Posta",
		code:"magyar-posta"
	}, {
		name:"Iceland Post",
		code:"iceland-post"
	}, {
		name:"India Post",
		code:"india-post"
	}, {
		name:"Indonesia Post",
		code:"indonesia-post"
	}, {
		name:"Iran Post",
		code:"iran-post"
	}, {
		name:"An Post",
		code:"an-post"
	}, {
		name:"Israel Post",
		code:"israel-post"
	}, {
		name:"Ivory Coast EMS",
		code:"ivory-coast-ems"
	}, {
		name:"Jamaica Post",
		code:"jamaica-post"
	}, {
		name:"Japan Post",
		code:"japan-post"
	}, {
		name:"Jordan Post",
		code:"jordan-post"
	}, {
		name:"Kazakhstan Post",
		code:"kazpost"
	}, {
		name:"Kenya Post",
		code:"kenya-post"
	}, {
		name:"Korea Post",
		code:"korea-post"
	}, {
		name:"Kyrgyzstan Post",
		code:"kyrgyzpost"
	}, {
		name:"Laos Post",
		code:"laos-post"
	}, {
		name:"Latvia Post",
		code:"latvijas-pasts"
	}, {
		name:"Lebanon Post",
		code:"liban-post"
	}, {
		name:"Lesotho Post",
		code:"lesotho-post"
	}, {
		name:"Liechtenstein Post",
		code:"liechtenstein-post"
	}, {
		name:"Lithuania Post",
		code:"lietuvos-pastas"
	}, {
		name:"Luxembourg Post",
		code:"luxembourg-post"
	}, {
		name:"Macao Post",
		code:"macao-post"
	}, {
		name:"Macedonia Post",
		code:"macedonia-post"
	}, {
		name:"Malaysia Post",
		code:"malaysia-post"
	}, {
		name:"Maldives Post",
		code:"maldives-post"
	}, {
		name:"Malta Post",
		code:"malta-post"
	}, {
		name:"Mauritius Post",
		code:"mauritius-post"
	}, {
		name:"Mexico Post",
		code:"correos-mexico"
	}, {
		name:"Moldova Post",
		code:"moldova-post"
	}, {
		name:"Monaco Post",
		code:"la-poste-monaco"
	}, {
		name:"Monaco EMS",
		code:"monaco-ems"
	}, {
		name:"Mongol Post",
		code:"mongol-post"
	}, {
		name:"Montenegro Post",
		code:"posta-crne-gore"
	}, {
		name:"Maroc Poste",
		code:"poste-maroc"
	}, {
		name:"Namibia Post",
		code:"namibia-post"
	}, {
		name:"Netherlands Post",
		code:"netherlands-post"
	}, {
		name:"New Caledonia Post",
		code:"new-caledonia-post"
	}, {
		name:"Nicaragua Post",
		code:"nicaragua-post"
	}, {
		name:"Nigeria Post",
		code:"nigeria-post"
	}, {
		name:"Posten Norge",
		code:"posten-norge"
	}, {
		name:"Oman Post",
		code:"oman-post"
	}, {
		name:"Overseas Territory FR EMS",
		code:"overseas-territory-fr-ems"
	}, {
		name:"Overseas Territory US Post",
		code:"overseas-territory-us-post"
	}, {
		name:"Pakistan Post",
		code:"pakistan-post"
	}, {
		name:"Panama Post",
		code:"correos-panama"
	}, {
		name:"Papua New Guinea Post",
		code:"postpng"
	}, {
		name:"Paraguay Post",
		code:"correo-paraguayo"
	}, {
		name:"Serpost",
		code:"serpost"
	}, {
		name:"Philippines Post",
		code:"phlpost"
	}, {
		name:"Poland Post",
		code:"poczta-polska"
	}, {
		name:"Portugal Post - CTT",
		code:"ctt"
	}, {
		name:"Qatar Post",
		code:"qatar-post"
	}, {
		name:"Romania Post",
		code:"posta-romana"
	}, {
		name:"Rwanda Post",
		code:"iposita-rwanda"
	}, {
		name:"Saint Lucia Post",
		code:"saint-lucia-post"
	}, {
		name:"Saint Vincent And The Grenadines",
		code:"svgpost"
	}, {
		name:"Samoa Post",
		code:"samoa-post"
	}, {
		name:"San Marino Post",
		code:"san-marino-post"
	}, {
		name:"Saudi Post",
		code:"saudi-post"
	}, {
		name:"Senegal Post",
		code:"senegal-post"
	}, {
		name:"Serbia Post",
		code:"serbia-post"
	}, {
		name:"Seychelles Post",
		code:"seychelles-post"
	}, {
		name:"Slovakia Post",
		code:"slovakia-post"
	}, {
		name:"Slovenia Post",
		code:"slovenia-post"
	}, {
		name:"Solomon Post",
		code:"solomon-post"
	}, {
		name:"South African Post Office",
		code:"south-africa-post"
	}, {
		name:"Correos Spain",
		code:"correos-spain"
	}, {
		name:"Sri Lanka Post",
		code:"sri-lanka-post"
	}, {
		name:"Sudan Post",
		code:"sudan-post"
	}, {
		name:"Syrian Post",
		code:"syrian-post"
	}, {
		name:"Chunghwa POST",
		code:"taiwan-post"
	}, {
		name:"Tanzania Post",
		code:"tanzania-post"
	}, {
		name:"Thailand Post",
		code:"thailand-post"
	}, {
		name:"Togo Post",
		code:"togo-post"
	}, {
		name:"Tonga Post",
		code:"tonga-post"
	}, {
		name:"Tunisia Post",
		code:"tunisia-post"
	}, {
		name:"Turkey Post",
		code:"turkey-post"
	}, {
		name:"Turkmenistan Post",
		code:"turkmenistan-post"
	}, {
		name:"Tuvalu Post",
		code:"tuvalu-post"
	}, {
		name:"Uganda Post",
		code:"uganda-post"
	}, {
		name:"Ukraine Post",
		code:"ukraine-post"
	}, {
		name:"Ukraine EMS",
		code:"ukraine-ems"
	}, {
		name:"Emirates Post",
		code:"emirates-post"
	}, {
		name:"Uruguay Post",
		code:"uruguay-post"
	}, {
		name:"Uzbekistan Post",
		code:"uzbekistan-post"
	}, {
		name:"Uzbekistan EMS",
		code:"uzbekistan-ems"
	}, {
		name:"Vanuatu Post",
		code:"vanuatu-post"
	}, {
		name:"Vietnam Post",
		code:"vietnam-post"
	}, {
		name:"Yemen Post",
		code:"yemen-post"
	}, {
		name:"Zambia Post",
		code:"zambia-post"
	}, {
		name:"Zimbabwe Post",
		code:"zimbabwe-post"
	}, {
		name:"YANWEN",
		code:"yanwen"
	}, {
		name:"GLS",
		code:"gls"
	}, {
		name:"BRT Bartolini",
		code:"bartolini"
	}, {
		name:"DPD",
		code:"dpd"
	}, {
		name:"SF International Small Packet",
		code:"sfb2c"
	}, {
		name:"Aramex",
		code:"aramex"
	}, {
		name:"TOLL",
		code:"toll"
	}, {
		name:"DHL Germany",
		code:"dhl-germany"
	}, {
		name:"4PX",
		code:"4px"
	}, {
		name:"Flyt Express",
		code:"flytexpress"
	}, {
		name:"Yun Express",
		code:"yunexpress"
	}, {
		name:"One World Express",
		code:"oneworldexpress"
	}, {
		name:"DHL Parcel NL",
		code:"dhlparcel-nl"
	}, {
		name:"DHL Poland Domestic",
		code:"dhl-poland"
	}, {
		name:"DHL Spain Domestic",
		code:"dhl-es"
	}, {
		name:"TNT Italy",
		code:"tnt-it"
	}, {
		name:"TNT France",
		code:"tnt-fr"
	}, {
		name:"DPD UK",
		code:"dpd-uk"
	}, {
		name:"TNT UK",
		code:"tnt-uk"
	}, {
		name:"GLS Italy",
		code:"gls-italy"
	}, {
		name:"Toll IPEC",
		code:"toll-ipec"
	}, {
		name:"Asendia USA",
		code:"asendia-usa"
	}, {
		name:"Asendia UK",
		code:"asendia-uk"
	}, {
		name:"Yodel",
		code:"yodel"
	}, {
		name:"Asendia Germany",
		code:"asendia-de"
	}, {
		name:"Kerry Logistics",
		code:"kerry-logistics"
	}, {
		name:"XRU",
		code:"xru"
	}, {
		name:"DPEX",
		code:"dpex"
	}, {
		name:"Ruston",
		code:"ruston"
	}, {
		name:"UPU",
		code:"upu"
	}, {
		name:"Bluedart",
		code:"bluedart"
	}, {
		name:"DTDC",
		code:"dtdc"
	}, {
		name:"GoJavas",
		code:"gojavas"
	}, {
		name:"First Flight",
		code:"first-flight"
	}, {
		name:"Gati-KWE",
		code:"gati-kwe"
	}, {
		name:"ROSAN EXPRESS",
		code:"rosan"
	}, {
		name:"WSGD Logistics",
		code:"wsgd-logistics"
	}, {
		name:"WishPost",
		code:"wishpost"
	}, {
		name:"STO Express",
		code:"sto"
	}, {
		name:"YTO Express",
		code:"yto"
	}, {
		name:"ZTO Express",
		code:"zto"
	}, {
		name:"DHL ECommerce",
		code:"dhlglobalmail"
	}, {
		name:"DSV",
		code:"dsv"
	}, {
		name:"Echo",
		code:"echo"
	}, {
		name:"DPD Ireland",
		code:"dpd-ireland"
	}, {
		name:"OnTrac",
		code:"ontrac"
	}, {
		name:"Purolator",
		code:"purolator"
	}, {
		name:"Fastway New Zealand",
		code:"fastway-nz"
	}, {
		name:"Aramex Australia(Fastway Australia)",
		code:"fastway-au"
	}, {
		name:"Fastway Ireland",
		code:"fastway-ie"
	}, {
		name:"I-parcel",
		code:"i-parcel"
	}, {
		name:"LaserShip",
		code:"lasership"
	}, {
		name:"SkyNet Worldwide Express",
		code:"skynetworldwide"
	}, {
		name:"PFC Express",
		code:"pfcexpress"
	}, {
		name:"Nexive",
		code:"nexive"
	}, {
		name:"RL Carriers",
		code:"rl-carriers"
	}, {
		name:"Nanjing Woyuan",
		code:"nanjingwoyuan"
	}, {
		name:"LWE",
		code:"lwehk"
	}, {
		name:"Hua Han Logistics",
		code:"hhexp"
	}, {
		name:"Envialia",
		code:"envialia"
	}, {
		name:"Canpar Courier",
		code:"canpar"
	}, {
		name:"Delcart",
		code:"delcart-in"
	}, {
		name:"City-Link Express",
		code:"citylinkexpress"
	}, {
		name:"2GO",
		code:"2go"
	}, {
		name:"Xend Express",
		code:"xend"
	}, {
		name:"AIR21",
		code:"air21"
	}, {
		name:"Airspeed International Corporation",
		code:"airspeed"
	}, {
		name:"RAF Philippines",
		code:"raf"
	}, {
		name:"Wahana",
		code:"wahana"
	}, {
		name:"Giao Hàng Nhanh",
		code:"ghn"
	}, {
		name:"Viettel Post",
		code:"viettelpost"
	}, {
		name:"Dotzot",
		code:"dotzot"
	}, {
		name:"Kangaroo Worldwide Express",
		code:"kangaroo-my"
	}, {
		name:"Maxcellents Pte Ltd",
		code:"maxcellents"
	}, {
		name:"Nationwide Express",
		code:"nationwide-my"
	}, {
		name:"RPX Online",
		code:"rpxonline"
	}, {
		name:"Nhans Solutions",
		code:"nhans-solutions"
	}, {
		name:"Jet-Ship Worldwide",
		code:"jet-ship"
	}, {
		name:"Ecargo",
		code:"ecargo-asia"
	}, {
		name:"Delhivery",
		code:"delhivery"
	}, {
		name:"Ecom Express",
		code:"ecom-express"
	}, {
		name:"GDEX",
		code:"gdex"
	}, {
		name:"SkyNet Malaysia",
		code:"skynet"
	}, {
		name:"SFC Service",
		code:"sfcservice"
	}, {
		name:"EC-Firstclass",
		code:"ec-firstclass"
	}, {
		name:"WeDo Logistics",
		code:"wedo"
	}, {
		name:"JCEX",
		code:"jcex"
	}, {
		name:"CNE Express",
		code:"cnexps"
	}, {
		name:"Equick China",
		code:"equick-cn"
	}, {
		name:"EMPS Express",
		code:"empsexpress"
	}, {
		name:"DPE Express",
		code:"dpe-express"
	}, {
		name:"Bonds Couriers",
		code:"bondscouriers"
	}, {
		name:"CourierPost",
		code:"courierpost"
	}, {
		name:"ACOMMERCE",
		code:"acommerce"
	}, {
		name:"139 ECONOMIC Package",
		code:"139express"
	}, {
		name:"UBI Smart Parcel",
		code:"ubi-logistics"
	}, {
		name:"MRW",
		code:"mrw-spain"
	}, {
		name:"Packlink",
		code:"packlink"
	}, {
		name:"Colis Prive",
		code:"colis-prive"
	}, {
		name:"FedEx Poland Domestic",
		code:"opek"
	}, {
		name:"SGT Corriere Espresso",
		code:"sgt-it"
	}, {
		name:"KGM Hub",
		code:"kgmhub"
	}, {
		name:"Qxpress",
		code:"qxpress"
	}, {
		name:"SRE Korea",
		code:"srekorea"
	}, {
		name:"Yamato Japan",
		code:"taqbin-jp"
	}, {
		name:"Sagawa",
		code:"sagawa"
	}, {
		name:"ABX Express",
		code:"abxexpress-my"
	}, {
		name:"Mypostonline",
		code:"mypostonline"
	}, {
		name:"Jam Express",
		code:"jam-express"
	}, {
		name:"Jayon Express (JEX)",
		code:"jayonexpress"
	}, {
		name:"RPX Indonesia",
		code:"rpx"
	}, {
		name:"RaidereX",
		code:"raiderex"
	}, {
		name:"RZY Express",
		code:"rzyexpress"
	}, {
		name:"Airpak Express",
		code:"airpak-express"
	}, {
		name:"LBC Express",
		code:"lbcexpress"
	}, {
		name:"Pandu Logistics",
		code:"pandulogistics"
	}, {
		name:"Collect+",
		code:"collectplus"
	}, {
		name:"Skynet Worldwide Express UK",
		code:"skynetworldwide-uk"
	}, {
		name:"Hermesworld",
		code:"hermes"
	}, {
		name:"Nightline",
		code:"nightline"
	}, {
		name:"APC Postal Logistics",
		code:"apc"
	}, {
		name:"Newgistics",
		code:"newgistics"
	}, {
		name:"Old Dominion Freight Line",
		code:"old-dominion"
	}, {
		name:"Estes",
		code:"estes"
	}, {
		name:"Greyhound",
		code:"greyhound"
	}, {
		name:"Globegistics Inc.",
		code:"globegistics"
	}, {
		name:"TGX",
		code:"tgx"
	}, {
		name:"ZJS International",
		code:"zjs-express"
	}, {
		name:"Hermes Germany",
		code:"hermes-de"
	}, {
		name:"Spanish Seur",
		code:"international-seur"
	}, {
		name:"P2P TrakPak",
		code:"trakpak"
	}, {
		name:"Matkahuolto",
		code:"matkahuolto"
	}, {
		name:"ACS Courier",
		code:"acscourier"
	}, {
		name:"DPD Poland",
		code:"dpd-poland"
	}, {
		name:"Geniki Taxydromiki",
		code:"taxydromiki"
	}, {
		name:"CBL Logistics",
		code:"cbl-logistica"
	}, {
		name:"Redur Spain",
		code:"redur-es"
	}, {
		name:"Siodemka",
		code:"siodemka"
	}, {
		name:"DPD France",
		code:"exapaq"
	}, {
		name:"Global Cainiao",
		code:"cainiao"
	}, {
		name:"ETS Express",
		code:"ets-express"
	}, {
		name:"Ali Business Logistics",
		code:"al8856"
	}, {
		name:"Anjun Logistics",
		code:"anjun"
	}, {
		name:"Quantium",
		code:"quantium"
	}, {
		name:"XQ Express",
		code:"xqwl"
	}, {
		name:"Alpha Fast",
		code:"alpha-fast"
	}, {
		name:"Omni Parcel",
		code:"omniparcel"
	}, {
		name:"CDEK Express",
		code:"cdek"
	}, {
		name:"Trackon Courier",
		code:"trackon"
	}, {
		name:"Yunda Express",
		code:"yunda"
	}, {
		name:"Netherland Post - PostNL",
		code:"postnl-3s"
	}, {
		name:"ADSOne",
		code:"adsone"
	}, {
		name:"Landmark Global",
		code:"landmark-global"
	}, {
		name:"The Courier Guy",
		code:"thecourierguy"
	}, {
		name:"SMSA Express",
		code:"smsa-express"
	}, {
		name:"Domestic SF Express",
		code:"sf-express"
	}, {
		name:"Cosmetics Now",
		code:"costmeticsnow"
	}, {
		name:"Buylogic",
		code:"buylogic"
	}, {
		name:"InPost Paczkomaty",
		code:"inpost-paczkomaty"
	}, {
		name:"StarTrack",
		code:"star-track"
	}, {
		name:"QFKD Express",
		code:"qfkd"
	}, {
		name:"JD Express",
		code:"jd"
	}, {
		name:"TTKD Express",
		code:"ttkd"
	}, {
		name:"DEPPON",
		code:"deppon"
	}, {
		name:"Cacesa Postal",
		code:"cacesapostal"
	}, {
		name:"Chukou1 Logistics",
		code:"chukou1"
	}, {
		name:"Arrow XL",
		code:"arrowxl"
	}, {
		name:"XDP Express",
		code:"xdp-uk"
	}, {
		name:"IMEX Global Solutions",
		code:"imexglobalsolutions"
	}, {
		name:"Easy Mail",
		code:"easy-mail"
	}, {
		name:"IDEX",
		code:"idexpress"
	}, {
		name:"RR Donnelley",
		code:"rrdonnelley"
	}, {
		name:"Con-way Freight",
		code:"con-way"
	}, {
		name:"Ninja Van Singapore",
		code:"ninjavan"
	}, {
		name:"Speedex Courier",
		code:"speedexcourier"
	}, {
		name:"Expeditors",
		code:"expeditors"
	}, {
		name:"SPSR",
		code:"spsr"
	}, {
		name:"Chronopost Portugal(DPD)",
		code:"chronopost-portugal"
	}, {
		name:"DWZ Express",
		code:"dwz"
	}, {
		name:"XpressBees",
		code:"xpressbees"
	}, {
		name:"Courier IT",
		code:"courier-it"
	}, {
		name:"Specialised Freight",
		code:"specialised-freight"
	}, {
		name:"UPS Mail Innovations",
		code:"ups-mi"
	}, {
		name:"DPE South Africa",
		code:"dpe-south-africa"
	}, {
		name:"Dawn Wing",
		code:"dawn-wing"
	}, {
		name:"Fastrak Services",
		code:"fastrak-services"
	}, {
		name:"Nova Poshta",
		code:"nova-poshta"
	}, {
		name:"UC Express",
		code:"uc-express"
	}, {
		name:"Takesend Logistics",
		code:"takesend"
	}, {
		name:"DHL Netherlands",
		code:"dhl-nl"
	}, {
		name:"Roadbull Logistics",
		code:"roadbull"
	}, {
		name:"DHL Benelux",
		code:"dhl-benelux"
	}, {
		name:"Tk Kit",
		code:"tk-kit"
	}, {
		name:"ABF Freight",
		code:"abf"
	}, {
		name:"Couriers Please express",
		code:"couriers-please"
	}, {
		name:"Cess",
		code:"cess"
	}, {
		name:"Best Express",
		code:"bestex"
	}, {
		name:"Gofly",
		code:"gofly"
	}, {
		name:"SINOAIR",
		code:"sinoair"
	}, {
		name:"Italy SDA",
		code:"italy-sda"
	}, {
		name:"T Cat",
		code:"t-cat"
	}, {
		name:"Fastgo",
		code:"fastgo"
	}, {
		name:"PCA",
		code:"pca"
	}, {
		name:"FTD Express",
		code:"ftd"
	}, {
		name:"Shipgce Express",
		code:"shipgce"
	}, {
		name:"Wise Express",
		code:"wise-express"
	}, {
		name:"Cnpex",
		code:"cnpex"
	}, {
		name:"1hcang",
		code:"1hcang"
	}, {
		name:"Sunyou",
		code:"sunyou"
	}, {
		name:"DHL Global Mail Asia",
		code:"dhlecommerce-asia"
	}, {
		name:"DHL Active Tracing",
		code:"dhl-active"
	}, {
		name:"TNT Reference",
		code:"tnt-reference"
	}, {
		name:"J-NET Express",
		code:"j-net"
	}, {
		name:"Jiayi Express",
		code:"jiayi56"
	}, {
		name:"Deltec Courier",
		code:"deltec-courier"
	}, {
		name:"Miuson Express",
		code:"miuson-international"
	}, {
		name:"Espeedpost",
		code:"espeedpost"
	}, {
		name:"Asendia HK",
		code:"asendia-hk"
	}, {
		name:"GATI Courier",
		code:"gaticn"
	}, {
		name:"DPEX China",
		code:"szdpex"
	}, {
		name:"TNT Click",
		code:"tnt-click"
	}, {
		name:"Rufengda",
		code:"rufengda"
	}, {
		name:"MailAmericas",
		code:"mailamericas"
	}, {
		name:"Far International Logistics",
		code:"far800"
	}, {
		name:"Winit",
		code:"winit"
	}, {
		name:"360zebra",
		code:"360zebra"
	}, {
		name:"Auexpress",
		code:"auexpress"
	}, {
		name:"Sure56",
		code:"sure56"
	}, {
		name:"KUAYUE EXPRESS",
		code:"kye"
	}, {
		name:"Fast Express",
		code:"kjkd"
	}, {
		name:"Fetchr",
		code:"fetchr"
	}, {
		name:"Flyway Express",
		code:"flywayex"
	}, {
		name:"China Russia56",
		code:"china-russia56"
	}, {
		name:"EFSPost",
		code:"efspost"
	}, {
		name:"Eyou800",
		code:"eyoupost"
	}, {
		name:"FD Express",
		code:"fd-express"
	}, {
		name:"ESHUN International Logistics",
		code:"zes-express"
	}, {
		name:"utec",
		code:"utec"
	}, {
		name:"XDEXPRESS",
		code:"xdexpress"
	}, {
		name:"venucia",
		code:"qichen"
	}, {
		name:"13ten",
		code:"13-ten"
	}, {
		name:"KWT Express",
		code:"kwt56"
	}, {
		name:"Wiseloads",
		code:"wiseloads"
	}, {
		name:"wnDirect",
		code:"wndirect"
	}, {
		name:"Eurodis",
		code:"eurodis"
	}, {
		name:"Matdespatch",
		code:"matdespatch"
	}, {
		name:"TNT Australia",
		code:"tnt-au"
	}, {
		name:"yakit",
		code:"yakit"
	}, {
		name:"TAQBIN Hong Kong",
		code:"taqbin-hk"
	}, {
		name:"UBon Express",
		code:"ubonex"
	}, {
		name:"EWS Profit Fields",
		code:"8dt"
	}, {
		name:"2U Express",
		code:"2uex"
	}, {
		name:"Ane Express",
		code:"ane66"
	}, {
		name:"Ausworld Express",
		code:"aus"
	}, {
		name:"EWE Global Express",
		code:"ewe"
	}, {
		name:"Huida Express",
		code:"huidaex"
	}, {
		name:"allekurier",
		code:"allekurier"
	}, {
		name:"Transrush",
		code:"transrush"
	}, {
		name:"Suteng Logistics",
		code:"ste56"
	}, {
		name:"QEXPRESS",
		code:"qexpress"
	}, {
		name:"Chinz Logistics",
		code:"chinz56"
	}, {
		name:"DPD(HK)",
		code:"dpd-hk"
	}, {
		name:"Zhongtie Logistics",
		code:"ztky"
	}, {
		name:"Dada logistic",
		code:"idada56"
	}, {
		name:"Jersey Post",
		code:"jersey-post"
	}, {
		name:"Ninja Van Malaysia",
		code:"ninjavan-my"
	}, {
		name:"Ninja Van Indonesia",
		code:"ninjaxpress"
	}, {
		name:"Ninja Van Philippines",
		code:"ninjavan-ph"
	}, {
		name:"Ninja Van Thailand",
		code:"ninjavan-th"
	}, {
		name:"Sai Cheng Logistics",
		code:"saicheng"
	}, {
		name:"8Europe",
		code:"8europe"
	}, {
		name:"A PLUS EXPRESS",
		code:"aplus100"
	}, {
		name:"SYD Express",
		code:"suyd56"
	}, {
		name:"OCS Express",
		code:"ocschina"
	}, {
		name:"Naqel",
		code:"naqel"
	}, {
		name:"BSI express",
		code:"bsi"
	}, {
		name:"Jayeek",
		code:"jayeek"
	}, {
		name:"Blue Sky Express",
		code:"blueskyexpress"
	}, {
		name:"PosLaju",
		code:"poslaju"
	}, {
		name:"TAQBIN Malaysia",
		code:"taqbin-my"
	}, {
		name:"Ekart Logistics",
		code:"ekart"
	}, {
		name:"Shree Tirupati Courier",
		code:"shree-tirupati"
	}, {
		name:"Safexpress",
		code:"safexpress"
	}, {
		name:"IML Logistics",
		code:"imlb2c"
	}, {
		name:"HiveWMS",
		code:"hivewms"
	}, {
		name:"Usky",
		code:"uskyexpress"
	}, {
		name:"Ark express",
		code:"arkexpress"
	}, {
		name:"Winlink logistics",
		code:"winlink"
	}, {
		name:"xpresspost",
		code:"xpresspost"
	}, {
		name:"ePacket",
		code:"epacket"
	}, {
		name:"DTDC Plus",
		code:"dtdc-plus"
	}, {
		name:"Fedex Freight",
		code:"fedex-freight"
	}, {
		name:"FedEx Ground",
		code:"fedex-ground"
	}, {
		name:"DHL Hong Kong",
		code:"dhl-hong-kong"
	}, {
		name:"T Force (UPS Freight)",
		code:"ups-freight"
	}, {
		name:"UPS Ground",
		code:"ups-ground"
	}, {
		name:"Auspost",
		code:"auspost"
	}, {
		name:"SGT Express",
		code:"sgtwl"
	}, {
		name:"COE",
		code:"coe"
	}, {
		name:"LHT Express",
		code:"lhtex"
	}, {
		name:"Wanb Express",
		code:"wanbexpress"
	}, {
		name:"SprintPack",
		code:"sprintpack"
	}, {
		name:"Kawa",
		code:"kawa"
	}, {
		name:"Speed Post",
		code:"speed-post"
	}, {
		name:"IEPost",
		code:"iepost"
	}, {
		name:"Alljoy",
		code:"alljoy"
	}, {
		name:"SX-Express",
		code:"sxexpress"
	}, {
		name:"DEX-I",
		code:"dex-i"
	}, {
		name:"WEL",
		code:"logistics"
	}, {
		name:"Un-line",
		code:"un-line"
	}, {
		name:"BAB international",
		code:"bab-ru"
	}, {
		name:"CNILINK",
		code:"cnilink"
	}, {
		name:"HKD",
		code:"hkdexpress"
	}, {
		name:"Showl",
		code:"showl"
	}, {
		name:"Sendle",
		code:"sendle"
	}, {
		name:"Bombino Express",
		code:"bombino-express"
	}, {
		name:"Whistl",
		code:"whistl"
	}, {
		name:"DX Delivery",
		code:"dxdelivery"
	}, {
		name:"Hui Logistics",
		code:"huilogistics"
	}, {
		name:"SuperOZ Logistics",
		code:"superoz"
	}, {
		name:"Leopards Express",
		code:"leopardschina"
	}, {
		name:"Overseas Logistics",
		code:"overseas-logistics"
	}, {
		name:"Better Express",
		code:"cbtsd"
	}, {
		name:"Linex",
		code:"linexsolutions"
	}, {
		name:"Airwings Courier Express India",
		code:"airwings-india"
	}, {
		name:"The Professional Couriers (TPC)",
		code:"professional-couriers"
	}, {
		name:"ASM (GLS ES)",
		code:"asmred"
	}, {
		name:"Mondial Relay",
		code:"mondialrelay"
	}, {
		name:"LJS",
		code:"bt-exp"
	}, {
		name:"AsiaFly",
		code:"asiafly"
	}, {
		name:"Flying Leopards Express",
		code:"njfeibao"
	}, {
		name:"First Flight Couriers",
		code:"firstflightme"
	}, {
		name:"JET Express",
		code:"jet"
	}, {
		name:"360lion Express",
		code:"360lion"
	}, {
		name:"HCT Express",
		code:"hct"
	}, {
		name:"LDXpress",
		code:"ldxpress"
	}, {
		name:"CJ Logistics",
		code:"doortodoor"
	}, {
		name:"K1 Express",
		code:"kuajingyihao"
	}, {
		name:"7-ELEVEN",
		code:"qi-eleven"
	}, {
		name:"ORANGE CONNEX",
		code:"orangeconnex"
	}, {
		name:"JS EXPRESS",
		code:"js-exp"
	}, {
		name:"Gao Post",
		code:"gaopost"
	}, {
		name:"DB Schenker",
		code:"dbschenker"
	}, {
		name:"UK Mail",
		code:"ukmail"
	}, {
		name:"Palletways",
		code:"palletways"
	}, {
		name:"Eshipping Gateway",
		code:"yht"
	}, {
		name:"MyIB",
		code:"myib"
	}, {
		name:"Fulfillmen",
		code:"fulfillmen"
	}, {
		name:"CEVA Logistics",
		code:"ceva-logistics"
	}, {
		name:"UBX Express",
		code:"ubx-uk"
	}, {
		name:"Shree Mahabali Express",
		code:"shree-mahabali-express"
	}, {
		name:"YDH",
		code:"ydhex"
	}, {
		name:"QuicKway",
		code:"quickway"
	}, {
		name:"YL express",
		code:"yunlu"
	}, {
		name:"sfwl",
		code:"sfwl"
	}, {
		name:"Kerry Express VN",
		code:"kerryexpress"
	}, {
		name:"GEL Express",
		code:"gel-express"
	}, {
		name:"Buffalo",
		code:"buffaloex"
	}, {
		name:"LD Logistics",
		code:"ldlog"
	}, {
		name:"XPOST",
		code:"xpost"
	}, {
		name:"GmbH",
		code:"myaustrianpost"
	}, {
		name:"Cosex",
		code:"cosex"
	}, {
		name:"Hong Tai",
		code:"ht56"
	}, {
		name:"E-lian",
		code:"elianpost"
	}, {
		name:"Bao Tongda Freight Forwarding",
		code:"btd56"
	}, {
		name:"Shree Maruti Courier",
		code:"shreemaruticourier"
	}, {
		name:"BQC",
		code:"bqc"
	}, {
		name:"Hnfywl",
		code:"hnfywl"
	}, {
		name:"Kerry Tec",
		code:"kerry-tec"
	}, {
		name:"BEL",
		code:"8256ru"
	}, {
		name:"CXC",
		code:"cxc"
	}, {
		name:"Airfex",
		code:"airfex"
	}, {
		name:"King Kong Express",
		code:"kke"
	}, {
		name:"Best Express(logistic)",
		code:"800best"
	}, {
		name:"YJI",
		code:"yji"
	}, {
		name:"SpeedPAK",
		code:"speedpak"
	}, {
		name:"Zajil",
		code:"zajil"
	}, {
		name:"Dekun",
		code:"dekun"
	}, {
		name:"YMDD",
		code:"yimidida"
	}, {
		name:"ECPOST",
		code:"ecpost"
	}, {
		name:"CRE",
		code:"cre"
	}, {
		name:"Famiport",
		code:"famiport"
	}, {
		name:"Taiwan Pelican Express",
		code:"e-can"
	}, {
		name:"Meest Express",
		code:"meest"
	}, {
		name:"Boxc Logistics",
		code:"boxc"
	}, {
		name:"Ltian",
		code:"ltian"
	}, {
		name:"SJTSZ Express",
		code:"sjtsz"
	}, {
		name:"ComOne Express",
		code:"com1express"
	}, {
		name:"MC Express",
		code:"md-express"
	}, {
		name:"Grand Slam Express",
		code:"grandslamexpress"
	}, {
		name:"LiBang International Logistics",
		code:"lbexps"
	}, {
		name:"eTotal",
		code:"etotal"
	}, {
		name:"hound",
		code:"hound"
	}, {
		name:"UEQ",
		code:"ueq"
	}, {
		name:"Sum Xpress",
		code:"sumxpress"
	}, {
		name:"eParcel Korea",
		code:"eparcel-kr"
	}, {
		name:"SUNING",
		code:"suning"
	}, {
		name:"DPD Germany",
		code:"dpd-de"
	}, {
		name:"Hanxuan international express",
		code:"hxgj56"
	}, {
		name:"KJY Logistics",
		code:"kjy"
	}, {
		name:"Euasia Express",
		code:"euasia"
	}, {
		name:"1DL Express",
		code:"1dlexpress"
	}, {
		name:"UVAN Express",
		code:"uvan"
	}, {
		name:"Nippon Express",
		code:"nippon"
	}, {
		name:"Ninja Van Vietnam",
		code:"ninjavan-vn"
	}, {
		name:"Sagawa Global",
		code:"sagawa-global"
	}, {
		name:"Szendex",
		code:"szendex"
	}, {
		name:"Spoton Logistics",
		code:"spoton"
	}, {
		name:"Dachser",
		code:"dachser"
	}, {
		name:"TopYou",
		code:"topyou"
	}, {
		name:"SAP Express",
		code:"sap-express"
	}, {
		name:"WSE Logistics",
		code:"gdwse"
	}, {
		name:"KINGRUNS",
		code:"kingruns"
	}, {
		name:"YingNuo Supply Chain",
		code:"szyn"
	}, {
		name:"Redpack Mexico",
		code:"redpack-mexico"
	}, {
		name:"Beebird Logistics",
		code:"beebird"
	}, {
		name:"Royal Shipments",
		code:"royal-shipments"
	}, {
		name:"Amazon Logistics",
		code:"amazon"
	}, {
		name:"Evri(Hermes UK)",
		code:"hermes-uk"
	}, {
		name:"Geodis",
		code:"geodis"
	}, {
		name:"CJ Packet",
		code:"cj-dropshipping"
	}, {
		name:"17Feia Express",
		code:"17feia"
	}, {
		name:"DHL Global Forwarding",
		code:"dhl-global-logistics"
	}, {
		name:"Aprche",
		code:"aprche"
	}, {
		name:"Yong Man Yi",
		code:"ymy"
	}, {
		name:"Pony Express",
		code:"pony-express"
	}, {
		name:"Hi Life",
		code:"hi-life"
	}, {
		name:"Ltexp",
		code:"ltexp"
	}, {
		name:"Ledii",
		code:"ledii"
	}, {
		name:"Top Ideal Express",
		code:"zhuozhi"
	}, {
		name:"OCS Worldwide",
		code:"ocs-worldwide"
	}, {
		name:"Estafeta USA",
		code:"estafetausa"
	}, {
		name:"Art Logexpress",
		code:"artlogexpress"
	}, {
		name:"Trending Times",
		code:"deltafille"
	}, {
		name:"DD Express",
		code:"ddexpress"
	}, {
		name:"DPD Romania",
		code:"dpd-ro"
	}, {
		name:"RRS Logistics",
		code:"rrs"
	}, {
		name:"Saia LTL Freight",
		code:"saia-freight"
	}, {
		name:"Antron Express",
		code:"168express"
	}, {
		name:"Correos Express",
		code:"correosexpress"
	}, {
		name:"FAST BEE",
		code:"fbb"
	}, {
		name:"ELTA Courier",
		code:"elta-courier-gr"
	}, {
		name:"TIPSA",
		code:"tip-sa"
	}, {
		name:"AnserX",
		code:"anserx"
	}, {
		name:"CHOICE Logistics",
		code:"choice"
	}, {
		name:"JD Logistics",
		code:"jd-logistics"
	}, {
		name:"Line Clear Express & Logistics",
		code:"line-clear"
	}, {
		name:"Asendia",
		code:"asendia"
	}, {
		name:"Espost",
		code:"espost"
	}, {
		name:"Echindia",
		code:"global-routers"
	}, {
		name:"iMile",
		code:"imile"
	}, {
		name:"CSD Express",
		code:"csd"
	}, {
		name:"COSCO eGlobal",
		code:"cosco"
	}, {
		name:"Spee-Dee Delivery",
		code:"speedee"
	}, {
		name:"LP Express",
		code:"lpexpress"
	}, {
		name:"Venipak",
		code:"venipak"
	}, {
		name:"Smartcat",
		code:"smartcat"
	}, {
		name:"Pitney Bowes",
		code:"pitneybowes"
	}, {
		name:"DPD Belgium",
		code:"dpd-be"
	}, {
		name:"V-Xpress",
		code:"v-xpress"
	}, {
		name:"DHL Parcel UK",
		code:"dhl-uk"
	}, {
		name:"TONGDA Global",
		code:"tarrive"
	}, {
		name:"Lexship",
		code:"lexship"
	}, {
		name:"OrangeDS",
		code:"orangeds"
	}, {
		name:"Jadlog Brazil",
		code:"dpd-brazil"
	}, {
		name:"ChangJiang Express",
		code:"changjiangexpress"
	}, {
		name:"CSE",
		code:"cse"
	}, {
		name:"FirstMile",
		code:"firstmile"
	}, {
		name:"Dellin",
		code:"dellin"
	}, {
		name:"Bluecare Express",
		code:"bluecare"
	}, {
		name:"intelcom",
		code:"intelcom"
	}, {
		name:"JT Express TH",
		code:"jt-express-th"
	}, {
		name:"ESNAD Express",
		code:"esnad"
	}, {
		name:"XingYunYi",
		code:"xingyunyi"
	}, {
		name:"TNT LT",
		code:"tnt-lt"
	}, {
		name:"GLS PL",
		code:"gls-pl"
	}, {
		name:"PostaPlus",
		code:"postaplus"
	}, {
		name:"1SD",
		code:"1shida"
	}, {
		name:"VNCPost",
		code:"vncpost"
	}, {
		name:"ZTO International",
		code:"zto-international"
	}, {
		name:"Spring GDS",
		code:"spring-gds"
	}, {
		name:"TCS Express",
		code:"tcs-express"
	}, {
		name:"VOVA Logistics",
		code:"vova-logistics"
	}, {
		name:"JT Express VN",
		code:"jt-express"
	}, {
		name:"Global Leader",
		code:"global-leader"
	}, {
		name:"CTT Express",
		code:"ctt-express"
	}, {
		name:"GLS Netherland",
		code:"gls-nl"
	}, {
		name:"We World Express",
		code:"weworld-express"
	}, {
		name:"SPX VN",
		code:"spx-vn"
	}, {
		name:"SPX MY",
		code:"spx-my"
	}, {
		name:"JINDOUYUN Logistics",
		code:"jdy"
	}, {
		name:"ZHONGSU International",
		code:"zhongsu"
	}, {
		name:"UK Asendia",
		code:"uktracking-asendia"
	}, {
		name:"Asendia UK Premium",
		code:"asendia-wmp"
	}, {
		name:"Fastway South Africa",
		code:"fastway-za"
	}, {
		name:"Weaship",
		code:"weaship"
	}, {
		name:"GTI",
		code:"gti"
	}, {
		name:"Parcel Freight Logistics",
		code:"pflogistics"
	}, {
		name:"Exelot",
		code:"exelot"
	}, {
		name:"JT Express CN",
		code:"jtexpress"
	}, {
		name:"Sailpost",
		code:"sailpost"
	}, {
		name:"Asyad Express",
		code:"asyad"
	}, {
		name:"mz56",
		code:"mz56"
	}, {
		name:"Janio Asia",
		code:"janio"
	}, {
		name:"Kerry Express TH",
		code:"kerryexpress-th"
	}, {
		name:"Border Express",
		code:"border-express"
	}, {
		name:"TT Sucha",
		code:"twth"
	}, {
		name:"Kerry eCommerce",
		code:"kerry-ecommerce"
	}, {
		name:"NZCouriers",
		code:"nzcouriers"
	}, {
		name:"Hermes Borderguru",
		code:"hermes-borderguru"
	}, {
		name:"Shipa",
		code:"shipa"
	}, {
		name:"Post Haste",
		code:"posthaste"
	}, {
		name:"Flash Express",
		code:"flashexpress"
	}, {
		name:"SCG Express",
		code:"scg-express"
	}, {
		name:"GLS Spain",
		code:"gls-es"
	}, {
		name:"FBA UK Swiship",
		code:"swiship-uk"
	}, {
		name:"FBA USA Swiship",
		code:"swiship-usa"
	}, {
		name:"CGS Express",
		code:"cgs-express"
	}, {
		name:"Comet Hellas",
		code:"cometcourier"
	}, {
		name:"Day & Ross",
		code:"dayross"
	}, {
		name:"TForce Final Mile",
		code:"tforce"
	}, {
		name:"JT Express PH",
		code:"jtexpress-ph"
	}, {
		name:"CND Express",
		code:"cndexpress"
	}, {
		name:"JoeyCo",
		code:"joeyco"
	}, {
		name:"Packeta",
		code:"packeta"
	}, {
		name:"Paquet Express",
		code:"paquet"
	}, {
		name:"GOGO Xpress",
		code:"gogo-xpress"
	}, {
		name:"etower",
		code:"etower"
	}, {
		name:"YiYuan",
		code:"yiyuan"
	}, {
		name:"BEST Express (Malaysia)",
		code:"best-my"
	}, {
		name:"Cubyn",
		code:"cubyn"
	}, {
		name:"anxl",
		code:"anxl"
	}, {
		name:"Hlihang Express",
		code:"hlihang-express"
	}, {
		name:"Zeleris",
		code:"zeleris"
	}, {
		name:"DAO365",
		code:"dao365"
	}, {
		name:"Estafeta",
		code:"estafeta"
	}, {
		name:"Pushpak Courier",
		code:"pushpak-courier"
	}, {
		name:"Shree Nandan Courier",
		code:"shree-nandan"
	}, {
		name:"Madhur Couriers",
		code:"madhur-couriers"
	}, {
		name:"Bombax",
		code:"bombax"
	}, {
		name:"Shadowfax",
		code:"shadowfax"
	}, {
		name:"International EMS",
		code:"ems-post"
	}, {
		name:"Star Global",
		code:"starglobal"
	}, {
		name:"OSM Worldwide",
		code:"osmworldwide"
	}, {
		name:"Chit Chats",
		code:"chitchats"
	}, {
		name:"TCI Express",
		code:"tci"
	}, {
		name:"DPD Russia",
		code:"dpd-ru"
	}, {
		name:"GLS US",
		code:"gls-us"
	}, {
		name:"FUJIE Express",
		code:"fujexp"
	}, {
		name:"Express One",
		code:"expressone"
	}, {
		name:"CARIBOU",
		code:"caribou"
	}, {
		name:"SKY Postal",
		code:"sky-postal"
	}, {
		name:"Delnext",
		code:"delnext"
	}, {
		name:"Mainfreight",
		code:"mainfreight"
	}, {
		name:"eFMX",
		code:"fmx"
	}, {
		name:"Huanshid",
		code:"huanshid"
	}, {
		name:"SEINO(西濃運輸)",
		code:"seino"
	}, {
		name:"PPL CZ",
		code:"ppl-cz"
	}, {
		name:"JT Express SG",
		code:"jt-express-sg"
	}, {
		name:"Tracknator",
		code:"tracknator"
	}, {
		name:"ECMS Express",
		code:"ecms"
	}, {
		name:"CDEK Turkey",
		code:"cdek-tr"
	}, {
		name:"collivery",
		code:"collivery"
	}, {
		name:"99minutos",
		code:"99minutos"
	}, {
		name:"SPX PH",
		code:"spx-ph"
	}, {
		name:"Atlantic International Express",
		code:"atlantic"
	}, {
		name:"Maxway Logistics",
		code:"maxway"
	}, {
		name:"Comet Hellas",
		code:"comethellas"
	}, {
		name:"JT Express MY",
		code:"jtexpress-my"
	}, {
		name:"XYL 816Kapro",
		code:"816kf"
	}, {
		name:"Easy Ship",
		code:"easyship"
	}, {
		name:"Post One",
		code:"postone"
	}, {
		name:"Bee Express",
		code:"bee"
	}, {
		name:"FBA ES Swiship",
		code:"swiship-es"
	}, {
		name:"YuTeng Worldwide",
		code:"yuteng"
	}, {
		name:"Loomis Express",
		code:"loomis"
	}, {
		name:"SPX ID",
		code:"spx-id"
	}, {
		name:"JUXI EXPRESS",
		code:"juxiex"
	}, {
		name:"ShipEntegra",
		code:"shipentegra"
	}, {
		name:"cititrans",
		code:"cititrans"
	}, {
		name:"IN Amazon Shipping",
		code:"amazon-in"
	}, {
		name:"UK Amazon Shipping",
		code:"amazon-uk"
	}, {
		name:"AVERITT Express",
		code:"averittexpress"
	}, {
		name:"urvaam",
		code:"urvaam"
	}, {
		name:"LM Parcel",
		code:"lmparcel"
	}, {
		name:"Pago Logistics",
		code:"szpago"
	}, {
		name:"Bona",
		code:"bnexp"
	}, {
		name:"Sunnyway",
		code:"isunnyway"
	}, {
		name:"Sky Express",
		code:"skyex"
	}, {
		name:"Smart Delivery",
		code:"smart-delivery"
	}, {
		name:"madrooex",
		code:"madrooex"
	}, {
		name:"Tianzheng International Freight",
		code:"tzgjwl"
	}, {
		name:"STONE3PL",
		code:"stone3pl"
	}, {
		name:"3JMS Logistics",
		code:"3jmslogistics"
	}, {
		name:"ECOSCOOTING",
		code:"ecoscooting"
	}, {
		name:"Amsma Group",
		code:"amsma"
	}, {
		name:"UAB Nėgė",
		code:"nege-it"
	}, {
		name:"Early Bird",
		code:"earlybird"
	}, {
		name:"Dicom",
		code:"dicom"
	}, {
		name:"Geis CZ",
		code:"geis-cz"
	}, {
		name:"FBA IT Swiship",
		code:"swiship-it"
	}, {
		name:"fietskoeriers",
		code:"fietskoeriers"
	}, {
		name:"Flow Commerce",
		code:"flow-io"
	}, {
		name:"auodexpress",
		code:"auodexpress"
	}, {
		name:"maxeedexpress",
		code:"maxeedexpress"
	}, {
		name:"ees-logistics",
		code:"ees-logistics"
	}, {
		name:"Allied Express",
		code:"alliedexpress"
	}, {
		name:"JIUZHOU Logistics",
		code:"szjiuz"
	}, {
		name:"zjcy56",
		code:"zjcy56"
	}, {
		name:"baoxianda",
		code:"baoxianda"
	}, {
		name:"The Lorry",
		code:"thelorry"
	}, {
		name:"Cargo International",
		code:"cargointl-de"
	}, {
		name:"Best Express (TH)",
		code:"best-th"
	}, {
		name:"decnlh",
		code:"decnlh"
	}, {
		name:"bluex",
		code:"bluex"
	}, {
		name:"dfglobalex",
		code:"dfglobalex"
	}, {
		name:"Southeastern Freightlines",
		code:"se-freightlines"
	}, {
		name:"Happy Post",
		code:"happy-post"
	}, {
		name:"Zip Philippines",
		code:"zip-ph"
	}, {
		name:"Raben Group",
		code:"raben-group"
	}, {
		name:"Morning Express",
		code:"morning"
	}, {
		name:"U-Speed Express",
		code:"u-speedex"
	}, {
		name:"Alliance Air Freight & Logistics",
		code:"alliance"
	}, {
		name:"UniUni",
		code:"uni"
	}, {
		name:"Boxberry",
		code:"boxberry"
	}, {
		name:"joomlogistics",
		code:"joomlogistics"
	}, {
		name:"Zinc",
		code:"zinc"
	}, {
		name:"fafalux",
		code:"fafalux"
	}, {
		name:"jne",
		code:"jne"
	}, {
		name:"fgmailconnect",
		code:"fgmailconnect"
	}, {
		name:"FBA DE Swiship",
		code:"swiship-de"
	}, {
		name:"Lone Star Overnight",
		code:"lso"
	}, {
		name:"Mail Boxed Etc",
		code:"mbe"
	}, {
		name:"FBA CA Swiship",
		code:"swiship-ca"
	}, {
		name:"FBA FR Swiship",
		code:"swiship-fr"
	}, {
		name:"FBA AU Swiship",
		code:"swiship-au"
	}, {
		name:"FBA JP Swiship",
		code:"swiship-jp"
	}, {
		name:"United Delivery Services",
		code:"uniteddeliveryservice"
	}, {
		name:"mircoexpress",
		code:"mircoexpress"
	}, {
		name:"fourseasonsfly",
		code:"fourseasonsfly"
	}, {
		name:"Skynet South Africa",
		code:"skynet-za"
	}, {
		name:"TD Express",
		code:"topdser"
	}, {
		name:"EnvFast",
		code:"envfast"
	}, {
		name:"cdl",
		code:"cdl"
	}, {
		name:"nextsmartship",
		code:"nextsmartship"
	}, {
		name:"cargus",
		code:"cargus"
	}, {
		name:"sameday",
		code:"sameday"
	}, {
		name:"Wyngs",
		code:"wyngs"
	}, {
		name:"Kintetsu World Express",
		code:"kwe"
	}, {
		name:"Stallion Express",
		code:"stallionexpress"
	}, {
		name:"Janco Ecommerce",
		code:"janco"
	}, {
		name:"Courant",
		code:"courant-plus"
	}, {
		name:"Mylerz",
		code:"mylerz"
	}, {
		name:"SDK Express",
		code:"sdk-express"
	}, {
		name:"Pressiode",
		code:"pressiode"
	}, {
		name:"jtexpress-vn",
		code:"jtexpress-vn"
	}, {
		name:"Pan-Asia International",
		code:"pan-asia"
	}, {
		name:"World Express",
		code:"world-express"
	}, {
		name:"OCS India",
		code:"ocs"
	}, {
		name:"NOX Night Time Express",
		code:"nox-nighttimeexpress"
	}, {
		name:"HuanTong Express",
		code:"htkjwl"
	}, {
		name:"Legion Express",
		code:"legionexp"
	}, {
		name:"Qwintry Logistics",
		code:"qwintry"
	}, {
		name:"Roadrunner Freight",
		code:"rrts"
	}, {
		name:"Correo Uruguayo",
		code:"correo-uy"
	}, {
		name:"Goglobal Post",
		code:"goglobalpost"
	}, {
		name:"Logisters",
		code:"logisters"
	}, {
		name:"Thabit Logistics",
		code:"thabit-logistics"
	}, {
		name:"e-Commerce KZ",
		code:"e-commercekz"
	}, {
		name:"Ship It Asia",
		code:"ship-it-asia"
	}, {
		name:"Step Forward Freight",
		code:"stepforwardfs"
	}, {
		name:"Pickrr",
		code:"pickrr"
	}, {
		name:"ASE",
		code:"ase"
	}, {
		name:"Pickupp",
		code:"pickupp-mys"
	}, {
		name:"Bring",
		code:"bring"
	}, {
		name:"Lineclear Express",
		code:"lineclearexpress"
	}, {
		name:"Colicoli",
		code:"colicoli"
	}, {
		name:"DG Transporte",
		code:"dg-transporte"
	}, {
		name:"Kuehne Nagel",
		code:"kuehne"
	}, {
		name:"Danske Fragtmænd",
		code:"fragt"
	}, {
		name:"CJ Logistics Global",
		code:"cjlogistics"
	}, {
		name:"BH Posta",
		code:"bh-posta"
	}, {
		name:"Sicepat Ekspres",
		code:"sicepat"
	}, {
		name:"Asigna ES",
		code:"asigna-es"
	}, {
		name:"Lonestar",
		code:"lonestar"
	}, {
		name:"HR Parcel",
		code:"hrparcel"
	}, {
		name:"Celeritas Transporte",
		code:"celeritastransporte"
	}, {
		name:"Smooth Parcel",
		code:"smooth"
	}, {
		name:"Kurasi",
		code:"kurasi"
	}, {
		name:"Clevy Links",
		code:"clevy-links"
	}, {
		name:"Wizmo",
		code:"wizmo"
	}, {
		name:"Pitt Ohio",
		code:"pittohio"
	}, {
		name:"EFS Asia",
		code:"efs"
	}, {
		name:"Neway",
		code:"neway"
	}, {
		name:"NT Logistics VN",
		code:"ntlogistics-vn"
	}, {
		name:"Ram",
		code:"ram"
	}, {
		name:"CTC Express",
		code:"ctc-express"
	}, {
		name:"Kerry TJ Logistics",
		code:"kerrytj"
	}, {
		name:"XPO Logistics",
		code:"xpoweb"
	}, {
		name:"AAA Cooper Transportation",
		code:"aaacooper"
	}, {
		name:"Mxpress",
		code:"m-xpress"
	}, {
		name:"skybox",
		code:"skybox"
	}, {
		name:"Freightquote",
		code:"freightquote"
	}, {
		name:"Anicam Box Express",
		code:"anicamboxexpress"
	}, {
		name:"Pickupp",
		code:"pickupp"
	}, {
		name:"LICCARDI",
		code:"liccardi-express"
	}, {
		name:"SY Express",
		code:"chengfeng"
	}, {
		name:"Interparcel Au",
		code:"interparcel-au"
	}, {
		name:"Interparcel Uk",
		code:"interparcel-uk"
	}, {
		name:"Intexpress",
		code:"intexpress"
	}, {
		name:"QuikenMx",
		code:"quikenmx"
	}, {
		name:"ProMed Deliversy",
		code:"promeddelivery"
	}, {
		name:"XDE Logistics",
		code:"xde"
	}, {
		name:"Coordinadora",
		code:"coordinadora"
	}, {
		name:"Hellmann",
		code:"hellmann"
	}, {
		name:"eRetail Logistics",
		code:"eretail"
	}, {
		name:"Pass The Parcel",
		code:"passtheparcel"
	}, {
		name:"Parcelport",
		code:"payport"
	}, {
		name:"ANNTO",
		code:"annto"
	}, {
		name:"HuiSenKy",
		code:"huisenky"
	}, {
		name:"Anteraja",
		code:"anteraja"
	}, {
		name:"GTTEXPRESS",
		code:"gttexpress"
	}, {
		name:"AdaPost",
		code:"ada-post"
	}, {
		name:"COMPASS EXPRESS",
		code:"comexpress"
	}, {
		name:"ETEEN",
		code:"eteenlog"
	}, {
		name:"Crazy Express",
		code:"crazyexpress"
	}, {
		name:"Sca Express",
		code:"scaexpress"
	}, {
		name:"King Freight",
		code:"kingfreight"
	}, {
		name:"ChinaStarLogistics",
		code:"chinastarlogistics"
	}, {
		name:"Royal International",
		code:"royal-international"
	}, {
		name:"HuiLin56",
		code:"huilin56"
	}, {
		name:"Jetstarexp",
		code:"jetstarexp"
	}, {
		name:"GIANT EXPRESS",
		code:"giantpost"
	}, {
		name:"Ybd Express",
		code:"ybdexpress"
	}, {
		name:"Jieborne",
		code:"jieborne"
	}, {
		name:"JDIEX",
		code:"jdiex"
	}, {
		name:"JD-168",
		code:"jd-168"
	}, {
		name:"Jcsuda",
		code:"jcsuda"
	}, {
		name:"Jumstc",
		code:"jumstc"
	}, {
		name:"Kaha Express",
		code:"kahaexpress"
	}, {
		name:"TAScourier",
		code:"tascourier"
	}, {
		name:"Szuem",
		code:"szuem"
	}, {
		name:"Janco Express",
		code:"jancoexpress"
	}, {
		name:"LingSong",
		code:"lingsong"
	}, {
		name:"LuBang56",
		code:"lubang56"
	}, {
		name:"MM-logi",
		code:"mm-logi"
	}, {
		name:"Tmw Express",
		code:"tmw-express"
	}, {
		name:"Mhsy88",
		code:"mhsy88"
	}, {
		name:"Padtf",
		code:"padtf"
	}, {
		name:"Renrenex",
		code:"renrenex"
	}, {
		name:"Sja56",
		code:"sja56"
	}, {
		name:"Superb Express",
		code:"superb-express"
	}, {
		name:"Sdto",
		code:"sdto"
	}, {
		name:"Usasd",
		code:"usasd"
	}, {
		name:"Bf-Lg",
		code:"bf-lg"
	}, {
		name:"XF-lt56",
		code:"xf-lt56"
	}, {
		name:"Ssd",
		code:"ssd"
	}, {
		name:"Jetlogistic",
		code:"jetlogistic"
	}, {
		name:"Sendex",
		code:"sendex"
	}, {
		name:"Trackyourparcel",
		code:"trackyourparcel"
	}, {
		name:"Pitneybowes1",
		code:"pitneybowes1"
	}, {
		name:"Luben",
		code:"luben"
	}, {
		name:"Driverfastgo",
		code:"driverfastgo"
	}, {
		name:"BIRD SYSTEM LTD",
		code:"birdsystem"
	}, {
		name:"DPD Austria",
		code:"mydpd"
	}, {
		name:"CHT",
		code:"cht361"
	}, {
		name:"FLYSMAN",
		code:"flysman"
	}, {
		name:"BAI LE JIE TONG",
		code:"bljt56"
	}, {
		name:"HFD",
		code:"hfd"
	}, {
		name:"Better Trucks",
		code:"bettertrucks"
	}, {
		name:"Taimek",
		code:"taimek"
	}, {
		name:"Tstexp",
		code:"tstexp"
	}, {
		name:"Tzky",
		code:"tzky"
	}, {
		name:"Taoplus",
		code:"taoplus"
	}, {
		name:"Taijin-logistics",
		code:"taijin-logistics"
	}, {
		name:"Ttkeurope",
		code:"ttkeurope"
	}, {
		name:"Express Courier",
		code:"expresscourierintl"
	}, {
		name:"Timelytitan",
		code:"timelytitan"
	}, {
		name:"Omni2",
		code:"omni2"
	}, {
		name:"Igcaexpress",
		code:"igcaexpress"
	}, {
		name:"Qhxyyg",
		code:"qhxyyg"
	}, {
		name:"Yadex",
		code:"yadex"
	}, {
		name:"Yjs-China",
		code:"yjs-china"
	}, {
		name:"Aramex AU",
		code:"aramexau"
	}, {
		name:"Ecmsglobal",
		code:"ecmsglobal"
	}, {
		name:"Line-1 International Express",
		code:"line-1"
	}, {
		name:"Qexlogistics",
		code:"qexlogistics"
	}, {
		name:"DPD-FR",
		code:"dpd-fr"
	}, {
		name:"Ant Eparcel",
		code:"anteparcel"
	}, {
		name:"Superton",
		code:"super-ton"
	}, {
		name:"RedC",
		code:"redchains"
	}, {
		name:"CH EXPRESS",
		code:"hzchgj"
	}, {
		name:"Xinjie Logistics",
		code:"sunjex"
	}, {
		name:"Xlobo",
		code:"xlobo"
	}, {
		name:"JOYING BOX",
		code:"joying-box"
	}, {
		name:"SLICITY",
		code:"yz-ex"
	}, {
		name:"IML",
		code:"imlexpres"
	}, {
		name:"Yuema Express",
		code:"yue777"
	}, {
		name:"Yousheng International Express",
		code:"yoseus"
	}, {
		name:"BJYTSYWL",
		code:"bjytsywl"
	}, {
		name:"Monotetrad",
		code:"yidingmu"
	}, {
		name:"Yao Fei Kuai Di",
		code:"1fkd"
	}, {
		name:"Youhai International Express",
		code:"uhiexpress"
	}, {
		name:"Hanghangtong Logistics",
		code:"yhtlogistics"
	}, {
		name:"ACT logistic",
		code:"act-logistics"
	}, {
		name:"Citisprint",
		code:"citisprint"
	}, {
		name:"Postal State International",
		code:"youban"
	}, {
		name:"Cloud mail cross border Express",
		code:"hkems"
	}, {
		name:"Cjpacket",
		code:"cjpacket"
	}, {
		name:"FlashExpress PH",
		code:"flashexpress-ph"
	}, {
		name:"Yujietong",
		code:"yujtong"
	}, {
		name:"Yong Bang",
		code:"guangdongyongbang"
	}, {
		name:"Cosco Express",
		code:"zy100-express"
	}, {
		name:"DPD Portugal",
		code:"dpd-por"
	}, {
		name:"Tianyun International",
		code:"tianyun"
	}, {
		name:"Qiyue Logistics",
		code:"qiyue"
	}, {
		name:"AxleHire",
		code:"axlehire"
	}, {
		name:"Yi Long Exp",
		code:"ylexp"
	}, {
		name:"SKR InterNational",
		code:"skr56"
	}, {
		name:"China Railway Flying Leopard",
		code:"fb56"
	}, {
		name:"Zhigu special goods",
		code:"zhiguil"
	}, {
		name:"Zhongrong Tailong",
		code:"zrtl"
	}, {
		name:"Midway Express",
		code:"ztcce"
	}, {
		name:"iCumulus Global Express",
		code:"icumulus"
	}, {
		name:"Xun Tian International",
		code:"xtl"
	}, {
		name:"myKN",
		code:"mykn"
	}, {
		name:"South American Post",
		code:"southamericapost"
	}, {
		name:"Central Transit",
		code:"zhonghuanus"
	}, {
		name:"China Post E-commerce",
		code:"chinapost-cb"
	}, {
		name:"YFHEX LOGISTICS",
		code:"yfhex"
	}, {
		name:"Yue Xi Logistics",
		code:"yxilogistics"
	}, {
		name:"DIDADI LOGISTICS TECH",
		code:"didadi"
	}, {
		name:"CPEX",
		code:"cpex"
	}, {
		name:"ZhongLu Logistics",
		code:"zlwww"
	}, {
		name:"Speedaf Express",
		code:"speedaf"
	}, {
		name:"HJYT Express",
		code:"hjyt56"
	}, {
		name:"First Line",
		code:"firstline56"
	}, {
		name:"QLINYUN",
		code:"qlinyun"
	}, {
		name:"XiangDao Supply Chain",
		code:"gzxdgyl"
	}, {
		name:"LvSe International",
		code:"ntlsgj"
	}, {
		name:"ELITEBIO",
		code:"elitebio"
	}, {
		name:"QYEXP",
		code:"qyexp"
	}, {
		name:"CY Epxress",
		code:"cy-express"
	}, {
		name:"Yuan Hao",
		code:"mzlyuanhao"
	}, {
		name:"Hua Yu",
		code:"huayu"
	}, {
		name:"Ka Jie",
		code:"kajie"
	}, {
		name:"Yisu International Logistics",
		code:"geswl"
	}, {
		name:"SDT",
		code:"jssdt56"
	}, {
		name:"SXJD",
		code:"sxjdfreight"
	}, {
		name:"Go Express",
		code:"goex"
	}, {
		name:"Shang Qiao",
		code:"shangqiao56"
	}, {
		name:"Shun Chang International",
		code:"shunchangguoji"
	}, {
		name:"CPSZY",
		code:"cpszy"
	}, {
		name:"MEI TAI",
		code:"56net"
	}, {
		name:"VALUEWAY",
		code:"valueway"
	}, {
		name:"LD Express",
		code:"leda-express"
	}, {
		name:"JIACHEN INTERNATIONAL",
		code:"jiachenexpress"
	}, {
		name:"UNICON EXPRESS USA",
		code:"lhexpressus"
	}, {
		name:"Run Bai Internation",
		code:"runbail"
	}, {
		name:"FT Exprss",
		code:"101iex"
	}, {
		name:"La Huo Express",
		code:"lahuoex"
	}, {
		name:"LF Express",
		code:"lf-express"
	}, {
		name:"Hui Feng Logistics",
		code:"huif56"
	}, {
		name:"LONGCPS",
		code:"longcps"
	}, {
		name:"Canada Air Express",
		code:"air-gtc"
	}, {
		name:"Bridge",
		code:"bri-ems"
	}, {
		name:"Polar Express",
		code:"polarexpress"
	}, {
		name:"HD Express",
		code:"hdc-express"
	}, {
		name:"HJWL",
		code:"hjwl"
	}, {
		name:"HOTWMS",
		code:"hotwms"
	}, {
		name:"Austa Internation",
		code:"austa"
	}, {
		name:"King Delivery",
		code:"kuaidaexp"
	}, {
		name:"Zhi Teng Logistics",
		code:"zhiteng"
	}, {
		name:"AIRTRANS",
		code:"airtranscourier"
	}, {
		name:"AMSEGROUP",
		code:"amsegroup"
	}, {
		name:"Hua Xi",
		code:"huaxiexpress"
	}, {
		name:"Yide International Freight Forwarder",
		code:"ydexp"
	}, {
		name:"Guangzhou Onegoal International Logistics",
		code:"ogilogistic"
	}, {
		name:"Starken",
		code:"starken"
	}, {
		name:"The Courier Guy Co",
		code:"thecourierguy-co"
	}, {
		name:"KOMON EXPRESS",
		code:"komonexpress"
	}, {
		name:"Xin Shu Logistics",
		code:"xs-exp"
	}, {
		name:"EBO",
		code:"ebowxp"
	}, {
		name:"ZIM Logistics",
		code:"zim"
	}, {
		name:"Kaigenlogistics",
		code:"kaigenlogistics"
	}, {
		name:"Grupo ampm",
		code:"grupoampm"
	}, {
		name:"Elog Luxembourg",
		code:"elog-luxembourg"
	}, {
		name:"Setel Express",
		code:"setel"
	}, {
		name:"Smartr Logistics",
		code:"smartr"
	}, {
		name:"Holisol",
		code:"holisol"
	}, {
		name:"HHY Express",
		code:"hhyexpress"
	}, {
		name:"YunHui Express",
		code:"yunhui"
	}, {
		name:"Pidge",
		code:"pidge"
	}, {
		name:"Pargo",
		code:"pargo"
	}, {
		name:"Gotofreight",
		code:"gotofreight"
	}, {
		name:"Dhlink",
		code:"dhlink"
	}, {
		name:"Fedex FIMS",
		code:"fedex-fims"
	}, {
		name:"ZMC EXPRESS",
		code:"zmcexpress"
	}, {
		name:"ConnectCo",
		code:"connect-co"
	}, {
		name:"Pilot",
		code:"pilot"
	}, {
		name:"Fast Despatch Logistics",
		code:"fastdespatch"
	}, {
		name:"Maratrack",
		code:"maratrack"
	}, {
		name:"AM Home Delivery",
		code:"am-home-delivery"
	}, {
		name:"Solid Logistcs",
		code:"solidlogistics"
	}, {
		name:"Biz Courier",
		code:"biz-courier"
	}, {
		name:"Courier Center",
		code:"courier-center"
	}, {
		name:"Wanmeng",
		code:"wmycc"
	}, {
		name:"Angel",
		code:"angel"
	}, {
		name:"Emons",
		code:"emons"
	}, {
		name:"Norsk Global",
		code:"norsk"
	}, {
		name:"Worldwide Logistics",
		code:"worldwide-logistics"
	}, {
		name:"Morning Global",
		code:"morninglobal"
	}, {
		name:"blexpress",
		code:"blexpress"
	}, {
		name:"Shiprocket",
		code:"shiprocket"
	}, {
		name:"SDH Express",
		code:"sdhexpress"
	}, {
		name:"Quiqup",
		code:"quiqup"
	}, {
		name:"Jet Global Express",
		code:"jet-global"
	}, {
		name:"J&T Express(AE)",
		code:"jtexpress-ae"
	}, {
		name:"Hunter Express",
		code:"hunterexpress"
	}, {
		name:"PARCLL",
		code:"parcll"
	}, {
		name:"Crane Worldwide Logistics",
		code:"crane-etowertech"
	}, {
		name:"YYPOST",
		code:"yypost"
	}, {
		name:"Test Carrier",
		code:"test-carrier"
	}, {
		name:"JusdaSR",
		code:"jusdasr"
	}, {
		name:"Dora Gate",
		code:"doragate"
	}, {
		name:"HONGHAI SUPPLY CHAIN",
		code:"gzbtygj"}

]